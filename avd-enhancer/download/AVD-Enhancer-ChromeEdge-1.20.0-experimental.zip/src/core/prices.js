// Hourly pay-as-you-go VM prices from Microsoft's public Azure Retail Prices API (no sign-in; the only host besides Azure itself that the
// extension calls, and it is sent a VM size and a region, never a tenant, user or subscription). Used by the Size and cost report.
// The fetch is injected so the tests never touch the network. No Azure token is ever sent here (arm.js is the only code that holds tokens).

import { idleCostPerDay } from "./avd.js";

export const PRICES_HOST = "https://prices.azure.com";
const PRICE_TIMEOUT_MS = 10000;
/** The currencies Microsoft's price list answered in when each was tried (Microsoft does the conversion; nothing else is used). USD is the default. */
export const PRICE_CURRENCIES = ["USD", "AUD", "NZD", "GBP", "EUR", "CAD", "CHF", "DKK", "NOK", "SEK", "JPY", "KRW", "CNY", "TWD", "HKD", "SGD", "INR", "BRL", "MXN", "ZAR", "PLN", "CZK", "AED", "THB", "IDR", "MYR", "TRY", "ILS", "RUB"];
const VM_SIZE = /^[A-Za-z0-9_]{1,64}$/;
const REGION = /^[a-z0-9]{1,40}$/;

/** True only for the one kind of address this file ever asks: the price list's own host and path, over https, nothing else. */
export const isPriceUrl = (url) => String(url).startsWith(`${PRICES_HOST}/api/retail/prices?`);

/** The key a price is kept under: VM size and region, lower case ("standard_d2s_v5|australiaeast"). */
export const priceKey = (size, region) => `${String(size || "").toLowerCase()}|${String(region || "").toLowerCase()}`;

/** A currency code from the supported list (any case), or "" when it is not one. */
export const cleanCurrency = (code) => { const c = String(code || "").toUpperCase(); return PRICE_CURRENCIES.includes(c) ? c : ""; };

/** The lookup address for one VM size in one region, or "" when either does not look like a size or a region (nothing odd is put in the filter). */
export function priceUrl(size, region, currency = "USD") {
  const reg = String(region || "").toLowerCase();
  if (!VM_SIZE.test(size || "") || !REGION.test(reg) || !cleanCurrency(currency)) return "";
  const filter = `serviceName eq 'Virtual Machines' and priceType eq 'Consumption' and armSkuName eq '${size}' and armRegionName eq '${reg}'`;
  return `${PRICES_HOST}/api/retail/prices?currencyCode='${cleanCurrency(currency)}'&$filter=${encodeURIComponent(filter)}`;
}

/** The pay-as-you-go hourly price from the rows the API returned: not Spot, not Low Priority, not the Windows licence rate (AVD hosts bring a Microsoft 365 or
 *  Windows licence, so the plain compute rate is the one that applies), and in the currency asked for when one is given. 0 when no row fits. */
export function pickHourly(items, currency = "") {
  const row = (Array.isArray(items) ? items : []).find((i) => i && i.unitOfMeasure === "1 Hour" && Number(i.retailPrice) > 0 && (!currency || i.currencyCode === currency)
    && !/spot|low priority/i.test(`${i.skuName} ${i.meterName}`) && !/windows/i.test(`${i.productName} ${i.skuName}`));
  return row ? Number(row.retailPrice) : 0;
}

/** Looks up each { size, region } pair not already in `known`. Returns { prices: { key: hourly }, failed: [{ key, error }] }; a size the API has no price for is
 *  put in `failed` too. One pair failing never stops the others. currency: a code from PRICE_CURRENCIES. deps: { fetch } for tests only. */
export async function lookupPrices(pairs, known = {}, currency = "USD", deps = {}) {
  const doFetch = deps.fetch || ((...a) => fetch(...a));
  const prices = {}; const failed = []; const seen = new Set();
  for (const { size, region } of pairs) {
    const key = priceKey(size, region);
    if (seen.has(key) || key in known) continue;
    seen.add(key);
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), PRICE_TIMEOUT_MS);
    try {
      const url = priceUrl(size, region, currency);
      if (!url) throw new Error(`"${size}" in "${region}" does not look like a VM size and region, or the currency is not supported`);
      if (!isPriceUrl(url)) throw new Error("Blocked a request to an address that is not the Azure price list");
      const res = await doFetch(url, { signal: ctl.signal });
      if (!res.ok) throw new Error(`Azure Retail Prices answered ${res.status}`);
      const hourly = pickHourly((await res.json()).Items, currency);
      if (!hourly) throw new Error(`no pay-as-you-go price found in ${currency}`);
      prices[key] = hourly;
    } catch (e) { failed.push({ key, error: e?.name === "AbortError" ? "Azure Retail Prices did not answer in time" : e?.message || String(e) }); }
    finally { clearTimeout(timer); }
  }
  return { prices, failed };
}

/** One host's hourly price: the looked-up price for its size and region, else the hourly rate set in Settings (0 or less = none), else 0. */
export const hostHourly = (h, prices, rate = 0) => prices[priceKey(h.size, h.region)] || (rate > 0 ? rate : 0);

/** The cost of these hosts for 24 hours on, their hourly prices added before rounding once: { cost (a number, or null when no host can be costed), priced (hosts costed from a
 *  looked-up price), unpriced (hosts with neither a price nor a rate) }. */
export function dayCost(hosts, prices, rate = 0) {
  const list = hosts || [];
  const hourly = list.map((h) => hostHourly(h, prices, rate));
  return {
    cost: hourly.some((x) => x > 0) ? idleCostPerDay(1, hourly.reduce((sum, x) => sum + x, 0)) : null,
    priced: list.filter((h) => prices[priceKey(h.size, h.region)]).length,
    unpriced: hourly.filter((x) => !(x > 0)).length,
  };
}
