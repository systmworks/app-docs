// The VM prices the workspace holds and the one lookup that fills them, shared by the Dashboard's idle tile and the Size and cost report (core/prices.js asks
// Microsoft's public price list; this keeps what it found). Nothing is saved: the prices live only while the workspace tab is open. Skipped in the demo (sample
// tenant), which sends nothing anywhere.

import { lookupPrices, priceKey, cleanCurrency } from "../core/prices.js";
import { state, send } from "./core.js";

/** The hourly prices looked up so far ("size|region": price). */
export const priceCache = {};
/** The pairs Microsoft had no price for or could not be asked (not asked again until the page reloads). */
const priceTried = new Set();
let pricing = false;
/** The next request that arrived while a lookup was running (asked for when it ends). */
let waiting = null;
/** The currency the prices held were asked for. */
let pricesIn = "";

/** The currency prices are shown in (the Settings pick, USD by default); the prices held are dropped when it changes, so no price is ever shown under the wrong currency. */
export function currentCurrency() {
  const c = cleanCurrency(state.priceCurrency) || "USD";
  if (c !== pricesIn) { for (const k of Object.keys(priceCache)) delete priceCache[k]; priceTried.clear(); pricesIn = c; }
  return c;
}

/** Looks up the prices of the VM sizes these hosts use, once for each size and region, and calls onDone when new prices (or failures) arrive. onStart runs when a lookup begins.
 *  A failure goes to the browser console and the Console tab, and the cost falls back to the Settings rate. */
export async function loadPrices(hosts, hooks = {}) {
  currentCurrency();
  if (state.sample) return;
  if (pricing) { waiting = [hosts, hooks]; return; }
  const pairs = (hosts || []).filter((h) => h.size && h.region && !(priceKey(h.size, h.region) in priceCache) && !priceTried.has(priceKey(h.size, h.region))).map((h) => ({ size: h.size, region: h.region }));
  if (!pairs.length) return;
  pricing = true;
  hooks.onStart?.();
  const asked = currentCurrency();
  const res = await lookupPrices(pairs, priceCache, asked).finally(() => { pricing = false; });
  if (currentCurrency() === asked) {
    Object.assign(priceCache, res.prices);
    for (const f of res.failed) {
      priceTried.add(f.key);
      console.error(`AVD Enhancer: price lookup failed for ${f.key}: ${f.error}`);
      send("log/add", { level: "warn", message: `Price lookup failed for ${f.key}: ${f.error}` });
    }
  }
  hooks.onDone?.();
  const next = waiting; waiting = null;
  if (next) await loadPrices(...next);
  return loadPrices(hosts, hooks);
}
