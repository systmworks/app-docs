// Dashboard: the tiles, custom cards, pool and host tables, the host drawer, saved views, Scan sessions and the page export.

import { isOn, isIdle, scopeTo } from "../core/avd.js";
import { CHIPS, COLUMNS, filterHosts, chipCounts, sortHosts, searchRows, gridCells, POOL_COLS, ago, hashToView, viewToHash, visibleColumns, saveView, removeView, esc } from "../core/host-table.js";
import { docHtml, docMarkdown } from "../core/report-doc.js";
import { maintRows, hostWindows } from "../core/windows.js";
import { hostsByTag } from "../core/tags.js";
import { $, state, send, errorBanner, chipHtml, exportDefs, tables, shownRows, dataTable, portalLink, saveFile, syncHash, getInventory, savePrefs, showTab, onTabLeave, renderNavSections, scopeName, copyWith } from "./core.js";
import { poolLinkRows } from "../core/pool-links.js";
import { dayCost } from "../core/prices.js";
import { priceCache, currentCurrency, loadPrices } from "./prices.js";

/** Closes the right-hand drawer, whether it shows a host, a pool or a scaling plan (a no-op when it is already shut). */
export function closeDrawer() {
  if (!state.drawer && !state.side) return;
  state.drawer = ""; state.side = null;
  if (state.view) renderHosts();
  renderDrawer();
}

function tileHtml({ id, cls, label, val, big, small, extra = "", pressed }) {
  return `<button class="tile ${cls}" data-tile="${esc(id)}" aria-pressed="${pressed}">
    <div class="label" title="${esc(label)}">${esc(label)}</div>
    <div class="big">${big ?? esc(val)}</div><div class="small">${esc(small)}</div>${extra ? `<div class="small">${esc(extra)}</div>` : ""}</button>`;
}

const idleHosts = () => state.view.hosts.filter(isIdle);
/** The idle tile's cost line: each idle host's looked-up Microsoft price (else the Settings rate) x 24, with "at least" when some idle hosts could not be costed. */
const idleCostText = () => {
  const hosts = idleHosts();
  const { cost, priced, unpriced } = dayCost(hosts, priceCache, state.rate);
  const inCurrency = priced > 0 && priced + unpriced === hosts.length; /* every costed host used a Microsoft price, none the Settings rate */
  return cost ? `${unpriced ? "at least " : ""}about ${Math.round(cost)} per day (${inCurrency ? `${currentCurrency()}, ` : ""}estimate)` : "";
};

const tileList = () => {
  const { totals: t } = state.view.summary;
  const on = (chip) => state.chip === chip && !state.pool;
  const tiles = [
    { key: "pools", id: "all", cls: "off", label: "Host pools", val: String(t.pools), small: `${t.hosts} session hosts`, pressed: !state.pool && state.chip === "all" },
    { key: "sessions", id: "connected", cls: "ok", label: "Active sessions", val: String(t.sessions), small: "user sessions", pressed: on("connected") },
    { key: "capacity", id: "all", cls: t.capacityPct >= 90 ? "bad" : t.capacityPct >= 70 ? "warn" : "ok", label: "Capacity used", val: t.capacityPct === null ? "-" : `${t.capacityPct}%`, big: t.capacityPct === null ? "-" : `${t.capacityPct}<span class="of">%</span>`, small: t.capacity ? `${t.sessions} of ${t.capacity} sessions` : t.on ? "pool session limits not read" : "no capacity (all hosts off)", pressed: false },
    { key: "idle", id: "idle", cls: t.idle ? "warn" : "ok", label: "Idle hosts", val: String(t.idle), small: "on, no sessions", extra: idleCostText(), pressed: on("idle") },
    { key: "attention", id: "attention", cls: t.issues ? "bad" : "ok", label: "Needs attention", val: String(t.issues), small: "hosts with issues", pressed: on("attention") },
    { key: "oldagent", id: "oldagent", cls: t.oldAgent ? "warn" : "ok", label: "Old agent", val: String(t.oldAgent), small: "AVD agent out of date", pressed: on("oldagent") },
    { key: "drain", id: "drain", cls: t.drain ? "warn" : "ok", label: "Drain mode", val: String(t.drain), small: "not taking new sessions", pressed: on("drain") },
    { key: "off", id: "off", cls: "off", label: "Powered off", val: String(t.off), small: "deallocated or stopped", pressed: on("off") },
  ];
  return tiles;
};
export const renderTiles = () => { $("#tiles").innerHTML = tileList().map(tileHtml).join(""); };

/* Custom cards (Settings): a third row of up to four under the eight tiles, each a session-host count or a count of hosts with a tag. */
const encTag = (s) => encodeURIComponent(s);
/** The tiles for the filled custom card slots, from the current view. */
function customTiles() {
  const { totals: t } = state.view.summary;
  return state.cards.flatMap((c) => {
    if (c.kind === "tag" && c.tag) {
      const n = hostsByTag(state.view.hosts, c.tag, c.value ? "value" : "all", c.value).length;
      return [{ id: `tag:${encTag(c.tag)}|${encTag(c.value)}`, cls: "off", label: c.value ? `${c.tag} = ${c.value}` : c.tag, val: String(n), small: "hosts with this tag", pressed: false }];
    }
    if (c.kind === "hosts") return [{ id: "all", cls: "off", label: "Session hosts", val: String(t.hosts), small: `in ${t.pools} pools`, pressed: false }];
    return [];
  });
}
/** Draws the custom card row under the tiles (hidden when no slot is filled). */
export function renderCards() {
  const tiles = state.view ? customTiles() : [];
  $("#cards-row").hidden = !tiles.length;
  $("#cards-row").innerHTML = tiles.map(tileHtml).join("");
}

/* ---------- sidebar pool links (chosen in Settings): a "Pools" section whose links open the Dashboard on one pool ---------- */
/** Draws the Pools section of the sidebar from the saved slots; the open pool (Dashboard only) is marked, and a pool missing from the latest read is greyed. */
export function renderPoolLinks() {
  const rows = poolLinkRows(state.poolLinks, state.data);
  const box = $("#pool-nav");
  box.hidden = !rows.length;
  box.innerHTML = rows.length ? `<span class="tab-head" role="button" tabindex="0">Pools</span>${rows.map((r) =>
    `<button type="button" class="poollink${r.missing ? " missing" : ""}" data-poolnav="${esc(r.id)}" data-section="Pools"${state.tab === "dashboard" && state.pool === r.id ? ' aria-current="page"' : ""} title="${esc(r.missing ? `${r.name} (not in the latest read)` : r.name)}">${esc(r.name)}</button>`).join("")}` : "";
  renderNavSections();
}

/** Opens the Dashboard on one pool (the pool's subscription replaces a different subscription pick). */
export function openPoolLink(id) {
  const pool = state.data?.pools.find((p) => p.id.toLowerCase() === id);
  if (pool && state.sub && pool.subscriptionId !== state.sub) state.sub = "";
  state.pool = id;
  state.chip = "all";
  showTab("dashboard");
  if (state.data) renderDashboard();
}

/* The pools as one scrolling table (there can be hundreds), beside the tiles: name, type, powered on, total, sessions. The title bar
   above it has the filter box (only for a long list) and the export buttons. A row click filters the host table to that pool. */
const POOL_SHOWN = POOL_COLS.slice(0, 5);
const shownPools = () => sortHosts(searchRows(state.view.summary.pools, POOL_SHOWN, state.poolQ), state.poolSort.key, state.poolSort.dir, POOL_COLS);
export function renderPools() {
  const { pools } = state.view.summary;
  const list = shownPools();
  $("#pools").hidden = !pools.length;
  $("#poolq").hidden = pools.length <= 8;
  $("#poolcount").textContent = state.poolQ.trim() ? `${list.length} of ${pools.length}` : String(pools.length);
  const rows = list.map((p) => {
    const id = esc(p.id.toLowerCase());
    const cls = p.total === 0 || p.on === 0 ? "" : p.on === p.total ? "ok" : "warn";
    return `<tr data-tile="pool:${id}" aria-selected="${state.pool === p.id.toLowerCase()}"><td><span class="poolcell"><button type="button" class="poolname" data-tile="pool:${id}" title="${esc(p.name)}">${esc(p.name)}</button><button type="button" class="infobtn" data-side="pool:${id}" title="Pool details" aria-label="Details of ${esc(p.name)}"></button></span></td>
      <td>${esc(p.type)}</td><td class="num"><span class="badge ${cls}">${p.on}</span></td><td class="num">${p.total}</td><td class="num">${p.capacity ? `${p.sessions} of ${p.capacity}` : p.sessions}</td></tr>`;
  }).join("");
  const th = (c) => { const on = state.poolSort.key === c.key; return `<th data-psort="${c.key}"${c.kind === "n" ? ' class="num"' : ""}${on ? ` aria-sort="${state.poolSort.dir === "asc" ? "ascending" : "descending"}"` : ""}>${esc(c.label)}${on ? (state.poolSort.dir === "asc" ? " ▲" : " ▼") : ""}</th>`; };
  $("#pool-table").innerHTML = `<table><thead><tr>${POOL_SHOWN.map(th).join("")}</tr></thead><tbody>${rows || `<tr><td colspan="5" class="empty">No pools match.</td></tr>`}</tbody></table>`;
}

exportDefs.hosts = () => ({ rows: state.rows || [], cols: visibleColumns(state.cols), title: "AVD hosts", file: "avd-hosts" });

/* The whole Dashboard as one printable page (Save HTML) or Markdown (Copy Markdown): the tiles, the pools and the hosts as shown. */
function pageDoc() {
  const hosts = state.rows || [];
  const scope = scopeName();
  const filtered = state.pool || state.chip !== "all" || state.q.trim();
  const sectionOf = (title, cols, rows, note = "") => ({ title, head: cols.map((c) => c.label), cells: gridCells(rows, cols), note });
  return {
    title: "AVD Enhancer: Dashboard",
    subtitle: `${scope}. Saved ${new Date().toISOString().slice(0, 16).replace("T", " ")} UTC${state.sample ? ". Sample data, not a real tenant" : ""}.`,
    headline: tileList().map((t) => ({ label: t.label, value: t.val, small: t.small, cls: t.cls })),
    sections: [sectionOf("Host pools", POOL_COLS, shownPools()), sectionOf("Session hosts", visibleColumns(state.cols), hosts, filtered ? `Filtered: ${hosts.length} of ${state.view.hosts.length} hosts shown.` : ""),
      // The user sessions of the last Scan sessions, as shown (filter and sort applied), when a scan has been run.
      ...(tables.sessions ? [sectionOf("User sessions", tables.sessions.cols, shownRows("sessions"), `From the last Scan sessions: ${shownRows("sessions").length} of ${tables.sessions.rows.length} sessions shown.`)] : [])],
  };
}

const CELLS = {
  name: (h) => `<td>${esc(h.name)}</td>`,
  pool: (h) => `<td>${esc(h.pool)}</td>`,
  power: (h) => `<td><span class="badge ${isOn(h) ? "ok" : ""}">${esc(h.power)}</span></td>`,
  status: (h) => `<td><span class="badge ${h.status === "Available" ? "ok" : h.issue ? "bad" : ""}">${esc(h.status)}</span></td>`,
  issue: (h) => `<td>${h.issue ? `<span class="badge bad">${esc(h.issue)}</span>` : ""}</td>`,
  sessions: (h) => `<td class="num">${h.sessions}</td>`,
  user: (h) => `<td>${esc(h.user)}</td>`,
  drain: (h) => `<td>${h.drain ? '<span class="badge warn">Drain</span>' : ""}</td>`,
  agent: (h) => `<td>${esc(h.agent)}</td>`,
  heartbeat: (h) => `<td title="${esc(h.heartbeat)}">${esc(ago(h.heartbeat))}</td>`,
  region: (h) => `<td>${esc(h.region)}</td>`,
};

function renderColpick(cols) {
  const on = new Set(cols.map((c) => c.key));
  $("#colpick-list").innerHTML = COLUMNS.map((c) => `<label><input type="checkbox" data-col="${c.key}"${on.has(c.key) ? " checked" : ""}${c.key === "name" ? " disabled" : ""}> ${esc(c.label)}</label>`).join("");
}

function renderViews() {
  $("#views-sum").textContent = `Saved views (${state.views.length})`;
  $("#views-list").innerHTML = state.views.map((v) => `<div class="vrow"><button type="button" data-view="${esc(v.name)}">${esc(v.name)}</button><button type="button" class="del" data-viewdel="${esc(v.name)}" aria-label="Delete view ${esc(v.name)}" title="Delete view">x</button></div>`).join("")
    + `${state.views.length ? "" : `<div class="empty-note">No saved views yet.</div>`}<button id="view-save" type="button">Save current view...</button>`;
}

export function renderHosts() {
  const { hosts } = state.view;
  $("#hosts").hidden = false;
  const pool = state.view.summary.pools.find((p) => p.id.toLowerCase() === state.pool);
  $("#hosts-title").textContent = pool ? `Hosts in ${pool.name}` : "All hosts";
  const counts = chipCounts(hosts, { pool: state.pool, q: state.q });
  $("#chips").innerHTML = CHIPS.map((c) => chipHtml(`data-chip="${c.id}"`, c.label, counts[c.id], state.chip === c.id, counts[c.id] === 0 && state.chip !== c.id)).join("");
  const rows = sortHosts(filterHosts(hosts, state), state.sort.key, state.sort.dir);
  const cols = visibleColumns(state.cols);
  const head = cols.map((c) => `<th data-sort="${c.key}"${state.sort.key === c.key ? ` aria-sort="${state.sort.dir === "asc" ? "ascending" : "descending"}"` : ""}>${esc(c.label)}${state.sort.key === c.key ? (state.sort.dir === "asc" ? " ▲" : " ▼") : ""}</th>`).join("");
  const body = rows.map((h) => `<tr data-host="${esc(h.id)}"${state.drawer === h.id ? ' aria-selected="true"' : ""}>${cols.map((c) => CELLS[c.key](h)).join("")}</tr>`).join("");
  $("#table").innerHTML = `<thead><tr>${head}</tr></thead><tbody>${body || `<tr><td colspan="${cols.length}" class="empty">No hosts match.</td></tr>`}</tbody>`;
  renderColpick(cols);
  $("#limit").textContent = `${rows.length} of ${hosts.length} hosts`;
  state.rows = rows;
  syncHash();
}

/* ---------- host drawer ---------- */
export const drawerHost = () => state.data?.hosts.find((h) => h.id === state.drawer);

export function renderDrawer(sessions) {
  const h = drawerHost();
  $("#drawer").hidden = !h;
  if (!h) return;
  const rows = (s) => s.map((x) => `<tr><td>${esc(x.user)}</td><td><span class="badge ${x.state === "Active" ? "ok" : ""}">${esc(x.state)}</span></td><td title="${esc(x.created)}">${esc(ago(x.created))}</td></tr>`).join("");
  const sess = sessions === undefined ? `<p class="muted small">Reading sessions...</p>`
    : sessions === null ? `<p class="muted small">Could not read sessions.</p>`
    : sessions.length ? `<div class="tablewrap"><table><thead><tr><th>User</th><th>State</th><th>Since</th></tr></thead><tbody>${rows(sessions)}</tbody></table></div>`
    : `<p class="muted small">No user sessions.</p>`;
  $("#drawer-body").innerHTML = `<h2>${esc(h.name)}</h2><div class="muted small">${esc(h.pool)}</div>
    <dl><dt>Power</dt><dd>${esc(h.power)}</dd><dt>AVD status</dt><dd>${esc(h.status)}</dd><dt>Issue</dt><dd>${esc(h.issue) || "None"}</dd>
    <dt>Drain mode</dt><dd>${h.drain ? "On" : "Off"}</dd><dt>VM size</dt><dd>${esc(h.size) || "-"}</dd>
    <dt>OS build</dt><dd>${esc(h.os) || "-"}</dd><dt>Agent</dt><dd>${esc(h.agent) || "-"}</dd>
    <dt>Heartbeat</dt><dd>${esc(ago(h.heartbeat)) || "-"}</dd><dt>Region</dt><dd>${esc(h.region)}</dd>
    <dt>Resource group</dt><dd>${esc(h.resourceGroup)}</dd><dt>Assigned user</dt><dd>${esc(h.user) || "-"}</dd></dl>
    <div class="portallinks">${h.vmId ? portalLink(h.vmId, "Open VM in Azure portal") : ""}${portalLink(h.id, h.vmId ? "Open session host in AVD" : "Open in Azure portal")}</div>
    ${Object.keys(h.tags || {}).length ? `<h3>Tags</h3><div class="taglist">${Object.entries(h.tags).map(([k, v]) => `<span class="badge">${esc(k)}: ${esc(v)}</span>`).join("")}</div>` : ""}
    <div id="drawer-maint"></div>
    <h3>User sessions (${h.sessions})</h3>${sess}`;
  renderDrawerMaint();
}

/** The host's Azure maintenance configuration(s), from the inventory read (started when the drawer opens). */
function renderDrawerMaint() {
  const h = drawerHost(), el = $("#drawer-maint");
  if (!h || !el) return;
  const inv = state.inventory;
  let body;
  if (!inv) body = state.invError ? `<p class="muted small">Could not read maintenance windows: ${esc(state.invError)}</p>` : `<p class="muted small">Reading maintenance windows...</p>`;
  else {
    const mine = hostWindows(h.vmId, maintRows(inv.configs, inv.assignments, state.data.hosts), inv.assignments);
    const failed = (inv.errors || []).some((e) => /^Maintenance/.test(e));
    body = mine.length ? mine.map((m) => `<div><strong>${esc(m.name)}</strong> <span class="muted small">${esc(m.scope)}</span></div>
      <dl><dt>Days</dt><dd>${esc(m.days) || "-"}</dd><dt>Start</dt><dd>${esc(m.start) || "-"}</dd><dt>End</dt><dd>${esc(m.end) || "-"}</dd>
      <dt>Length</dt><dd>${esc(m.length) || "-"}</dd><dt>Time zone</dt><dd>${esc(m.timeZone) || "-"}</dd></dl>`).join("")
      : `<p class="muted small">${failed ? "Maintenance windows could not be read (see the Console tab)." : "No maintenance configuration is assigned to this VM. Windows applied by a dynamic scope (a subscription or tag filter) are not listed."}</p>`;
  }
  el.innerHTML = `<h3>Maintenance window</h3>${body}`;
}

export async function openDrawer(id) {
  state.side = null;
  state.drawer = state.drawer === id ? "" : id;
  renderHosts();
  renderDrawer(state.drawer && drawerHost()?.sessions ? undefined : []);
  if (state.drawer) getInventory().then((res) => { state.invError = res.ok ? "" : res.error; renderDrawerMaint(); });
  if (!state.drawer || !drawerHost()?.sessions) return;
  const asked = state.drawer;
  const res = await send("avd/sessions", { id: asked, sample: state.sample });
  if (state.drawer === asked) renderDrawer(res.ok ? res.sessions : null); // an older answer never replaces a newer pick
}

function renderScope() {
  const subs = state.data.subs || [];
  if (state.sub && !subs.some((s) => s.id === state.sub)) state.sub = "";
  $("#scopebar").hidden = subs.length < 2;
  $("#sub").innerHTML = [`<option value="">All subscriptions (${subs.length})</option>`, ...subs.map((s) => `<option value="${esc(s.id)}">${esc(s.name)}</option>`)].join("");
  $("#sub").value = state.sub;
}

export function renderDashboard() {
  renderScope();
  state.view = scopeTo(state.data, state.sub);
  $("#scoperow").hidden = false;
  renderTiles();
  loadPrices(idleHosts(), { onDone: () => { if (state.view && state.tab === "dashboard") renderTiles(); } });
  renderCards();
  renderPoolLinks();
  renderPools();
  renderViews();
  renderHosts();
  $("#stamp").textContent = `Updated ${new Date(state.data.fetchedAt).toLocaleTimeString()}`;
}

export function onTile(id) {
  if (id.startsWith("tag:")) { const [tag, value] = id.slice(4).split("|").map(decodeURIComponent); state.tagSel = { tag, mode: value ? "value" : "all", value }; return showTab("tags"); }
  if (id.startsWith("pool:")) { const p = id.slice(5); state.pool = state.pool === p ? "" : p; state.chip = "all"; }
  else if (id === "all") { state.pool = ""; state.chip = "all"; }
  else { state.pool = ""; state.chip = state.chip === id ? "all" : id; }
  renderDashboard();
}

/* ---------- saved views ---------- */
function applyView(hash) {
  const v = hashToView(hash);
  Object.assign(state, { pool: v.pool, chip: v.chip, q: v.q, sort: v.sort, cols: v.cols, sub: v.sub });
  $("#search").value = v.q;
  if (state.data) renderDashboard();
}

/* ---------- session scan: the user sessions of the hosts currently shown ---------- */
async function scanSessions() {
  const hosts = (state.rows || []).filter((h) => h.sessions > 0).map((h) => ({ id: h.id, name: h.name, pool: h.pool }));
  const out = $("#scan-out");
  if (!hosts.length) { out.innerHTML = `<p class="muted small">None of the hosts shown has user sessions.</p>`; return; }
  out.innerHTML = `<p class="muted small">Reading sessions on ${hosts.length} hosts...</p>`;
  $("#scan").disabled = true;
  const res = await send("avd/allsessions", { hosts, sample: state.sample });
  $("#scan").disabled = false;
  if (!res.ok) { out.innerHTML = errorBanner(res.error); return; }
  const disc = res.sessions.filter((s) => s.state === "Disconnected").length;
  const cols = [{ key: "user", label: "User" }, { key: "state", label: "State", html: (r) => `<span class="badge ${r.state === "Active" ? "ok" : "warn"}">${esc(r.state)}</span>` },
    { key: "host", label: "Host" }, { key: "pool", label: "Pool" }, { key: "created", label: "Started", html: (r) => `<span title="${esc(r.created)}">${esc(ago(r.created))}</span>` }];
  out.innerHTML = `${dataTable("sessions", "User sessions", cols, res.sessions, "avd-user-sessions")}<p class="muted small">${res.sessions.length} sessions on ${hosts.length - (res.skipped || 0)} hosts, ${disc} disconnected (listed first, then longest-running)${res.failed ? `; ${res.failed} hosts could not be read` : ""}${res.skipped ? `; ${res.skipped} more hosts were not read (one scan reads only the first ${hosts.length - res.skipped}: filter the table to fewer hosts and scan again)` : ""}. Azure gives a start time, not a disconnect time.</p>`;
}

onTabLeave(closeDrawer); // a host's details belong to the tab they were opened on

$("#scan").addEventListener("click", scanSessions);

$("#page-html").addEventListener("click", () => saveFile("html", docHtml(pageDoc()), "text/html", "avd-dashboard"));
$("#page-md").addEventListener("click", async () => {
  await copyWith($("#page-md"), docMarkdown(pageDoc()));
});

$("#colpick-list").addEventListener("change", (e) => {
  const key = e.target.dataset.col;
  if (!key) return;
  const on = new Set(visibleColumns(state.cols).map((c) => c.key));
  if (e.target.checked) on.add(key); else on.delete(key);
  state.cols = on.size >= COLUMNS.length ? [] : [...on];
  savePrefs();
  renderHosts();
});

$("#views-list").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.view !== undefined) {
    const v = state.views.find((x) => x.name === b.dataset.view);
    if (v) applyView(v.hash);
    $("#viewmenu").open = false;
  } else if (b.dataset.viewdel !== undefined) {
    state.views = removeView(state.views, b.dataset.viewdel);
    savePrefs(); renderViews();
  } else if (b.id === "view-save") {
    const name = (prompt("Name for this view (it keeps the filters, search, sort, columns and subscription)") || "").trim();
    if (!name) return;
    state.views = saveView(state.views, { name, hash: viewToHash({ ...state, tab: "dashboard" }) });
    savePrefs(); renderViews(); $("#viewmenu").open = false;
  }
});

$("#poolq").addEventListener("input", (e) => { state.poolQ = e.target.value; renderPools(); });

$("#sub").addEventListener("change", async (e) => {
  state.sub = e.target.value; state.pool = ""; state.chip = "all";
  await savePrefs();
  renderDashboard();
});
$("#search").addEventListener("input", (e) => { state.q = e.target.value; renderHosts(); });
