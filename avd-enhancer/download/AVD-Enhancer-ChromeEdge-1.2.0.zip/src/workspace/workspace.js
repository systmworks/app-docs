// Workspace page: Dashboard (tiles + host table), Links, Settings. Talks to the service worker only (README rule 5).

import { isOn, scopeTo, poolRows, groupRows, idleCostPerDay, countOf } from "../core/avd.js";
import { CHIPS, COLUMNS, filterHosts, chipCounts, sortHosts, searchRows, gridCells, POOL_COLS, toCsv, toTsv, toHtml, ago, hashToView, viewToHash, visibleColumns, saveView, removeView, cleanViews } from "../core/host-table.js";
import { linkGroups, resourceUrl, intuneStore } from "../data/links.js";
import { atLevel, formatLog } from "../core/log.js";
import { docHtml, docMarkdown } from "../core/report-doc.js";
import { scopesOf } from "../core/access.js";
import { scheduleRows, maintRows, hostWindows } from "../core/windows.js";
import { CARD_METRICS, tagList, tagValues, tagHostRows, hostsByTag, cleanCards } from "../core/tags.js";

const $ = (sel) => document.querySelector(sel);
const TABS = ["dashboard", "inventory", "tags", "pim", "links", "console", "settings"];
const PREFS_KEY = "avd.prefs";
const BG_KEY = "avd.bg"; // minutes between background checks (the worker reads it)

const state = {
  tab: "dashboard", data: null, status: { consented: false, signedIn: false }, sample: new URLSearchParams(location.search).has("sample"),
  pool: "", poolQ: "", poolSort: { key: "name", dir: "asc" }, chip: "all", q: "", drawer: "", side: null, starredTabs: new Set(), starredOnly: false, sub: "", view: null, cols: [], views: [], rate: 0, cards: cleanCards(null), tagSel: { tag: "", mode: "all", value: "" }, pim: null, pimFilter: "all", sort: { key: "name", dir: "asc" }, timer: null, interval: 0,
};

const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const send = (type, extra = {}) => chrome.runtime.sendMessage({ type, ...extra }).catch((e) => ({ ok: false, error: e.message }));

/* ---------- tabs ---------- */
/** Closes the right-hand drawer, whether it shows a host, a pool or a scaling plan (a no-op when it is already shut). */
function closeDrawer() {
  if (!state.drawer && !state.side) return;
  state.drawer = ""; state.side = null;
  if (state.view) renderHosts();
  renderDrawer();
}
function showTab(name) {
  const next = TABS.includes(name) ? name : "dashboard";
  if (next !== state.tab) closeDrawer(); // a host's details belong to the tab they were opened on
  state.tab = next;
  for (const t of TABS) $(`#tab-${t}`).hidden = t !== state.tab;
  document.querySelectorAll("[data-tab]").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.tab === state.tab)));
  $("#refresh-group").classList.toggle("off", state.tab !== "dashboard"); // hidden but still taking its space, so the header does not shift between tabs
  if (state.tab === "inventory") loadInventoryTab();
  if (state.tab === "tags") renderTagsTab();
  if (state.tab === "pim") loadPimTab();
  if (state.tab === "console") loadConsole();
  if (state.tab === "links") renderLinks();
  if (state.tab === "settings") renderSettings();
  syncHash();
}

/* ---------- data ---------- */
async function refresh() {
  const status = await send("status/get");
  state.status = status.ok ? status : { consented: false, signedIn: false };
  renderWho();
  if (!state.sample && !state.status.consented) return renderNotice("off");
  if (!state.sample && !state.status.signedIn) return renderNotice("signin");
  $("#refresh").disabled = true;
  const res = await send("avd/overview", { sample: state.sample });
  $("#refresh").disabled = false;
  if (!res.ok) return renderNotice("error", res.error);
  state.data = res;
  renderNotice(state.sample ? "sample" : "");
  renderDashboard();
  if (state.drawer) renderDrawer(drawerHost()?.sessions ? undefined : []);
  if (state.side) renderSide();
  if (state.tab === "tags") renderTagsTab();
  if (state.tab === "inventory") loadInventoryTab(); // opened from a bookmark before the overview had arrived
}

function schedule() {
  clearInterval(state.timer);
  if (state.interval > 0) state.timer = setInterval(() => { if (document.visibilityState === "visible" && state.tab === "dashboard") refresh(); }, state.interval * 1000);
}

/* ---------- dashboard ---------- */
function renderWho() {
  const s = state.status;
  $("#who").textContent = s.signedIn ? `${s.upn || "Signed in"} (${s.cloud === "gov" ? "Azure Government" : "Azure"})` : "";
  const dot = $("#session");
  dot.className = `session${s.signedIn ? " live" : s.consented ? " none" : ""}`;
  dot.title = s.signedIn ? "Signed in to Azure" : s.consented ? "On, but no Azure sign-in found: open the Azure portal" : "Turned off";
}

/** An error message as HTML; a sign-in problem gets a link to the Azure portal, where the sign-in is refreshed. */
const errorHtml = (msg) => escapeHtml(msg) + (/sign-in|signed in|sign in|portal/i.test(msg) ? ` <a href="https://portal.azure.com" target="_blank" rel="noopener">Open portal.azure.com</a>` : "");
/** One error message, or a list of them, as a red banner. */
const errorBanner = (msgs) => `<div class="banner bad">${[].concat(msgs).map(errorHtml).join("<br>")}</div>`;

function renderNotice(kind, message = "") {
  const box = $("#notice");
  const msgs = {
    off: `Sign-in reuse is off. <a href="#" data-go="settings">Turn it on in Settings</a>, or <a href="#" data-demo="1">try the demo</a>.`,
    signin: `No Azure sign-in found yet. Open the <a href="https://portal.azure.com" target="_blank" rel="noopener">Azure portal</a> (signed in), then press Refresh. Or <a href="#" data-demo="1">try the demo</a>.`,
    sample: `Showing sample data, not your tenant. <a href="#" data-demo="1">Leave demo</a>.`,
    error: errorHtml(message),
  };
  box.hidden = !kind;
  box.className = `banner${kind === "error" ? " bad" : ""}`;
  box.innerHTML = msgs[kind] || "";
  if (kind === "off" || kind === "signin" || kind === "error") { $("#tiles").innerHTML = ""; $("#pools").hidden = true; $("#hosts").hidden = true; $("#scoperow").hidden = true; $("#cards-row").hidden = true; }
}

function tileHtml({ id, cls, label, val, big, small, extra = "", pressed }) {
  return `<button class="tile ${cls}" data-tile="${escapeHtml(id)}" aria-pressed="${pressed}">
    <div class="label" title="${escapeHtml(label)}">${escapeHtml(label)}</div>
    <div class="big">${big ?? escapeHtml(val)}</div><div class="small">${escapeHtml(small)}</div>${extra ? `<div class="small">${escapeHtml(extra)}</div>` : ""}</button>`;
}

const tileList = () => {
  const { totals: t } = state.view.summary;
  const on = (chip) => state.chip === chip && !state.pool;
  const tiles = [
    { key: "pools", id: "all", cls: "off", label: "Host pools", val: String(t.pools), small: `${t.hosts} session hosts`, pressed: !state.pool && state.chip === "all" },
    { key: "sessions", id: "connected", cls: "ok", label: "Active sessions", val: String(t.sessions), small: "user sessions", pressed: on("connected") },
    { key: "capacity", id: "all", cls: t.capacityPct >= 90 ? "bad" : t.capacityPct >= 70 ? "warn" : "ok", label: "Capacity used", val: t.capacityPct === null ? "-" : `${t.capacityPct}%`, big: t.capacityPct === null ? "-" : `${t.capacityPct}<span class="of">%</span>`, small: t.capacity ? `${t.sessions} of ${t.capacity} sessions` : "no capacity (all hosts off)", pressed: false },
    { key: "idle", id: "idle", cls: t.idle ? "warn" : "ok", label: "Idle hosts", val: String(t.idle), small: "on, no sessions", extra: idleCostPerDay(t.idle, state.rate) ? `about ${idleCostPerDay(t.idle, state.rate)} a day (estimate)` : "", pressed: on("idle") },
    { key: "attention", id: "attention", cls: t.issues ? "bad" : "ok", label: "Needs attention", val: String(t.issues), small: "hosts with issues", pressed: on("attention") },
    { key: "oldagent", id: "oldagent", cls: t.oldAgent ? "warn" : "ok", label: "Old agent", val: String(t.oldAgent), small: "AVD agent out of date", pressed: on("oldagent") },
    { key: "drain", id: "drain", cls: t.drain ? "warn" : "ok", label: "Drain mode", val: String(t.drain), small: "not taking new sessions", pressed: on("drain") },
    { key: "off", id: "off", cls: "off", label: "Powered off", val: String(t.off), small: "deallocated or stopped", pressed: on("off") },
  ];
  return tiles;
};
const renderTiles = () => { $("#tiles").innerHTML = tileList().map(tileHtml).join(""); };

/* Custom cards (Settings): a third row of up to four under the eight tiles, each a session-host count or a count of hosts with a tag. */
const encTag = (s) => encodeURIComponent(s);
/** The tiles for the filled custom card slots, from the current view. */
function customTiles() {
  const { totals: t } = state.view.summary;
  return state.cards.flatMap((c) => {
    if (c.kind === "tag" && c.tag) {
      const n = hostsByTag(state.view.hosts, c.tag, c.value ? "value" : "all", c.value).length;
      return [{ id: `tag:${encTag(c.tag)}|${encTag(c.value)}`, cls: "off", label: c.value ? `${c.tag} = ${c.value}` : c.tag, val: String(n), small: "hosts with this tag", pressed: false }];
    }
    if (c.kind === "hosts") return [{ id: "all", cls: "off", label: "Session hosts", val: String(t.hosts), small: `in ${t.pools} pools`, pressed: false }];
    return [];
  });
}
/** Draws the custom card row under the tiles (hidden when no slot is filled). */
function renderCards() {
  const tiles = state.view ? customTiles() : [];
  $("#cards-row").hidden = !tiles.length;
  $("#cards-row").innerHTML = tiles.map(tileHtml).join("");
}

/* The pools as one scrolling table (there can be hundreds), beside the tiles: name, type, powered on, total, sessions. The title bar
   above it has the filter box (only for a long list) and the export buttons. A row click filters the host table to that pool. */
const POOL_SHOWN = POOL_COLS.slice(0, 5);
const shownPools = () => sortHosts(searchRows(state.view.summary.pools, POOL_SHOWN, state.poolQ), state.poolSort.key, state.poolSort.dir, POOL_COLS);
function renderPools() {
  const { pools } = state.view.summary;
  const list = shownPools();
  $("#pools").hidden = !pools.length;
  $("#poolq").hidden = pools.length <= 8;
  $("#poolcount").textContent = state.poolQ.trim() ? `${list.length} of ${pools.length}` : String(pools.length);
  const rows = list.map((p) => {
    const id = escapeHtml(p.id.toLowerCase());
    const cls = p.total === 0 || p.on === 0 ? "" : p.on === p.total ? "ok" : "warn";
    return `<tr data-tile="pool:${id}" aria-selected="${state.pool === p.id.toLowerCase()}"><td><span class="poolcell"><button type="button" class="poolname" data-tile="pool:${id}" title="${escapeHtml(p.name)}">${escapeHtml(p.name)}</button><button type="button" class="infobtn" data-side="pool:${id}" title="Pool details" aria-label="Details of ${escapeHtml(p.name)}"></button></span></td>
      <td>${escapeHtml(p.type)}</td><td class="num"><span class="badge ${cls}">${p.on}</span></td><td class="num">${p.total}</td><td class="num">${p.capacity ? `${p.sessions} of ${p.capacity}` : p.sessions}</td></tr>`;
  }).join("");
  const th = (c) => { const on = state.poolSort.key === c.key; return `<th data-psort="${c.key}"${c.kind === "n" ? ' class="num"' : ""}${on ? ` aria-sort="${state.poolSort.dir === "asc" ? "ascending" : "descending"}"` : ""}>${escapeHtml(c.label)}${on ? (state.poolSort.dir === "asc" ? " ▲" : " ▼") : ""}</th>`; };
  $("#pool-table").innerHTML = `<table><thead><tr>${POOL_SHOWN.map(th).join("")}</tr></thead><tbody>${rows || `<tr><td colspan="5" class="empty">No pools match.</td></tr>`}</tbody></table>`;
}

/* ---------- the shared table pattern: a title bar (filter box, export buttons) and sortable headers ---------- */
const svgIcon = (paths) => `<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
const EXPORT_KINDS = [ // left to right; the most used is rightmost. Icon buttons: the full name is the hover text and the accessible name.
  ["html", "Save HTML", svgIcon('<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>')],
  ["copy", "Copy table", svgIcon('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>')],
  ["csv", "Save CSV", svgIcon('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16"/>')],
];
const exportButtons = (id) => EXPORT_KINDS.map(([k, label, icon]) => `<button type="button" class="export ico" data-xfor="${id}" data-xkind="${k}" title="${label}" aria-label="${label}">${icon}</button>`).join("");
/** A filter pill; attrs is the data attribute(s) the click handler reads. */
const chipHtml = (attrs, label, n, pressed, disabled = false) => `<button type="button" class="chip" ${attrs} aria-pressed="${pressed}"${disabled ? " disabled" : ""}>${escapeHtml(label)}<span class="n">${n}</span></button>`;
const exportDefs = {}; // table id -> () => { rows, cols, title, file }, read when a button is clicked
for (const el of document.querySelectorAll("[data-export]")) el.innerHTML = exportButtons(el.dataset.export);
exportDefs.hosts = () => ({ rows: state.rows || [], cols: visibleColumns(state.cols), title: "AVD hosts", file: "avd-hosts" });
async function doExport(btn) {
  const def = exportDefs[btn.dataset.xfor]?.();
  if (!def) return;
  if (btn.dataset.xkind === "csv") saveFile("csv", toCsv(def.rows, def.cols), "text/csv", def.file);
  else if (btn.dataset.xkind === "html") saveFile("html", toHtml(def.rows, def.cols, def.title), "text/html", def.file);
  else {
    const was = btn.title;
    try { await navigator.clipboard.writeText(toTsv(def.rows, def.cols)); btn.title = "Copied"; } catch { btn.title = "Copy failed"; }
    btn.classList.add("flash");
    setTimeout(() => { btn.title = was; btn.classList.remove("flash"); }, 1500);
  }
}

/* A generated table (scanned sessions, the Inventory tables): cols are { key, label, kind, html(row) }, rows are plain objects. */
const tables = {};
const shownRows = (id) => { const t = tables[id]; const r = searchRows(t.rows, t.cols, t.q); return t.sort ? sortHosts(r, t.sort.key, t.sort.dir, t.cols) : r; };
function tableBody(id) {
  const t = tables[id];
  const th = (c) => { const on = t.sort?.key === c.key; return `<th data-tsort="${id}|${c.key}"${c.kind === "n" ? ' class="num"' : ""}${on ? ` aria-sort="${t.sort.dir === "asc" ? "ascending" : "descending"}"` : ""}>${escapeHtml(c.label)}${on ? (t.sort.dir === "asc" ? " ▲" : " ▼") : ""}</th>`; };
  const rows = shownRows(id).map((r) => `<tr${r.hostId ? ` data-host="${escapeHtml(r.hostId)}"` : ""}${r.side ? ` data-side="${escapeHtml(r.side)}"` : ""}>${t.cols.map((c) => `<td${c.kind === "n" ? ' class="num"' : ""}>${c.html ? c.html(r) : escapeHtml(r[c.key])}</td>`).join("")}</tr>`).join("");
  return `<table><thead><tr>${t.cols.map(th).join("")}</tr></thead><tbody>${rows || `<tr><td colspan="${t.cols.length}" class="empty">${t.q.trim() ? "Nothing matches the filter." : "None found."}</td></tr>`}</tbody></table>`;
}
const tableCount = (id) => (tables[id].q.trim() ? `${shownRows(id).length} of ${tables[id].rows.length}` : String(tables[id].rows.length));
function refreshTable(id) { $(`#${id}-wrap`).innerHTML = tableBody(id); $(`#${id}-count`).textContent = tableCount(id); }
/** file is the export file name; leave it out for a table that needs no export buttons. */
function dataTable(id, title, cols, rows, file) {
  tables[id] = { cols, rows, sort: null, q: "" };
  if (file) exportDefs[id] = () => ({ rows: shownRows(id), cols, title, file });
  return `<div class="tbar"><h2>${escapeHtml(title)} <span class="muted small" id="${id}-count">${tableCount(id)}</span></h2><input type="search" class="tfilter" data-tfilter="${id}" placeholder="Filter ${escapeHtml(title.toLowerCase())}" aria-label="Filter ${escapeHtml(title)}"><span class="spacer"></span>${file ? exportButtons(id) : ""}</div>
    <div class="tablewrap" id="${id}-wrap">${tableBody(id)}</div>`;
}
document.addEventListener("input", (e) => { const id = e.target.dataset?.tfilter; if (id && tables[id]) { tables[id].q = e.target.value; refreshTable(id); } });

/* The whole Dashboard as one printable page (Save HTML) or Markdown (Copy Markdown): the tiles, the pools and the hosts as shown. */
function pageDoc() {
  const hosts = state.rows || [];
  const scope = state.sub ? $("#sub").selectedOptions[0]?.textContent : "All subscriptions";
  const filtered = state.pool || state.chip !== "all" || state.q.trim();
  const sectionOf = (title, cols, rows, note = "") => ({ title, head: cols.map((c) => c.label), cells: gridCells(rows, cols), note });
  return {
    title: "AVD Enhancer: Dashboard",
    subtitle: `${scope}. Saved ${new Date().toISOString().slice(0, 16).replace("T", " ")} UTC${state.sample ? ". Sample data, not a real tenant" : ""}.`,
    headline: tileList().map((t) => ({ label: t.label, value: t.val, small: t.small, cls: t.cls })),
    sections: [sectionOf("Host pools", POOL_COLS, shownPools()), sectionOf("Session hosts", visibleColumns(state.cols), hosts, filtered ? `Filtered: ${hosts.length} of ${state.view.hosts.length} hosts shown.` : ""),
      // The user sessions of the last Scan sessions, as shown (filter and sort applied), when a scan has been run.
      ...(tables.sessions ? [sectionOf("User sessions", tables.sessions.cols, shownRows("sessions"), `From the last Scan sessions: ${shownRows("sessions").length} of ${tables.sessions.rows.length} sessions shown.`)] : [])],
  };
}

const CELLS = {
  name: (h) => `<td>${escapeHtml(h.name)}</td>`,
  pool: (h) => `<td>${escapeHtml(h.pool)}</td>`,
  power: (h) => `<td><span class="badge ${isOn(h) ? "ok" : ""}">${escapeHtml(h.power)}</span></td>`,
  status: (h) => `<td><span class="badge ${h.status === "Available" ? "ok" : h.issue ? "bad" : ""}">${escapeHtml(h.status)}</span></td>`,
  issue: (h) => `<td>${h.issue ? `<span class="badge bad">${escapeHtml(h.issue)}</span>` : ""}</td>`,
  sessions: (h) => `<td class="num">${h.sessions}</td>`,
  user: (h) => `<td>${escapeHtml(h.user)}</td>`,
  drain: (h) => `<td>${h.drain ? '<span class="badge warn">Drain</span>' : ""}</td>`,
  agent: (h) => `<td>${escapeHtml(h.agent)}</td>`,
  heartbeat: (h) => `<td title="${escapeHtml(h.heartbeat)}">${escapeHtml(ago(h.heartbeat))}</td>`,
  region: (h) => `<td>${escapeHtml(h.region)}</td>`,
};

function renderColpick(cols) {
  const on = new Set(cols.map((c) => c.key));
  $("#colpick-list").innerHTML = COLUMNS.map((c) => `<label><input type="checkbox" data-col="${c.key}"${on.has(c.key) ? " checked" : ""}${c.key === "name" ? " disabled" : ""}> ${escapeHtml(c.label)}</label>`).join("");
}

function renderViews() {
  $("#views-sum").textContent = `Saved views (${state.views.length})`;
  $("#views-list").innerHTML = state.views.map((v) => `<div class="vrow"><button type="button" data-view="${escapeHtml(v.name)}">${escapeHtml(v.name)}</button><button type="button" class="del" data-viewdel="${escapeHtml(v.name)}" aria-label="Delete view ${escapeHtml(v.name)}" title="Delete view">x</button></div>`).join("")
    + `${state.views.length ? "" : `<div class="empty-note">No saved views yet.</div>`}<button id="view-save" type="button">Save current view...</button>`;
}

function renderHosts() {
  const { hosts } = state.view;
  $("#hosts").hidden = false;
  const pool = state.view.summary.pools.find((p) => p.id.toLowerCase() === state.pool);
  $("#hosts-title").textContent = pool ? `Hosts in ${pool.name}` : "All hosts";
  const counts = chipCounts(hosts, { pool: state.pool, q: state.q });
  $("#chips").innerHTML = CHIPS.map((c) => chipHtml(`data-chip="${c.id}"`, c.label, counts[c.id], state.chip === c.id, counts[c.id] === 0 && state.chip !== c.id)).join("");
  const rows = sortHosts(filterHosts(hosts, state), state.sort.key, state.sort.dir);
  const cols = visibleColumns(state.cols);
  const head = cols.map((c) => `<th data-sort="${c.key}"${state.sort.key === c.key ? ` aria-sort="${state.sort.dir === "asc" ? "ascending" : "descending"}"` : ""}>${escapeHtml(c.label)}${state.sort.key === c.key ? (state.sort.dir === "asc" ? " ▲" : " ▼") : ""}</th>`).join("");
  const body = rows.map((h) => `<tr data-host="${escapeHtml(h.id)}"${state.drawer === h.id ? ' aria-selected="true"' : ""}>${cols.map((c) => CELLS[c.key](h)).join("")}</tr>`).join("");
  $("#table").innerHTML = `<thead><tr>${head}</tr></thead><tbody>${body || `<tr><td colspan="${cols.length}" class="empty">No hosts match.</td></tr>`}</tbody>`;
  renderColpick(cols);
  $("#limit").textContent = `${rows.length} of ${hosts.length} hosts`;
  state.rows = rows;
  syncHash();
}

/* ---------- host drawer ---------- */
const drawerHost = () => state.data?.hosts.find((h) => h.id === state.drawer);

function renderDrawer(sessions) {
  const h = drawerHost();
  $("#drawer").hidden = !h;
  if (!h) return;
  const rows = (s) => s.map((x) => `<tr><td>${escapeHtml(x.user)}</td><td><span class="badge ${x.state === "Active" ? "ok" : ""}">${escapeHtml(x.state)}</span></td><td title="${escapeHtml(x.created)}">${escapeHtml(ago(x.created))}</td></tr>`).join("");
  const sess = sessions === undefined ? `<p class="muted small">Reading sessions...</p>`
    : sessions === null ? `<p class="muted small">Could not read sessions.</p>`
    : sessions.length ? `<div class="tablewrap"><table><thead><tr><th>User</th><th>State</th><th>Since</th></tr></thead><tbody>${rows(sessions)}</tbody></table></div>`
    : `<p class="muted small">No user sessions.</p>`;
  $("#drawer-body").innerHTML = `<h2>${escapeHtml(h.name)}</h2><div class="muted small">${escapeHtml(h.pool)}</div>
    <dl><dt>Power</dt><dd>${escapeHtml(h.power)}</dd><dt>AVD status</dt><dd>${escapeHtml(h.status)}</dd><dt>Issue</dt><dd>${escapeHtml(h.issue) || "None"}</dd>
    <dt>Drain mode</dt><dd>${h.drain ? "On" : "Off"}</dd><dt>VM size</dt><dd>${escapeHtml(h.size) || "-"}</dd>
    <dt>OS build</dt><dd>${escapeHtml(h.os) || "-"}</dd><dt>Agent</dt><dd>${escapeHtml(h.agent) || "-"}</dd>
    <dt>Heartbeat</dt><dd>${escapeHtml(ago(h.heartbeat)) || "-"}</dd><dt>Region</dt><dd>${escapeHtml(h.region)}</dd>
    <dt>Resource group</dt><dd>${escapeHtml(h.resourceGroup)}</dd><dt>Assigned user</dt><dd>${escapeHtml(h.user) || "-"}</dd></dl>
    <div class="portallinks">${h.vmId ? portalLink(h.vmId, "Open VM in Azure portal") : ""}${portalLink(h.id, h.vmId ? "Open session host in AVD" : "Open in Azure portal")}</div>
    ${Object.keys(h.tags || {}).length ? `<h3>Tags</h3><div class="taglist">${Object.entries(h.tags).map(([k, v]) => `<span class="badge">${escapeHtml(k)}: ${escapeHtml(v)}</span>`).join("")}</div>` : ""}
    <div id="drawer-maint"></div>
    <h3>User sessions (${h.sessions})</h3>${sess}`;
  renderDrawerMaint();
}

/** The host's Azure maintenance configuration(s), from the inventory read (started when the drawer opens). */
function renderDrawerMaint() {
  const h = drawerHost(), el = $("#drawer-maint");
  if (!h || !el) return;
  const inv = state.inventory;
  let body;
  if (!inv) body = state.invError ? `<p class="muted small">Could not read maintenance windows: ${escapeHtml(state.invError)}</p>` : `<p class="muted small">Reading maintenance windows...</p>`;
  else {
    const mine = hostWindows(h.vmId, maintRows(inv.configs, inv.assignments, state.data.hosts), inv.assignments);
    const failed = (inv.errors || []).some((e) => /^Maintenance/.test(e));
    body = mine.length ? mine.map((m) => `<div><strong>${escapeHtml(m.name)}</strong> <span class="muted small">${escapeHtml(m.scope)}</span></div>
      <dl><dt>Days</dt><dd>${escapeHtml(m.days) || "-"}</dd><dt>Start</dt><dd>${escapeHtml(m.start) || "-"}</dd><dt>End</dt><dd>${escapeHtml(m.end) || "-"}</dd>
      <dt>Length</dt><dd>${escapeHtml(m.length) || "-"}</dd><dt>Time zone</dt><dd>${escapeHtml(m.timeZone) || "-"}</dd></dl>`).join("")
      : `<p class="muted small">${failed ? "Maintenance windows could not be read (see the Console tab)." : "No maintenance configuration is assigned to this VM. Windows applied by a dynamic scope (a subscription or tag filter) are not listed."}</p>`;
  }
  el.innerHTML = `<h3>Maintenance window</h3>${body}`;
}

async function openDrawer(id) {
  state.side = null;
  state.drawer = state.drawer === id ? "" : id;
  renderHosts();
  renderDrawer(state.drawer && drawerHost()?.sessions ? undefined : []);
  if (state.drawer) getInventory().then((res) => { state.invError = res.ok ? "" : res.error; renderDrawerMaint(); });
  if (!state.drawer || !drawerHost()?.sessions) return;
  const asked = state.drawer;
  const res = await send("avd/sessions", { id: asked, sample: state.sample });
  if (state.drawer === asked) renderDrawer(res.ok ? res.sessions : null); // an older answer never replaces a newer pick
}

/* ---------- pool and scaling plan details: the same right-hand drawer as a host ---------- */
const poolNameOf = (id) => (state.data?.pools || []).find((q) => String(q.id).toLowerCase() === id)?.name || "?";
/** "pool-a, pool-b (off)": the pools a scaling plan is attached to. */
const planPools = (p) => p.pools.map((x) => `${poolNameOf(x.id)}${x.enabled ? "" : " (off)"}`).join(", ");
/** Max sessions as shown: a personal pool holds one session per host. */
const poolMax = (type, max) => (type === "Personal" ? 1 : max);
/** A link to the Azure portal page of a resource id (default text "Open in Azure portal"). */
const portalLink = (id, text = "Open in Azure portal") => `<a href="${escapeHtml(resourceUrl(id, state.status.tid))}" target="_blank" rel="noopener">${escapeHtml(text)}</a>`;
/** A link-style button that opens the pool or plan drawer for "kind:id". */
const sideBtn = (kind, id, label) => `<button type="button" class="poolname" data-side="${kind}:${escapeHtml(id)}">${escapeHtml(label)}</button>`;
/** A drawer fact list from [label, value] pairs (an empty value shows a dash). */
const dlOf = (pairs) => `<dl>${pairs.map(([k, v]) => `<dt>${escapeHtml(k)}</dt><dd>${escapeHtml(v) || "-"}</dd>`).join("")}</dl>`;

/** The pool's drawer: its facts, its scaling plan and application groups (from the inventory read), and its hosts (click one for the host). */
function poolPanel(id, inv) {
  const pool = (state.data.pools || []).find((q) => String(q.id).toLowerCase() === id);
  if (!pool) return `<p class="muted small">That pool is not in the current read.</p>`;
  const row = poolRows([pool], state.data.hosts, inv?.plans || [])[0];
  const hosts = state.data.hosts.filter((h) => h.poolId === id);
  const waiting = state.invError ? `Could not read: ${escapeHtml(state.invError)}` : "Reading...";
  const plans = (inv?.plans || []).filter((pl) => pl.pools.some((x) => x.id === id));
  const groups = inv ? groupRows(inv.appGroups, state.data.pools || [], inv.workspaces).filter((g) => g.pool === pool.name) : [];
  const hostRows = hosts.map((h) => `<tr data-host="${escapeHtml(h.id)}"><td>${escapeHtml(h.name)}</td><td><span class="badge ${isOn(h) ? "ok" : ""}">${escapeHtml(h.power)}</span></td><td class="num">${h.sessions}</td></tr>`).join("");
  return `<h2>${escapeHtml(pool.name)}</h2><div class="muted small">Host pool</div>
    ${dlOf([["Type", row.type], ["Load balancer", row.balancer], ["Max sessions", String(poolMax(row.type, row.maxSessions))], ["Hosts powered on", `${hosts.filter(isOn).length} of ${hosts.length}`],
      ["User sessions", String(hosts.reduce((a, h) => a + (Number(h.sessions) || 0), 0))], ["OS builds", row.os], ["VM sizes", row.sizes], ["Agents", row.agents], ["Mix", row.mixed ? "Mixed" : "Uniform"]])}
    ${portalLink(pool.id)}
    <h3>Scaling plan</h3>${inv ? (plans.length ? plans.map((pl) => `<div>${sideBtn("plan", String(pl.id).toLowerCase(), pl.name)}${pl.pools.find((x) => x.id === id)?.enabled ? "" : ' <span class="muted small">(off for this pool)</span>'}</div>`).join("") : `<p class="muted small">None attached.</p>`) : `<p class="muted small">${waiting}</p>`}
    <h3>Application groups</h3>${inv ? (groups.length ? groups.map((g) => `<div>${escapeHtml(g.name)} <span class="muted small">${escapeHtml(g.kind)}</span></div>`).join("") : `<p class="muted small">None.</p>`) : `<p class="muted small">${waiting}</p>`}
    <h3>Hosts (${hosts.length})</h3><div class="tablewrap"><table><thead><tr><th>Host</th><th>Power</th><th class="num">Sessions</th></tr></thead><tbody>${hostRows}</tbody></table></div>`;
}

/** The scaling plan's drawer: time zone, the pools it is attached to and every schedule with its times. */
function planPanel(id, inv) {
  if (!inv) return `<p class="muted small">${state.invError ? `Could not read: ${escapeHtml(state.invError)}` : "Reading scaling plans..."}</p>`;
  const plan = inv.plans.find((x) => String(x.id).toLowerCase() === id);
  if (!plan) return `<p class="muted small">That scaling plan is not in the current read.</p>`;
  const sched = plan.scheduleList.length ? scheduleRows([plan]).map((r) => `<div><strong>${escapeHtml(r.schedule)}</strong> <span class="muted small">${escapeHtml(r.days)}</span></div>
    ${dlOf([["Ramp-up", r.rampUp], ["Peak", r.peak], ["Ramp-down", r.rampDown], ["Off-peak", r.offPeak], ["At ramp-down", r.logoff]])}`).join("") : `<p class="muted small">No schedules.</p>`;
  return `<h2>${escapeHtml(plan.name)}</h2><div class="muted small">Scaling plan</div>
    ${dlOf([["Time zone", plan.timeZone], ["Resource group", plan.resourceGroup]])}
    ${portalLink(plan.id)}
    <h3>Host pools</h3>${plan.pools.length ? plan.pools.map((x) => `<div>${sideBtn("pool", x.id, poolNameOf(x.id))}${x.enabled ? "" : ' <span class="muted small">(off)</span>'}</div>`).join("") : `<p class="muted small">None attached.</p>`}
    <h3>Schedules (${plan.scheduleList.length})</h3>${sched}`;
}

/** Draws the pool or plan drawer for state.side. */
function renderSide() {
  const side = state.side;
  if (!side || !state.data) return;
  $("#drawer").hidden = false;
  $("#drawer-body").innerHTML = side.kind === "pool" ? poolPanel(side.id, state.inventory) : planPanel(side.id, state.inventory);
}

/** Opens (or, on the same item again, closes) the drawer for "pool:<id>" or "plan:<id>"; the inventory read fills in the plans and groups. */
function openSide(key) {
  if (state.side?.key === key) return closeDrawer();
  const cut = key.indexOf(":");
  state.drawer = ""; state.side = { kind: key.slice(0, cut), id: key.slice(cut + 1).toLowerCase(), key };
  if (state.view) renderHosts(); // clears the highlighted host row
  renderSide();
  getInventory().then((res) => { state.invError = res.ok ? "" : res.error; if (state.side?.key === key) renderSide(); });
}

function renderScope() {
  const subs = state.data.subs || [];
  if (state.sub && !subs.some((s) => s.id === state.sub)) state.sub = "";
  $("#scopebar").hidden = subs.length < 2;
  $("#sub").innerHTML = [`<option value="">All subscriptions (${subs.length})</option>`, ...subs.map((s) => `<option value="${escapeHtml(s.id)}">${escapeHtml(s.name)}</option>`)].join("");
  $("#sub").value = state.sub;
}

function renderDashboard() {
  renderScope();
  state.view = scopeTo(state.data, state.sub);
  $("#scoperow").hidden = false;
  renderTiles();
  renderCards();
  renderPools();
  renderViews();
  renderHosts();
  $("#stamp").textContent = `Updated ${new Date(state.data.fetchedAt).toLocaleTimeString()}`;
}

function onTile(id) {
  if (id.startsWith("tag:")) { const [tag, value] = id.slice(4).split("|").map(decodeURIComponent); state.tagSel = { tag, mode: value ? "value" : "all", value }; return showTab("tags"); }
  if (id.startsWith("pool:")) { const p = id.slice(5); state.pool = state.pool === p ? "" : p; state.chip = "all"; }
  else if (id === "all") { state.pool = ""; state.chip = "all"; }
  else { state.pool = ""; state.chip = state.chip === id ? "all" : id; }
  renderDashboard();
}

function saveFile(ext, text, type, name = "avd-hosts") {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = Object.assign(document.createElement("a"), { href: url, download: `${name}-${new Date().toISOString().slice(0, 10)}.${ext}` });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ---------- saved views ---------- */
function applyView(hash) {
  const v = hashToView(hash);
  Object.assign(state, { pool: v.pool, chip: v.chip, q: v.q, sort: v.sort, cols: v.cols, sub: v.sub });
  $("#search").value = v.q;
  if (state.data) renderDashboard();
}

/* ---------- view in the URL, so a view can be bookmarked ---------- */
function syncHash() {
  const h = viewToHash(state);
  try { history.replaceState(null, "", `${location.pathname}${location.search}${h ? `#${h}` : ""}`); } catch { /* not allowed here */ }
}

/* ---------- session scan: the user sessions of the hosts currently shown ---------- */
async function scanSessions() {
  const hosts = (state.rows || []).filter((h) => h.sessions > 0).map((h) => ({ id: h.id, name: h.name, pool: h.pool }));
  const out = $("#scan-out");
  if (!hosts.length) { out.innerHTML = `<p class="muted small">None of the hosts shown has user sessions.</p>`; return; }
  out.innerHTML = `<p class="muted small">Reading sessions on ${hosts.length} hosts...</p>`;
  $("#scan").disabled = true;
  const res = await send("avd/allsessions", { hosts, sample: state.sample });
  $("#scan").disabled = false;
  if (!res.ok) { out.innerHTML = errorBanner(res.error); return; }
  const disc = res.sessions.filter((s) => s.state === "Disconnected").length;
  const cols = [{ key: "user", label: "User" }, { key: "state", label: "State", html: (r) => `<span class="badge ${r.state === "Active" ? "ok" : "warn"}">${escapeHtml(r.state)}</span>` },
    { key: "host", label: "Host" }, { key: "pool", label: "Pool" }, { key: "created", label: "Started", html: (r) => `<span title="${escapeHtml(r.created)}">${escapeHtml(ago(r.created))}</span>` }];
  out.innerHTML = `${dataTable("sessions", "User sessions", cols, res.sessions, "avd-user-sessions")}<p class="muted small">${res.sessions.length} sessions on ${hosts.length} hosts, ${disc} disconnected (listed first, then longest-running)${res.failed ? `; ${res.failed} hosts could not be read` : ""}. Azure gives a start time, not a disconnect time.</p>`;
}

/* ---------- inventory: pools (image and size mix, scaling plans), application groups, workspaces ---------- */
function renderInventory(inv) {
  const pools = poolRows(state.data.pools || [], state.data.hosts, inv.plans);
  const groups = groupRows(inv.appGroups, state.data.pools || [], inv.workspaces);
  const T = (key, label) => ({ key, label });
  const N = (key, label) => ({ key, label, kind: "n" });
  $("#inventory-out").innerHTML = (inv.errors?.length ? errorBanner(inv.errors) : "")
    + dataTable("inv-pools", "Host pools", [T("name", "Pool"), T("type", "Type"), T("balancer", "Load balancer"), N("max", "Max sessions"), N("hosts", "Hosts"), T("os", "OS builds"), T("sizes", "VM sizes"), T("agents", "Agents"),
      { key: "mix", label: "Mix", html: (r) => `<span class="badge ${r.mix === "Mixed" ? "warn" : "ok"}">${r.mix}</span>` }, T("plans", "Scaling plan")],
      pools.map((p) => ({ name: p.name, type: p.type, balancer: p.balancer, max: poolMax(p.type, p.maxSessions), hosts: p.hosts, os: p.os, sizes: p.sizes, agents: p.agents, mix: p.mixed ? "Mixed" : "Uniform", plans: p.plans || "None", side: `pool:${String(p.id).toLowerCase()}` })), "avd-pools-inventory")
    + dataTable("inv-sched", "Scaling plans and schedules", [T("plan", "Plan"), T("timeZone", "Time zone"), T("pools", "Pools"), T("schedule", "Schedule"), T("days", "Days"), T("rampUp", "Ramp-up"), T("peak", "Peak"), T("rampDown", "Ramp-down"), T("offPeak", "Off-peak"), T("logoff", "At ramp-down")],
      scheduleRows(inv.plans).map((r) => ({ ...r, pools: planPools(inv.plans.find((p) => String(p.id).toLowerCase() === r.planId)), side: `plan:${r.planId}` })), "avd-scaling-schedules")
    + dataTable("inv-maint", "Maintenance windows", [T("name", "Configuration"), T("scope", "Scope"), T("days", "Days"), T("start", "Start"), T("end", "End"), T("length", "Length"), T("timeZone", "Time zone"), N("vms", "VMs"), N("hosts", "AVD hosts"), T("resourceGroup", "Resource group")],
      maintRows(inv.configs, inv.assignments, state.data.hosts))
    + dataTable("inv-groups", "Application groups", [T("name", "Group"), T("kind", "Type"), T("pool", "Pool"), T("workspace", "Workspace"), T("resourceGroup", "Resource group")], groups)
    + dataTable("inv-ws", "Workspaces", [T("name", "Workspace"), T("friendly", "Friendly name"), N("groups", "App groups"), T("resourceGroup", "Resource group")],
      inv.workspaces.map((w) => ({ name: w.name, friendly: w.friendly, groups: countOf(w.groups), resourceGroup: w.resourceGroup })));
}

/** A worker read kept for a minute and shared by everyone who asks, one read at a time (Inventory tab, PIM tab, host drawer). */
/** The in-flight reads by slot. */
const reading = {};
/** The answer for a slot (state.inventory, state.pim): the saved one if under a minute old, else a fresh read. */
async function cachedRead(slot, type) {
  if (state[slot] && Date.now() - state[slot].fetchedAt < 60000) return state[slot];
  reading[slot] ||= send(type, { sample: state.sample }).finally(() => { delete reading[slot]; });
  const res = await reading[slot];
  if (res.ok) state[slot] = res;
  return res;
}
const getInventory = () => cachedRead("inventory", "avd/inventory");

async function loadInventoryTab() {
  const out = $("#inventory-out");
  if (!state.data) { out.innerHTML = `<p class="muted small">Open the Dashboard first so the pools and hosts are read.</p>`; return; }
  if (!state.inventory) out.innerHTML = `<p class="muted small">Reading scaling plans, maintenance windows, application groups and workspaces...</p>`;
  const res = await getInventory();
  if (!res.ok) { out.innerHTML = errorBanner(res.error); return; }
  if (state.tab === "inventory") renderInventory(res);
}

/* ---------- PIM roles: Azure roles held now or open to activation (read when the tab opens, kept for a minute) ---------- */
/** Reads the PIM roles when the tab opens and draws them. */
async function loadPimTab() {
  if (!state.pim) $("#pim-out").innerHTML = `<p class="muted small">Reading your PIM roles...</p>`;
  const res = await cachedRead("pim", "avd/pim");
  if (!res.ok) { $("#pim-out").innerHTML = errorBanner(res.error); return; }
  if (state.tab === "pim") renderPim();
}
/** Role-name pills on the PIM tab: a pill keeps the roles whose name contains the word. */
const PIM_ROLE_WORDS = ["Reader", "Contributor", "Operator"];
/** The PIM tab: Active / Eligible / role-word pills over one table (an eligible role that is switched on shows once, as Active). */
function renderPim() {
  const { rows, errors } = state.pim, f = state.pimFilter;
  const isActive = (r) => r.status.startsWith("Active");
  const hasWord = (r, w) => r.role.toLowerCase().includes(w.toLowerCase());
  const word = PIM_ROLE_WORDS.find((w) => w.toLowerCase() === f);
  const shown = rows.filter((r) => (word ? hasWord(r, word) : f === "all" || (f === "active" ? isActive(r) : !isActive(r))));
  const chip = (id, label, n) => chipHtml(`data-pimf="${id}"`, label, n, f === id, n === 0 && f !== id);
  const day = (iso) => (iso ? new Date(iso).toLocaleDateString() : "No end date");
  const link = linkGroups(state.status.tid).flatMap((g) => g.links).find((l) => l.label === "Activate Azure resource roles");
  const status = (r) => (!isActive(r) && link
    ? `<a class="badge" href="${escapeHtml(link.url)}" target="_blank" rel="noopener" title="Open Privileged Identity Management to activate this role">${escapeHtml(r.status)}</a>`
    : `<span class="badge ${isActive(r) ? "ok" : ""}">${escapeHtml(r.status)}</span>`);
  $("#pim-out").innerHTML = (errors.length ? errorBanner(errors) : "")
    + `<div class="chips">${chip("all", "All", rows.length)}${chip("active", "Active now", rows.filter(isActive).length)}${chip("eligible", "Eligible", rows.filter((r) => !isActive(r)).length)}${PIM_ROLE_WORDS.map((w) => chip(w.toLowerCase(), w, rows.filter((r) => hasWord(r, w)).length)).join("")}</div>`
    + dataTable("pim", "Azure roles", [{ key: "role", label: "Role" }, { key: "scope", label: "Scope" }, { key: "scopeType", label: "Scope type" },
      { key: "status", label: "Status", html: status }, { key: "left", label: "Active for" },
      { key: "eligibleUntil", label: "Eligible until" }, { key: "member", label: "Via" }],
      shown.map((r) => ({ ...r, eligibleUntil: r.isEligible ? day(r.eligibleEnds) : "" })), "avd-pim-roles")
    + `<p class="muted small">Azure resource roles only: Entra directory roles and group roles are managed by a different service and are not shown. To activate a role use ${link ? `<a href="${escapeHtml(link.url)}" target="_blank" rel="noopener">Privileged Identity Management</a>` : "Privileged Identity Management"} in the Azure portal; this page only reads.</p>`;
}

/* ---------- tags: every tag on the hosts' VMs, then the hosts with the picked tag, narrowed by value ---------- */
const tagHosts = () => scopeTo(state.data, state.sub).hosts;
/** The Tags tab: every tag on the hosts' VMs in a table; the picked tag's hosts go under it. */
function renderTagsTab() {
  const out = $("#tags-out");
  if (!state.data) { out.innerHTML = `<p class="muted small">Open the Dashboard first so the pools and hosts are read.</p>`; return; }
  const list = tagList(tagHosts());
  if (!list.length) { out.innerHTML = `<p class="muted small">No tags found on the VMs behind your session hosts.</p>`; return; }
  const N = (key, label) => ({ key, label, kind: "n" });
  out.innerHTML = dataTable("tags-all", "Tags", [{ key: "tag", label: "Tag", html: (r) => `<button type="button" class="poolname" data-tagpick="${escapeHtml(r.tag)}">${escapeHtml(r.tag)}</button>` }, N("hosts", "Hosts"), N("values", "Values"), { key: "summary", label: "Most common values" }], list)
    + `<div id="tags-hosts"></div>`;
  renderTagHosts();
}
/** The hosts with the picked tag: value pills (has the tag, each value, not set) over a host table. */
function renderTagHosts() {
  const el = $("#tags-hosts"), sel = state.tagSel;
  if (!el) return;
  if (!sel.tag) { el.innerHTML = `<p class="muted small">Pick a tag above to list the hosts that have it.</p>`; return; }
  const hosts = tagHosts(), vals = tagValues(hosts, sel.tag), withTag = vals.reduce((a, v) => a + v.n, 0);
  const chip = (mode, value, label, n) => chipHtml(`data-tagmode="${mode}" data-tagval="${escapeHtml(value)}"`, label, n, sel.mode === mode && sel.value.toLowerCase() === value.toLowerCase());
  const title = sel.mode === "none" ? `Hosts without ${sel.tag}` : sel.mode === "value" ? `Hosts with ${sel.tag} = ${sel.value || "(empty)"}` : `Hosts with ${sel.tag}`;
  el.innerHTML = `<div class="chips">${chip("all", "", "Has the tag", withTag)}${vals.map((v) => chip("value", v.value, v.value || "(empty)", v.n)).join("")}${chip("none", "", "Not set", hosts.length - withTag)}</div>`
    + dataTable("tags-hosts-t", title, [{ key: "name", label: "Host" }, { key: "pool", label: "Pool" }, { key: "power", label: "Power", html: (r) => `<span class="badge ${r.power === "running" ? "ok" : ""}">${escapeHtml(r.power)}</span>` },
      { key: "status", label: "AVD status" }, { key: "value", label: "Tag value" }, { key: "sessions", label: "Sessions", kind: "n" }], tagHostRows(hosts, sel.tag, sel.mode, sel.value), "avd-tagged-hosts");
}

/* ---------- Settings: what the signed-in account may do (read from Azure's permission list; nothing is changed) ---------- */
async function checkAccess() {
  const out = $("#access-out");
  if (!state.data) { out.innerHTML = `<p class="muted small">Open the Dashboard first so the pools and hosts are read.</p>`; return; }
  out.innerHTML = `<p class="muted small">Reading your permissions...</p>`;
  const res = await send("avd/access", { scopes: scopesOf([...(state.data.pools || []), ...(state.data.hosts || [])]), sample: state.sample });
  if (!res.ok) { out.innerHTML = errorBanner(res.error); return; }
  const cols = [{ key: "action", label: "You can" }, { key: "can", label: "Allowed", html: (r) => `<span class="badge ${r.can === "Yes" ? "ok" : r.can === "Some" ? "warn" : ""}">${escapeHtml(r.can)}</span>` }, { key: "where", label: "Where" }];
  out.innerHTML = `${dataTable("access", "What your roles allow", cols, res.rows, "avd-your-access")}<p class="muted small">Checked ${res.scopes} resource groups${res.failed ? `, ${res.failed} could not be read` : ""}. This lists your active roles only: a role you still have to activate (PIM) is not counted. Azure can still refuse an action for other reasons, such as a deny assignment, a lock or a conditional access rule, so "Yes" means probably allowed.</p>`;
}
$("#access-check").addEventListener("click", checkAccess);

/* ---------- console: the extension's own log, kept by the worker ---------- */
async function loadConsole() {
  const res = await send("log/get");
  state.log = res.ok ? res.entries || [] : [];
  renderConsole(res.ok ? "" : res.error);
}

function renderConsole(problem = "") {
  const shownEntries = atLevel(state.log || [], $("#log-level").value);
  const rows = [...shownEntries].reverse().map((e) => `<tr><td class="time">${escapeHtml(new Date(e.t).toLocaleTimeString())}</td><td><span class="badge ${e.level === "error" ? "bad" : e.level === "warn" ? "warn" : ""}">${escapeHtml(e.level)}</span></td><td>${escapeHtml(e.source)}</td><td>${escapeHtml(e.message)}${e.detail ? ` <span class="muted">(${escapeHtml(e.detail)})</span>` : ""}</td></tr>`).join("");
  $("#log-out").innerHTML = (problem ? `<div class="banner bad">${escapeHtml(problem)}</div>` : "")
    + `<div class="tablewrap"><table><thead><tr><th>Time</th><th>Level</th><th>Source</th><th>Message</th></tr></thead><tbody>${rows || `<tr><td colspan="4" class="empty">Nothing logged yet.</td></tr>`}</tbody></table></div>`;
}

/* ---------- links and settings ---------- */
function renderLinks() {
  $("#link-groups").innerHTML = linkGroups(state.status.tid).map((g) => `<div class="link-group"><h2>${escapeHtml(g.title)}</h2>${
    g.links.map((l) => `<a href="${escapeHtml(l.url)}" target="_blank" rel="noopener">${escapeHtml(l.label)}</a>`).join("")}</div>`).join("");
}

async function renderSettings() {
  const s = await send("status/get");
  state.status = s.ok ? s : state.status;
  const on = !!state.status.consented;
  $("#consent-on").hidden = on;
  $("#consent-off").hidden = !on;
  $("#off-banner").hidden = on;
  $("#interval").value = String(state.interval);
  $("#rate").value = state.rate || "";
  renderCardSlots();
  $("#bg").value = String((await chrome.storage.local.get(BG_KEY).catch(() => ({})))[BG_KEY] || 0);
  $("#status-line").textContent = !state.status.consented ? "Sign-in reuse is off."
    : state.status.signedIn ? `Signed in as ${state.status.upn || "unknown"} (tenant ${state.status.tid || "unknown"}).` : "On, but no Azure sign-in found yet. Open the Azure portal.";
}

/* ---------- demo on sample data (reopens this page with or without ?sample=1, as in Intune Enhancer) ---------- */
function toggleDemo() {
  const url = new URL(location.href);
  if (state.sample) url.searchParams.delete("sample");
  else url.searchParams.set("sample", "1");
  location.assign(url.href);
}
{
  const demo = $("#demo-toggle");
  demo.classList.toggle("on", state.sample);
  if (state.sample) { $("#demo-text").textContent = "Leave demo"; demo.title = "Back to your own tenant"; }
  demo.addEventListener("click", toggleDemo);
}

/* ---------- reset display settings (consent and your Azure data are kept) ---------- */
async function resetDefaults() {
  if (!confirm("Reset AVD Enhancer's display settings to their defaults?\n\nThe theme, stars, auto-refresh, subscription choice and filters go back to how they were at install. Turning the extension on or off is not changed.")) return;
  try { localStorage.removeItem("avd.theme"); } catch { /* storage unavailable */ }
  await chrome.storage.local.remove(PREFS_KEY).catch(() => {});
  location.assign(location.pathname);
}

/** The four custom card slots in Settings: what each shows, and for a tag card the tag name and optional value. */
function renderCardSlots() {
  const opts = (sel) => `<option value="">- empty -</option>${CARD_METRICS.map(([id, label]) => `<option value="${id}"${sel === id ? " selected" : ""}>${escapeHtml(label)}</option>`).join("")}<option value="tag"${sel === "tag" ? " selected" : ""}>Hosts with a tag...</option>`;
  $("#cards-slots").innerHTML = state.cards.map((c, i) => `<div class="cardslot"><span class="muted small">Card ${i + 1}</span><select data-slot="${i}" data-cf="kind" aria-label="Card ${i + 1} shows">${opts(c.kind)}</select>${c.kind === "tag"
    ? `<input type="text" list="known-tags" data-slot="${i}" data-cf="tag" value="${escapeHtml(c.tag)}" placeholder="Tag name" aria-label="Card ${i + 1} tag name"><input type="text" data-slot="${i}" data-cf="value" value="${escapeHtml(c.value)}" placeholder="Value (optional)" aria-label="Card ${i + 1} tag value">` : ""}</div>`).join("");
  $("#known-tags").innerHTML = state.data ? tagList(state.data.hosts).map((t) => `<option value="${escapeHtml(t.tag)}">`).join("") : "";
}
$("#cards-slots").addEventListener("change", async (e) => {
  const i = Number(e.target.dataset.slot), field = e.target.dataset.cf;
  if (!(i >= 0) || !field) return;
  state.cards[i] = { ...state.cards[i], [field]: e.target.value };
  state.cards = cleanCards(state.cards);
  await savePrefs();
  if (field === "kind") renderCardSlots();
  if (state.view) renderCards();
});

const savePrefs = () => chrome.storage.local.set({ [PREFS_KEY]: { interval: state.interval, sub: state.sub, cols: state.cols, views: state.views, rate: state.rate, cards: state.cards, starredTabs: [...state.starredTabs], starredOnly: state.starredOnly } }).catch(() => {});

/* ---------- sidebar stars (as in Intune Enhancer): a star beside each tool, and "Starred only" ---------- */
const STAR_SVG = '<svg class="star-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.85 5.95 6.55.85-4.8 4.55 1.2 6.5L12 17.35l-5.8 3.1 1.2-6.5-4.8-4.55 6.55-.85z"/></svg>';
/** The hover text of a tool's star. */
const starTitle = (on) => (on ? "Starred: click to unstar" : "Star this tool");
/** Each tool's star, and the "Starred only" pill (it hides nothing until at least one tool is starred). */
function renderTabStars() {
  for (const btn of document.querySelectorAll('.tabs [role="tab"]')) {
    const on = state.starredTabs.has(btn.dataset.tab);
    const star = btn.querySelector(".star");
    star.classList.toggle("on", on);
    star.title = starTitle(on);
  }
  const filter = $("#star-filter");
  filter.setAttribute("aria-pressed", String(state.starredOnly));
  filter.title = state.starredTabs.size ? "Show only the starred tools" : "Star a tool (the star beside its name) to use this";
  $(".tabs").classList.toggle("starred-only", state.starredOnly && state.starredTabs.size > 0);
}
/** Star or unstar a tool, shown at once and then saved. */
function toggleTabStar(tab) {
  if (state.starredTabs.has(tab)) state.starredTabs.delete(tab); else state.starredTabs.add(tab);
  renderTabStars();
  savePrefs();
}
/** Switches the "Starred only" pill on or off and saves it. */
function toggleStarredOnly() {
  state.starredOnly = !state.starredOnly;
  renderTabStars();
  savePrefs();
}
// A span, not a button: a button cannot sit inside the tab button.
for (const btn of document.querySelectorAll('.tabs [role="tab"]')) btn.insertAdjacentHTML("beforeend", `<span class="star" title="${starTitle(false)}">${STAR_SVG}</span>`);
$("#star-filter").insertAdjacentHTML("afterbegin", STAR_SVG);

/* ---------- "Try Intune Enhancer" at the foot of the sidebar: opens the store page that matches this browser ---------- */
const tryStore = intuneStore(navigator.userAgent);
$("#try-intune").href = tryStore.url;
$("#try-intune").title = `Intune Enhancer in the ${tryStore.name} (opens in a new tab)`;

/* ---------- wiring ---------- */
document.addEventListener("click", (e) => {
  const star = e.target.closest(".tabs .star");
  if (star) return void toggleTabStar(star.closest("[data-tab]").dataset.tab);
  if (e.target.closest("#star-filter")) return void toggleStarredOnly();
  const row = e.target.closest("tr[data-host]");
  if (row && !e.target.closest("a")) return void openDrawer(row.dataset.host);
  const t = e.target.closest("[data-tab],[data-tile],[data-chip],[data-sort],[data-psort],[data-tsort],[data-xfor],[data-go],[data-demo],[data-tagpick],[data-tagmode],[data-pimf],[data-side]");
  if (!t) return;
  const d = t.dataset;
  if (d.tab) showTab(d.tab);
  else if (d.side) openSide(d.side);
  else if (d.tile) onTile(d.tile);
  else if (d.chip) { state.chip = d.chip; renderHosts(); }
  else if (d.tagpick !== undefined) { state.tagSel = { tag: d.tagpick, mode: "all", value: "" }; renderTagHosts(); }
  else if (d.tagmode) { state.tagSel = { ...state.tagSel, mode: d.tagmode, value: d.tagval }; renderTagHosts(); }
  else if (d.pimf) { state.pimFilter = d.pimf; renderPim(); }
  else if (d.xfor) doExport(t);
  else if (d.tsort) { const [id, key] = d.tsort.split("|"); const tb = tables[id]; tb.sort = { key, dir: tb.sort?.key === key && tb.sort.dir === "asc" ? "desc" : "asc" }; refreshTable(id); }
  else if (d.psort) { state.poolSort = { key: d.psort, dir: state.poolSort.key === d.psort && state.poolSort.dir === "asc" ? "desc" : "asc" }; renderPools(); }
  else if (d.sort) { state.sort = { key: d.sort, dir: state.sort.key === d.sort && state.sort.dir === "asc" ? "desc" : "asc" }; renderHosts(); }
  else if (d.go) { e.preventDefault(); showTab(d.go); }
  else if (d.demo !== undefined) { e.preventDefault(); toggleDemo(); }
});
$("#refresh").addEventListener("click", refresh);
$("#scan").addEventListener("click", scanSessions);
$("#log-level").addEventListener("change", () => renderConsole());
$("#log-refresh").addEventListener("click", loadConsole);
$("#log-clear").addEventListener("click", async () => { await send("log/clear"); await loadConsole(); });
$("#log-save").addEventListener("click", () => saveFile("txt", formatLog(atLevel(state.log || [], $("#log-level").value)), "text/plain", "avd-console"));
$("#log-copy").addEventListener("click", async () => {
  const btn = $("#log-copy");
  try { await navigator.clipboard.writeText(formatLog(atLevel(state.log || [], $("#log-level").value))); btn.textContent = "Copied"; } catch { btn.textContent = "Copy failed"; }
  setTimeout(() => { btn.textContent = "Copy"; }, 1500);
});
// This page's own script errors go to the Console too.
window.addEventListener("error", (e) => send("log/add", { level: "error", message: e.message || "Script error", detail: `${(e.filename || "").split("/").pop()}:${e.lineno || ""}` }));
window.addEventListener("unhandledrejection", (e) => send("log/add", { level: "error", message: `Unhandled: ${e.reason?.message || e.reason}` }));
$("#page-html").addEventListener("click", () => saveFile("html", docHtml(pageDoc()), "text/html", "avd-dashboard"));
$("#page-md").addEventListener("click", async () => {
  const b = $("#page-md");
  try { await navigator.clipboard.writeText(docMarkdown(pageDoc())); b.textContent = "Copied"; } catch { b.textContent = "Copy failed"; }
  setTimeout(() => { b.textContent = "Copy Markdown"; }, 1500);
});
$("#colpick-list").addEventListener("change", (e) => {
  const key = e.target.dataset.col;
  if (!key) return;
  const on = new Set(visibleColumns(state.cols).map((c) => c.key));
  if (e.target.checked) on.add(key); else on.delete(key);
  state.cols = on.size >= COLUMNS.length ? [] : [...on];
  savePrefs();
  renderHosts();
});
$("#views-list").addEventListener("click", (e) => {
  const b = e.target.closest("button");
  if (!b) return;
  if (b.dataset.view !== undefined) {
    const v = state.views.find((x) => x.name === b.dataset.view);
    if (v) applyView(v.hash);
    $("#viewmenu").open = false;
  } else if (b.dataset.viewdel !== undefined) {
    state.views = removeView(state.views, b.dataset.viewdel);
    savePrefs(); renderViews();
  } else if (b.id === "view-save") {
    const name = (prompt("Name for this view (it keeps the filters, search, sort, columns and subscription)") || "").trim();
    if (!name) return;
    state.views = saveView(state.views, { name, hash: viewToHash({ ...state, tab: "dashboard" }) });
    savePrefs(); renderViews(); $("#viewmenu").open = false;
  }
});
$("#poolq").addEventListener("input", (e) => { state.poolQ = e.target.value; renderPools(); });
$("#reset").addEventListener("click", resetDefaults);
document.addEventListener("keydown", (e) => {
  if (e.ctrlKey || e.metaKey || e.altKey || /^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName) || state.tab !== "dashboard") return;
  if (e.key === "/") { e.preventDefault(); $("#search").focus(); }
  else if (e.key === "r") refresh();
});
$("#drawer-close").addEventListener("click", closeDrawer);
/* Dropdown menus (Columns, Export, Saved views) close on a click anywhere outside them, and on Escape. */
const closeMenus = (except) => document.querySelectorAll("details.colpick[open]").forEach((d) => { if (!except || !d.contains(except)) d.open = false; });
document.addEventListener("click", (e) => closeMenus(e.target));
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenus(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });
$("#bg").addEventListener("change", (e) => chrome.storage.local.set({ [BG_KEY]: Number(e.target.value) || 0 }).catch(() => {}));
$("#rate").addEventListener("change", async (e) => {
  state.rate = Number(e.target.value) > 0 ? Number(e.target.value) : 0;
  await savePrefs();
  if (state.data) renderTiles();
});
$("#sub").addEventListener("change", async (e) => {
  state.sub = e.target.value; state.pool = ""; state.chip = "all";
  await savePrefs();
  renderDashboard();
});
$("#search").addEventListener("input", (e) => { state.q = e.target.value; renderHosts(); });
for (const [id, on] of [["#consent-on", true], ["#consent-off", false]]) {
  $(id).addEventListener("click", async () => { await send("consent/set", { on }); await renderSettings(); renderWho(); });
}

/* ---------- theme (theme-init.js has already applied the saved theme) ---------- */
function syncThemeButton() {
  const label = document.documentElement.dataset.theme === "dark" ? "Switch to light theme" : "Switch to dark theme";
  const btn = $("#theme-toggle");
  btn.setAttribute("aria-label", label);
  btn.title = label;
}
$("#theme-toggle").addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem("avd.theme", next); } catch { /* storage unavailable: still switches for this visit */ }
  syncThemeButton();
});
syncThemeButton();
$("#app-version").textContent = ` (v${chrome.runtime.getManifest?.().version || ""})`;
$("#interval").addEventListener("change", async (e) => {
  state.interval = Number(e.target.value) || 0;
  await savePrefs();
  schedule();
});
chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes["avd.consent"]) refresh(); });

(async function init() {
  const saved = (await chrome.storage.local.get(PREFS_KEY).catch(() => ({})))[PREFS_KEY];
  state.interval = Number(saved?.interval) || 0;
  state.sub = String(saved?.sub || "");
  state.cols = Array.isArray(saved?.cols) ? saved.cols : [];
  state.rate = Number(saved?.rate) > 0 ? Number(saved.rate) : 0;
  state.views = cleanViews(saved?.views);
  state.cards = cleanCards(saved?.cards);
  state.starredTabs = new Set((Array.isArray(saved?.starredTabs) ? saved.starredTabs : []).filter((t) => TABS.includes(t)));
  state.starredOnly = saved?.starredOnly === true;
  renderTabStars();
  const v = hashToView(location.hash);
  Object.assign(state, { pool: v.pool, chip: v.chip, q: v.q, sort: v.sort });
  if (v.cols.length) state.cols = v.cols;
  if (v.sub) state.sub = v.sub;
  $("#search").value = v.q;
  showTab(v.tab);
  schedule();
  await refresh();
  if (!state.status.consented && !state.sample && location.hash === "") showTab("settings");
})();
