// The Azure clouds the extension can work in. Commercial is built in; Azure Government is optional (the admin grants
// its hosts from Settings as optional host permissions). Every host the extension may talk to is listed here, in one place.

export const DEFAULT_CLOUD = "commercial";

export const CLOUDS = {
  commercial: { armHost: "management.azure.com", portalHost: "portal.azure.com" },
  gov: { armHost: "management.usgovcloudapi.net", portalHost: "portal.azure.us" },
};

export const ARM_HOSTS = Object.values(CLOUDS).map((c) => c.armHost);

/** Token audiences (hosts or the older core.windows.net names) that mean "Azure Resource Manager". */
export const ARM_AUDIENCES = [
  "https://management.azure.com", "https://management.core.windows.net",
  "https://management.usgovcloudapi.net", "https://management.core.usgovcloudapi.net",
];

/** The cloud a portal host belongs to (commercial unless it is the Government portal). */
export const cloudForPortal = (host) => (host === CLOUDS.gov.portalHost ? "gov" : DEFAULT_CLOUD);
