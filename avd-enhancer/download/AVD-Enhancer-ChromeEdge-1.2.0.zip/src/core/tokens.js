// Pool of Azure Resource Manager access tokens read from the portal's sign-in cache. Held in memory and mirrored to
// chrome.storage.session (RAM only, cleared when the browser closes) so a sleeping service worker can pick them up
// again. Never written to disk, never sent anywhere but the ARM host (see core/arm.js).

import { ARM_AUDIENCES, DEFAULT_CLOUD, cloudForPortal } from "./clouds.js";

const MAX_TOKENS = 6;
const SESSION_KEY = "avd.tokens";
const IAT_SKEW_S = 300; // a token issued further in the future than this is not a real one

function decodeJwt(jwt) {
  try {
    const part = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(part), (c) => c.charCodeAt(0))));
  } catch {
    return null;
  }
}

/** Claims of a real ARM access token: ARM audience, tenant, numeric expiry, issue time not in the future. */
export const looksReal = (c, nowS = Date.now() / 1000) => Boolean(c?.tid) && Number.isFinite(c.exp)
  && ARM_AUDIENCES.some((a) => c.aud === a || c.aud === `${a}/`) && !(Number(c.iat) > nowS + IAT_SKEW_S);

export function createTokenPool() {
  /** token -> { exp, tid, upn, cloud } (claims decoded once, on add) */
  const pool = new Map();

  const ready = chrome.storage.session.get(SESSION_KEY).then((v) => {
    for (const [token, meta] of v[SESSION_KEY] || []) pool.set(token, meta);
  }).catch(() => {});

  const persist = () => chrome.storage.session.set({ [SESSION_KEY]: [...pool.entries()] }).catch(() => {});

  function prune(now = Date.now()) {
    for (const [token, meta] of pool) if (meta.exp * 1000 < now + 60000) pool.delete(token);
  }

  return {
    ready,
    get size() { prune(); return pool.size; },

    /** The signed-in identity (newest token), or null. */
    get identity() {
      prune();
      const newest = [...pool.values()].sort((a, b) => b.exp - a.exp)[0];
      return newest ? { tid: newest.tid, upn: newest.upn, cloud: newest.cloud } : null;
    },
    get cloud() { return this.identity?.cloud || DEFAULT_CLOUD; },

    /** portalHost: the portal host that held the token; it picks the cloud. Returns true when the token was kept. */
    add(token, portalHost = "") {
      const claims = decodeJwt(token);
      if (!looksReal(claims)) return false;
      pool.set(token, { exp: claims.exp, tid: claims.tid, upn: claims.upn || claims.unique_name || "", cloud: cloudForPortal(portalHost) });
      prune();
      while (pool.size > MAX_TOKENS) pool.delete([...pool.entries()].sort((a, b) => a[1].exp - b[1].exp)[0][0]);
      persist();
      return true;
    },

    /** Tokens for the signed-in tenant, longest-lived first (the portal can cache more than one tenant). */
    candidates() {
      prune();
      const tid = this.identity?.tid;
      return [...pool.entries()].filter(([, m]) => m.tid === tid).sort((a, b) => b[1].exp - a[1].exp).map(([t]) => t);
    },

    clear() { pool.clear(); persist(); },
  };
}
