// Reports tabs: charts and tables built from the hosts the Dashboard already read (core/reports.js builds each report; Coverage also uses the
// Inventory read), with Copy Markdown and Save HTML for each, and the All reports tab: the reports in AVD Enhancer and links to Azure's own reports.
// The report tabs and panels are made here from REPORTS, so a new report is one entry there and one builder.

import { esc } from "../core/host-table.js";
import { reportGroups } from "../data/links.js";
import { REPORTS, buildReport } from "../core/reports.js";
import { chartHtml } from "../core/charts.js";
import { lookupPrices, priceKey, cleanCurrency } from "../core/prices.js";
import { docHtml, docMarkdown } from "../core/report-doc.js";
import { $, state, dataTable, saveFile, registerTab, send, scopeName, groupsHtml, copyWith, getInventory, showReadError } from "./core.js";

/** The report documents last drawn, by tab name (what Copy Markdown and Save HTML write). */
const docs = {};
/** The Inventory read each Coverage-style report last drew from (its fetchedAt), so a newer read redraws it. */
const drawnWith = {};
/** The hourly prices looked up so far ("size|region": price), the pairs Microsoft had no price for or could not be asked (not asked again until the page reloads), and whether a lookup is running. */
const prices = {};
const priceTried = new Set();
let pricing = false;
/** The currency the prices held were asked for. */
let pricesIn = "";
/** The currency prices are shown in (the Settings pick, USD by default); the prices held are dropped when it changes, so no price is ever shown under the wrong currency. */
function currency() {
  const c = cleanCurrency(state.priceCurrency) || "USD";
  if (c !== pricesIn) { for (const k of Object.keys(prices)) delete prices[k]; priceTried.clear(); pricesIn = c; }
  return c;
}

/** The headline facts as tiles: the Dashboard's tile look, but plain boxes (nothing to click). */
const tilesHtml = (headline) => `<div class="tiles">${headline.map((h) => `<div class="tile ${/^(ok|warn|bad|off)$/.test(h.cls || "") ? h.cls : "off"}"><div class="label" title="${esc(h.label)}">${esc(h.label)}</div><div class="big">${esc(h.value)}</div>${h.small ? `<div class="small">${esc(h.small)}</div>` : ""}</div>`).join("")}</div>`;

/** Draws one report into its tab from the data in hand. */
function drawReport(tab) {
  const doc = buildReport(tab, { hosts: state.view.hosts, pools: state.view.summary.pools, inventory: state.inventory || null, rate: state.rate, scope: scopeName(), prices, currency: currency() });
  if (!doc) return;
  docs[tab] = doc;
  drawnWith[tab] = state.inventory?.fetchedAt;
  const sections = doc.sections.map((s, i) => {
    const cols = s.head.map((label, k) => ({ key: String(k), label, kind: /^(Sessions|Hosts|Hosts on|Capacity|Running|Idle|Used)$/.test(label) ? "n" : undefined }));
    const rows = s.cells.map((r) => Object.fromEntries(r.map((v, k) => [String(k), v])));
    return `<div class="card">${dataTable(`${tab}-t${i}`, s.title, cols, rows, `avd-${tab}-${i}`)}${s.note ? `<p class="muted small">${esc(s.note)}</p>` : ""}</div>`;
  }).join("");
  $(`#${tab}-out`).innerHTML = `<p class="muted small">${esc(doc.subtitle)}</p>${tilesHtml(doc.headline)}`
    + `<div class="chart-grid">${doc.charts.map((c) => `<div class="card"><h2>${esc(c.title)}</h2>${chartHtml(c)}</div>`).join("")}</div>${sections}`;
}

/** Looks up the prices of the VM sizes in view (Size and cost), once each, and redraws the tab when they arrive. A failure goes to the browser console and the Console tab. */
async function loadPrices(tab) {
  currency();
  if (pricing || !state.view) return;
  const pairs = state.view.hosts.filter((h) => h.size && h.region && !(priceKey(h.size, h.region) in prices) && !priceTried.has(priceKey(h.size, h.region))).map((h) => ({ size: h.size, region: h.region }));
  if (!pairs.length) return;
  pricing = true;
  if (!$(`#${tab}-out .price-note`)) $(`#${tab}-out`).insertAdjacentHTML("afterbegin", `<p class="muted small price-note">Looking up prices from Microsoft...</p>`);
  const asked = currency();
  const res = await lookupPrices(pairs, prices, asked).finally(() => { pricing = false; });
  if (currency() !== asked) { if (state.tab === tab && state.view) drawReport(tab); return loadPrices(tab); }
  Object.assign(prices, res.prices);
  for (const f of res.failed) {
    priceTried.add(f.key);
    console.error(`AVD Enhancer: price lookup failed for ${f.key}: ${f.error}`);
    send("log/add", { level: "warn", message: `Price lookup failed for ${f.key}: ${f.error}` });
  }
  if (state.tab === tab && state.view) drawReport(tab);
  loadPrices(tab);
}

/** Draws a report's tab: says what to do first when the hosts have not been read; Coverage also reads the Inventory (shown while it reads, redrawn when a newer read arrives). */
export function renderReport(tab = state.tab) {
  const meta = REPORTS.find((r) => r.tab === tab);
  const out = $(`#${tab}-out`);
  if (!meta || !out) return;
  if (!state.view) { out.innerHTML = `<p class="muted small">Open the <a href="#" data-go="dashboard">Dashboard</a> first so the pools and hosts are read.</p>`; return; }
  if (!meta.needsInventory) { drawReport(tab); if (meta.needsPrices) loadPrices(tab); return; }
  if (state.inventory) drawReport(tab); else out.innerHTML = `<p class="muted small">Reading scaling plans and maintenance windows...</p>`;
  getInventory().then((res) => {
    if (state.tab !== tab) return;
    if (showReadError(out, res)) return;
    if (res.fetchedAt !== drawnWith[tab]) drawReport(tab);
  });
}

/** Redraws the open report (after a refresh reads new hosts). */
export const refreshReport = () => { if (state.tab.startsWith("rep-")) renderReport(state.tab); };

document.addEventListener("click", async (e) => {
  const btn = e.target.closest("[data-repdoc]");
  if (!btn || !docs[btn.dataset.repdoc]) return;
  const doc = docs[btn.dataset.repdoc];
  if (btn.dataset.repfmt === "html") return void saveFile("html", docHtml(doc), "text/html", `avd-${btn.dataset.repdoc}`);
  await copyWith(btn, docMarkdown(doc));
});

/** The All reports tab: this extension's own reports, then Azure's (the addresses are unchecked, so the tab says so). */
function renderAllReports() {
  $("#reports-own").innerHTML = REPORTS.map((r) => `<div class="report-item"><button type="button" class="poolname report-open" data-tab="${esc(r.tab)}">${esc(r.label)}</button><span class="muted small"> ${esc(r.blurb)}</span></div>`).join("");
  $("#reports-azure").innerHTML = groupsHtml(reportGroups(state.status.tid));
}

/* The sidebar buttons (after All reports, in REPORTS order) and the panels. */
let after = $("#tabbtn-all-reports");
for (const r of REPORTS) {
  after.insertAdjacentHTML("afterend", `<button role="tab" id="tabbtn-${r.tab}" aria-controls="tab-${r.tab}" data-tab="${r.tab}">${esc(r.label)}</button>`);
  $("#tab-all-reports").insertAdjacentHTML("beforebegin", `<section id="tab-${r.tab}" class="panel" role="tabpanel" aria-labelledby="tabbtn-${r.tab}" hidden>
      <div class="scoperow"><div class="intro"><h1>${esc(r.label)}</h1><p>${esc(r.intro)} Built from data the extension already reads; nothing is changed.</p></div>
        <div class="pagebtns"><button type="button" class="export" data-repdoc="${r.tab}" data-repfmt="md" title="This report as Markdown">Copy Markdown</button><button type="button" class="export" data-repdoc="${r.tab}" data-repfmt="html" title="This report as one HTML page that prints">Save HTML</button></div></div>
      <div id="${r.tab}-out"></div>
    </section>`);
  after = $(`#tabbtn-${r.tab}`);
  registerTab(r.tab, () => renderReport(r.tab));
}
registerTab("all-reports", renderAllReports);
