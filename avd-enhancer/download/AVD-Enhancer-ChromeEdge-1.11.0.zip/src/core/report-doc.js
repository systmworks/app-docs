// The whole Dashboard as one printable report: { title, subtitle, headline: [{ label, value }], sections: [{ title, head: [labels],
// cells: [[text]], note }] }, written as Markdown or as one self-contained HTML page. The HTML looks like the Workspace in its
// light theme (white page, lightly tinted cards and tables) whatever theme the workspace is in, and prints; the browser's Print saves it as a PDF.
// Pure (no DOM), so the offline tests cover it.

import { esc } from "./host-table.js";

const mdCell = (s) => String(s ?? "").replace(/\s*\r?\n\s*/g, " ").replace(/\|/g, "\\|");

/** The report as Markdown: title, subtitle, headline facts, one table per section. */
export function docMarkdown(doc) {
  const md = [`# ${doc.title}`, "", ...(doc.subtitle ? [doc.subtitle, ""] : []), ...(doc.headline || []).map((h) => `- ${h.label}: ${h.value}`)];
  for (const s of doc.sections) {
    md.push("", `## ${s.title}`, "");
    if (s.cells.length) md.push(`| ${s.head.map(mdCell).join(" | ")} |`, `|${"---|".repeat(s.head.length)}`, ...s.cells.map((r) => `| ${s.head.map((_, i) => mdCell(r[i])).join(" | ")} |`));
    else md.push("None.");
    if (s.note) md.push("", s.note);
  }
  return md.join("\n") + "\n";
}

/** The report as one HTML page that looks like the Workspace in its light theme (white page, lightly tinted cards and tables, tile top borders in the tile colours); opens anywhere and prints (all text escaped). */
export function docHtml(doc) {
  const tile = (h) => `<div class="tile ${/^(ok|warn|bad|off)$/.test(h.cls || "") ? h.cls : "off"}"><div class="l">${esc(h.label)}</div><div class="v">${esc(h.value)}</div>${h.small ? `<div class="s">${esc(h.small)}</div>` : ""}</div>`;
  const sections = doc.sections.map((s) => `<section><h2>${esc(s.title)}</h2>${s.cells.length
    ? `<table><thead><tr>${s.head.map((h) => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${s.cells.map((r) => `<tr>${s.head.map((_, i) => `<td>${esc(r[i])}</td>`).join("")}</tr>`).join("")}</tbody></table>`
    : "<p>None.</p>"}${s.note ? `<p class="note">${esc(s.note)}</p>` : ""}</section>`).join("");
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${esc(doc.title)}</title><style>
:root{--fg:#10203c;--muted:#46628a;--line:#aec7ea;--soft:#dbe9fb;--tint:#e9f1fc;--card:#f4f8fe;--accent:#175cd3;--ok:#0a8446;--warn:#a16207;--bad:#dc2626;color-scheme:light}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font:13px/1.4 system-ui,"Segoe UI",sans-serif;margin:24px auto;max-width:1200px;padding:0 16px;background:#fff;color:var(--fg)}
.brand{font-weight:700;color:var(--accent);font-size:15px;padding-bottom:8px;border-bottom:1px solid var(--line)}
h1{font-size:22px;margin:14px 0 0}h2{font-size:15px;margin:0 0 8px;color:var(--accent)}.sub,.note{color:var(--muted)}.note{font-size:12px;margin:8px 0 0}
.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:12px;margin:16px 0}
.tile{text-align:center;background:var(--tint);border:1px solid var(--line);border-top:4px solid var(--muted);border-radius:10px;padding:10px 12px 8px;break-inside:avoid}
.tile.ok{border-top-color:var(--ok)}.tile.warn{border-top-color:var(--warn)}.tile.bad{border-top-color:var(--bad)}
.tile .l,.tile .s{color:var(--muted);font-size:12px}.tile .v{font-size:32px;font-weight:600;line-height:1.1;margin:2px 0}
section{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin:14px 0}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:4px 10px 4px 8px;border-bottom:1px solid #d3e2f6;vertical-align:top}
th{background:var(--soft);color:var(--muted);font-size:12px;font-weight:600;border-bottom:1px solid var(--line)}tbody tr:nth-child(even) td{background:var(--tint)}
thead{display:table-header-group}tr{break-inside:avoid}.foot{margin:18px 0 0;font-size:12px;color:var(--muted);text-align:center}
@page{margin:12mm}@media print{body{margin:0;max-width:none}}
</style></head><body><div class="brand">AVD Enhancer</div><h1>${esc(doc.title)}</h1>${doc.subtitle ? `<p class="sub">${esc(doc.subtitle)}</p>` : ""}<div class="tiles">${(doc.headline || []).map(tile).join("")}</div>${sections}<p class="foot">Created with AVD Enhancer.</p></body></html>
`;
}
