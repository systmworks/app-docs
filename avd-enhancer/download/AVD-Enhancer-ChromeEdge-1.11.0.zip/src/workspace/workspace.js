// Workspace page: Dashboard (tiles + host table), Links, Settings. Talks to the service worker only (README rule 5).

import { hashToView, cleanViews } from "../core/host-table.js";
import { intuneStore } from "../data/links.js";
import { cleanCards } from "../core/tags.js";
import { $, TABS, PREFS_KEY, state, send, errorHtml, doExport, tables, refreshTable, showTab, savePrefs } from "./core.js";
import { closeDrawer, renderHosts, renderDrawer, drawerHost, renderDashboard, renderPools, openDrawer, onTile } from "./dashboard.js";
import { renderSide, openSide, loadInventoryTab } from "./inventory.js";
import { renderTagsTab, renderTagHosts, renderPim } from "./tags-pim.js";
import { toggleDemo, renderSettings } from "./settings.js";
import { setupThemePicker } from "./themes.js";

/* ---------- data ---------- */
let refreshSeq = 0; // the newest refresh wins: an older answer that arrives after a newer refresh started is dropped
async function refresh() {
  const seq = ++refreshSeq;
  const status = await send("status/get");
  if (seq !== refreshSeq) return;
  $("#refresh").disabled = false; // an older refresh may have left it off; this one decides below
  state.status = status.ok ? status : { consented: false, signedIn: false };
  renderWho();
  if (!state.sample && !state.status.consented) return renderNotice("off");
  if (!state.sample && !state.status.signedIn) return renderNotice("signin");
  $("#refresh").disabled = true;
  const res = await send("avd/overview", { sample: state.sample });
  if (seq !== refreshSeq) return; // a newer refresh is running and will re-enable the button
  $("#refresh").disabled = false;
  if (!res.ok) return renderNotice("error", res.error);
  state.data = res;
  renderNotice(state.sample ? "sample" : "");
  renderDashboard();
  if (state.drawer) renderDrawer(drawerHost()?.sessions ? undefined : []);
  if (state.side) renderSide();
  if (state.tab === "tags") renderTagsTab();
  if (state.tab === "inventory") loadInventoryTab(); // opened from a bookmark before the overview had arrived
}

function schedule() {
  clearInterval(state.timer);
  if (state.interval > 0) state.timer = setInterval(() => { if (document.visibilityState === "visible" && state.tab === "dashboard") refresh(); }, state.interval * 1000);
}

/* ---------- dashboard ---------- */
function renderWho() {
  const s = state.status;
  $("#who").textContent = s.signedIn ? `${s.upn || "Signed in"} (Azure)` : "";
  const dot = $("#session");
  dot.className = `session${s.signedIn ? " live" : s.consented ? " none" : ""}`;
  dot.title = s.signedIn ? "Signed in to Azure" : s.consented ? "On, but no Azure sign-in found: open the Azure portal" : "Turned off";
}

function renderNotice(kind, message = "") {
  const box = $("#notice");
  const msgs = {
    off: `Sign-in reuse is off. <a href="#" data-go="settings">Turn it on in Settings</a>, or <a href="#" data-demo="1">try the demo</a>.`,
    signin: `No Azure sign-in found yet. Open the <a href="https://portal.azure.com" target="_blank" rel="noopener">Azure portal</a> (signed in), then press Refresh. Or <a href="#" data-demo="1">try the demo</a>.`,
    sample: `Showing sample data, not your tenant. <a href="#" data-demo="1">Leave demo</a>.`,
    error: errorHtml(message),
  };
  box.hidden = !kind;
  box.className = `banner${kind === "error" ? " bad" : ""}`;
  box.innerHTML = msgs[kind] || "";
  if (kind === "off" || kind === "signin" || kind === "error") { $("#tiles").innerHTML = ""; $("#pools").hidden = true; $("#hosts").hidden = true; $("#scoperow").hidden = true; $("#cards-row").hidden = true; }
}

/* ---------- sidebar stars (as in Intune Enhancer): a star beside each tool, and "Starred only" ---------- */
const STAR_SVG = '<svg class="star-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.85 5.95 6.55.85-4.8 4.55 1.2 6.5L12 17.35l-5.8 3.1 1.2-6.5-4.8-4.55 6.55-.85z"/></svg>';
/** The hover text of a tool's star. */
const starTitle = (on) => (on ? "Starred: click to unstar" : "Star this tool");
/** Each tool's star, and the "Starred only" pill (it hides nothing until at least one tool is starred). */
function renderTabStars() {
  for (const btn of document.querySelectorAll('.tabs [role="tab"]')) {
    const on = state.starredTabs.has(btn.dataset.tab);
    const star = btn.querySelector(".star");
    star.classList.toggle("on", on);
    star.title = starTitle(on);
  }
  const filter = $("#star-filter");
  filter.setAttribute("aria-pressed", String(state.starredOnly));
  filter.title = state.starredTabs.size ? "Show only the starred tools" : "Star a tool (the star beside its name) to use this";
  $(".tabs").classList.toggle("starred-only", state.starredOnly && state.starredTabs.size > 0);
}
/** Star or unstar a tool, shown at once and then saved. */
function toggleTabStar(tab) {
  if (state.starredTabs.has(tab)) state.starredTabs.delete(tab); else state.starredTabs.add(tab);
  renderTabStars();
  savePrefs();
}
/** Switches the "Starred only" pill on or off and saves it. */
function toggleStarredOnly() {
  state.starredOnly = !state.starredOnly;
  renderTabStars();
  savePrefs();
}
// A span, not a button: a button cannot sit inside the tab button.
for (const btn of document.querySelectorAll('.tabs [role="tab"]')) btn.insertAdjacentHTML("beforeend", `<span class="star" title="${starTitle(false)}">${STAR_SVG}</span>`);
$("#star-filter").insertAdjacentHTML("afterbegin", STAR_SVG);

/* ---------- tool tabs: Up and Down move through the visible tools, Home and End jump to the first and last (the tool opens as focus arrives) ---------- */
$(".tabs").addEventListener("keydown", (e) => {
  const tab = e.target.closest('[role="tab"]');
  if (!tab || e.ctrlKey || e.metaKey || e.altKey) return;
  const tabs = [...document.querySelectorAll('.tabs [role="tab"]')].filter((b) => b.offsetParent !== null); // "Starred only" hides some
  const i = tabs.indexOf(tab);
  const to = { ArrowDown: tabs[i + 1] || tabs[0], ArrowUp: tabs[i - 1] || tabs[tabs.length - 1], Home: tabs[0], End: tabs[tabs.length - 1] }[e.key];
  if (!to) return;
  e.preventDefault();
  to.focus();
  to.click();
});

/* ---------- "Try Intune Enhancer" at the foot of the sidebar: opens the store page that matches this browser ---------- */
const tryStore = intuneStore(navigator.userAgent);
$("#try-intune").href = tryStore.url;
$("#try-intune").title = `Intune Enhancer in the ${tryStore.name} (opens in a new tab)`;

/* ---------- wiring ---------- */
document.addEventListener("click", (e) => {
  const star = e.target.closest(".tabs .star");
  if (star) return void toggleTabStar(star.closest("[data-tab]").dataset.tab);
  if (e.target.closest("#star-filter")) return void toggleStarredOnly();
  const row = e.target.closest("tr[data-host]");
  if (row && !e.target.closest("a")) return void openDrawer(row.dataset.host);
  const t = e.target.closest("[data-tab],[data-tile],[data-chip],[data-sort],[data-psort],[data-tsort],[data-xfor],[data-go],[data-demo],[data-tagpick],[data-tagmode],[data-pimf],[data-side]");
  if (!t) return;
  const d = t.dataset;
  if (d.tab) showTab(d.tab);
  else if (d.side) openSide(d.side);
  else if (d.tile) onTile(d.tile);
  else if (d.chip) { state.chip = d.chip; renderHosts(); }
  else if (d.tagpick !== undefined) { state.tagSel = { tag: d.tagpick, mode: "all", value: "" }; renderTagHosts(); }
  else if (d.tagmode) { state.tagSel = { ...state.tagSel, mode: d.tagmode, value: d.tagval }; renderTagHosts(); }
  else if (d.pimf) { state.pimFilter = d.pimf; renderPim(); }
  else if (d.xfor) doExport(t);
  else if (d.tsort) { const [id, key] = d.tsort.split("|"); const tb = tables[id]; tb.sort = { key, dir: tb.sort?.key === key && tb.sort.dir === "asc" ? "desc" : "asc" }; refreshTable(id); }
  else if (d.psort) { state.poolSort = { key: d.psort, dir: state.poolSort.key === d.psort && state.poolSort.dir === "asc" ? "desc" : "asc" }; renderPools(); }
  else if (d.sort) { state.sort = { key: d.sort, dir: state.sort.key === d.sort && state.sort.dir === "asc" ? "desc" : "asc" }; renderHosts(); }
  else if (d.go) { e.preventDefault(); showTab(d.go); }
  else if (d.demo !== undefined) { e.preventDefault(); toggleDemo(); }
});

$("#refresh").addEventListener("click", refresh);

// This page's own script errors go to the Console too.
window.addEventListener("error", (e) => send("log/add", { level: "error", message: e.message || "Script error", detail: `${(e.filename || "").split("/").pop()}:${e.lineno || ""}` }));
window.addEventListener("unhandledrejection", (e) => send("log/add", { level: "error", message: `Unhandled: ${e.reason?.message || e.reason}` }));

document.addEventListener("keydown", (e) => {
  if (e.ctrlKey || e.metaKey || e.altKey || /^(INPUT|SELECT|TEXTAREA)$/.test(e.target.tagName) || state.tab !== "dashboard") return;
  if (e.key === "/") { e.preventDefault(); $("#search").focus(); }
  else if (e.key === "r") refresh();
});
$("#drawer-close").addEventListener("click", closeDrawer);
/* Dropdown menus (Columns, Export, Saved views) close on a click anywhere outside them, and on Escape. */
const closeMenus = (except) => document.querySelectorAll("details.colpick[open]").forEach((d) => { if (!except || !d.contains(except)) d.open = false; });
document.addEventListener("click", (e) => closeMenus(e.target));
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeMenus(); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });

for (const [id, on] of [["#consent-on", true], ["#consent-off", false]]) {
  $(id).addEventListener("click", async () => { await send("consent/set", { on }); await renderSettings(); renderWho(); });
}

/* ---------- theme (theme-init.js has already applied the saved theme; themes.js builds the dropdown) ---------- */
setupThemePicker();
$("#app-version").textContent = ` (v${chrome.runtime.getManifest?.().version || ""})`;
$("#interval").addEventListener("change", async (e) => {
  state.interval = Number(e.target.value) || 0;
  await savePrefs();
  schedule();
});
chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes["avd.consent"]) refresh(); });

(async function init() {
  const saved = (await chrome.storage.local.get(PREFS_KEY).catch(() => ({})))[PREFS_KEY];
  state.interval = Number(saved?.interval) || 0;
  state.sub = String(saved?.sub || "");
  state.cols = Array.isArray(saved?.cols) ? saved.cols : [];
  state.rate = Number(saved?.rate) > 0 ? Number(saved.rate) : 0;
  state.views = cleanViews(saved?.views);
  state.cards = cleanCards(saved?.cards);
  state.starredTabs = new Set((Array.isArray(saved?.starredTabs) ? saved.starredTabs : []).filter((t) => TABS.includes(t)));
  state.starredOnly = saved?.starredOnly === true;
  renderTabStars();
  const v = hashToView(location.hash);
  Object.assign(state, { pool: v.pool, chip: v.chip, q: v.q, sort: v.sort });
  if (v.cols.length) state.cols = v.cols;
  if (v.sub) state.sub = v.sub;
  $("#search").value = v.q;
  showTab(v.tab);
  schedule();
  await refresh();
  if (!state.status.consented && !state.sample && location.hash === "") showTab("settings");
})();
