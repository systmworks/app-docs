// Workspace core: the state, the worker call, the tab registry and the shared table, export and saved-settings helpers. The tool files import it.

import { toCsv, toTsv, toHtml, searchRows, sortHosts, viewToHash, esc } from "../core/host-table.js";
import { resourceUrl } from "../data/links.js";
import { cleanCards } from "../core/tags.js";

export const $ = (sel) => document.querySelector(sel);
export const TABS = ["dashboard", "inventory", "tags", "pim", "links", "console", "settings"];
export const PREFS_KEY = "avd.prefs";
export const BG_KEY = "avd.bg"; // minutes between background checks (the worker reads it)

export const state = {
  tab: "dashboard", data: null, status: { consented: false, signedIn: false }, sample: new URLSearchParams(location.search).has("sample"),
  pool: "", poolQ: "", poolSort: { key: "name", dir: "asc" }, chip: "all", q: "", drawer: "", side: null, starredTabs: new Set(), starredOnly: false, sub: "", view: null, cols: [], views: [], rate: 0, cards: cleanCards(null), tagSel: { tag: "", mode: "all", value: "" }, pim: null, pimFilter: "all", sort: { key: "name", dir: "asc" }, timer: null, interval: 0,
};

export const send = (type, extra = {}) => chrome.runtime.sendMessage({ type, ...extra }).catch((e) => ({ ok: false, error: e.message }));

/* ---------- tabs ---------- */

/** Each tool file registers what opens its tab (registerTab) and what runs when the tab is left (onTabLeave), so showTab names no tool. */
const tabOpeners = {};
const leaveHooks = [];
export const registerTab = (name, open) => { tabOpeners[name] = open; };
export const onTabLeave = (fn) => { leaveHooks.push(fn); };

export function showTab(name) {
  const next = TABS.includes(name) ? name : "dashboard";
  if (next !== state.tab) leaveHooks.forEach((f) => f()); // a host's details belong to the tab they were opened on
  state.tab = next;
  for (const t of TABS) $(`#tab-${t}`).hidden = t !== state.tab;
  document.querySelectorAll("[data-tab]").forEach((b) => {
    const open = b.dataset.tab === state.tab;
    if (b.getAttribute("role") === "tab") { b.setAttribute("aria-selected", String(open)); b.tabIndex = open ? 0 : -1; } // only the open tool is in the Tab order
    else b.setAttribute("aria-current", open ? "page" : "false"); // the Settings button
  });
  $("#refresh-group").classList.toggle("off", state.tab !== "dashboard"); // hidden but still taking its space, so the header does not shift between tabs
  tabOpeners[state.tab]?.(); // each tool file registers what opens its tab
  syncHash();
}

/** An error message as HTML; a sign-in problem gets a link to the Azure portal, where the sign-in is refreshed. */
export const errorHtml = (msg) => esc(msg) + (/sign-in|signed in|sign in|portal/i.test(msg) ? ` <a href="https://portal.azure.com" target="_blank" rel="noopener">Open portal.azure.com</a>` : "");
/** One error message, or a list of them, as a red banner. */
export const errorBanner = (msgs) => `<div class="banner bad">${[].concat(msgs).map(errorHtml).join("<br>")}</div>`;

/* ---------- the shared table pattern: a title bar (filter box, export buttons) and sortable headers ---------- */
const svgIcon = (paths) => `<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
const EXPORT_KINDS = [ // left to right; the most used is rightmost. Icon buttons: the full name is the hover text and the accessible name.
  ["html", "Save HTML", svgIcon('<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>')],
  ["copy", "Copy table", svgIcon('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>')],
  ["csv", "Save CSV", svgIcon('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16"/>')],
];
const exportButtons = (id) => EXPORT_KINDS.map(([k, label, icon]) => `<button type="button" class="export ico" data-xfor="${id}" data-xkind="${k}" title="${label}" aria-label="${label}">${icon}</button>`).join("");
/** A filter pill; attrs is the data attribute(s) the click handler reads. */
export const chipHtml = (attrs, label, n, pressed, disabled = false) => `<button type="button" class="chip" ${attrs} aria-pressed="${pressed}"${disabled ? " disabled" : ""}>${esc(label)}<span class="n">${n}</span></button>`;
export const exportDefs = {}; // table id -> () => { rows, cols, title, file }, read when a button is clicked
for (const el of document.querySelectorAll("[data-export]")) el.innerHTML = exportButtons(el.dataset.export);

export async function doExport(btn) {
  const def = exportDefs[btn.dataset.xfor]?.();
  if (!def) return;
  if (btn.dataset.xkind === "csv") saveFile("csv", toCsv(def.rows, def.cols), "text/csv", def.file);
  else if (btn.dataset.xkind === "html") saveFile("html", toHtml(def.rows, def.cols, def.title), "text/html", def.file);
  else {
    const was = btn.title;
    try { await navigator.clipboard.writeText(toTsv(def.rows, def.cols)); btn.title = "Copied"; } catch { btn.title = "Copy failed"; }
    btn.classList.add("flash");
    setTimeout(() => { btn.title = was; btn.classList.remove("flash"); }, 1500);
  }
}

/* A generated table (scanned sessions, the Inventory tables): cols are { key, label, kind, html(row) }, rows are plain objects. */
export const tables = {};
export const shownRows = (id) => { const t = tables[id]; const r = searchRows(t.rows, t.cols, t.q); return t.sort ? sortHosts(r, t.sort.key, t.sort.dir, t.cols) : r; };
function tableBody(id) {
  const t = tables[id];
  const th = (c) => { const on = t.sort?.key === c.key; return `<th data-tsort="${id}|${c.key}"${c.kind === "n" ? ' class="num"' : ""}${on ? ` aria-sort="${t.sort.dir === "asc" ? "ascending" : "descending"}"` : ""}>${esc(c.label)}${on ? (t.sort.dir === "asc" ? " ▲" : " ▼") : ""}</th>`; };
  const rows = shownRows(id).map((r) => `<tr${r.hostId ? ` data-host="${esc(r.hostId)}"` : ""}${r.side ? ` data-side="${esc(r.side)}"` : ""}>${t.cols.map((c) => `<td${c.kind === "n" ? ' class="num"' : ""}>${c.html ? c.html(r) : esc(r[c.key])}</td>`).join("")}</tr>`).join("");
  return `<table><thead><tr>${t.cols.map(th).join("")}</tr></thead><tbody>${rows || `<tr><td colspan="${t.cols.length}" class="empty">${t.q.trim() ? "Nothing matches the filter." : "None found."}</td></tr>`}</tbody></table>`;
}
const tableCount = (id) => (tables[id].q.trim() ? `${shownRows(id).length} of ${tables[id].rows.length}` : String(tables[id].rows.length));
export function refreshTable(id) { $(`#${id}-wrap`).innerHTML = tableBody(id); $(`#${id}-count`).textContent = tableCount(id); }
/** file is the export file name; leave it out for a table that needs no export buttons. */
export function dataTable(id, title, cols, rows, file) {
  tables[id] = { cols, rows, sort: null, q: "" };
  if (file) exportDefs[id] = () => ({ rows: shownRows(id), cols, title, file });
  return `<div class="tbar"><h2>${esc(title)} <span class="muted small" id="${id}-count">${tableCount(id)}</span></h2><input type="search" class="tfilter" data-tfilter="${id}" placeholder="Filter ${esc(title.toLowerCase())}" aria-label="Filter ${esc(title)}"><span class="spacer"></span>${file ? exportButtons(id) : ""}</div>
    <div class="tablewrap" id="${id}-wrap">${tableBody(id)}</div>`;
}
document.addEventListener("input", (e) => { const id = e.target.dataset?.tfilter; if (id && tables[id]) { tables[id].q = e.target.value; refreshTable(id); } });

/** A link to the Azure portal page of a resource id (default text "Open in Azure portal"). */
export const portalLink = (id, text = "Open in Azure portal") => `<a href="${esc(resourceUrl(id, state.status.tid))}" target="_blank" rel="noopener">${esc(text)}</a>`;

export function saveFile(ext, text, type, name = "avd-hosts") {
  const url = URL.createObjectURL(new Blob([text], { type }));
  const a = Object.assign(document.createElement("a"), { href: url, download: `${name}-${new Date().toISOString().slice(0, 10)}.${ext}` });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

/* ---------- view in the URL, so a view can be bookmarked ---------- */
export function syncHash() {
  const h = viewToHash(state);
  try { history.replaceState(null, "", `${location.pathname}${location.search}${h ? `#${h}` : ""}`); } catch { /* not allowed here */ }
}

/** A worker read kept for a minute and shared by everyone who asks, one read at a time (Inventory tab, PIM tab, host drawer). */
/** The in-flight reads by slot. */
const reading = {};
/** The answer for a slot (state.inventory, state.pim): the saved one if under a minute old, else a fresh read. */
export async function cachedRead(slot, type) {
  if (state[slot] && Date.now() - state[slot].fetchedAt < 60000) return state[slot];
  reading[slot] ||= send(type, { sample: state.sample }).finally(() => { delete reading[slot]; });
  const res = await reading[slot];
  if (res.ok) state[slot] = res;
  return res;
}
export const getInventory = () => cachedRead("inventory", "avd/inventory");

export const savePrefs = () => chrome.storage.local.set({ [PREFS_KEY]: { interval: state.interval, sub: state.sub, cols: state.cols, views: state.views, rate: state.rate, cards: state.cards, starredTabs: [...state.starredTabs], starredOnly: state.starredOnly } }).catch(() => {});
