// Shared helpers for content scripts. Scripts in the same frame share one isolated world, so they all see
// globalThis.AVDKit. Nothing in a content script runs before the user accepts the disclosure on the Settings tab
// (README ground rule 4): whenConsented waits for it.

(function () {
  if (globalThis.AVDKit) return;
  const CONSENT_KEY = "avd.consent";

  /** Run fn once consent is on, now or when the user turns it on later; never while it is off. */
  function whenConsented(fn) {
    let started = false;
    const go = () => { if (!started) { started = true; fn(); } };
    chrome.storage.local.get(CONSENT_KEY).then((v) => { if (v[CONSENT_KEY] === true) go(); }).catch(() => {});
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[CONSENT_KEY]?.newValue === true) go();
    });
  }

  globalThis.AVDKit = { CONSENT_KEY, whenConsented };
})();
