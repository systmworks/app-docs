// Service worker. Holds the ARM token pool and answers the Workspace's messages. All Azure calls are made here; content
// scripts never see a token apart from capture.js handing one in (README ground rule 5).

import { createTokenPool } from "./core/tokens.js";
import { createArmClient } from "./core/arm.js";
import { loadOverview, loadSessions, loadSessionsFor, sortSessions, loadInventory, badgeText } from "./core/avd.js";
import { sampleOverview, sampleSessions, sampleInventory, sampleAccess, samplePim } from "./data/sample.js";
import { loadPim } from "./core/pim.js";
import { loadAccess } from "./core/access.js";
import { addEntry, redact, LEVELS } from "./core/log.js";
import { injectIntoOpenTabs } from "./core/reinject.js";

const CONSENT_KEY = "avd.consent";
const BG_KEY = "avd.bg"; // minutes between background checks, 0 = off
const LAST_KEY = "avd.last"; // { issues, at } from the latest read, for the toolbar badge
const ALARM = "avd-poll";
const LOG_KEY = "avd.log"; // the Console tab's entries (storage.session: this browser session only)
const MAX_SCAN_HOSTS = 300; // Scan sessions reads at most this many hosts; the answer says how many were left out (skipped)

let logCache = null;
/** Adds a line to the Console log. Never throws, never records a token (redact). */
async function log(level, source, message, detail = "") {
  try {
    if (!logCache) logCache = (await chrome.storage.session.get(LOG_KEY))[LOG_KEY] || [];
    logCache = addEntry(logCache, { t: Date.now(), level, source: String(source).slice(0, 40), message: redact(message), detail: redact(detail).slice(0, 200) });
    await chrome.storage.session.set({ [LOG_KEY]: logCache });
  } catch { /* logging must never break the extension */ }
}
const tokens = createTokenPool();
const arm = createArmClient(() => tokens.candidates());

const readConsent = async () => (await chrome.storage.local.get(CONSENT_KEY))[CONSENT_KEY] === true;

async function openWorkspace() {
  const url = chrome.runtime.getURL("src/workspace/workspace.html");
  const [existing] = await chrome.tabs.query({ url });
  if (existing) await chrome.tabs.update(existing.id, { active: true });
  else await chrome.tabs.create({ url });
}

/** Each handler gets (message, sender) and returns the reply; a thrown error becomes { ok: false, error, code }. */
const handlers = {
  async "consent/get"() { return { ok: true, consented: await readConsent() }; },

  async "consent/set"(msg) {
    const on = msg.on === true;
    await chrome.storage.local.set({ [CONSENT_KEY]: on });
    await log("info", "consent", on ? "Sign-in reuse turned on" : "Sign-in reuse turned off");
    if (!on) tokens.clear();
    return { ok: true, consented: on };
  },

  // capture.js hands in a token (only after consent; looksReal checks it is an ARM access token).
  async "token/seen"(msg) {
    await tokens.ready;
    if ((await readConsent()) && tokens.add(String(msg.token || ""))) await log("info", "token", "Azure sign-in picked up from the portal", `${tokens.size} in the pool`);
    return { ok: true };
  },

  async "status/get"() {
    await tokens.ready;
    const id = tokens.identity;
    return { ok: true, consented: await readConsent(), signedIn: tokens.size > 0, upn: id?.upn || "", tid: id?.tid || "" };
  },

  async "avd/overview"(msg) {
    if (msg.sample) return { ok: true, ...sampleOverview() };
    await tokens.ready;
    if (!(await readConsent())) return { ok: false, code: "NO_CONSENT", error: "Turn on sign-in reuse in Settings first." };
    const overview = await loadOverview(arm);
    await rememberIssues(overview.summary.totals.issues, overview.fetchedAt);
    await log("info", "overview", `Read ${overview.hosts.length} hosts in ${overview.pools.length} pools`);
    return { ok: true, ...overview };
  },

  async "avd/sessions"(msg) {
    if (msg.sample) return { ok: true, sessions: sampleSessions(msg.id) };
    await tokens.ready;
    return { ok: true, sessions: await loadSessions(arm, msg.id) };
  },

  // Sessions of many hosts at once (the dashboard's Scan sessions). Each id is checked inside loadSessions.
  async "avd/allsessions"(msg) {
    const asked = Array.isArray(msg.hosts) ? msg.hosts : [];
    const hosts = asked.slice(0, MAX_SCAN_HOSTS).map((h) => ({ id: String(h.id), name: String(h.name), pool: String(h.pool) }));
    const skipped = asked.length - hosts.length;
    if (msg.sample) return { ok: true, failed: 0, skipped, sessions: sortSessions(hosts.flatMap((h) => sampleSessions(h.id).map((s) => ({ ...s, hostId: h.id, host: h.name, pool: h.pool })))) };
    await tokens.ready;
    return { ok: true, skipped, ...(await loadSessionsFor(arm, hosts)) };
  },

  async "avd/inventory"(msg) {
    if (msg.sample) return { ok: true, ...sampleInventory() };
    await tokens.ready;
    const inv = await loadInventory(arm);
    for (const e of inv.errors) await log("warn", "inventory", e);
    return { ok: true, ...inv };
  },

  // PIM roles tab: the Azure roles the account holds or can activate (two role schedule lists, read only).
  async "avd/pim"(msg) {
    if (msg.sample) return { ok: true, ...samplePim() };
    await tokens.ready;
    const res = await loadPim(arm);
    for (const e of res.errors) await log("warn", "pim", e);
    return { ok: true, ...res };
  },

  // Settings "Check my access": the account's permissions on each resource group (read only). loadAccess checks each scope,
  // keeps the first MAX_SCOPES distinct ones and reports how many it left out (skipped).
  async "avd/access"(msg) {
    const scopes = (Array.isArray(msg.scopes) ? msg.scopes : []).map(String);
    if (msg.sample) return { ok: true, ...sampleAccess(scopes.length ? scopes : undefined) };
    await tokens.ready;
    const res = await loadAccess(arm, scopes);
    if (res.failed) await log("warn", "access", `Could not read permissions on ${res.failed} of ${res.scopes} resource groups`);
    return { ok: true, ...res };
  },

  // The Console tab: read, clear, and lines the Workspace page adds (its own script errors).
  async "log/get"() { if (!logCache) logCache = (await chrome.storage.session.get(LOG_KEY))[LOG_KEY] || []; return { ok: true, entries: logCache }; },
  async "log/clear"() { logCache = []; await chrome.storage.session.set({ [LOG_KEY]: [] }).catch(() => {}); return { ok: true }; },
  async "log/add"(msg) { await log(LEVELS.includes(msg.level) ? msg.level : "error", "workspace", String(msg.message || ""), String(msg.detail || "")); return { ok: true }; },

  async "workspace/open"() { await openWorkspace(); return { ok: true }; },
};

// Messages that work before consent: the disclosure itself, the sample data, and opening the Workspace. token/seen checks
// consent itself; every other handler is refused until the user has consented.
const BEFORE_CONSENT = new Set(["consent/get", "consent/set", "token/seen", "status/get", "workspace/open", "log/get", "log/clear", "log/add"]);

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = handlers[msg?.type];
  if (!handler) return false;
  (async () => {
    if (!BEFORE_CONSENT.has(msg.type) && !msg.sample && !(await readConsent())) {
      return { ok: false, code: "NO_CONSENT", error: "Turn on sign-in reuse in Settings first." };
    }
    return handler(msg, sender);
  })().then(sendResponse, async (e) => {
    if (msg.type !== "log/add") await log("error", msg.type, e.message || String(e), e.code || "");
    sendResponse({ ok: false, code: e.code || "ERROR", error: e.message || String(e) });
  });
  return true;
});

chrome.action.onClicked.addListener(() => { openWorkspace(); });

/** Toolbar badge: OFF until consent; then the number of hosts needing attention from the latest read (none shows nothing). */
async function syncBadge() {
  const on = await readConsent();
  const last = (await chrome.storage.local.get(LAST_KEY))[LAST_KEY];
  chrome.action.setBadgeText({ text: !on ? "OFF" : badgeText(last?.issues) });
  chrome.action.setBadgeBackgroundColor({ color: !on ? "#6b7280" : "#c42b1c" });
}

const rememberIssues = async (issues, at) => { await chrome.storage.local.set({ [LAST_KEY]: { issues, at } }); await syncBadge(); };

/** Starts or stops the background check from the Settings choice; it only runs with consent. */
async function syncAlarm() {
  const minutes = Number((await chrome.storage.local.get(BG_KEY))[BG_KEY]) || 0;
  await chrome.alarms.clear(ALARM);
  if (minutes > 0 && await readConsent()) chrome.alarms.create(ALARM, { periodInMinutes: minutes });
}

// A background check reads the overview with whatever token the portal has last supplied; with none it does nothing.
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name !== ALARM) return;
  try {
    await tokens.ready;
    if (!(await readConsent()) || tokens.size === 0) return;
    const overview = await loadOverview(arm);
    await rememberIssues(overview.summary.totals.issues, overview.fetchedAt);
  } catch (e) { await log("warn", "background check", e.message || String(e), e.code || ""); } // keep the last badge; the next check tries again
});
chrome.runtime.onInstalled.addListener(async (details) => {
  await syncBadge();
  await syncAlarm();
  if (details.reason === "install") openWorkspace(); // opens on Settings once the Workspace exists (README rule 4)
  if (details.reason === "install" || details.reason === "update") injectCapture();
});
// An update empties the token pool, and an Azure portal tab opened before it keeps a dead script: run the version's own
// token pickup in the open portal tabs so the sign-in is found without reloading the tab.
async function injectCapture() {
  const [capture] = chrome.runtime.getManifest().content_scripts;
  const n = await injectIntoOpenTabs(chrome, capture.js, capture.matches);
  if (n) await log("info", "sign-in", `Looked for the Azure sign-in in ${n} open tab${n === 1 ? "" : "s"} after an update`);
}
chrome.runtime.onStartup.addListener(() => { syncBadge(); syncAlarm(); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[CONSENT_KEY]) { syncBadge(); syncAlarm(); }
  if (changes[BG_KEY]) syncAlarm();
});
