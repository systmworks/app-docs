// Inventory tab and the pool and scaling plan details in the right-hand drawer.

import { poolRows, groupRows, countOf, isOn } from "../core/avd.js";
import { esc } from "../core/host-table.js";
import { scheduleRows, maintRows } from "../core/windows.js";
import { $, state, errorBanner, dataTable, portalLink, getInventory, registerTab, showReadError } from "./core.js";
import { closeDrawer, renderHosts } from "./dashboard.js";

/* ---------- pool and scaling plan details: the same right-hand drawer as a host ---------- */
const poolNameOf = (id) => (state.data?.pools || []).find((q) => String(q.id).toLowerCase() === id)?.name || "?";
/** "pool-a, pool-b (off)": the pools a scaling plan is attached to. */
const planPools = (p) => p.pools.map((x) => `${poolNameOf(x.id)}${x.enabled ? "" : " (off)"}`).join(", ");
/** Max sessions as shown: a personal pool holds one session per host. */
const poolMax = (type, max) => (type === "Personal" ? 1 : max);

/** A link-style button that opens the pool or plan drawer for "kind:id". */
const sideBtn = (kind, id, label) => `<button type="button" class="poolname" data-side="${kind}:${esc(id)}">${esc(label)}</button>`;
/** A drawer fact list from [label, value] pairs (an empty value shows a dash). */
const dlOf = (pairs) => `<dl>${pairs.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v) || "-"}</dd>`).join("")}</dl>`;

/** The pool's drawer: its facts, its scaling plan and application groups (from the inventory read), and its hosts (click one for the host). */
function poolPanel(id, inv) {
  const pool = (state.data.pools || []).find((q) => String(q.id).toLowerCase() === id);
  if (!pool) return `<p class="muted small">That pool is not in the current read.</p>`;
  const row = poolRows([pool], state.data.hosts, inv?.plans || [])[0];
  const hosts = state.data.hosts.filter((h) => h.poolId === id);
  const waiting = state.invError ? `Could not read: ${esc(state.invError)}` : "Reading...";
  const plans = (inv?.plans || []).filter((pl) => pl.pools.some((x) => x.id === id));
  const groups = inv ? groupRows(inv.appGroups, state.data.pools || [], inv.workspaces).filter((g) => g.pool === pool.name) : [];
  const hostRows = hosts.map((h) => `<tr data-host="${esc(h.id)}"><td>${esc(h.name)}</td><td><span class="badge ${isOn(h) ? "ok" : ""}">${esc(h.power)}</span></td><td class="num">${h.sessions}</td></tr>`).join("");
  return `<h2>${esc(pool.name)}</h2><div class="muted small">Host pool</div>
    ${dlOf([["Type", row.type], ["Load balancer", row.balancer], ["Max sessions", String(poolMax(row.type, row.maxSessions))], ["Hosts powered on", `${hosts.filter(isOn).length} of ${hosts.length}`],
      ["User sessions", String(hosts.reduce((a, h) => a + (Number(h.sessions) || 0), 0))], ["OS builds", row.os], ["VM sizes", row.sizes], ["Agents", row.agents], ["Mix", row.mixed ? "Mixed" : "Uniform"]])}
    ${portalLink(pool.id)}
    <h3>Scaling plan</h3>${inv ? (plans.length ? plans.map((pl) => `<div>${sideBtn("plan", String(pl.id).toLowerCase(), pl.name)}${pl.pools.find((x) => x.id === id)?.enabled ? "" : ' <span class="muted small">(off for this pool)</span>'}</div>`).join("") : `<p class="muted small">None attached.</p>`) : `<p class="muted small">${waiting}</p>`}
    <h3>Application groups</h3>${inv ? (groups.length ? groups.map((g) => `<div>${esc(g.name)} <span class="muted small">${esc(g.kind)}</span></div>`).join("") : `<p class="muted small">None.</p>`) : `<p class="muted small">${waiting}</p>`}
    <h3>Hosts (${hosts.length})</h3><div class="tablewrap"><table><thead><tr><th>Host</th><th>Power</th><th class="num">Sessions</th></tr></thead><tbody>${hostRows}</tbody></table></div>`;
}

/** The scaling plan's drawer: time zone, the pools it is attached to and every schedule with its times. */
function planPanel(id, inv) {
  if (!inv) return `<p class="muted small">${state.invError ? `Could not read: ${esc(state.invError)}` : "Reading scaling plans..."}</p>`;
  const plan = inv.plans.find((x) => String(x.id).toLowerCase() === id);
  if (!plan) return `<p class="muted small">That scaling plan is not in the current read.</p>`;
  const sched = plan.scheduleList.length ? scheduleRows([plan]).map((r) => `<div><strong>${esc(r.schedule)}</strong> <span class="muted small">${esc(r.days)}</span></div>
    ${dlOf([["Ramp-up", r.rampUp], ["Peak", r.peak], ["Ramp-down", r.rampDown], ["Off-peak", r.offPeak], ["At ramp-down", r.logoff]])}`).join("") : `<p class="muted small">No schedules.</p>`;
  return `<h2>${esc(plan.name)}</h2><div class="muted small">Scaling plan</div>
    ${dlOf([["Time zone", plan.timeZone], ["Resource group", plan.resourceGroup]])}
    ${portalLink(plan.id)}
    <h3>Host pools</h3>${plan.pools.length ? plan.pools.map((x) => `<div>${sideBtn("pool", x.id, poolNameOf(x.id))}${x.enabled ? "" : ' <span class="muted small">(off)</span>'}</div>`).join("") : `<p class="muted small">None attached.</p>`}
    <h3>Schedules (${plan.scheduleList.length})</h3>${sched}`;
}

/** Draws the pool or plan drawer for state.side. */
export function renderSide() {
  const side = state.side;
  if (!side || !state.data) return;
  $("#drawer").hidden = false;
  $("#drawer-body").innerHTML = side.kind === "pool" ? poolPanel(side.id, state.inventory) : planPanel(side.id, state.inventory);
}

/** Opens (or, on the same item again, closes) the drawer for "pool:<id>" or "plan:<id>"; the inventory read fills in the plans and groups. */
export function openSide(key) {
  if (state.side?.key === key) return closeDrawer();
  const cut = key.indexOf(":");
  state.drawer = ""; state.side = { kind: key.slice(0, cut), id: key.slice(cut + 1).toLowerCase(), key };
  if (state.view) renderHosts(); // clears the highlighted host row
  renderSide();
  getInventory().then((res) => { state.invError = res.ok ? "" : res.error; if (state.side?.key === key) renderSide(); });
}

/* ---------- inventory: pools (image and size mix, scaling plans), application groups, workspaces ---------- */
function renderInventory(inv) {
  const pools = poolRows(state.data.pools || [], state.data.hosts, inv.plans);
  const groups = groupRows(inv.appGroups, state.data.pools || [], inv.workspaces);
  const T = (key, label) => ({ key, label });
  const N = (key, label) => ({ key, label, kind: "n" });
  $("#inventory-out").innerHTML = (inv.errors?.length ? errorBanner(inv.errors) : "")
    + dataTable("inv-pools", "Host pools", [T("name", "Pool"), T("type", "Type"), T("balancer", "Load balancer"), N("max", "Max sessions"), N("hosts", "Hosts"), T("os", "OS builds"), T("sizes", "VM sizes"), T("agents", "Agents"),
      { key: "mix", label: "Mix", html: (r) => `<span class="badge ${r.mix === "Mixed" ? "warn" : "ok"}">${r.mix}</span>` }, T("plans", "Scaling plan")],
      pools.map((p) => ({ name: p.name, type: p.type, balancer: p.balancer, max: poolMax(p.type, p.maxSessions), hosts: p.hosts, os: p.os, sizes: p.sizes, agents: p.agents, mix: p.mixed ? "Mixed" : "Uniform", plans: p.plans || "None", side: `pool:${String(p.id).toLowerCase()}` })), "avd-pools-inventory")
    + dataTable("inv-sched", "Scaling plans and schedules", [T("plan", "Plan"), T("timeZone", "Time zone"), T("pools", "Pools"), T("schedule", "Schedule"), T("days", "Days"), T("rampUp", "Ramp-up"), T("peak", "Peak"), T("rampDown", "Ramp-down"), T("offPeak", "Off-peak"), T("logoff", "At ramp-down")],
      scheduleRows(inv.plans).map((r) => ({ ...r, pools: planPools(inv.plans.find((p) => String(p.id).toLowerCase() === r.planId)), side: `plan:${r.planId}` })), "avd-scaling-schedules")
    + dataTable("inv-maint", "Maintenance windows", [T("name", "Configuration"), T("scope", "Scope"), T("days", "Days"), T("start", "Start"), T("end", "End"), T("length", "Length"), T("timeZone", "Time zone"), N("vms", "VMs"), N("hosts", "AVD hosts"), T("resourceGroup", "Resource group")],
      maintRows(inv.configs, inv.assignments, state.data.hosts))
    + dataTable("inv-groups", "Application groups", [T("name", "Group"), T("kind", "Type"), T("pool", "Pool"), T("workspace", "Workspace"), T("resourceGroup", "Resource group")], groups)
    + dataTable("inv-ws", "Workspaces", [T("name", "Workspace"), T("friendly", "Friendly name"), N("groups", "App groups"), T("resourceGroup", "Resource group")],
      inv.workspaces.map((w) => ({ name: w.name, friendly: w.friendly, groups: countOf(w.groups), resourceGroup: w.resourceGroup })));
}

export async function loadInventoryTab() {
  const out = $("#inventory-out");
  if (!state.data) { out.innerHTML = `<p class="muted small">Open the Dashboard first so the pools and hosts are read.</p>`; return; }
  if (!state.inventory) out.innerHTML = `<p class="muted small">Reading scaling plans, maintenance windows, application groups and workspaces...</p>`;
  const res = await getInventory();
  if (showReadError(out, res)) return;
  if (state.tab === "inventory") renderInventory(res);
}

registerTab("inventory", loadInventoryTab);
