// How the workspace's small pop-ups close: the Scope panel, the group picker's result list and the theme menu. Imports nothing.

/**
 * Closes a pop-up on a click outside `root` or on Escape pressed inside it; Escape also puts focus back on `focusEl` when one is
 * given (the button that opened it). Does nothing while the pop-up is closed. `isOpen` and `close` are the pop-up's own.
 */
export function dismissable(root, isOpen, close, focusEl) {
  document.addEventListener("click", (e) => { if (isOpen() && !root.contains(e.target)) close(); });
  root.addEventListener("keydown", (e) => { if (e.key === "Escape" && isOpen()) { close(); focusEl?.focus(); } });
}
