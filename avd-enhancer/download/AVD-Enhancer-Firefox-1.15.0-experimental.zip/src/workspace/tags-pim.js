// PIM roles tab and Tags tab.

import { scopeTo } from "../core/avd.js";
import { esc } from "../core/host-table.js";
import { linkGroups } from "../data/links.js";
import { tagList, tagValues, tagHostRows } from "../core/tags.js";
import { $, state, errorBanner, chipHtml, dataTable, cachedRead, registerTab, showReadError } from "./core.js";

/* ---------- PIM roles: Azure roles held now or open to activation (read when the tab opens, kept for a minute) ---------- */
/** Reads the PIM roles when the tab opens and draws them. */
async function loadPimTab() {
  if (!state.pim) $("#pim-out").innerHTML = `<p class="muted small">Reading your PIM roles...</p>`;
  const res = await cachedRead("pim", "avd/pim");
  if (showReadError($("#pim-out"), res)) return;
  if (state.tab === "pim") renderPim();
}
/** Role-name pills on the PIM tab: a pill keeps the roles whose name contains the word. */
const PIM_ROLE_WORDS = ["Reader", "Contributor", "Operator"];
/** The PIM tab: Active / Eligible / role-word pills over one table (an eligible role that is switched on shows once, as Active). */
export function renderPim() {
  const { rows, errors } = state.pim, f = state.pimFilter;
  const isActive = (r) => r.status.startsWith("Active");
  const hasWord = (r, w) => r.role.toLowerCase().includes(w.toLowerCase());
  const word = PIM_ROLE_WORDS.find((w) => w.toLowerCase() === f);
  const shown = rows.filter((r) => (word ? hasWord(r, word) : f === "all" || (f === "active" ? isActive(r) : !isActive(r))));
  const chip = (id, label, n) => chipHtml(`data-pimf="${id}"`, label, n, f === id, n === 0 && f !== id);
  const day = (iso) => (iso ? new Date(iso).toLocaleDateString() : "No end date");
  const link = linkGroups(state.status.tid).flatMap((g) => g.links).find((l) => l.label === "Activate Azure resource roles");
  const status = (r) => (!isActive(r) && link
    ? `<a class="badge" href="${esc(link.url)}" target="_blank" rel="noopener" title="Open Privileged Identity Management to activate this role">${esc(r.status)}</a>`
    : `<span class="badge ${isActive(r) ? "ok" : ""}">${esc(r.status)}</span>`);
  $("#pim-out").innerHTML = (errors.length ? errorBanner(errors) : "")
    + `<div class="chips">${chip("all", "All", rows.length)}${chip("active", "Active now", rows.filter(isActive).length)}${chip("eligible", "Eligible", rows.filter((r) => !isActive(r)).length)}${PIM_ROLE_WORDS.map((w) => chip(w.toLowerCase(), w, rows.filter((r) => hasWord(r, w)).length)).join("")}</div>`
    + dataTable("pim", "Azure roles", [{ key: "role", label: "Role" }, { key: "scope", label: "Scope" }, { key: "scopeType", label: "Scope type" },
      { key: "status", label: "Status", html: status }, { key: "left", label: "Active for" },
      { key: "eligibleUntil", label: "Eligible until" }, { key: "member", label: "Via" }],
      shown.map((r) => ({ ...r, eligibleUntil: r.isEligible ? day(r.eligibleEnds) : "" })), "avd-pim-roles")
    + `<p class="muted small">Azure resource roles only: Entra directory roles and group roles are managed by a different service and are not shown. To activate a role use ${link ? `<a href="${esc(link.url)}" target="_blank" rel="noopener">Privileged Identity Management</a>` : "Privileged Identity Management"} in the Azure portal; this page only reads.</p>`;
}

/* ---------- tags: every tag on the hosts' VMs, then the hosts with the picked tag, narrowed by value ---------- */
const tagHosts = () => scopeTo(state.data, state.sub).hosts;
/** The Tags tab: every tag on the hosts' VMs in a table; the picked tag's hosts go under it. */
export function renderTagsTab() {
  const out = $("#tags-out");
  if (!state.data) { out.innerHTML = `<p class="muted small">Open the Dashboard first so the pools and hosts are read.</p>`; return; }
  const list = tagList(tagHosts());
  if (!list.length) { out.innerHTML = `<p class="muted small">No tags found on the VMs behind your session hosts.</p>`; return; }
  const N = (key, label) => ({ key, label, kind: "n" });
  out.innerHTML = dataTable("tags-all", "Tags", [{ key: "tag", label: "Tag", html: (r) => `<button type="button" class="poolname" data-tagpick="${esc(r.tag)}">${esc(r.tag)}</button>` }, N("hosts", "Hosts"), N("values", "Values"), { key: "summary", label: "Most common values" }], list)
    + `<div id="tags-hosts"></div>`;
  renderTagHosts();
}
/** The hosts with the picked tag: value pills (has the tag, each value, not set) over a host table. */
export function renderTagHosts() {
  const el = $("#tags-hosts"), sel = state.tagSel;
  if (!el) return;
  if (!sel.tag) { el.innerHTML = `<p class="muted small">Pick a tag above to list the hosts that have it.</p>`; return; }
  const hosts = tagHosts(), vals = tagValues(hosts, sel.tag), withTag = vals.reduce((a, v) => a + v.n, 0);
  const chip = (mode, value, label, n) => chipHtml(`data-tagmode="${mode}" data-tagval="${esc(value)}"`, label, n, sel.mode === mode && sel.value.toLowerCase() === value.toLowerCase());
  const title = sel.mode === "none" ? `Hosts without ${sel.tag}` : sel.mode === "value" ? `Hosts with ${sel.tag} = ${sel.value || "(empty)"}` : `Hosts with ${sel.tag}`;
  el.innerHTML = `<div class="chips">${chip("all", "", "Has the tag", withTag)}${vals.map((v) => chip("value", v.value, v.value || "(empty)", v.n)).join("")}${chip("none", "", "Not set", hosts.length - withTag)}</div>`
    + dataTable("tags-hosts-t", title, [{ key: "name", label: "Host" }, { key: "pool", label: "Pool" }, { key: "power", label: "Power", html: (r) => `<span class="badge ${r.power === "running" ? "ok" : ""}">${esc(r.power)}</span>` },
      { key: "status", label: "AVD status" }, { key: "value", label: "Tag value" }, { key: "sessions", label: "Sessions", kind: "n" }], tagHostRows(hosts, sel.tag, sel.mode, sel.value), "avd-tagged-hosts");
}

registerTab("pim", loadPimTab);
registerTab("tags", renderTagsTab);
