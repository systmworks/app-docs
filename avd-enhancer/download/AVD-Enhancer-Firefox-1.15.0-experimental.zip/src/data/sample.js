// Sample data for building and testing the Workspace without a tenant. Same shape loadOverview returns, built through
// the real joinHosts and summarise so the sample can never drift from the live path.

import { joinHosts, summarise, subsWithPools, normalizePlans } from "../core/avd.js";
import { evaluate, scopesOf } from "../core/access.js";
import { normalizeInstance, pimRows } from "../core/pim.js";

const SUB = "00000000-0000-0000-0000-000000000001";
const SUB_TEST = "00000000-0000-0000-0000-000000000002";
const SUBS = [{ subscriptionId: SUB, name: "Contoso Production" }, { subscriptionId: SUB_TEST, name: "Contoso Test" }];
const poolId = (rg, name, sub = SUB) => `/subscriptions/${sub}/resourcegroups/${rg}/providers/microsoft.desktopvirtualization/hostpools/${name}`;
const vmId = (rg, name, sub = SUB) => `/subscriptions/${sub}/resourcegroups/${rg}/providers/microsoft.compute/virtualmachines/${name}`;
const subOf = (pool) => pool.id.split("/")[2];

const POOLS = [
  { id: poolId("rg-avd-prod", "hp-pooled-prod"), name: "hp-pooled-prod", poolType: "Pooled", maxSessions: 8, subscriptionId: SUB },
  { id: poolId("rg-avd-prod", "hp-personal-exec"), name: "hp-personal-exec", poolType: "Personal", maxSessions: 1, subscriptionId: SUB },
  { id: poolId("rg-avd-test", "hp-pooled-test", SUB_TEST), name: "hp-pooled-test", poolType: "Pooled", maxSessions: 4, subscriptionId: SUB_TEST },
  // The first three are the compact sample the tests use; the rest make the demo a realistic 8 pools, Pooled and Personal mixed.
  { id: poolId("rg-avd-prod", "hp-pooled-finance"), name: "hp-pooled-finance", poolType: "Pooled", maxSessions: 10, subscriptionId: SUB },
  { id: poolId("rg-avd-dev", "hp-personal-dev"), name: "hp-personal-dev", poolType: "Personal", maxSessions: 1, subscriptionId: SUB },
  { id: poolId("rg-avd-prod", "hp-pooled-hr"), name: "hp-pooled-hr", poolType: "Pooled", maxSessions: 6, subscriptionId: SUB },
  { id: poolId("rg-avd-eng", "hp-personal-eng"), name: "hp-personal-eng", poolType: "Personal", maxSessions: 1, subscriptionId: SUB },
  { id: poolId("rg-avd-ext", "hp-pooled-contractors"), name: "hp-pooled-contractors", poolType: "Pooled", maxSessions: 12, subscriptionId: SUB },
];
const COMPACT_POOLS = 3;

// [pool index, host number, power code, status, sessions, allowNew, assigned user]
const SPEC = [
  [0, 1, "running", "Available", 6, true, ""], [0, 2, "running", "Available", 4, true, ""],
  [0, 3, "running", "Available", 0, false, ""], [0, 4, "deallocated", "Unavailable", 0, true, ""],
  [0, 5, "running", "NeedsAssistance", 2, true, ""], [0, 6, "deallocated", "Unavailable", 0, true, ""],
  [1, 1, "running", "Available", 1, true, "alex@contoso.com"], [1, 2, "deallocated", "Unavailable", 0, true, "sam@contoso.com"],
  [1, 3, "running", "Available", 0, true, "jo@contoso.com"],
  [2, 1, "running", "Available", 1, true, ""], [2, 2, "deallocated", "Unavailable", 0, true, ""],
  [3, 1, "running", "Available", 7, true, ""], [3, 2, "running", "Available", 9, true, ""], [3, 3, "running", "Available", 3, true, ""], [3, 4, "deallocated", "Unavailable", 0, true, ""],
  [4, 1, "running", "Available", 1, true, "kim@contoso.com"], [4, 2, "running", "Available", 0, true, "lee@contoso.com"], [4, 3, "deallocated", "Unavailable", 0, true, "max@contoso.com"],
  [5, 1, "running", "Available", 2, true, ""], [5, 2, "running", "Available", 0, false, ""],
  [6, 1, "running", "Available", 1, true, "ana@contoso.com"], [6, 2, "running", "NeedsAssistance", 1, true, "ben@contoso.com"],
  [6, 3, "deallocated", "Unavailable", 0, true, "cho@contoso.com"], [6, 4, "running", "Available", 0, true, "dee@contoso.com"],
  [7, 1, "running", "Available", 5, true, ""], [7, 2, "running", "Available", 8, true, ""], [7, 3, "running", "Available", 0, true, ""],
  [7, 4, "deallocated", "Unavailable", 0, true, ""], [7, 5, "running", "Available", 2, true, ""],
];
// The compact sample is the first three pools and their hosts (SPEC is in pool order).
const COMPACT_ROWS = SPEC.filter(([p]) => p < COMPACT_POOLS).length;

const hosts = SPEC.map(([p, n, , status, sessions, allowNew, user]) => ({
  id: `${POOLS[p].id}/sessionhosts/${POOLS[p].name}-${n}.contoso.local`, name: `${POOLS[p].name}/${POOLS[p].name}-${n}.contoso.local`,
  resourceGroup: POOLS[p].id.split("/")[4], subscriptionId: subOf(POOLS[p]), location: "australiaeast", status, sessions, allowNew,
  agent: n === 5 ? "1.0.8431.2300" : "1.0.9103.1500", os: n === 5 ? "10.0.22621" : "10.0.22631", heartbeat: new Date(Date.now() - (n === 5 ? 3 * 3600 : 120) * 1000).toISOString(), user,
  vmId: vmId(POOLS[p].id.split("/")[4], `${POOLS[p].name}-${n}`, subOf(POOLS[p])),
}));
/** The Environment tag of each sample pool, in pool order. */
const ENV = ["Production", "Production", "Test", "Production", "Development", "Production", "Development", "Production"];
// Tags on the sample VMs: Environment by pool, Backup alternating True and False, Tier on the Personal pools.
const vmTags = (p, n) => ({ Environment: ENV[p], Backup: n % 2 ? "True" : "False", ...(POOLS[p].poolType === "Personal" ? { Tier: "Personal" } : {}) });
const vms = SPEC.map(([p, n, power]) => ({ vmTags: vmTags(p, n), vmId: vmId(POOLS[p].id.split("/")[4], `${POOLS[p].name}-${n}`, subOf(POOLS[p])), power: `PowerState/${power}`, size: n === 5 ? "Standard_D8s_v5" : "Standard_D4s_v5" }));

/** Fictional user sessions for a sample host: as many as the host reports. */
export function sampleSessions(hostId) {
  const h = joinHosts(POOLS, hosts, vms).find((x) => x.id === hostId);
  const names = ["alex", "sam", "jo", "kim", "lee", "max", "ana", "ben"];
  return Array.from({ length: h?.sessions || 0 }, (_, i) => ({
    user: `${h.user ? h.user.split("@")[0] : names[i % names.length] + (i + 1)}@contoso.com`,
    state: i % 3 === 2 ? "Disconnected" : "Active", app: "Desktop", created: "2026-11-12T06:30:00Z",
  }));
}

/** Sample scaling plans, application groups and workspaces for the Inventory tab. */
export function sampleInventory({ compact = false } = {}) {
  const [prod, personal, test, finance, dev, hr, eng, ext] = POOLS;
  const cfgId = (n) => `/subscriptions/${SUB}/resourcegroups/rg-avd-prod/providers/microsoft.maintenance/maintenanceconfigurations/${n}`;
  // Assign a maintenance configuration to the first `limit` hosts of a pool (all of them by default).
  const assign = (pool, cfg, id, limit) => hosts.filter((h) => h.name.startsWith(`${pool}/`)).slice(0, limit)
    .map((h) => ({ id: `${h.vmId}/providers/microsoft.maintenance/configurationassignments/${id}`, cfgId: cfgId(cfg).toLowerCase(), target: h.vmId }));
  const wsId = (n) => `/subscriptions/${SUB}/resourcegroups/rg-avd-prod/providers/microsoft.desktopvirtualization/workspaces/${n}`;
  const more = compact ? { plans: [], groups: [], ws: [] } : {
    plans: [{ id: "p2", name: "sp-extended", resourceGroup: "rg-avd-prod", timeZone: "AUS Eastern Standard Time", schedules: [
        { name: "Early", daysOfWeek: ["Monday", "Tuesday", "Wednesday"], rampUpStartTime: { hour: 6, minute: 0 }, peakStartTime: { hour: 8, minute: 0 }, rampDownStartTime: { hour: 16, minute: 0 }, offPeakStartTime: { hour: 19, minute: 0 }, rampDownForceLogoffUsers: true },
        { name: "Late", daysOfWeek: ["Thursday", "Friday"], rampUpStartTime: { hour: 8, minute: 30 }, peakStartTime: { hour: 10, minute: 0 }, rampDownStartTime: { hour: 18, minute: 30 }, offPeakStartTime: { hour: 21, minute: 0 }, rampDownForceLogoffUsers: true },
        { name: "Weekend", daysOfWeek: ["Saturday"], rampUpStartTime: { hour: 9, minute: 0 }, peakStartTime: { hour: 10, minute: 0 }, rampDownStartTime: { hour: 13, minute: 0 }, offPeakStartTime: { hour: 15, minute: 0 }, rampDownForceLogoffUsers: false }],
      pools: [{ hostPoolArmPath: finance.id, scalingPlanEnabled: true }, { hostPoolArmPath: ext.id, scalingPlanEnabled: true }, { hostPoolArmPath: hr.id, scalingPlanEnabled: false }] }],
    groups: [
      { id: "g4", name: "hp-pooled-finance-DAG", resourceGroup: "rg-avd-prod", groupKind: "Desktop", poolPath: finance.id.toLowerCase(), workspacePath: wsId("ws-contoso").toLowerCase() },
      { id: "g5", name: "hp-personal-dev-DAG", resourceGroup: "rg-avd-dev", groupKind: "Desktop", poolPath: dev.id.toLowerCase(), workspacePath: wsId("ws-engineering").toLowerCase() },
      { id: "g6", name: "hp-pooled-hr-apps", resourceGroup: "rg-avd-prod", groupKind: "RemoteApp", poolPath: hr.id.toLowerCase(), workspacePath: wsId("ws-contoso").toLowerCase() },
      { id: "g7", name: "hp-personal-eng-DAG", resourceGroup: "rg-avd-eng", groupKind: "Desktop", poolPath: eng.id.toLowerCase(), workspacePath: wsId("ws-engineering").toLowerCase() },
      { id: "g8", name: "hp-pooled-contractors-DAG", resourceGroup: "rg-avd-ext", groupKind: "Desktop", poolPath: ext.id.toLowerCase(), workspacePath: "" },
    ],
    ws: [{ id: wsId("ws-engineering"), name: "ws-engineering", resourceGroup: "rg-avd-eng", friendly: "Engineering Desktops", groups: 2 }],
  };
  return {
    plans: normalizePlans([{ id: "p1", name: "sp-weekday", resourceGroup: "rg-avd-prod", timeZone: "AUS Eastern Standard Time", schedules: [
        { name: "Weekdays", daysOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"], rampUpStartTime: { hour: 7, minute: 0 }, peakStartTime: { hour: 9, minute: 0 }, rampDownStartTime: { hour: 17, minute: 30 }, offPeakStartTime: { hour: 20, minute: 0 }, rampDownForceLogoffUsers: true },
        { name: "Weekend", daysOfWeek: ["Saturday", "Sunday"], rampUpStartTime: { hour: 9, minute: 0 }, peakStartTime: { hour: 10, minute: 0 }, rampDownStartTime: { hour: 14, minute: 0 }, offPeakStartTime: { hour: 16, minute: 0 }, rampDownForceLogoffUsers: false }],
      pools: [{ hostPoolArmPath: prod.id, scalingPlanEnabled: true }, { hostPoolArmPath: test.id, scalingPlanEnabled: false }] }, ...more.plans]),
    appGroups: [
      { id: "g1", name: "hp-pooled-prod-DAG", resourceGroup: "rg-avd-prod", groupKind: "Desktop", poolPath: prod.id.toLowerCase(), workspacePath: wsId("ws-contoso").toLowerCase() },
      { id: "g2", name: "hp-personal-exec-DAG", resourceGroup: "rg-avd-prod", groupKind: "Desktop", poolPath: personal.id.toLowerCase(), workspacePath: wsId("ws-contoso").toLowerCase() },
      { id: "g3", name: "hp-pooled-prod-apps", resourceGroup: "rg-avd-prod", groupKind: "RemoteApp", poolPath: prod.id.toLowerCase(), workspacePath: "" },
      ...more.groups,
    ],
    workspaces: [{ id: wsId("ws-contoso"), name: "ws-contoso", resourceGroup: "rg-avd-prod", friendly: "Contoso Desktops", groups: compact ? 2 : 4 }, ...more.ws],
    configs: [
      { id: cfgId("mc-patch-weekend"), name: "mc-patch-weekend", resourceGroup: "rg-avd-prod", location: "australiaeast", cfgScope: "InGuestPatch", startsAt: "2026-01-01 22:00", windowLength: "03:55", recurrence: "Week Saturday, Sunday", cfgZone: "AUS Eastern Standard Time" },
      { id: cfgId("mc-patch-midweek"), name: "mc-patch-midweek", resourceGroup: "rg-avd-prod", location: "australiaeast", cfgScope: "InGuestPatch", startsAt: "2026-01-01 23:00", windowLength: "02:30", recurrence: "Week Wednesday", cfgZone: "AUS Eastern Standard Time" },
      { id: cfgId("mc-patch-monthly"), name: "mc-patch-monthly", resourceGroup: "rg-avd-dev", location: "australiaeast", cfgScope: "InGuestPatch", startsAt: "2026-01-01 01:00", windowLength: "04:00", recurrence: "Month Second Tuesday", cfgZone: "AUS Eastern Standard Time" },
    ],
    assignments: [...assign("hp-pooled-prod", "mc-patch-weekend", "a"), ...assign("hp-personal-exec", "mc-patch-midweek", "b"), ...assign("hp-pooled-prod", "mc-patch-midweek", "c", 2)],
    fetchedAt: Date.now(), sample: true,
  };
}

/** Sample PIM role schedules (the raw shape Azure returns, run through the real normalizer and merge). */
export function samplePim(now = Date.now()) {
  const hours = (h) => new Date(now + h * 3600 * 1000).toISOString();
  const sub = `/subscriptions/${SUB}`, rg = `${sub}/resourcegroups/rg-avd-prod`;
  const inst = (role, scope, name, type, p = {}) => ({ properties: { roleDefinitionId: `/providers/microsoft.authorization/roledefinitions/${role}`, scope, expandedProperties: { roleDefinition: { displayName: role }, scope: { displayName: name, type, id: scope } }, ...p } });
  const eligible = [
    inst("Desktop Virtualization Contributor", sub, "Contoso Production", "subscription", { endDateTime: hours(24 * 180) }),
    inst("Virtual Machine Contributor", rg, "rg-avd-prod", "resourcegroup", { endDateTime: hours(24 * 180) }),
    inst("Contributor", sub, "Contoso Production", "subscription"),
    inst("Owner", `/subscriptions/${SUB_TEST}`, "Contoso Test", "subscription", { endDateTime: hours(24 * 30) }),
  ];
  const active = [
    inst("Desktop Virtualization Contributor", sub, "Contoso Production", "subscription", { assignmentType: "Activated", memberType: "Direct", endDateTime: hours(5) }),
    inst("Reader", sub, "Contoso Production", "subscription", { assignmentType: "Assigned", memberType: "Inherited" }),
  ];
  return { rows: pimRows(eligible.map(normalizeInstance), active.map(normalizeInstance), now), errors: [], fetchedAt: now, sample: true };
}

/** The demo overview: 8 pools. { compact: true } gives the first 3 pools only (the offline tests are written against that). */
export function sampleOverview({ compact = false } = {}) {
  const pools = compact ? POOLS.slice(0, COMPACT_POOLS) : POOLS;
  const rows = joinHosts(pools, compact ? hosts.slice(0, COMPACT_ROWS) : hosts, compact ? vms.slice(0, COMPACT_ROWS) : vms);
  return { summary: summarise(pools, rows), hosts: rows, pools, subs: subsWithPools(SUBS, pools), fetchedAt: Date.now(), sample: true };
}

/** The demo's "Your access" answer, through the real evaluate: read everywhere, power on two groups, drain mode on one. */
export function sampleAccess(scopes = scopesOf(POOLS)) {
  const reader = { actions: ["*/read"], notActions: [] };
  const power = { actions: ["Microsoft.Compute/virtualMachines/start/action", "Microsoft.Compute/virtualMachines/restart/action", "Microsoft.Compute/virtualMachines/deallocate/action"], notActions: [] };
  const drain = { actions: ["Microsoft.DesktopVirtualization/hostPools/sessionHosts/write"], notActions: [] };
  const byScope = {};
  for (const sc of scopes) byScope[sc] = [reader, ...(/rg-avd-(prod|dev)$/i.test(sc) ? [power] : []), ...(/rg-avd-prod$/i.test(sc) ? [drain] : [])];
  return { ...evaluate(byScope), checkedAt: Date.now() };
}
