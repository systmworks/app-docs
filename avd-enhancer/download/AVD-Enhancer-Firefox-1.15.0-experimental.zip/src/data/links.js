// Quick links shown on the Workspace Links tab: one list, grouped. When the signed-in tenant is known it is added to
// each link (linkGroups), otherwise the portal opens the default directory. Deep links are Microsoft's own portal
// addresses; docs/status.md lists which have been checked on a live tenant.

const AZ = "https://portal.azure.com";
const EN = "https://entra.microsoft.com";
const IN = "https://intune.microsoft.com";
const browse = (type) => `${AZ}/#browse/${encodeURIComponent(type)}`;

/** The store pages of Intune Enhancer, by browser. The sidebar link opens one in a new tab; the extension makes no request to it. */
export const INTUNE_STORES = {
  chrome: { name: "Chrome Web Store", url: "https://chromewebstore.google.com/detail/intune-enhancer/geifmacoimaenjdednhfiegamkjkgjjm" },
  edge: { name: "Edge Add-ons", url: "https://microsoftedge.microsoft.com/addons/detail/intune-enhancer/hcmhldmcpgieiaeobdbppcgfckahdeci" },
  firefox: { name: "Firefox Add-ons", url: "https://addons.mozilla.org/firefox/addon/intune-enhancer/" },
};
/** The store that matches a browser's user agent: Edge, Firefox, otherwise Chrome (also Brave, Opera and other Chromium browsers). */
export const intuneStore = (ua = "") => (/\bEdg(e|A|iOS)?\//.test(ua) ? INTUNE_STORES.edge : /\bFirefox\//.test(ua) ? INTUNE_STORES.firefox : INTUNE_STORES.chrome);

export const LINK_GROUPS = [
  { title: "Azure Virtual Desktop", links: [
    { label: "AVD overview", url: `${AZ}/#view/Microsoft_Azure_WVD/WvdManagerMenuBlade/~/overview` },
    { label: "Host pools", url: browse("Microsoft.DesktopVirtualization/hostpools") },
    { label: "Workspaces", url: browse("Microsoft.DesktopVirtualization/workspaces") },
    { label: "Application groups", url: browse("Microsoft.DesktopVirtualization/applicationgroups") },
    { label: "Scaling plans", url: browse("Microsoft.DesktopVirtualization/scalingplans") },
  ] },
  { title: "Azure compute and operations", links: [
    { label: "Virtual machines", url: browse("Microsoft.Compute/virtualMachines") },
    { label: "Compute galleries", url: browse("Microsoft.Compute/galleries") },
    { label: "Disks", url: browse("Microsoft.Compute/disks") },
    { label: "Resource groups", url: `${AZ}/#view/HubsExtension/BrowseResourceGroups` },
    { label: "Azure Monitor", url: `${AZ}/#view/Microsoft_Azure_Monitoring/AzureMonitoringBrowseBlade/~/overview` },
    { label: "Cost Management", url: `${AZ}/#view/Microsoft_Azure_CostManagement/Menu/~/overview` },
  ] },
  { title: "Entra ID", links: [
    { label: "Users", url: `${EN}/#view/Microsoft_AAD_UsersAndTenants/UserManagementMenuBlade/~/AllUsers` },
    { label: "Groups", url: `${EN}/#view/Microsoft_AAD_IAM/GroupsManagementMenuBlade/~/AllGroups` },
    { label: "Devices", url: `${EN}/#view/Microsoft_AAD_Devices/DevicesMenuBlade/~/Devices/menuId~/null` },
    { label: "Conditional Access", url: `${EN}/#view/Microsoft_AAD_ConditionalAccess/ConditionalAccessBlade/~/Policies` },
    { label: "Sign-in logs", url: `${EN}/#view/Microsoft_AAD_IAM/ActiveDirectoryMenuBlade/~/SignIns` },
  ] },
  { title: "Privileged Identity Management", links: [
    { label: "Activate Entra roles", url: `${AZ}/#view/Microsoft_Azure_PIMCommon/ActivationMenuBlade/~/aadmigratedroles` },
    { label: "Activate Azure resource roles", url: `${AZ}/#view/Microsoft_Azure_PIMCommon/ActivationMenuBlade/~/azurerbac` },
    { label: "Activate group roles", url: `${AZ}/#view/Microsoft_Azure_PIMCommon/ActivationMenuBlade/~/aadgroup` },
  ] },
  { title: "Intune", links: [
    { label: "Devices", url: `${IN}/#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/overview` },
    { label: "Windows 365", url: `${IN}/#view/Microsoft_Intune_DeviceSettings/DevicesWindowsMenu/~/cloudPcs` },
  ] },
];

/**
 * Azure's own reports and dashboards that bear on AVD, for the All reports tab. UNCHECKED: these are the portal's blade addresses as
 * Microsoft documents or names them, not yet opened on a live tenant (docs/status.md lists the ones that have been). A wrong one opens the
 * portal's home or a "not found" page, never anything in the tenant.
 */
export const REPORT_GROUPS = [
  { title: "Monitoring and insights", links: [
    { label: "Azure Virtual Desktop Insights", url: `${AZ}/#view/Microsoft_Azure_WVD/WvdManagerMenuBlade/~/insights` },
    { label: "Azure Monitor workbooks", url: `${AZ}/#view/Microsoft_Azure_Monitoring/AzureMonitoringBrowseBlade/~/workbooks` },
    { label: "Log Analytics workspaces", url: browse("Microsoft.OperationalInsights/workspaces") },
    { label: "Service Health", url: `${AZ}/#view/Microsoft_Azure_Health/AzureHealthBrowseBlade/~/serviceIssues` },
  ] },
  { title: "Cost and recommendations", links: [
    { label: "Cost analysis", url: `${AZ}/#view/Microsoft_Azure_CostManagement/Menu/~/costanalysis` },
    { label: "Advisor recommendations", url: `${AZ}/#view/Microsoft_Azure_Expert/AdvisorMenuBlade/~/overview` },
  ] },
  { title: "Governance and inventory", links: [
    { label: "Azure Policy compliance", url: `${AZ}/#view/Microsoft_Azure_Policy/PolicyMenuBlade/~/Compliance` },
    { label: "Resource Graph Explorer", url: `${AZ}/#view/HubsExtension/ArgQueryBlade` },
    { label: "Defender for Cloud", url: `${AZ}/#view/Microsoft_Azure_Security/SecurityMenuBlade/~/overview` },
  ] },
];

/** The links with the tenant filled in. Only https urls on the three portal hosts come out (a safety net for edits). */
const fillGroups = (groups, tid) => {
  const ok = /^https:\/\/(?:portal\.azure\.com|entra\.microsoft\.com|intune\.microsoft\.com)\//;
  return groups.map((g) => ({
    title: g.title,
    links: g.links.filter((l) => ok.test(l.url)).map((l) => ({ label: l.label, url: tid ? withTenant(l.url, tid) : l.url })),
  }));
};

/** The Links tab's groups, with the tenant filled in. */
export const linkGroups = (tid = "") => fillGroups(LINK_GROUPS, tid);
/** The All reports tab's groups of Azure reports, with the tenant filled in. */
export const reportGroups = (tid = "") => fillGroups(REPORT_GROUPS, tid);

/** Azure portal page of a resource (a session host id from avd.js); the tenant form is added when known. */
export const resourceUrl = (id, tid = "") => `${AZ}/#${tid ? `@${encodeURIComponent(tid)}/` : ""}resource${id}/overview`;

/** https://host/#view/... -> https://host/#@<tenant>/view/... (the portal shell's own tenant form; unverified on Entra/Intune). */
export const withTenant = (url, tid) => url.replace("/#", `/#@${encodeURIComponent(tid)}/`);
