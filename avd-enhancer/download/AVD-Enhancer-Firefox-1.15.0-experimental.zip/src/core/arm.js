// Azure Resource Manager client for the service worker (README ground rules 1 and 2). The host permission on
// management.azure.com means these fetches are not subject to CORS. Two guards run on every request, next-page links
// included: the host must be a known ARM host, and the request must be a read.

import { ARM_HOSTS } from "./clouds.js";

const TIMEOUT_MS = 30000;
const MAX_RETRIES = 3;
const RETRY_STATUS = new Set([429, 502, 503, 504]);
const MAX_PAGES = 100; // a safety stop for a paged query whose skip tokens never end
const ARG_PATH = "/providers/Microsoft.ResourceGraph/resources";
export const ARG_API = "2022-10-01";

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const armError = (message, code, extra = {}) => Object.assign(new Error(message), { code, ...extra });

/** True only for https URLs on a known ARM host (no credentials, no odd port); when `host` is given, only that one. */
export function isArmUrl(url, host = "") {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && ARM_HOSTS.includes(u.hostname) && (!host || u.hostname === host)
      && !u.username && !u.password && (u.port === "" || u.port === "443");
  } catch {
    return false;
  }
}

/** GET is always a read. The one POST allowed is the Resource Graph query, which reads and changes nothing. */
export function assertReadOnly(method, path) {
  if (method === "GET") return;
  if (method === "POST" && path.toLowerCase() === ARG_PATH.toLowerCase()) return;
  throw armError(`Blocked a ${method} request: the extension only reads (${String(path).slice(0, 100)})`, "BLOCKED_METHOD");
}

/**
 * getTokens(): access tokens best-first; a 401/403 moves on to the next, and the first that works goes to onGood.
 * getHost(): the signed-in cloud's ARM host. deps: { fetch, sleep } for tests only.
 */
export function createArmClient(getTokens, onGood = () => {}, getHost = () => ARM_HOSTS[0], deps = {}) {
  // deps lets the offline tests swap in a fake fetch and a no-wait sleep.
  const doFetch = deps.fetch || ((...args) => fetch(...args));
  const wait = deps.sleep || sleep;
  async function once(url, init, token) {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), TIMEOUT_MS);
    try {
      return await doFetch(url, { ...init, signal: ctl.signal, headers: { ...init.headers, Authorization: `Bearer ${token}`, Accept: "application/json" } });
    } catch (e) {
      throw armError(e.name === "AbortError" ? "Azure did not answer in time." : "Could not reach Azure.", "NETWORK");
    } finally {
      clearTimeout(timer);
    }
  }

  async function request(url, init = {}) {
    const tokens = getTokens();
    if (!tokens.length) throw armError("Not signed in: open the Azure portal once, then try again.", "NO_TOKEN");
    if (!isArmUrl(url, getHost())) throw armError(`Blocked a request to a non-Azure address: ${String(url).slice(0, 100)}`, "BLOCKED_HOST");
    assertReadOnly((init.method || "GET").toUpperCase(), new URL(url).pathname);
    let denied = null;
    for (const token of tokens) {
      for (let tries = 0; ; tries++) {
        const res = await once(url, init, token);
        if (RETRY_STATUS.has(res.status)) {
          if (tries >= MAX_RETRIES) throw armError(`Azure is busy or unavailable (${res.status}). Try again in a few minutes.`, "THROTTLED", { status: res.status });
          await wait(Math.min(Number(res.headers.get("Retry-After")) || 2 ** (tries + 1), 60) * 1000);
          continue;
        }
        if (res.status === 401 || res.status === 403) { denied = res.status; break; }
        if (!res.ok) {
          // Azure says what it disliked (a bad query, say) in the body; show the first line of it.
          const detail = await res.json().then((j) => j?.error?.details?.[0]?.message || j?.error?.message || "").catch(() => "");
          throw armError(`Azure answered ${res.status}${detail ? `: ${String(detail).slice(0, 240)}` : "."}`, "HTTP", { status: res.status });
        }
        onGood(token);
        return res.json();
      }
    }
    throw armError(denied === 403 ? "Azure refused: your account needs Reader on the subscriptions or resource groups." : "Azure refused the sign-in: open the Azure portal again.", "DENIED", { status: denied });
  }

  return {
    request,

    /** GET a path on the signed-in cloud's ARM host (path starts with "/"); api-version is added. */
    get(path, apiVersion) {
      return request(`https://${getHost()}${path}${path.includes("?") ? "&" : "?"}api-version=${apiVersion}`);
    },

    /** GET every page of a list: follows nextLink (an absolute URL, held to the same host guard as every request). */
    async getAll(path, apiVersion) {
      const out = [];
      let res = await this.get(path, apiVersion);
      for (let page = 0; ; page++) {
        out.push(...(res.value || []));
        if (!res.nextLink || page >= MAX_PAGES) return out;
        res = await request(res.nextLink);
      }
    },

    /** Run a Resource Graph query across every subscription the account can read; returns all rows (pages followed). */
    async query(kql) {
      const url = `https://${getHost()}${ARG_PATH}?api-version=${ARG_API}`;
      const rows = [];
      let skipToken;
      for (let page = 0; page < MAX_PAGES; page++) {
        const body = { query: kql, options: { resultFormat: "objectArray", $top: 1000, ...(skipToken ? { $skipToken: skipToken } : {}) } };
        const res = await request(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
        rows.push(...(res.data || []));
        skipToken = res.$skipToken;
        if (!skipToken) break;
      }
      return rows;
    },
  };
}
