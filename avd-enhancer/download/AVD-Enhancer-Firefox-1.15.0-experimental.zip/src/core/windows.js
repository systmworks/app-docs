// Time windows shown in the Workspace: scaling plan schedules (days and times for ramp-up, peak, ramp-down, off-peak) and
// Azure maintenance configurations (recurrence, start, end) with the VMs they are assigned to. Pure functions.

// The two maintenance reads are plain Resource Graph queries (the second table is not one of the AVD tables).
export const MAINT_KQL = `resources
| where type =~ 'microsoft.maintenance/maintenanceconfigurations'
| project id, name, resourceGroup, location, cfgScope = tostring(properties.maintenanceScope),
    startsAt = tostring(properties.maintenanceWindow.startDateTime), windowLength = tostring(properties.maintenanceWindow.duration),
    recurrence = tostring(properties.maintenanceWindow.recurEvery), cfgZone = tostring(properties.maintenanceWindow.timeZone)`;

// An assignment's id is "<resource id>/providers/microsoft.maintenance/configurationassignments/<name>"; the part before is the VM.
export const ASSIGN_KQL = `maintenanceresources
| where type =~ 'microsoft.maintenance/configurationassignments'
| project id, cfgId = tolower(tostring(properties.maintenanceConfigurationId)),
    target = tolower(tostring(split(id, '/providers/microsoft.maintenance/')[0]))`;

/** Day names in week order (Monday first), lower case. */
const DAY_ORDER = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
/** A number as at least two digits. */
const pad = (n) => String(n).padStart(2, "0");

/** { hour, minute } -> "07:30"; anything else -> "". */
export const hhmm = (t) => (t && Number.isFinite(Number(t.hour)) ? `${pad(Number(t.hour))}:${pad(Number(t.minute) || 0)}` : "");

/** ["Monday","Tuesday","Wednesday","Friday"] -> "Mon-Wed, Fri": week order, runs of three or more joined with a dash. */
export function dayList(days) {
  const idx = [...new Set((days || []).map((d) => DAY_ORDER.indexOf(String(d).toLowerCase())).filter((i) => i >= 0))].sort((a, b) => a - b);
  const name = (i) => DAY_ORDER[i].slice(0, 1).toUpperCase() + DAY_ORDER[i].slice(1, 3);
  const parts = [];
  for (let i = 0; i < idx.length;) {
    let j = i;
    while (j + 1 < idx.length && idx[j + 1] === idx[j] + 1) j++;
    if (j - i >= 2) parts.push(`${name(idx[i])}-${name(idx[j])}`);
    else for (let k = i; k <= j; k++) parts.push(name(idx[k]));
    i = j + 1;
  }
  return parts.join(", ");
}

/** One schedule as plain fields: days and the four phase start times. */
export const scheduleFields = (s) => ({
  schedule: s.name || "", days: dayList(s.daysOfWeek), rampUp: hhmm(s.rampUpStartTime), peak: hhmm(s.peakStartTime),
  rampDown: hhmm(s.rampDownStartTime), offPeak: hhmm(s.offPeakStartTime), logoff: s.rampDownForceLogoffUsers ? "Force log off" : "Wait for users",
});

/** One row per schedule of every scaling plan, with the plan's id and time zone; a plan with no schedule still gets one row ("No schedules"). */
export const scheduleRows = (plans) => (plans || []).flatMap((p) => {
  const base = { plan: p.name, planId: String(p.id || "").toLowerCase(), timeZone: p.timeZone || "" };
  const list = p.scheduleList || [];
  return list.length ? list.map((s) => ({ ...base, ...scheduleFields(s) }))
    : [{ ...base, schedule: "No schedules", days: "", rampUp: "", peak: "", rampDown: "", offPeak: "", logoff: "" }];
}).sort((a, b) => a.plan.localeCompare(b.plan) || a.rampUp.localeCompare(b.rampUp) || a.schedule.localeCompare(b.schedule));

/** "Week Saturday, Sunday" -> "Sat-Sun"; "2Weeks Monday" -> "Every 2 weeks: Mon"; "Day" -> "Every day"; "Month Fourth Monday" -> "Fourth Monday of the month". */
export function recurDays(recur) {
  const m = /^\s*(\d*)\s*(day|week|month)s?\s*(.*)$/i.exec(String(recur || ""));
  if (!m) return String(recur || "");
  const n = Number(m[1]) || 1, rest = m[3].replace(/\s*Offset-?\d+/i, "").trim();
  if (m[2].toLowerCase() === "day") return n > 1 ? `Every ${n} days` : "Every day";
  if (m[2].toLowerCase() === "week") {
    const days = dayList(rest.split(/[,\s]+/).filter(Boolean)) || "every day";
    return n > 1 ? `Every ${n} weeks: ${days}` : days;
  }
  const what = rest.replace(/day\s*(\d+)/gi, "Day $1").replace(/,\s*/g, ", ");
  return `${what || "Every month"} of the month${n > 1 ? ` (every ${n} months)` : ""}`;
}

/** Start time, end time and length from a maintenance window ("2026-01-01 22:00", "03:55"); end is "" when unreadable. */
export function windowTimes(startsAt, windowLength) {
  const s = /(\d{1,2}):(\d{2})/.exec(String(startsAt || "")), d = /^(\d{1,2}):(\d{2})/.exec(String(windowLength || ""));
  if (!s) return { start: "", end: "", length: String(windowLength || "") };
  const start = `${pad(Number(s[1]))}:${s[2]}`;
  if (!d) return { start, end: "", length: "" };
  const total = Number(s[1]) * 60 + Number(s[2]) + Number(d[1]) * 60 + Number(d[2]);
  const e = total % 1440;
  return { start, end: `${pad(Math.floor(e / 60))}:${pad(e % 60)}${total >= 1440 ? " (next day)" : ""}`, length: `${Number(d[1])}h ${pad(Number(d[2]))}m` };
}

/** Maintenance configurations as rows with their day, start, end and how many VMs (and AVD hosts) they are assigned to. */
export function maintRows(configs, assignments, hosts) {
  const byCfg = new Map();
  for (const a of assignments || []) {
    const set = byCfg.get(a.cfgId) || new Set();
    set.add(a.target);
    byCfg.set(a.cfgId, set);
  }
  return (configs || []).map((c) => {
    const targets = byCfg.get(String(c.id).toLowerCase()) || new Set();
    const t = windowTimes(c.startsAt, c.windowLength);
    return {
      id: String(c.id), name: c.name, scope: c.cfgScope || "", days: recurDays(c.recurrence), start: t.start, end: t.end, length: t.length,
      timeZone: c.cfgZone || "", vms: targets.size, hosts: (hosts || []).filter((h) => targets.has(h.vmId)).length, resourceGroup: c.resourceGroup || "",
    };
  }).sort((a, b) => a.name.localeCompare(b.name));
}

/** The maintenance rows that apply to one VM (by lower-case VM id), from the assignments. */
export function hostWindows(vmId, rows, assignments) {
  const mine = new Set((assignments || []).filter((a) => a.target === String(vmId || "").toLowerCase()).map((a) => a.cfgId));
  return (rows || []).filter((r) => mine.has(r.id.toLowerCase()));
}
