// The Console tab's log: pure helpers (the worker keeps the list in chrome.storage.session, so it lasts for the browser
// session and is never written to disk). Nothing secret goes in: redact() strips anything that looks like a token.

export const MAX_LOG = 200;
export const LEVELS = ["info", "warn", "error"];

/** Text safe to keep: JWTs and Bearer values replaced, and cut to a sensible length. */
export const redact = (text) => String(text ?? "")
  .replace(/eyJ[\w-]{8,}\.[\w-]{8,}(\.[\w-]*)?/g, "[token]")
  .replace(/Bearer\s+[\w.~+/=-]+/gi, "Bearer [token]")
  .slice(0, 600);

/** The list with one more entry, keeping only the newest `max`. */
export const addEntry = (list, entry, max = MAX_LOG) => [...list, entry].slice(-max);

/** Entries at or above a level ("all", "warn" = warnings and errors, "error" = errors only). */
export const atLevel = (entries, level) => {
  const min = level === "error" ? 2 : level === "warn" ? 1 : 0;
  return entries.filter((e) => LEVELS.indexOf(e.level) >= min);
};

/** The entries as plain text, one line each, for copying or saving. */
export const formatLog = (entries) => entries
  .map((e) => `${new Date(e.t).toISOString()} ${String(e.level).toUpperCase()} [${e.source}] ${e.message}${e.detail ? ` (${e.detail})` : ""}`)
  .join("\n");
