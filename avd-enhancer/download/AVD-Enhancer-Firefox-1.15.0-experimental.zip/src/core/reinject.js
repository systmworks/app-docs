// After an install or an update the browser does not run a content script in a tab that was already open: the tab keeps
// the old, orphaned copy (it can no longer reach the extension), and the new version's token pickup waits for the next
// page load. An update also empties the token pool (storage.session), so the Intune tab would show no token until the
// admin reloaded it. This runs the version's own scripts in those tabs once, so the sign-in is picked up at once.

/**
 * Run `files` (the manifest's content script files, in order) in the top frame of every open tab that matches `matches`.
 * api is the extension API (chrome, or a stand-in in the tests): it needs tabs.query and scripting.executeScript.
 * A tab that refuses (closed meanwhile, discarded, no access) is skipped. Returns how many tabs the scripts ran in.
 */
export async function injectIntoOpenTabs(api, files, matches) {
  if (!api?.tabs?.query || !api?.scripting?.executeScript || !files?.length || !matches?.length) return 0;
  const tabs = (await api.tabs.query({ url: matches }).catch(() => [])) || [];
  let done = 0;
  for (const tab of tabs) {
    if (tab.id === undefined) continue;
    try {
      await api.scripting.executeScript({ target: { tabId: tab.id }, files });
      done++;
    } catch { /* this tab cannot be reached: it picks the sign-in up on its next load */ }
  }
  return done;
}
