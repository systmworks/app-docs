// Charts for the Reports tabs and the saved report page: plain HTML and CSS bars, no library, no script, no animation. Every bar sits beside
// its value as text, so a chart reads without colour (and prints, and a screen reader hears it). A bar's colour is a class, never a colour
// value: the workspace maps the classes to the theme's tokens (workspace.css) and the saved page maps them to its own palette (report-doc.js).
// Pure (no DOM), so the offline tests cover it.

import { esc } from "./host-table.js";

/** How many series colours there are (classes c1 to c6); a bar without a tone takes the next one, round and round. */
export const SERIES = 6;
const TONES = new Set(["ok", "warn", "bad", "off"]);

/** The class of item i: its tone (ok, warn, bad, off) when it has a known one, otherwise the numbered series colour. */
export const toneClass = (item, i) => (TONES.has(item?.tone) ? item.tone : `c${(i % SERIES) + 1}`);

const barWidth = (v, max) => (max > 0 && v > 0 ? Math.min(100, Math.max(2, Math.round((v * 1000) / max) / 10)) : 0);

/** A list of horizontal bars, longest at 100%: items are { label, value, tone?, note? }. Empty list gives the empty text. */
export function barList(items, empty = "Nothing to show.") {
  const rows = (items || []).filter((x) => x && Number.isFinite(Number(x.value)) && Number(x.value) >= 0);
  if (!rows.length) return `<p class="muted small">${esc(empty)}</p>`;
  const max = Math.max(...rows.map((x) => Number(x.value)));
  return `<ul class="chart-bars">${rows.map((x, i) => `<li><span class="chart-label">${esc(x.label)}</span><span class="chart-track"><span class="chart-fill ${toneClass(x, i)}" style="width:${barWidth(Number(x.value), max)}%"></span></span><span class="chart-val">${esc(x.value)}${x.note ? ` <span class="muted small">${esc(x.note)}</span>` : ""}</span></li>`).join("")}</ul>`;
}

/** One bar split into parts that add up to the whole, with a legend that lists each part and its value: parts are { label, value, tone? }. */
export function stackBar(parts, empty = "Nothing to show.") {
  const rows = (parts || []).filter((x) => x && Number.isFinite(Number(x.value)) && Number(x.value) > 0);
  const total = rows.reduce((n, x) => n + Number(x.value), 0);
  if (!total) return `<p class="muted small">${esc(empty)}</p>`;
  const text = rows.map((x) => `${x.label} ${x.value}`).join(", ");
  return `<div class="chart-stack" role="img" aria-label="${esc(text)}">${rows.map((x, i) => `<span class="chart-fill ${toneClass(x, i)}" style="width:${Math.round((Number(x.value) * 1000) / total) / 10}%"></span>`).join("")}</div>`
    + `<ul class="chart-legend">${rows.map((x, i) => `<li><span class="chart-key ${toneClass(x, i)}"></span>${esc(x.label)} <b>${esc(x.value)}</b> <span class="muted small">${Math.round((Number(x.value) * 100) / total)}%</span></li>`).join("")}</ul>`;
}

/** One chart as HTML, by kind ("bars" or "stack"). */
export const chartHtml = (chart) => (chart.kind === "stack" ? stackBar(chart.items, chart.empty) : barList(chart.items, chart.empty));
