// Pool quick links: up to six host pools the user picks in Settings, shown as a "Pools" section in the sidebar. Pure functions;
// the page saves the slots in the display settings (poolLinks) and draws them (renderPoolLinks in workspace/dashboard.js).

export const POOL_LINK_SLOTS = 6;

/** Saved slots as exactly POOL_LINK_SLOTS of { id, name }: the id is a lower-case pool resource id ("" for an empty slot, as is a repeat of an earlier slot). */
export function cleanPoolLinks(raw) {
  const seen = new Set();
  return Array.from({ length: POOL_LINK_SLOTS }, (_, i) => {
    const c = Array.isArray(raw) ? raw[i] : null;
    const id = typeof c?.id === "string" ? c.id.trim().toLowerCase().slice(0, 300) : "";
    if (!id.startsWith("/subscriptions/") || seen.has(id)) return { id: "", name: "" };
    seen.add(id);
    return { id, name: String(c.name || "").trim().slice(0, 128) };
  });
}

/**
 * The filled slots as sidebar rows { id, name, missing }. The name is the pool's current name when it is in the data, otherwise the saved one.
 * missing is true only when the overview has been read and the pool is not in it (any subscription): while nothing is loaded, or after a
 * failed read, no link is marked missing. Pure.
 */
export function poolLinkRows(links, data) {
  const pools = Array.isArray(data?.pools) ? data.pools : null;
  return (links || []).filter((l) => l.id).map((l) => {
    const live = pools?.find((p) => String(p.id).toLowerCase() === l.id);
    return { id: l.id, name: live?.name || l.name || l.id.split("/").pop(), missing: Boolean(pools && !live) };
  });
}
