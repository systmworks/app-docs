// Azure tags on the VMs behind the session hosts (a host row's `tags` object), and the Dashboard's custom cards. Pure functions.
// Tag names and values are compared without regard to case, as Azure does for names and as True/true/TRUE are one answer to a person.

/** How many custom cards the Dashboard can show (a third row under the eight tiles). */
export const CARD_SLOTS = 4;

/** The built-in numbers a custom card can show: [id, label]. Only numbers the Dashboard's eight tiles do not already show (a card that repeated a tile would add nothing). */
export const CARD_METRICS = [["hosts", "Session hosts"]];

/** A name or value as compared: trimmed, lower case. */
const key = (s) => String(s ?? "").trim().toLowerCase();

/** The host's value for a tag (any case of the name), or undefined when it does not have the tag. */
export function tagValue(host, tag) {
  const tags = host.tags || {};
  for (const k of Object.keys(tags)) if (key(k) === key(tag)) return String(tags[k] ?? "");
  return undefined;
}

/** Distinct values of a tag across the hosts with their counts, most common first: [{ value, n }]. */
export function tagValues(hosts, tag) {
  const counts = new Map();
  for (const h of hosts) {
    const v = tagValue(h, tag);
    if (v === undefined) continue;
    const e = counts.get(key(v)) || { value: v, n: 0 };
    e.n++;
    counts.set(key(v), e);
  }
  return [...counts.values()].sort((a, b) => b.n - a.n || a.value.localeCompare(b.value));
}

/** Every tag name seen on the hosts: { tag, hosts, values, summary } with the three most common values, sorted by name. */
export function tagList(hosts) {
  const names = new Map();
  for (const h of hosts) for (const k of Object.keys(h.tags || {})) if (!names.has(key(k))) names.set(key(k), k);
  return [...names.values()].map((tag) => {
    const vals = tagValues(hosts, tag);
    const summary = vals.slice(0, 3).map((v) => `${v.value || "(empty)"} x${v.n}`).join(", ") + (vals.length > 3 ? ", ..." : "");
    return { tag, hosts: vals.reduce((a, v) => a + v.n, 0), values: vals.length, summary };
  }).sort((a, b) => a.tag.localeCompare(b.tag, undefined, { sensitivity: "base" }));
}

/** Hosts by a tag. mode "all" = has the tag, "value" = has it with that value, "none" = does not have it. */
export function hostsByTag(hosts, tag, mode = "all", value = "") {
  return hosts.filter((h) => {
    const v = tagValue(h, tag);
    if (mode === "none") return v === undefined;
    if (v === undefined) return false;
    return mode === "value" ? key(v) === key(value) : true;
  });
}

/** Rows for the tagged-hosts table; hostId opens the host drawer. */
export const tagHostRows = (hosts, tag, mode, value) => hostsByTag(hosts, tag, mode, value).map((h) => ({
  hostId: h.id, name: h.name, pool: h.pool, power: h.power, status: h.status, value: tagValue(h, tag) ?? "", sessions: h.sessions,
})).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

/** Saved card settings as exactly CARD_SLOTS slots of { kind, tag, value }; kind is "" (empty slot), a metric id or "tag". */
export function cleanCards(raw) {
  const ok = new Set(["tag", ...CARD_METRICS.map(([id]) => id)]);
  return Array.from({ length: CARD_SLOTS }, (_, i) => {
    const c = Array.isArray(raw) ? raw[i] : null;
    const kind = ok.has(c?.kind) ? c.kind : "";
    return { kind, tag: kind === "tag" ? String(c.tag || "").trim().slice(0, 128) : "", value: kind === "tag" ? String(c.value || "").trim().slice(0, 256) : "" };
  });
}
