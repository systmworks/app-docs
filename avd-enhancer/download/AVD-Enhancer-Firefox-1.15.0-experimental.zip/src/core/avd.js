// AVD reads: two Resource Graph queries (pools and session hosts, VM power state) joined into one host list, plus the
// summary the Workspace tiles show. Pure functions except loadOverview, which takes the ARM client.

import { MAINT_KQL, ASSIGN_KQL } from "./windows.js";

const POOLS_KQL = `TABLE
| where type =~ 'microsoft.desktopvirtualization/hostpools'
| project id, name, resourceGroup, subscriptionId, location,
    poolType = tostring(properties.hostPoolType), maxSessions = toint(properties.maxSessionLimit),
    balancer = tostring(properties.loadBalancerType)`;

const HOSTS_KQL = `desktopvirtualizationresources
| where type =~ 'microsoft.desktopvirtualization/hostpools/sessionhosts'
| project id, name, resourceGroup, subscriptionId, location,
    status = tostring(properties.status), sessions = toint(properties.sessions),
    allowNew = tobool(properties.allowNewSession), agent = tostring(properties.agentVersion),
    os = tostring(properties.osVersion), heartbeat = tostring(properties.lastHeartBeat),
    user = tostring(properties.assignedUser), vmId = tolower(tostring(properties.resourceId))`;

// Pools, plans, application groups and workspaces are in `resources` on some tenants and in `desktopvirtualizationresources`
// on others, so the queries above say TABLE and are run against both, then merged by id. Session hosts are only in the second.
const TABLES = ["resources", "desktopvirtualizationresources"];

/** Run a TABLE query against both tables and merge the rows by resource id; fails only when both tables fail. */
export async function queryTables(arm, kql) {
  const results = await Promise.allSettled(TABLES.map((t) => arm.query(kql.replace("TABLE", t))));
  const ok = results.filter((r) => r.status === "fulfilled");
  if (!ok.length) throw results[0].reason;
  const byId = new Map();
  for (const r of ok) for (const row of r.value) if (!byId.has(String(row.id).toLowerCase())) byId.set(String(row.id).toLowerCase(), row);
  return [...byId.values()];
}

const SUBS_KQL = `resourcecontainers
| where type =~ 'microsoft.resources/subscriptions'
| project subscriptionId, name`;

const PLANS_KQL = `TABLE
| where type =~ 'microsoft.desktopvirtualization/scalingplans'
| project id, name, resourceGroup, timeZone = tostring(properties.timeZone),
    schedules = properties.schedules, pools = properties.hostPoolReferences`;

const APPGROUPS_KQL = `TABLE
| where type =~ 'microsoft.desktopvirtualization/applicationgroups'
| project id, name, resourceGroup, groupKind = tostring(properties.applicationGroupType),
    poolPath = tolower(tostring(properties.hostPoolArmPath)), workspacePath = tolower(tostring(properties.workspaceArmPath))`;

const WORKSPACES_KQL = `TABLE
| where type =~ 'microsoft.desktopvirtualization/workspaces'
| project id, name, resourceGroup, friendly = tostring(properties.friendlyName),
    groups = properties.applicationGroupReferences`;

const VMS_KQL = `resources
| where type =~ 'microsoft.compute/virtualmachines'
| project vmId = tolower(id), power = tostring(properties.extended.instanceView.powerState.code),
    size = tostring(properties.hardwareProfile.vmSize), vmTags = tags`;

/** "PowerState/running" -> "running"; anything unknown (no VM found, no instance view) -> "unknown". */
export const powerOf = (code) => String(code || "").replace(/^PowerState\//i, "").toLowerCase() || "unknown";

/** Session host resource names are "pool/host.fqdn"; the pool id is the host id minus its last two segments. */
const splitHost = (name) => { const [pool, ...rest] = String(name).split("/"); return { pool, host: rest.join("/") }; };
const poolIdOf = (hostId) => String(hostId).toLowerCase().replace(/\/sessionhosts\/[^/]+$/, "");

/** Compare dotted version strings numerically: negative when a is older than b. */
export function compareVersions(a, b) {
  const pa = String(a).split(".").map(Number), pb = String(b).split(".").map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) - (pb[i] || 0);
  return 0;
}

/** A running host whose last heartbeat is older than this is stale: its agent has probably stopped reporting. */
export const STALE_MS = 15 * 60 * 1000;

/** One row per session host with its pool, power state and health, from the three query results. */
export function joinHosts(pools, hosts, vms, now = Date.now()) {
  const poolBy = new Map(pools.map((p) => [String(p.id).toLowerCase(), p]));
  const vmBy = new Map(vms.map((v) => [v.vmId, v]));
  const rows = hosts.map((h) => {
    const { pool, host } = splitHost(h.name);
    const p = poolBy.get(poolIdOf(h.id));
    const vm = vmBy.get(h.vmId);
    return {
      id: h.id, name: host, pool, poolId: poolIdOf(h.id), resourceGroup: h.resourceGroup, subscriptionId: h.subscriptionId,
      region: h.location, power: powerOf(vm?.power), size: vm?.size || "", tags: vm?.vmTags && typeof vm.vmTags === "object" ? vm.vmTags : {}, status: h.status || "Unknown",
      sessions: h.sessions || 0, drain: h.allowNew === false, agent: h.agent || "", os: h.os || "",
      heartbeat: h.heartbeat || "", user: h.user || "", vmId: h.vmId || "", poolType: p?.poolType || "", maxSessions: p?.maxSessions || 0,
      oldAgent: false, stale: false, issue: "",
    };
  });
  // An agent older than the newest one seen across all hosts is "old" (the newest is the best guide to what is current).
  const agents = rows.map((r) => r.agent).filter(Boolean);
  const newest = agents.reduce((a, b) => (compareVersions(a, b) >= 0 ? a : b), agents[0] || "");
  for (const r of rows) {
    r.oldAgent = Boolean(r.agent) && compareVersions(r.agent, newest) < 0;
    const beat = Date.parse(r.heartbeat);
    r.stale = isOn(r) && Number.isFinite(beat) && now - beat > STALE_MS && r.status !== "Available";
    r.issue = issueReason(r);
  }
  return rows;
}

/** True when the host's VM is running (the "X" in "X of Y powered on"). */
export const isOn = (h) => h.power === "running";
/** A running host with nobody on it: the cost-saver list. */
export const isIdle = (h) => isOn(h) && h.sessions === 0;
/** True when the AVD agent does not report the host as available (a running VM that users cannot use). */
const OK_STATUSES = new Set(["Available", "Upgrading", "Shutdown"]);
const STATUS_TEXT = {
  NoHeartbeat: "Agent not reporting", Unavailable: "Agent unavailable", UpgradeFailed: "Agent upgrade failed", NotJoinedToDomain: "Not joined to the domain",
  DomainTrustRelationshipLost: "Domain trust lost", SxSStackListenerNotReady: "Side-by-side stack not ready", FSLogixNotHealthy: "FSLogix not healthy",
  NeedsAssistance: "Needs assistance", Disconnected: "Disconnected",
};

/**
 * Why a host needs attention, or "" when it does not. A host whose VM is off is never an issue (Azure reports Shutdown or
 * Unavailable for it, which is expected). For a running host (or one with unknown power) the AVD status decides; an old
 * heartbeat counts only when the status is not Available too, because the heartbeat Resource Graph holds can lag.
 */
export function issueReason(h) {
  if (h.power !== "running" && h.power !== "unknown") return "";
  if (!OK_STATUSES.has(h.status)) return STATUS_TEXT[h.status] || `Status: ${h.status}`;
  return h.stale ? "Heartbeat is old" : "";
}

export const hasIssue = (h) => Boolean(issueReason(h));

/** Tiles: per pool "on of total" and sessions, plus totals. Pools with no hosts still appear. */
export function summarise(pools, hostRows) {
  const byPool = new Map(pools.map((p) => [String(p.id).toLowerCase(), {
    id: p.id, name: p.name, type: p.poolType || "", maxSessions: p.maxSessions || 0, total: 0, on: 0, sessions: 0, issues: 0, idle: 0, capacity: 0,
  }]));
  for (const h of hostRows) {
    const s = byPool.get(h.poolId);
    if (!s) continue;
    s.total++;
    if (isOn(h)) s.on++;
    s.sessions += h.sessions;
    if (hasIssue(h)) s.issues++;
    if (isIdle(h)) s.idle++;
    // Capacity is what the running hosts can take now: personal hosts hold one session, pooled hosts the pool's limit.
    if (isOn(h)) s.capacity += s.type === "Personal" ? 1 : s.maxSessions;
  }
  const list = [...byPool.values()].sort((a, b) => a.name.localeCompare(b.name));
  const sessions = hostRows.reduce((n, h) => n + h.sessions, 0);
  const capacity = list.reduce((n, p) => n + p.capacity, 0);
  const on = hostRows.filter(isOn).length;
  return {
    pools: list,
    totals: {
      pools: list.length, hosts: hostRows.length, on, off: hostRows.length - on, drain: hostRows.filter((h) => h.drain).length,
      sessions, capacity, capacityPct: capacity ? Math.round((sessions * 100) / capacity) : null, issues: hostRows.filter(hasIssue).length,
      idle: hostRows.filter(isIdle).length, oldAgent: hostRows.filter((h) => h.oldAgent).length, stale: hostRows.filter((h) => h.stale).length,
    },
  };
}

/** The only resource ids the session read accepts: one AVD session host, never an arbitrary path (a name of only dots would walk up the path). */
export const HOST_ID_RE = /^\/subscriptions\/[\w-]+\/resourcegroups\/(?!\.+\/)[\w.()-]+\/providers\/microsoft\.desktopvirtualization\/hostpools\/(?!\.+\/)[\w.-]+\/sessionhosts\/(?!\.+$)[\w.-]+$/i;

/** User sessions from the ARM list ({ value: [...] }) as plain rows, by user name. */
export const normalizeSessions = (rows) => (rows || []).map((r) => ({
  user: r.properties?.userPrincipalName || r.properties?.activeDirectoryUserName || "",
  state: r.properties?.sessionState || "", app: r.properties?.applicationType || "", created: r.properties?.createTime || "",
})).sort((a, b) => a.user.localeCompare(b.user));

/** The user sessions on one session host (read when the drawer opens). */
export async function loadSessions(arm, hostId) {
  if (!HOST_ID_RE.test(String(hostId))) throw Object.assign(new Error("Not an AVD session host."), { code: "BAD_ID" });
  return normalizeSessions((await arm.get(`${hostId}/userSessions`, "2024-04-03")).value);
}

/** The pools, hosts and summary for one subscription id ("" = all). Raw pools and hosts are in `data`. */
export function scopeTo(data, sub = "") {
  if (!sub) return { summary: data.summary, hosts: data.hosts };
  const hosts = data.hosts.filter((h) => h.subscriptionId === sub);
  return { summary: summarise(data.pools.filter((p) => p.subscriptionId === sub), hosts), hosts };
}

/** Only the subscriptions that hold a host pool, by name (the picker lists nothing else). */
export const subsWithPools = (subs, pools) => subs.filter((s) => pools.some((p) => p.subscriptionId === s.subscriptionId))
  .map((s) => ({ id: s.subscriptionId, name: s.name })).sort((a, b) => a.name.localeCompare(b.name));

/** Disconnected sessions first, then the longest-running first (the ARM list gives a start time, not a disconnect time). */
export const sortSessions = (rows) => [...rows].sort((a, b) =>
  (b.state === "Disconnected") - (a.state === "Disconnected") || String(a.created).localeCompare(String(b.created)) || a.user.localeCompare(b.user));

/** Run fn over items with at most `limit` running at once. fn must not throw. */
export async function eachLimited(items, limit, fn) {
  let next = 0;
  const run = async () => { while (next < items.length) await fn(items[next++]); };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
}

/** The user sessions of several hosts ({ id, name, pool }), a few reads at a time; a host that fails is counted, not fatal. */
export async function loadSessionsFor(arm, hosts, limit = 4) {
  const out = [];
  let failed = 0;
  await eachLimited(hosts, limit, async (h) => {
    try { for (const s of await loadSessions(arm, h.id)) out.push({ ...s, hostId: h.id, host: h.name, pool: h.pool }); } catch { failed++; }
  });
  return { sessions: sortSessions(out), failed };
}

/** How many items an ARG array column holds (the column may already be a number). */
export const countOf = (v) => (Array.isArray(v) ? v.length : Number(v) || 0);

/** Scaling plans as plain rows; each lists the pools it is attached to (lower-case ids) and whether it is switched on for them. */
export const normalizePlans = (rows) => (rows || []).map((r) => ({
  id: String(r.id), name: r.name, resourceGroup: r.resourceGroup, timeZone: r.timeZone || "", schedules: countOf(r.schedules), scheduleList: Array.isArray(r.schedules) ? r.schedules : [],
  pools: (r.pools || []).map((x) => ({ id: String(x.hostPoolArmPath || "").toLowerCase(), enabled: x.scalingPlanEnabled !== false })),
}));

/** "1.0.9103 x5, 1.0.8431 x1": distinct values of a host field with their counts, most common first. */
export function countBy(hosts, key) {
  const counts = new Map();
  for (const h of hosts) { const v = h[key] || "unknown"; counts.set(v, (counts.get(v) || 0) + 1); }
  return [...counts.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0])).map(([v, n]) => `${v} x${n}`).join(", ");
}

/** Per pool: type, balancer, limits, host counts, OS builds and VM sizes (mixed = more than one of either), scaling plans. */
export function poolRows(pools, hosts, plans) {
  return pools.map((p) => {
    const id = String(p.id).toLowerCase();
    const mine = hosts.filter((h) => h.poolId === id);
    const attached = plans.flatMap((pl) => pl.pools.filter((x) => x.id === id).map((x) => (x.enabled ? pl.name : `${pl.name} (off)`)));
    const distinct = (k) => new Set(mine.map((h) => h[k] || "unknown")).size;
    return {
      id: p.id, name: p.name, type: p.poolType || "", balancer: p.balancer || "", maxSessions: p.maxSessions || 0, hosts: mine.length,
      os: countBy(mine, "os"), sizes: countBy(mine, "size"), agents: countBy(mine, "agent"), mixed: distinct("os") > 1 || distinct("size") > 1,
      plans: attached.join(", "),
    };
  }).sort((a, b) => a.name.localeCompare(b.name));
}

/** App groups and workspaces as table rows, with the pool or workspace name looked up from the ids. */
export function groupRows(appGroups, pools, workspaces) {
  const poolName = new Map(pools.map((p) => [String(p.id).toLowerCase(), p.name]));
  const wsName = new Map(workspaces.map((w) => [String(w.id).toLowerCase(), w.name]));
  return appGroups.map((g) => ({ name: g.name, kind: g.groupKind, pool: poolName.get(g.poolPath) || "", workspace: wsName.get(g.workspacePath) || "", resourceGroup: g.resourceGroup }))
    .sort((a, b) => a.name.localeCompare(b.name));
}

/** The inventory read: scaling plans, application groups, workspaces and maintenance (five parallel reads). */
export async function loadInventory(arm) {
  // A third item of true marks a plain query: the maintenance tables are not AVD tables, so they are not run against both AVD tables.
  const reads = [["Scaling plans", PLANS_KQL], ["Application groups", APPGROUPS_KQL], ["Workspaces", WORKSPACES_KQL], ["Maintenance windows", MAINT_KQL, true], ["Maintenance assignments", ASSIGN_KQL, true]];
  const results = await Promise.allSettled(reads.map(([, kql, plain]) => (plain ? arm.query(kql) : queryTables(arm, kql))));
  // One failing read must not blank the tab: show the others and list what failed and why.
  const errors = results.flatMap((r, i) => (r.status === "rejected" ? [`${reads[i][0]}: ${r.reason?.message || r.reason}`] : []));
  const rows = results.map((r) => (r.status === "fulfilled" ? r.value : []));
  return { plans: normalizePlans(rows[0]), appGroups: rows[1], workspaces: rows[2], configs: rows[3], assignments: rows[4], errors, fetchedAt: Date.now() };
}

/** Toolbar badge text for the number of hosts needing attention: empty for none, capped at 99. */
export const badgeText = (issues) => (issues > 0 ? String(Math.min(issues, 99)) : "");

/** A rough daily cost of the running-but-idle hosts at an hourly rate per host (0 when no rate is set). */
export const idleCostPerDay = (idleHosts, hourlyRate) => (hourlyRate > 0 ? Math.round(idleHosts * hourlyRate * 24 * 100) / 100 : 0);

/** Every pool the hosts belong to, adding a minimal one (name from the host) for any the pool query did not return. */
export function ensurePools(pools, rows) {
  const known = new Set(pools.map((p) => String(p.id).toLowerCase()));
  const extra = new Map();
  for (const r of rows) {
    if (known.has(r.poolId) || extra.has(r.poolId)) continue;
    extra.set(r.poolId, { id: r.id.replace(/\/sessionhosts\/[^/]+$/i, ""), name: r.pool, subscriptionId: r.subscriptionId, poolType: "", maxSessions: 0, balancer: "" });
  }
  return [...pools, ...extra.values()];
}

/** Fetch pools, session hosts and VM power state (three parallel reads) and return { summary, hosts, fetchedAt }. */
export async function loadOverview(arm) {
  const [found, hosts, vms, subs] = await Promise.all([queryTables(arm, POOLS_KQL), arm.query(HOSTS_KQL), arm.query(VMS_KQL), arm.query(SUBS_KQL)]);
  const rows = joinHosts(found, hosts, vms);
  const pools = ensurePools(found, rows);
  return { summary: summarise(pools, rows), hosts: rows, pools, subs: subsWithPools(subs, pools), fetchedAt: Date.now() };
}
