// "Your access": what the signed-in account may do on the resource groups that hold the pools and hosts, read from Azure's own
// permission list for each group (one GET to Microsoft.Authorization/permissions, the same read-only client as everything else).
// The answer is the account's active roles only: a role that must still be activated (PIM) is not counted, and Azure can still
// refuse an action for other reasons (a deny assignment, a lock, a conditional access rule), so "Yes" means "probably allowed".
// Pure matching and summary code here, so the offline tests cover it; the one network function takes the ARM client.

import { eachLimited } from "./avd.js";

const DV = "Microsoft.DesktopVirtualization";
const VM = "Microsoft.Compute/virtualMachines";

/** What the Settings table lists: a plain-language action and every Azure action it needs. */
export const CAPABILITIES = [
  { id: "read", label: "See host pools, hosts and sessions", needs: [`${DV}/hostPools/read`, `${DV}/hostPools/sessionHosts/read`] },
  { id: "power", label: "Power on, restart and stop hosts", needs: [`${VM}/start/action`, `${VM}/restart/action`, `${VM}/deallocate/action`] },
  { id: "drain", label: "Turn drain mode on or off", needs: [`${DV}/hostPools/sessionHosts/write`] },
  { id: "sessions", label: "Log off, disconnect and message users", needs: [`${DV}/hostPools/sessionHosts/userSessions/disconnect/action`, `${DV}/hostPools/sessionHosts/userSessions/delete`, `${DV}/hostPools/sessionHosts/userSessions/sendMessage/action`] },
  { id: "remove", label: "Remove session hosts", needs: [`${DV}/hostPools/sessionHosts/delete`] },
  { id: "pools", label: "Change host pool settings", needs: [`${DV}/hostPools/write`] },
];

export const MAX_SCOPES = 40;
const SCOPE_RE = /^\/subscriptions\/([\w-]+)\/resourcegroups\/(?!\.+(?:\/|$))([\w.()-]+)/i; // a group name of only dots would walk up the path

/** The resource group scope of any resource id ("" when it has none). */
export const scopeOf = (id) => { const m = SCOPE_RE.exec(String(id || "")); return m ? `/subscriptions/${m[1]}/resourceGroups/${m[2]}` : ""; };
/** The distinct resource group scopes of a list of resources (anything with an id). */
export const scopesOf = (items) => [...new Set((items || []).map((x) => scopeOf(x?.id)).filter(Boolean))];

const globRe = (pattern) => new RegExp(`^${pattern.replace(/[.+?^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*")}$`, "i");

/** True when an action is allowed by a list of permission blocks ({ actions, notActions }): in one block's actions and not in its notActions. */
export const allows = (blocks, action) => (blocks || []).some((b) => (b.actions || []).some((a) => globRe(a).test(action)) && !(b.notActions || []).some((a) => globRe(a).test(action)));

/** The permission blocks from the ARM list answer. */
export const normalizePermissions = (res) => (res?.value || []).map((p) => ({ actions: p.actions || [], notActions: p.notActions || [] }));

const rgName = (scope) => scope.split("/").pop();

/** One row per capability from { scope: blocks | null } (null = that scope could not be read). */
export function evaluate(byScope) {
  const scopes = Object.keys(byScope);
  const failed = scopes.filter((s) => byScope[s] === null).length;
  const rows = CAPABILITIES.map((c) => {
    const known = scopes.filter((s) => byScope[s] !== null);
    const yes = known.filter((s) => c.needs.every((n) => allows(byScope[s], n)));
    const state = !known.length ? "Unknown" : yes.length === known.length && !failed ? "Yes" : yes.length ? "Some" : "No";
    const names = yes.map(rgName);
    const where = state === "Unknown" ? "Could not read your permissions"
      : state === "Yes" ? (scopes.length === 1 ? rgName(scopes[0]) : `All ${scopes.length} resource groups`)
      : state === "No" ? (scopes.length === 1 ? rgName(scopes[0]) : `None of ${scopes.length} resource groups`)
      : `${yes.length} of ${scopes.length}: ${names.slice(0, 4).join(", ")}${names.length > 4 ? ", ..." : ""}`;
    return { id: c.id, action: c.label, can: state, where };
  });
  return { rows, scopes: scopes.length, failed };
}

/** Read the permissions of each resource group scope (a few at a time; one that fails is counted, not fatal) and summarise. */
export async function loadAccess(arm, scopes, limit = 4) {
  const distinct = [...new Set((scopes || []).map(scopeOf).filter(Boolean))];
  const list = distinct.slice(0, MAX_SCOPES);
  const byScope = {};
  await eachLimited(list, limit, async (sc) => {
    try { byScope[sc] = normalizePermissions(await arm.get(`${sc}/providers/Microsoft.Authorization/permissions`, "2022-04-01")); } catch { byScope[sc] = null; }
  });
  return { ...evaluate(byScope), skipped: distinct.length - list.length, checkedAt: Date.now() };
}
