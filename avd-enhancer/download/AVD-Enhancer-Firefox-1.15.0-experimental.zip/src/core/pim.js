// "PIM roles": the Azure resource roles the signed-in account is eligible for or holds right now, read from Azure's own role
// schedule lists (Privileged Identity Management for Azure resources). Two GETs through the same read-only client, no new host or
// token. Entra directory roles and group roles are a different service (Microsoft Graph) and are not read. Pure code except loadPim.

/** The API version of the role schedule lists. */
const PIM_API = "2020-10-01";
/** Roles the account can activate (asTarget() = for the signed-in account, at every scope). */
const PIM_ELIGIBLE_PATH = "/providers/Microsoft.Authorization/roleEligibilityScheduleInstances?$filter=asTarget()";
/** Roles the account holds now: activated ones and permanent assignments. */
const PIM_ACTIVE_PATH = "/providers/Microsoft.Authorization/roleAssignmentScheduleInstances?$filter=asTarget()";

/** A value as a lower-case string. */
const lowerOf = (s) => String(s || "").toLowerCase();
/** The last segment of a resource id. */
const idTail = (id) => String(id || "").split("/").filter(Boolean).pop() || "";

/** One schedule instance as a plain object. Names come from expandedProperties; the id tail is the fallback. */
export function normalizeInstance(item) {
  const p = item?.properties || {};
  const ex = p.expandedProperties || {};
  return {
    roleId: lowerOf(p.roleDefinitionId), role: ex.roleDefinition?.displayName || idTail(p.roleDefinitionId),
    scope: lowerOf(p.scope || ex.scope?.id), scopeName: ex.scope?.displayName || idTail(p.scope), scopeType: ex.scope?.type || "",
    start: p.startDateTime || "", end: p.endDateTime || "", assignmentType: p.assignmentType || "", member: p.memberType || "",
    scheduleId: lowerOf(p.roleEligibilityScheduleId || p.roleAssignmentScheduleId), linked: lowerOf(p.linkedRoleEligibilityScheduleId),
  };
}

/** "3h 20m left", "45m left", "Expired", or "No end date". */
export function leftText(end, now = Date.now()) {
  if (!end) return "No end date";
  const ms = Date.parse(end) - now;
  if (!Number.isFinite(ms)) return "";
  if (ms <= 0) return "Expired";
  const m = Math.floor(ms / 60000);
  if (m >= 1440) return `${Math.floor(m / 1440)}d ${Math.floor((m % 1440) / 60)}h left`;
  return m >= 60 ? `${Math.floor(m / 60)}h ${m % 60}m left` : `${m}m left`;
}

/**
 * One row per role at a scope: Active (activated now, or assigned with no activation needed) or Eligible (can be activated).
 * An eligible role that is also active shows once, as Active, with both end dates.
 */
export function pimRows(eligible, active, now = Date.now()) {
  const rows = new Map();
  const keyOf = (i) => `${i.roleId}|${i.scope}`;
  for (const e of eligible) rows.set(keyOf(e), { role: e.role, scope: e.scopeName, scopeType: e.scopeType, status: "Eligible", isEligible: true, activeEnds: "", eligibleEnds: e.end, member: e.member, scopeId: e.scope });
  for (const a of active) {
    const permanent = a.assignmentType !== "Activated";
    const row = rows.get(keyOf(a)) || { role: a.role, scope: a.scopeName, scopeType: a.scopeType, isEligible: false, eligibleEnds: "", member: a.member, scopeId: a.scope };
    rows.set(keyOf(a), { ...row, status: permanent ? "Active (permanent)" : "Active", activeEnds: a.end, member: a.member || row.member });
  }
  const order = { Active: 0, "Active (permanent)": 1, Eligible: 2 };
  return [...rows.values()].map((r) => ({ ...r, left: r.status === "Active" ? leftText(r.activeEnds, now) : r.status === "Eligible" ? "" : "Always on" }))
    .sort((a, b) => order[a.status] - order[b.status] || a.role.localeCompare(b.role) || a.scope.localeCompare(b.scope));
}

/** Read the eligible and active role schedules of the signed-in account; one failing list is reported, not fatal. */
export async function loadPim(arm, now = Date.now()) {
  const [el, ac] = await Promise.allSettled([arm.getAll(PIM_ELIGIBLE_PATH, PIM_API), arm.getAll(PIM_ACTIVE_PATH, PIM_API)]);
  const errors = [["Eligible roles", el], ["Active roles", ac]].flatMap(([name, r]) => (r.status === "rejected" ? [`${name}: ${r.reason?.message || r.reason}`] : []));
  const rows = pimRows((el.value || []).map(normalizeInstance), (ac.value || []).map(normalizeInstance), now);
  return { rows, errors, fetchedAt: now };
}
