// Every host the extension may talk to, in one place. Commercial Azure only: Azure Government was never wired (no host permission,
// and the content script runs only on portal.azure.com). To add it: its ARM host and token audiences here, the host in both manifests
// (host permissions and connect-src) and in content/capture.js, which keeps its own audience list because a content script cannot
// import (the build test checks the two lists agree).

export const ARM_HOSTS = ["management.azure.com"];

/** Token audiences (hosts or the older core.windows.net names) that mean "Azure Resource Manager". */
export const ARM_AUDIENCES = ["https://management.azure.com", "https://management.core.windows.net"];
