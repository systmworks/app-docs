// The VM prices the workspace holds and the one lookup that fills them, shared by the Dashboard's idle tile and the Size and cost report (the service worker asks
// Microsoft's public price list, "prices/get"; this keeps what it found). Nothing is saved: the prices live only while the workspace tab is open. Skipped in the demo (sample
// tenant), which sends nothing anywhere.

import { priceKey, cleanCurrency } from "../core/prices.js";
import { state, send } from "./core.js";

/** The hourly prices looked up so far ("size|region": price). */
export const priceCache = {};
/** The pairs Microsoft had no price for or could not be asked (not asked again until the page reloads). */
const priceTried = new Set();
let pricing = false;
/** The requests ({ hosts, hooks }) that arrived while a lookup was running (the newest ten); each is answered when it ends. */
let waiting = [];
/** The currency the prices held were asked for. */
let pricesIn = "";

/** Forgets which pairs failed, so the next lookup asks for them again (called when consent changes: a lookup refused for want of consent must not stay failed until the page reloads). */
export const retryPrices = () => priceTried.clear();

/** The currency prices are shown in (the Settings pick, USD by default); the prices held are dropped when it changes, so no price is ever shown under the wrong currency. */
export function currentCurrency() {
  const c = cleanCurrency(state.priceCurrency) || "USD";
  if (c !== pricesIn) { for (const k of Object.keys(priceCache)) delete priceCache[k]; priceTried.clear(); pricesIn = c; }
  return c;
}

/** Looks up the prices of the VM sizes these hosts use, once for each size and region, and calls onDone when new prices (or failures) arrive. onStart runs when a lookup begins.
 *  A failure goes to the browser console and the Console tab, and the cost falls back to the Settings rate. */
export async function loadPrices(hosts, hooks = {}) {
  currentCurrency();
  if (state.sample) return;
  if (pricing) { waiting = [...waiting.slice(-9), { hosts, hooks }]; return; }
  /* one pair for each size and region (many hosts share one), so a 100-pair request is 100 different prices */
  const pairs = [...new Map((hosts || []).filter((h) => h.size && h.region && !(priceKey(h.size, h.region) in priceCache) && !priceTried.has(priceKey(h.size, h.region))).map((h) => [priceKey(h.size, h.region), { size: h.size, region: h.region }])).values()];
  if (!pairs.length) return;
  pricing = true;
  hooks.onStart?.();
  const asked = currentCurrency();
  const reply = await send("prices/get", { pairs, currency: asked }).finally(() => { pricing = false; });
  const res = reply.ok ? reply : { prices: {}, failed: pairs.map((p) => ({ key: priceKey(p.size, p.region), error: reply.error || "the extension's worker did not answer" })) };
  if (currentCurrency() === asked) {
    Object.assign(priceCache, res.prices);
    for (const f of res.failed) {
      priceTried.add(f.key);
      console.error(`AVD Enhancer: price lookup failed for ${f.key}: ${f.error}`);
      send("log/add", { level: "warn", message: `Price lookup failed for ${f.key}: ${f.error}` });
    }
  }
  hooks.onDone?.();
  /* Whoever asked while this lookup ran may find its prices already held (this lookup covered them), so no lookup of its own would redraw it: tell it now, then let it ask for anything still missing. */
  const next = waiting; waiting = [];
  for (const w of next) w.hooks.onDone?.();
  for (const w of next) await loadPrices(w.hosts, w.hooks);
  return loadPrices(hosts, hooks);
}
