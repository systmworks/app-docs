// Settings, Links and Console tabs, the Demo switch, Reset to defaults, the custom card slots and the Settings controls.

import { esc } from "../core/host-table.js";
import { linkGroups } from "../data/links.js";
import { atLevel, formatLog } from "../core/log.js";
import { scopesOf } from "../core/access.js";
import { CARD_METRICS, tagList, cleanCards } from "../core/tags.js";
import { cleanPoolLinks } from "../core/pool-links.js";
import { PRICE_CURRENCIES, cleanCurrency } from "../core/prices.js";
import { $, state, send, errorBanner, dataTable, saveFile, savePrefs, registerTab, groupsHtml, BG_KEY, PREFS_KEY } from "./core.js";
import { renderCards, renderTiles, renderPoolLinks } from "./dashboard.js";

/* ---------- Settings: what the signed-in account may do (read from Azure's permission list; nothing is changed) ---------- */
async function checkAccess() {
  const out = $("#access-out");
  if (!state.data) { out.innerHTML = `<p class="muted small">Open the Dashboard first so the pools and hosts are read.</p>`; return; }
  out.innerHTML = `<p class="muted small">Reading your permissions...</p>`;
  const res = await send("avd/access", { scopes: scopesOf([...(state.data.pools || []), ...(state.data.hosts || [])]), sample: state.sample });
  if (!res.ok) { out.innerHTML = errorBanner(res.error); return; }
  const cols = [{ key: "action", label: "You can" }, { key: "can", label: "Allowed", html: (r) => `<span class="badge ${r.can === "Yes" ? "ok" : r.can === "Some" ? "warn" : ""}">${esc(r.can)}</span>` }, { key: "where", label: "Where" }];
  out.innerHTML = `${dataTable("access", "What your roles allow", cols, res.rows, "avd-your-access")}<p class="muted small">Checked ${res.scopes} resource groups${res.failed ? `, ${res.failed} could not be read` : ""}${res.skipped ? `, ${res.skipped} more were not checked (it checks only the first ${res.scopes})` : ""}. This lists your active roles only: a role you still have to activate (PIM) is not counted. Azure can still refuse an action for other reasons, such as a deny assignment, a lock or a conditional access rule, so "Yes" means probably allowed.</p>`;
}
$("#access-check").addEventListener("click", checkAccess);

/* ---------- console: the extension's own log, kept by the worker ---------- */
async function loadConsole() {
  const res = await send("log/get");
  state.log = res.ok ? res.entries || [] : [];
  renderConsole(res.ok ? "" : res.error);
}

function renderConsole(problem = "") {
  const shownEntries = atLevel(state.log || [], $("#log-level").value);
  const rows = [...shownEntries].reverse().map((e) => `<tr><td class="time">${esc(new Date(e.t).toLocaleTimeString())}</td><td><span class="badge ${e.level === "error" ? "bad" : e.level === "warn" ? "warn" : ""}">${esc(e.level)}</span></td><td>${esc(e.source)}</td><td>${esc(e.message)}${e.detail ? ` <span class="muted">(${esc(e.detail)})</span>` : ""}</td></tr>`).join("");
  $("#log-out").innerHTML = (problem ? `<div class="banner bad">${esc(problem)}</div>` : "")
    + `<div class="tablewrap"><table><thead><tr><th>Time</th><th>Level</th><th>Source</th><th>Message</th></tr></thead><tbody>${rows || `<tr><td colspan="4" class="empty">Nothing logged yet.</td></tr>`}</tbody></table></div>`;
}

/* ---------- links and settings ---------- */
function renderLinks() {
  $("#link-groups").innerHTML = groupsHtml(linkGroups(state.status.tid));
}

/** The consent state the Settings card was last drawn for: the disclosure opens or collapses only when this changes, so a refresh never closes it on someone who is reading it. */
let drawnConsent;

export async function renderSettings() {
  const s = await send("status/get");
  state.status = s.ok ? s : state.status;
  const on = !!state.status.consented;
  $("#consent-on").hidden = on;
  $("#consent-off").hidden = !on;
  $("#off-banner").hidden = on;
  if (drawnConsent !== on) { $("#consent-details").open = !on; $("#consent-title").textContent = on ? "Sign-in reuse is on" : "Turn it on"; drawnConsent = on; }
  $("#interval").value = String(state.interval);
  $("#rate").value = state.rate || "";
  $("#price-currency").innerHTML = PRICE_CURRENCIES.map((c) => `<option value="${c}">${c}${c === "USD" ? " (default)" : ""}</option>`).join("");
  $("#price-currency").value = cleanCurrency(state.priceCurrency) || "USD";
  renderCardSlots();
  renderPoolSlots();
  $("#bg").value = String((await chrome.storage.local.get(BG_KEY).catch(() => ({})))[BG_KEY] || 0);
  $("#status-line").textContent = !state.status.consented ? "Sign-in reuse is off."
    : state.status.signedIn ? `Signed in as ${state.status.upn || "unknown"} (tenant ${state.status.tid || "unknown"}).` : "On, but no Azure sign-in found yet. Open the Azure portal.";
}

/* ---------- demo on sample data (reopens this page with or without ?sample=1, as in Intune Enhancer) ---------- */
export function toggleDemo() {
  const url = new URL(location.href);
  if (state.sample) url.searchParams.delete("sample");
  else url.searchParams.set("sample", "1");
  location.assign(url.href);
}
{
  const demo = $("#demo-toggle");
  demo.classList.toggle("on", state.sample);
  if (state.sample) { $("#demo-text").textContent = "Leave demo"; demo.title = "Back to your own tenant"; }
  demo.addEventListener("click", toggleDemo);
}

/* ---------- reset display settings (consent and your Azure data are kept) ---------- */
async function resetDefaults() {
  if (!confirm("Reset AVD Enhancer's display settings to their defaults?\n\nThe theme, stars, auto-refresh, subscription choice and filters go back to how they were at install. Turning the extension on or off is not changed.")) return;
  try { localStorage.removeItem("avd.theme"); } catch { /* storage unavailable */ }
  await chrome.storage.local.remove(PREFS_KEY).catch(() => {});
  location.assign(location.pathname);
}

/** The six sidebar pool link slots in Settings: a list of the pools read so far (a saved pool that is not in the latest read stays listed). */
function renderPoolSlots() {
  const pools = [...(state.data?.pools || [])].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  $("#poollink-slots").innerHTML = state.poolLinks.map((l, i) => {
    const known = pools.some((p) => p.id.toLowerCase() === l.id);
    const opts = [`<option value="">- empty -</option>`, ...(l.id && !known ? [`<option value="${esc(l.id)}" selected>${esc(l.name || l.id)} (not in the latest read)</option>`] : []),
      ...pools.map((p) => `<option value="${esc(p.id.toLowerCase())}"${p.id.toLowerCase() === l.id ? " selected" : ""}>${esc(p.name)}</option>`)];
    return `<div class="cardslot"><span class="muted small">Link ${i + 1}</span><select data-pslot="${i}" aria-label="Pool link ${i + 1}">${opts.join("")}</select></div>`;
  }).join("");
}
$("#poollink-slots").addEventListener("change", async (e) => {
  const i = Number(e.target.dataset.pslot);
  if (!(i >= 0)) return;
  const pool = (state.data?.pools || []).find((p) => p.id.toLowerCase() === e.target.value);
  state.poolLinks[i] = { id: e.target.value, name: pool?.name || "" };
  state.poolLinks = cleanPoolLinks(state.poolLinks);
  await savePrefs();
  renderPoolSlots(); // a repeat of another slot comes back empty
  renderPoolLinks();
});

/** The four custom card slots in Settings: what each shows, and for a tag card the tag name and optional value. */
function renderCardSlots() {
  const opts = (sel) => `<option value="">- empty -</option>${CARD_METRICS.map(([id, label]) => `<option value="${id}"${sel === id ? " selected" : ""}>${esc(label)}</option>`).join("")}<option value="tag"${sel === "tag" ? " selected" : ""}>Hosts with a tag...</option>`;
  $("#cards-slots").innerHTML = state.cards.map((c, i) => `<div class="cardslot"><span class="muted small">Card ${i + 1}</span><select data-slot="${i}" data-cf="kind" aria-label="Card ${i + 1} shows">${opts(c.kind)}</select>${c.kind === "tag"
    ? `<input type="text" list="known-tags" data-slot="${i}" data-cf="tag" value="${esc(c.tag)}" placeholder="Tag name" aria-label="Card ${i + 1} tag name"><input type="text" data-slot="${i}" data-cf="value" value="${esc(c.value)}" placeholder="Value (optional)" aria-label="Card ${i + 1} tag value">` : ""}</div>`).join("");
  $("#known-tags").innerHTML = state.data ? tagList(state.data.hosts).map((t) => `<option value="${esc(t.tag)}">`).join("") : "";
}
$("#cards-slots").addEventListener("change", async (e) => {
  const i = Number(e.target.dataset.slot), field = e.target.dataset.cf;
  if (!(i >= 0) || !field) return;
  state.cards[i] = { ...state.cards[i], [field]: e.target.value };
  state.cards = cleanCards(state.cards);
  await savePrefs();
  if (field === "kind") renderCardSlots();
  if (state.view) renderCards();
});

$("#log-level").addEventListener("change", () => renderConsole());
$("#log-refresh").addEventListener("click", loadConsole);
$("#log-clear").addEventListener("click", async () => { await send("log/clear"); await loadConsole(); });
$("#log-save").addEventListener("click", () => saveFile("txt", formatLog(atLevel(state.log || [], $("#log-level").value)), "text/plain", "avd-console"));
$("#log-copy").addEventListener("click", async () => {
  const btn = $("#log-copy");
  try { await navigator.clipboard.writeText(formatLog(atLevel(state.log || [], $("#log-level").value))); btn.textContent = "Copied"; } catch { btn.textContent = "Copy failed"; }
  setTimeout(() => { btn.textContent = "Copy"; }, 1500);
});

$("#bg").addEventListener("change", (e) => chrome.storage.local.set({ [BG_KEY]: Number(e.target.value) || 0 }).catch(() => {}));
$("#price-currency").addEventListener("change", async (e) => { state.priceCurrency = e.target.value === "USD" ? "" : cleanCurrency(e.target.value); await savePrefs(); });
$("#rate").addEventListener("change", async (e) => {
  state.rate = Number(e.target.value) > 0 ? Number(e.target.value) : 0;
  await savePrefs();
  if (state.data) renderTiles();
});

$("#reset").addEventListener("click", resetDefaults);

registerTab("console", loadConsole);
registerTab("links", renderLinks);
registerTab("settings", renderSettings);
