// One job after another: each job starts when the one before it has finished, whether that one worked or failed. Used where
// a read-then-write must not overlap itself (the prefs writer, the Console log).

/** A function that runs a job after every job given to it earlier, and returns that job's own result or error. */
export function serialQueue() {
  let queue = Promise.resolve();
  return (job) => {
    const run = queue.then(job);
    queue = run.catch(() => {});
    return run;
  };
}
