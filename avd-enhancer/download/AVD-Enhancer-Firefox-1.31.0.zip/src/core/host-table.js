// Pure logic behind the Workspace host table: quick filters, search, sorting, CSV. No DOM here, so the offline tests
// cover it.

import { isOn, isIdle, hasIssue } from "./avd.js";

/** Quick-filter chips, in display order: id, label, test. */
export const CHIPS = [
  { id: "all", label: "All", test: () => true },
  { id: "running", label: "Running", test: isOn },
  { id: "off", label: "Off", test: (h) => !isOn(h) },
  { id: "connected", label: "User connected", test: (h) => h.sessions > 0 },
  { id: "idle", label: "Idle (on, no users)", test: isIdle },
  { id: "drain", label: "Drain mode", test: (h) => h.drain },
  { id: "attention", label: "Needs attention", test: hasIssue },
  { id: "oldagent", label: "Old agent", test: (h) => h.oldAgent },
  { id: "stale", label: "Stale heartbeat", test: (h) => h.stale },
];

/** Table columns: key, heading, how to compare (n = number, s = text). */
export const COLUMNS = [
  { key: "name", label: "Host", kind: "s" },
  { key: "pool", label: "Pool", kind: "s" },
  { key: "power", label: "Power", kind: "s" },
  { key: "status", label: "AVD status", kind: "s" },
  { key: "issue", label: "Issue", kind: "s" },
  { key: "sessions", label: "Sessions", kind: "n" },
  { key: "user", label: "Assigned user", kind: "s" },
  { key: "drain", label: "Drain", kind: "n" },
  { key: "agent", label: "Agent", kind: "s" },
  { key: "heartbeat", label: "Last heartbeat", kind: "s" },
  { key: "region", label: "Region", kind: "s" },
];

/** The dashboard view (tab, pool, chip, search, sort) as a URL hash, leaving out everything at its default. */
export function viewToHash(v) {
  const p = new URLSearchParams();
  if (v.tab && v.tab !== "dashboard") p.set("tab", v.tab);
  if (v.pool) p.set("pool", v.pool);
  if (v.chip && v.chip !== "all") p.set("chip", v.chip);
  if (v.q) p.set("q", v.q);
  if (v.sub) p.set("sub", v.sub);
  if (v.cols?.length && v.cols.length < COLUMNS.length) p.set("cols", v.cols.join(","));
  if (v.sort && (v.sort.key !== "name" || v.sort.dir !== "asc")) p.set("sort", `${v.sort.key}:${v.sort.dir}`);
  return p.toString();
}

/** The reverse of viewToHash, keeping only valid values; a bare word (an old "#links") is a tab name. */
export function hashToView(hash) {
  const raw = String(hash || "").replace(/^#/, "");
  const p = new URLSearchParams(raw.includes("=") ? raw : raw ? `tab=${raw}` : "");
  const [key, dir] = (p.get("sort") || "").split(":");
  return {
    tab: p.get("tab") || "dashboard",
    pool: (p.get("pool") || "").toLowerCase(),
    chip: CHIPS.some((c) => c.id === p.get("chip")) ? p.get("chip") : "all",
    q: p.get("q") || "",
    sub: p.get("sub") || "",
    cols: (p.get("cols") || "").split(",").filter((k) => COLUMNS.some((c) => c.key === k)),
    sort: COLUMNS.some((c) => c.key === key) && (dir === "asc" || dir === "desc") ? { key, dir } : { key: "name", dir: "asc" },
  };
}

const words = (q) => String(q || "").toLowerCase().split(/\s+/).filter(Boolean);
const haystack = (h) => [h.name, h.pool, h.power, h.status, h.issue, h.user, h.agent, h.region, h.resourceGroup, h.size].join(" ").toLowerCase();

/** Hosts matching the pool (id, or "" for all), the chip and every word of the search box. */
export function filterHosts(hosts, { pool = "", chip = "all", q = "" } = {}) {
  const test = (CHIPS.find((c) => c.id === chip) || CHIPS[0]).test;
  const ws = words(q);
  return hosts.filter((h) => (!pool || h.poolId === String(pool).toLowerCase()) && test(h) && ws.every((w) => haystack(h).includes(w)));
}

/** How many hosts each chip would show with the pool and search applied (the chip's own test is left out). */
export const chipCounts = (hosts, { pool = "", q = "" } = {}) =>
  Object.fromEntries(CHIPS.map((c) => [c.id, filterHosts(hosts, { pool, chip: c.id, q }).length]));

/** A sorted copy. Text compares naturally (host-2 before host-10); ties keep the host name order. */
export function sortHosts(hosts, key = "name", dir = "asc", cols = COLUMNS) {
  const col = cols.find((c) => c.key === key) || cols[0];
  const sign = dir === "desc" ? -1 : 1;
  const num = (v) => (typeof v === "boolean" ? Number(v) : Number(String(v).replace(/[^\d.-]/g, "")) || 0); /* a true or false (drain mode) sorts as 1 or 0 */
  const val = (h) => (col.kind === "n" ? num(h[col.key]) : String(h[col.key] ?? ""));
  const cmp = (a, b) => (col.kind === "n" ? val(a) - val(b) : val(a).localeCompare(val(b), undefined, { numeric: true, sensitivity: "base" }));
  const first = cols[0].key; // ties fall back to the first column (the host name, the pool name, the user ...)
  return [...hosts].sort((a, b) => sign * cmp(a, b) || String(a[first] ?? "").localeCompare(String(b[first] ?? ""), undefined, { numeric: true }));
}

const csvCell = (v) => {
  const s = String(v ?? "");
  // A leading = + - @ (or a tab or carriage return in front of one) would run as a formula when the file opens in Excel.
  const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
  return /[",\r\n]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
};

/** The columns to show for a list of keys: every column when the list is empty; the host name always stays. */
export function visibleColumns(keys) {
  const set = new Set(Array.isArray(keys) ? keys : []);
  const cols = COLUMNS.filter((c) => c.key === "name" || set.has(c.key));
  return set.size && cols.length > 1 ? cols : COLUMNS;
}

const cellText = (h, c) => (c.key === "drain" ? (h.drain ? "Yes" : "No") : h[c.key]);

/** The columns of the Dashboard pool table (kind "n" sorts as a number). capacity is exported but not shown as a column. */
export const POOL_COLS = [
  { key: "name", label: "Pool" }, { key: "type", label: "Type" }, { key: "on", label: "Powered on", kind: "n" },
  { key: "total", label: "Total", kind: "n" }, { key: "sessions", label: "Sessions", kind: "n" }, { key: "capacity", label: "Session capacity", kind: "n" },
];

/** Every row as an array of cell texts for the columns (what CSV, TSV, Markdown and the report print). */
export const gridCells = (rows, cols) => rows.map((r) => cols.map((c) => cellText(r, c)));

/** Rows whose shown cells contain every word of the text (any case); all rows for an empty text. Used by every table's filter box. */
export function searchRows(rows, cols, q) {
  const words = String(q || "").toLowerCase().split(/\s+/).filter(Boolean);
  return words.length ? rows.filter((r) => { const t = cols.map((c) => String(cellText(r, c) ?? "")).join(" ").toLowerCase(); return words.every((w) => t.includes(w)); }) : rows;
}

/** The rows as CSV text (header row first), for the given columns (all by default). */
export function toCsv(hosts, cols = COLUMNS) {
  return [cols.map((c) => c.label), ...gridCells(hosts, cols)].map((r) => r.map(csvCell).join(",")).join("\r\n");
}

/** Tab-separated, for pasting into a spreadsheet; tabs and line breaks inside a cell become spaces, formulas are guarded. */
export function toTsv(hosts, cols = COLUMNS) {
  const clean = (v) => { const t = String(v ?? "").replace(/[\t\r\n]+/g, " "); return /^[=+\-@]/.test(t) ? `'${t}` : t; };
  return [cols.map((c) => c.label), ...gridCells(hosts, cols)].map((r) => r.map(clean).join("\t")).join("\r\n");
}

export const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/** A standalone HTML page holding the rows (all text escaped), for saving or sharing. */
export function toHtml(hosts, cols = COLUMNS, title = "AVD hosts") {
  const rows = hosts.map((h) => `<tr>${cols.map((c) => `<td>${esc(cellText(h, c))}</td>`).join("")}</tr>`).join("\n");
  return `<!doctype html>\n<meta charset="utf-8">\n<title>${esc(title)}</title>\n<style>body{font:14px Segoe UI,sans-serif;margin:20px}table{border-collapse:collapse}th,td{border:1px solid gray;padding:4px 10px;text-align:left}</style>\n<h1>${esc(title)}</h1>\n<p>${hosts.length} rows, saved ${esc(new Date().toISOString().slice(0, 16).replace("T", " "))} UTC</p>\n<table>\n<tr>${cols.map((c) => `<th>${esc(c.label)}</th>`).join("")}</tr>\n${rows}\n</table>\n`;
}

export const MAX_VIEWS = 20;
/** Saved views are { name, hash } (the hash is viewToHash text). Adds or replaces by name; the oldest drop off. */
export function saveView(views, view) {
  const name = String(view.name || "").trim().slice(0, 40);
  return name ? [...views.filter((v) => v.name !== name), { name, hash: String(view.hash || "") }].slice(-MAX_VIEWS) : views;
}
export const removeView = (views, name) => views.filter((v) => v.name !== name);
/** Stored views with anything malformed dropped. */
export const cleanViews = (raw) => (Array.isArray(raw) ? raw.filter((v) => v && typeof v.name === "string" && typeof v.hash === "string").slice(0, MAX_VIEWS) : []);

/** "5m ago" style age of an ISO time; "" when it is empty or invalid. */
export function ago(iso, now = Date.now()) {
  const t = Date.parse(iso);
  if (!Number.isFinite(t)) return "";
  const s = Math.max(0, Math.round((now - t) / 1000));
  if (s < 90) return "just now";
  if (s < 5400) return `${Math.round(s / 60)}m ago`;
  if (s < 129600) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}
