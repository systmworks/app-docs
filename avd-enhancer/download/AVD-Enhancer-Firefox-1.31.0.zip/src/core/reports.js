// The reports built from what the Dashboard already read, plus the Inventory read for Coverage (nothing else is requested). Each builder returns a
// report document: { title, subtitle, headline: [{ label, value, small, cls }], charts: [{ title, kind, items, empty }], sections: [{ title, head,
// cells, note }] }. The page shows it, and report-doc.js writes the same document as Markdown or one HTML page. Pure.

import { isOn, isIdle } from "./avd.js";
import { priceKey, hostHourly, dayCost, moneyWhole } from "./prices.js";

/** The reports, in sidebar order (A to Z by label): tab name, sidebar label, the line on All reports, the intro on the tab, and whether it needs the Inventory read (needsInventory) or the Microsoft price lookup (needsPrices). */
export const REPORTS = [
  { tab: "rep-capacity", label: "Capacity", blurb: "Sessions against capacity, pool by pool.",
    intro: "How full each pool is: user sessions against what its running hosts can take. A pooled host takes the pool's session limit, a personal host one session." },
  { tab: "rep-coverage", label: "Coverage", blurb: "Pools without a scaling plan and hosts without a maintenance window.", needsInventory: true,
    intro: "Which pools have a scaling plan and which hosts have an Azure maintenance window assigned to them. Reads the Inventory when you open it." },
  { tab: "rep-fleet", label: "Fleet health", blurb: "Which session hosts are on, which need attention and why.",
    intro: "Which session hosts are on, which need attention and why, for the subscription picked on the Dashboard." },
  { tab: "rep-size", label: "Size and cost", blurb: "VM sizes in use and a rough cost of idle hosts.", needsPrices: true,
    intro: "The VM sizes behind your hosts and what the hosts that are on with nobody signed in cost. The cost is a rough estimate: each idle host's hourly price from Microsoft's public price list (in the currency picked in Settings), times 24 hours. The hourly rate set in Settings is used only where no price is found." },
  { tab: "rep-versions", label: "Versions", blurb: "Agent and OS versions across the hosts, and the hosts on an old agent.",
    intro: "Which AVD agent and OS builds your session hosts run. An agent is old when a newer one is running on another host." },
];

const POWER_LABEL = { running: "Running", deallocated: "Deallocated", stopped: "Stopped", unknown: "Unknown" };
const POWER_TONE = { running: "ok", deallocated: "off", stopped: "off", unknown: "warn" };
const tally = (list, keyOf) => list.reduce((m, x) => m.set(keyOf(x), (m.get(keyOf(x)) || 0) + 1), new Map());
const byCountThenName = (a, b) => b.value - a.value || a.label.localeCompare(b.label);
const plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;
/** The "Session hosts" tile every host-based report opens with, and the subtitle line that names the subscription and the host count. */
const hostsTile = (n) => ({ label: "Session hosts", value: String(n), cls: "off" });
const hostsSubtitle = (scopeText, n) => `${scopeText}. ${plural(n, "session host")}.`;
/** Sessions as a percentage of capacity, or null when there is no capacity to compare with. */
const percent = (sessions, capacity) => (capacity > 0 ? Math.round((sessions * 100) / capacity) : null);
/** The chart tone of a percentage used: red at 100 or more, amber from 80, otherwise green. */
const usedTone = (pct) => (pct >= 100 ? "bad" : pct >= 80 ? "warn" : "ok");

/** Fleet health: power state, healthy against needing attention, the reasons, and the hosts that need attention. */
export function fleetHealth(hosts, scopeText = "All subscriptions") {
  const list = hosts || [];
  const power = [...tally(list, (h) => h.power || "unknown")].map(([k, v]) => ({ label: POWER_LABEL[k] || k, value: v, tone: POWER_TONE[k] || "warn" })).sort(byCountThenName);
  const needing = list.filter((h) => h.issue);
  const reasons = [...tally(needing, (h) => h.issue)].map(([k, v]) => ({ label: k, value: v, tone: "bad" })).sort(byCountThenName);
  const idle = list.filter(isIdle).length;
  const drain = list.filter((h) => h.drain).length;
  return {
    title: "AVD Enhancer: Fleet health",
    subtitle: hostsSubtitle(scopeText, list.length),
    headline: [
      hostsTile(list.length),
      { label: "Powered on", value: String(list.filter(isOn).length), cls: "ok" },
      { label: "Need attention", value: String(needing.length), cls: needing.length ? "bad" : "ok" },
      { label: "Idle (on, no sessions)", value: String(idle), cls: idle ? "warn" : "off" },
      { label: "Drain mode", value: String(drain), cls: drain ? "warn" : "off" },
    ],
    charts: [
      { title: "Healthy and needing attention", kind: "stack", items: [{ label: "Healthy", value: list.length - needing.length, tone: "ok" }, { label: "Needs attention", value: needing.length, tone: "bad" }], empty: "No session hosts." },
      { title: "Power state", kind: "bars", items: power, empty: "No session hosts." },
      { title: "Why hosts need attention", kind: "bars", items: reasons, empty: "No host needs attention." },
    ],
    sections: [{
      title: "Hosts needing attention",
      head: ["Host", "Pool", "Power", "Status", "Reason", "Sessions"],
      cells: needing.map((h) => [h.name, h.pool, h.power, h.status, h.issue, String(h.sessions)]),
      note: needing.length ? "" : "No host needs attention.",
    }],
  };
}

/** Capacity: sessions against capacity per pool (percent used, with the counts beside it) and the hosts powered on per pool. pools are the Dashboard's pool summary rows. */
export function capacityReport(pools, scopeText = "All subscriptions") {
  const list = (pools || []).map((p) => ({ ...p, pct: percent(p.sessions, p.capacity) }));
  const sessions = list.reduce((n, p) => n + p.sessions, 0);
  const capacity = list.reduce((n, p) => n + p.capacity, 0);
  const total = percent(sessions, capacity);
  const hot = list.filter((p) => p.pct !== null && p.pct >= 80).length;
  const unread = list.filter((p) => p.on > 0 && p.capacity === 0);
  return {
    title: "AVD Enhancer: Capacity",
    subtitle: `${scopeText}. ${plural(list.length, "host pool")}.`,
    headline: [
      { label: "Host pools", value: String(list.length), cls: "off" },
      { label: "User sessions", value: String(sessions), cls: "off" },
      { label: "Capacity (running hosts)", value: String(capacity), cls: "off" },
      { label: "Used", value: total === null ? "-" : `${total}%`, cls: total === null ? "off" : usedTone(total) },
      { label: "Pools at 80% or more", value: String(hot), cls: hot ? "warn" : "ok" },
    ],
    charts: [
      { title: "Capacity used by pool (percent)", kind: "bars", items: list.filter((p) => p.pct !== null).sort((a, b) => b.pct - a.pct || a.name.localeCompare(b.name)).map((p) => ({ label: p.name, value: p.pct, note: `${p.sessions} of ${p.capacity} sessions`, tone: usedTone(p.pct) })), empty: "No pool has a running host with a session limit." },
      { title: "Hosts powered on by pool", kind: "bars", items: list.map((p) => ({ label: p.name, value: p.on, note: `of ${p.total}`, tone: "ok" })).sort(byCountThenName), empty: "No host pools." },
    ],
    sections: [{
      title: "Pools",
      head: ["Pool", "Type", "Hosts on", "Hosts", "Sessions", "Capacity", "Used"],
      cells: [...list].sort((a, b) => (b.pct ?? -1) - (a.pct ?? -1) || a.name.localeCompare(b.name)).map((p) => [p.name, p.type, String(p.on), String(p.total), String(p.sessions), p.capacity ? String(p.capacity) : "-", p.pct === null ? "-" : `${p.pct}%`]),
      note: unread.length ? `${plural(unread.length, "pool")} (${unread.map((p) => p.name).join(", ")}) ${unread.length === 1 ? "has" : "have"} hosts on but no session limit was read, so ${unread.length === 1 ? "its" : "their"} capacity is not counted.` : "",
    }],
  };
}

/** Versions: how many hosts run each agent version and OS build, and the hosts on an old agent. */
export function versionsReport(hosts, scopeText = "All subscriptions") {
  const list = hosts || [];
  const oldAgents = new Set(list.filter((h) => h.oldAgent).map((h) => h.agent || "unknown"));
  const agents = [...tally(list, (h) => h.agent || "unknown")].map(([k, v]) => ({ label: k, value: v, tone: oldAgents.has(k) ? "warn" : "ok" })).sort(byCountThenName);
  const builds = [...tally(list, (h) => h.os || "unknown")].map(([k, v]) => ({ label: k, value: v })).sort(byCountThenName);
  const old = list.filter((h) => h.oldAgent);
  return {
    title: "AVD Enhancer: Versions",
    subtitle: hostsSubtitle(scopeText, list.length),
    headline: [
      hostsTile(list.length),
      { label: "Agent versions", value: String(agents.length), cls: agents.length > 1 ? "warn" : "off" },
      { label: "On an old agent", value: String(old.length), cls: old.length ? "warn" : "ok" },
      { label: "OS builds", value: String(builds.length), cls: "off" },
    ],
    charts: [
      { title: "Agent versions (hosts)", kind: "bars", items: agents, empty: "No session hosts." },
      { title: "OS builds (hosts)", kind: "bars", items: builds, empty: "No session hosts." },
    ],
    sections: [{
      title: "Hosts on an old agent",
      head: ["Host", "Pool", "Agent", "OS build", "Power"],
      cells: old.map((h) => [h.name, h.pool, h.agent, h.os || "unknown", h.power]),
      note: old.length ? "An agent is old when a newer version is running on another host." : "No host is on an old agent.",
    }],
  };
}

/** Size and cost: VM sizes in use, idle hosts per pool and a rough daily cost of the idle hosts: each idle host's hourly price x 24. The price is the looked-up
 *  Microsoft pay-as-you-go price for its size and region (prices: { "size|region": hourly } in `currency`, core/prices.js) or, where there is none, the hourly rate set
 *  in Settings (rate; 0 or less = none). The table has one row for each size in each region, so each row has one price. */
export function sizeCostReport(hosts, rate = 0, scopeText = "All subscriptions", prices = {}, currency = "USD") {
  const list = hosts || [];
  const priceOf = (h) => prices[priceKey(h.size, h.region)] || 0;
  const hourlyOf = (h) => hostHourly(h, prices, rate);
  /* The cost of some hosts per day in whole dollars with the currency symbol, rounded once at the end from the added hourly prices: "-" when none of them can be costed, "0" for no hosts when any price or a rate exists. */
  const costOf = (hs) => { const { cost } = dayCost(hs, prices, rate); return cost !== null ? moneyWhole(cost, currency) : hs.length ? "-" : (rate > 0 || list.some(priceOf)) ? moneyWhole(0, currency) : "-"; };
  const sizes = [...tally(list, (h) => h.size || "unknown")].map(([k, v]) => ({ label: k, value: v })).sort(byCountThenName);
  const rowOf = (h) => `${h.size || "unknown"}${h.region ? ` (${h.region})` : ""}`;
  const rows = [...tally(list, rowOf)].map(([k, v]) => ({ label: k, value: v })).sort(byCountThenName);
  const idleList = list.filter(isIdle);
  const idlePools = [...tally(idleList, (h) => h.pool)].map(([k, v]) => { const c = costOf(idleList.filter((h) => h.pool === k)); return { label: k, value: v, note: c === "-" ? "" : `about ${c} per day`, tone: "warn" }; }).sort(byCountThenName);
  const idle = idleList.length;
  const { cost: idleTotal, unpriced } = dayCost(idleList, prices, rate);
  const anyCost = idleTotal !== null;
  const pairs = new Set(list.filter((h) => h.size && h.region).map((h) => priceKey(h.size, h.region)));
  const priced = [...pairs].filter((k) => prices[k]).length;
  const how = priced ? ` Prices: ${priced} of ${plural(pairs.size, "size and region pair")} from Microsoft's public pay-as-you-go prices (${currency}, Linux compute rate)${rate > 0 ? "; the hourly rate in Settings is used for the rest" : ""}.`
    : rate > 0 ? ` Rate used: ${rate} per host per hour.` : " No price was found and no hourly rate is set (Settings), so no cost is shown.";
  return {
    title: "AVD Enhancer: Size and cost",
    subtitle: `${scopeText}. ${plural(list.length, "session host")}.${how}`,
    headline: [
      hostsTile(list.length),
      { label: "VM sizes", value: String(sizes.length), cls: "off" },
      { label: "Running", value: String(list.filter(isOn).length), cls: "ok" },
      { label: "Idle (on, no sessions)", value: String(idle), cls: idle ? "warn" : "ok" },
      { label: `Idle cost per day (${currency})`, value: costOf(idleList), small: !anyCost ? "set a rate in Settings" : unpriced ? `at least: ${plural(unpriced, "idle host")} not priced` : "rough estimate", cls: idle && anyCost ? "warn" : "off" },
    ],
    charts: [
      { title: "VM sizes (hosts)", kind: "bars", items: sizes, empty: "No session hosts." },
      { title: "Idle hosts by pool", kind: "bars", items: idlePools, empty: "No host is idle." },
    ],
    sections: [{
      title: "By VM size and region",
      head: ["VM size (region)", "Hosts", "Running", "Idle", `Price per hour (${currency})`, `Running cost per day (${currency})`, `Idle cost per day (${currency})`],
      cells: rows.map((r) => {
        const mine = list.filter((h) => rowOf(h) === r.label);
        const hourly = priceOf(mine[0]);
        return [r.label, String(mine.length), String(mine.filter(isOn).length), String(mine.filter(isIdle).length), hourly ? hourly.toFixed(4) : "-", costOf(mine.filter(isOn)), costOf(mine.filter(isIdle))];
      }),
      note: [
        "Running means the host is powered on. Idle means it is powered on with no users connected. A deallocated host costs no compute, so it is in neither.",
        `Price per hour is Microsoft's public pay-as-you-go price in ${currency} for that VM size in that region. A dash means no price was found.`,
        "Running cost per day and Idle cost per day assume the host stays on for 24 hours. Scaling plans switch hosts off, so your real cost will be lower. The exception is hosts excluded from the scaling plan.",
        "If no Microsoft price was found, the hourly rate from Settings is used instead, in the currency you typed it in.",
      ].join("\n"),
    }],
  };
}

/** Coverage: pools with and without a scaling plan, and hosts with and without a maintenance window assigned to the VM. inv is the Inventory read (or null while it is not read). */
export function coverageReport(hosts, pools, inv, scopeText = "All subscriptions") {
  const list = hosts || [];
  const poolList = pools || [];
  const errs = inv?.errors || [];
  const plansOk = Boolean(inv) && !errs.some((e) => e.startsWith("Scaling plans"));
  const maintOk = Boolean(inv) && !errs.some((e) => e.startsWith("Maintenance"));
  const planState = (p) => { const mine = (inv?.plans || []).flatMap((pl) => pl.pools.filter((x) => x.id === String(p.id).toLowerCase())); return mine.some((x) => x.enabled) ? "with" : mine.length ? "off" : "none"; };
  const planCounts = { with: 0, off: 0, none: 0 };
  for (const p of poolList) planCounts[planState(p)]++;
  const covered = new Set((inv?.assignments || []).map((a) => a.target));
  const bare = list.filter((h) => !covered.has(String(h.vmId || "").toLowerCase()));
  const barePerPool = [...tally(bare, (h) => h.pool)].map(([k, v]) => ({ label: k, value: v, tone: "warn" })).sort(byCountThenName);
  const noPlan = poolList.filter((p) => planState(p) !== "with");
  const unread = (what) => `${what} could not be read (see Inventory).`;
  return {
    title: "AVD Enhancer: Coverage",
    subtitle: `${scopeText}. ${plural(poolList.length, "host pool")}, ${plural(list.length, "session host")}.${inv?.fetchedAt ? ` Inventory read at ${new Date(inv.fetchedAt).toISOString().slice(11, 16)} UTC.` : ""}`,
    headline: [
      { label: "Pools with a scaling plan", value: plansOk ? String(planCounts.with) : "-", small: plansOk ? `of ${poolList.length}` : "not read", cls: !plansOk ? "off" : planCounts.with === poolList.length ? "ok" : "warn" },
      { label: "Pools without one", value: plansOk ? String(planCounts.none + planCounts.off) : "-", small: plansOk && planCounts.off ? `${planCounts.off} switched off` : "", cls: plansOk && planCounts.none + planCounts.off ? "warn" : "off" },
      { label: "Hosts with a window", value: maintOk ? String(list.length - bare.length) : "-", small: maintOk ? `of ${list.length}` : "not read", cls: !maintOk ? "off" : bare.length ? "warn" : "ok" },
      { label: "Hosts without one", value: maintOk ? String(bare.length) : "-", cls: maintOk && bare.length ? "warn" : "off" },
    ],
    charts: [
      { title: "Pools and scaling plans", kind: "stack", items: plansOk ? [{ label: "With a scaling plan", value: planCounts.with, tone: "ok" }, { label: "Plan switched off", value: planCounts.off, tone: "warn" }, { label: "No scaling plan", value: planCounts.none, tone: "bad" }] : [], empty: plansOk ? "No host pools." : unread("Scaling plans") },
      { title: "Hosts and maintenance windows", kind: "stack", items: maintOk ? [{ label: "With a maintenance window", value: list.length - bare.length, tone: "ok" }, { label: "Without one", value: bare.length, tone: "warn" }] : [], empty: maintOk ? "No session hosts." : unread("Maintenance windows") },
      { title: "Hosts without a maintenance window, by pool", kind: "bars", items: maintOk ? barePerPool : [], empty: maintOk ? "Every host has a maintenance window." : unread("Maintenance windows") },
    ],
    sections: [
      { title: "Pools without a working scaling plan", head: ["Pool", "Type", "Hosts", "Scaling plan"], cells: plansOk ? noPlan.map((p) => [p.name, p.type, String(p.total), planState(p) === "off" ? "Switched off" : "None"]) : [], note: plansOk ? (noPlan.length ? "" : "Every pool has a scaling plan.") : unread("Scaling plans") },
      { title: "Hosts without a maintenance window", head: ["Host", "Pool", "Power"], cells: maintOk ? bare.map((h) => [h.name, h.pool, h.power]) : [], note: maintOk ? "Only a window assigned to the VM itself is seen here; one assigned to a whole subscription or resource group is not." : unread("Maintenance windows") },
    ],
  };
}

/**
 * The report for a tab name, or null. ctx: { hosts (narrowed to the subscription picked), pools (the Dashboard's pool summary rows for it),
 * inventory (the Inventory read or null), rate (hourly cost of a host), scope (text) }.
 */
export function buildReport(tab, ctx) {
  const { hosts, pools, inventory = null, rate = 0, scope, prices = {}, currency = "USD" } = ctx;
  switch (tab) {
    case "rep-fleet": return fleetHealth(hosts, scope);
    case "rep-capacity": return capacityReport(pools, scope);
    case "rep-versions": return versionsReport(hosts, scope);
    case "rep-size": return sizeCostReport(hosts, rate, scope, prices, currency);
    case "rep-coverage": return coverageReport(hosts, pools, inventory, scope);
    default: return null;
  }
}
