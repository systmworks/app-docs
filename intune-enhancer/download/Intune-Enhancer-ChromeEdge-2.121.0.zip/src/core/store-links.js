/** The store pages of AVD Enhancer, by browser. The "Try AVD Enhancer" card in the footer's bottom right corner opens one in a new tab; the extension makes no request to it. */
export const AVD_STORES = {
  chrome: { name: "Chrome Web Store", url: "https://chromewebstore.google.com/detail/avd-enhancer/pjfnicplgngkmhkhkenohahoapoimopg" },
  firefox: { name: "Firefox Add-ons", url: "https://addons.mozilla.org/en-US/firefox/addon/avd-enhancer/" },
};
/** The store that matches a browser's user agent: Firefox, otherwise the Chrome Web Store (Edge too, until AVD Enhancer has an Edge Add-ons page). */
export const avdStore = (ua = "") => (/\bFirefox\//.test(ua) ? AVD_STORES.firefox : AVD_STORES.chrome);
