// Policy tools: Setting check, Recent changes, Duplicate policies, Policy export, App details, Baseline gap, Failed apps and
// Failed policies, App versions and Cleanup. Moved out of workspace.js without changes to the code (see
// docs/workspace-split-plan.md).

import { baselineGap } from "../core/baseline-gap.js";
import { loadBaselines } from "./lazy-data.js";
import { settingArea } from "../core/setting-search.js";
import { searchWords, hasAllWords, platformName } from "../core/format.js";
import { isBelowVersion } from "../core/app-versions.js";
import { POLICY_TYPES } from "../core/policy-types.js";
import { policyDocument } from "../core/policy-export.js";
import { appSections } from "../core/app-details.js";
import { findDevice } from "./lookups.js";
import { $, $$, ago, appState, badge, badgeCounts, bindExport, capped, checkInCell, checkInText, emptyBox, errorBox, esc, exportButtons, fillPlatforms, friendlyOs, jobBar, kvTable, link, loadDevices, loading, newestOnly, nextSort, onEnterOrClear, oneAtATime, registerTab, runInto, scopeNote, scoped, send, showExport, sortHead, sortRows, tableHtml, tableWrap, td, tile, userOf, valueCell } from "./core.js";

// ------------------------------------------------------------------------------------------
// Setting check

// The policy index line, on every tab that reads the policy index.
export const setIndexLines = (html) => $$(".policy-index-line").forEach((el) => { el.innerHTML = html; });

/** Group ids named in the assignments of a Setting check or deprecated-settings answer. */
const settingGroupIds = (res) => [...new Set(res.settings.flatMap((s) => s.hits.flatMap((h) => h.assignments.map((a) => a.groupId))))];

export function renderIndexLine(p) {
  if (!p) { setIndexLines(""); return; }
  if (p.building) { setIndexLines('<span class="spinner"></span>Reading your policies...'); return; }
  const errs = Object.keys(p.errors || {}).filter((k) => !k.includes(":"));
  setIndexLines(p.builtAt
    ? `Policy index: ${p.count} policies, updated ${esc(ago(p.builtAt))}${p.stale ? " (refresh recommended)" : ""}. <button class="link" data-refresh-policies>Refresh</button>${errs.length ? `<br>Couldn't read: ${esc(errs.join(", "))}. Results don't include those.` : ""}`
    : 'Your policies are read the first time you use a tool that needs them. <button class="link" data-refresh-policies>Read them now</button>');
}

async function rebuildPolicies() {
  renderIndexLine({ building: true });
  try {
    const res = await send("policies/build");
    renderIndexLine(res.policies);
    changes = null; // re-read with the new index
    if (shown && appState.currentTab === "changes") showChanges(); // refresh results already on screen; a hidden tab re-reads when opened
  } catch (e) {
    setIndexLines(esc(e.message));
  }
}
document.addEventListener("click", (e) => { if (e.target.closest?.("[data-refresh-policies]")) rebuildPolicies(); });

let groupNameCache = {}; // group id -> name (null when Graph has none); not groupNames, a core/group-tools.js export
async function namesFor(ids) {
  const missing = ids.filter((id) => id && !(id in groupNameCache));
  if (missing.length) {
    try {
      const found = (await send("groups/names", { ids: missing })).names;
      // An id Graph doesn't know (a deleted group) is remembered as null, so it isn't asked for on every redraw.
      for (const id of missing) groupNameCache[id] = found[id] ?? null;
    } catch { /* show ids, and ask again next time */ }
  }
  return groupNameCache;
}

function assignmentText(assignments) {
  if (!assignments?.length) return '<span class="muted">Not assigned</span>';
  return assignments.map((a) => {
    const filter = a.filterId ? ` <span class="muted">(filter ${esc(a.filterType || "")})</span>` : "";
    if (a.kind === "allDevices") return `All devices${filter}`;
    if (a.kind === "allUsers") return `All users${filter}`;
    const name = groupNameCache[a.groupId] || a.groupId;
    return `${a.kind === "exclude" ? '<span class="badge warn">Exclude</span> ' : ""}${esc(name)}${filter}`;
  }).join("<br>");
}

const settingRun = newestOnly(); // Check and Deprecated settings share one results area

$("#setting-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query = $("#setting-query").value.trim();
  const out = $("#setting-results");
  if (!query) { settingRun(); out.innerHTML = ""; return; } // also stops an earlier search from drawing
  runInto(out, settingRun, "Searching your policies (the first search reads them, which can take a minute)...", async () => {
    const res = await send("settings/search", { query });
    renderIndexLine(res.policies);
    await namesFor(settingGroupIds(res));
    return renderSettings(query, res);
  });
});

function renderSettings(query, res) {
  if (!res.settings.length) {
    return `<div class="card"><h2>Not configured</h2>
      <p>No setting matching <strong>${esc(query)}</strong> is configured in any of the ${res.policyCount} policies with settings (${res.settingCount.toLocaleString()} configured settings checked).</p>
      <p class="muted">This searches settings that are <em>set</em> in a policy. A setting that exists in the catalog but isn't set anywhere won't appear, so check the spelling if you expected a match.</p></div>`;
  }
  const indexed = res.policies?.count ? ` of the ${res.policies.count} indexed (apps, scripts and similar have no settings)` : "";
  return `<p class="muted">${res.total} matching setting${res.total === 1 ? "" : "s"}${res.truncated ? `, showing the first ${res.settings.length}` : ""}. Checked the ${res.policyCount} policies that configure settings${indexed}.</p>` + settingCards(res.settings);
}

function renderDeprecated(res) {
  if (!res.settings.length) {
    return `<div class="card"><h2>No deprecated settings found</h2>
      <p>None of the ${res.settingCount.toLocaleString()} settings configured in your ${res.policyCount} policies is marked deprecated.</p></div>`;
  }
  const uses = res.settings.reduce((n, s) => n + s.hits.length, 0);
  return `<p class="muted">${res.total} deprecated setting${res.total === 1 ? " is" : "s are"} still configured, ${uses} time${uses === 1 ? "" : "s"} across your policies${res.truncated ? ` (showing the first ${res.settings.length})` : ""}. Found by "Deprecated" in the setting's name or catalog description: plan to remove or replace them.</p>` + settingCards(res.settings);
}

function settingCards(settings) {
  const sameName = new Map();
  for (const s of settings) sameName.set(s.name, (sameName.get(s.name) || 0) + 1);
  // Settings that share a name (one per Office app, say) are told apart by the product in their path.
  const hint = (s) => (sameName.get(s.name) > 1 && settingArea(s.path) ? ` <span class="muted small">${esc(settingArea(s.path))}</span>` : "");
  return settings.map((s) => `
    <article class="card">
      <h2>${esc(s.name)}${hint(s)}</h2>
      <div class="path">${esc(s.path)}</div>
      <div class="badges">
        <span class="badge ok">Configured in ${s.hits.length} polic${s.hits.length === 1 ? "y" : "ies"}</span>
        ${s.differs ? '<span class="badge warn">Values differ between policies</span>' : ""}
      </div>
      ${tableHtml(["Policy", "Type", "Value", "Assigned to"], s.hits.map((h) => [
        td(link(h.link, h.policyName)), td(esc(h.typeLabel)), valueCell(h.value || "(set)"), td(assignmentText(h.assignments)),
      ]))}
    </article>`).join("");
}

$("#deprecated-run").addEventListener("click", () => runInto($("#setting-results"), settingRun,
  "Looking for deprecated settings (the first run reads your policies, which can take a minute)...", async () => {
    const res = await send("settings/deprecated");
    renderIndexLine(res.policies);
    await namesFor(settingGroupIds(res));
    return renderDeprecated(res);
  }));

// ------------------------------------------------------------------------------------------
// Recent changes

let changes = null;
let changesLoading = null;
let shown = null; // rows of the last search, for Copy table and Save CSV

// Every type up front, so it can be picked before the first search.
$("#changes-type").innerHTML = '<option value="">All types</option>' +
  POLICY_TYPES.map((t) => t.label).sort().map((t) => `<option>${esc(t)}</option>`).join("");

async function showChanges() {
  if (!changes) {
    $("#changes-results").innerHTML = loading("Reading your policies (the first time can take a minute)...");
    try {
      if (!changesLoading) changesLoading = send("policies/changes").finally(() => { changesLoading = null; });
      const res = await changesLoading;
      renderIndexLine(res.policies);
      await namesFor([...new Set(res.items.flatMap((i) => i.assignments.map((a) => a.groupId)))]);
      changes = res.items;
    } catch (err) {
      $("#changes-results").innerHTML = errorBox(err);
      return;
    }
  }
  drawChanges();
}

function changesView() {
  const days = Number($("#changes-days").value) || 7;
  const by = $("#changes-by").value;
  const type = $("#changes-type").value;
  const words = searchWords($("#changes-filter").value);
  const since = new Date(Date.now() - days * 864e5).toISOString();
  return changes
    .filter((i) => i[by] && i[by] >= since && (!type || i.typeLabel === type) && hasAllWords(i.name, words))
    .sort((a, b) => b[by].localeCompare(a[by]));
}

const dateAgo = (iso) => (iso ? `${esc(new Date(iso).toLocaleDateString())} <span class="muted small">${esc(checkInText(iso))}</span>` : '<span class="muted">unknown</span>');

function drawChanges() {
  const rows = (shown = changesView());
  const days = Number($("#changes-days").value) || 7;
  const undated = changes.filter((i) => !i.modified).length;
  $("#changes-count").textContent = `${rows.length} of ${changes.length}`;
  showExport("changes", rows.length > 0);
  $("#changes-results").innerHTML = (rows.length
    ? tableHtml(["Name", "Type", "Modified", "Created", "Assigned to"], rows.map((i) => [
      td(link(i.link, i.name)), td(esc(i.typeLabel)), td(dateAgo(i.modified), "nowrap"), td(dateAgo(i.created), "nowrap"), td(assignmentText(i.assignments)),
    ]))
    : emptyBox(`Nothing ${$("#changes-by").value === "created" ? "created" : "changed"} in the last ${days} days.`)) +
    (undated ? `<p class="muted small">${undated} item${undated === 1 ? " has" : "s have"} no dates in Graph, so ${undated === 1 ? "isn't" : "aren't"} listed.</p>` : "");
}

// Runs on Show changes or Enter only, so the period and filters can be set first.
$("#changes-form").addEventListener("submit", (e) => { e.preventDefault(); showChanges(); });

function changesRows() {
  const target = (a) => (a.kind === "allDevices" ? "All devices" : a.kind === "allUsers" ? "All users"
    : `${a.kind === "exclude" ? "Exclude: " : ""}${groupNameCache[a.groupId] || a.groupId}`);
  return [["Name", "Type", "Modified", "Created", "Assigned to", "ID"],
    ...shown.map((i) => [i.name, i.typeLabel, i.modified, i.created, i.assignments.map(target).join("; "), i.id])];
}
bindExport("changes", () => shown && changesRows(), () => "recent-changes.csv");

// Duplicate policies

let dupPolReport = null;
const dupPolRun = newestOnly();
const DUP_POL_MATCH = { identical: ["bad", "Identical"], inside: ["warn", "One is inside the other"], partial: ["", "Partly the same"] };

function renderDupPolicies(r) {
  if (!r.pairs.length) return emptyBox("No two policies set the same values.");
  return `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${r.total.toLocaleString()} pair${r.total === 1 ? "" : "s"}${r.total > r.pairs.length ? `, showing the first ${r.pairs.length}` : ""}${r.skippedValues
        ? `. ${r.skippedValues.toLocaleString()} setting value${r.skippedValues === 1 ? " is" : "s are"} set by so many policies that ${r.skippedValues === 1 ? "it isn't" : "they aren't"} counted in Same settings` : ""}${r.partialPolicies?.length
        ? `. Only part of the settings of ${esc(r.partialPolicies.join(", "))} could be read, so their matches may be off; rebuild the policy list to try again` : ""}</span>
      <span class="spacer"></span>
      ${exportButtons("dupes")}
    </div>` +
    tableHtml(["Policy", "Other policy", "Same settings", "Match", "Same assignments", "Examples"], r.pairs.map((p) => [
      td(link(p.a.link, p.a.name) + `<div class="muted small">${esc(p.a.typeLabel)}</div>`), td(link(p.b.link, p.b.name) + `<div class="muted small">${esc(p.b.typeLabel)}</div>`),
      td(`${p.shared} of ${p.sizeA} and ${p.sizeB}`, "nowrap"), td(badge(DUP_POL_MATCH, p.match)),
      td(p.sameAssignments ? "Yes" : "No"), td(esc(p.sample.join("; ")), "small")])) + "</article>";
}

function dupPolRows() {
  return [["Policy", "Type", "Other policy", "Other type", "Same settings", "Settings in first", "Settings in second", "Match", "Same assignments", "Examples"],
    ...(dupPolReport?.pairs || []).map((p) => [p.a.name, p.a.typeLabel, p.b.name, p.b.typeLabel, p.shared, p.sizeA, p.sizeB, DUP_POL_MATCH[p.match][1], p.sameAssignments ? "Yes" : "No", p.sample.join("; ")])];
}

$("#dupes-run").addEventListener("click", () => runInto($("#dupes-results"), dupPolRun,
  "Comparing every policy. The first time, the policy index can take a few minutes to build...", async (current) => {
    const r = await send("policies/duplicates");
    if (!current()) return;
    dupPolReport = r;
    return renderDupPolicies(r);
  }));
bindExport("dupes", () => dupPolRows(), () => "duplicate-policies.csv");

// Policy export

const polRun = newestOnly();

/**
 * Shared by Policy export and App details: search the policy index by name (only apps when apps is true) and either
 * open the one hit or list up to 50 to pick from. The pick buttons carry `attr` (data-pol / data-app).
 */
function findIndexed({ q, out, newRun, apps = false, attr, open }) {
  return runInto(out, newRun, "Searching the policy index. The first time, it can take a few minutes to build...", async (current) => {
    const { policies, total } = await send("policy/find", { query: q, apps });
    if (!current()) return;
    if (policies.length === 1) { open(policies[0].id); return; }
    return policies.length
      ? `<article class="card"><p class="muted">${total.toLocaleString()} ${apps ? "apps" : "policies"} match. Pick one.</p>` +
        tableHtml([apps ? "App" : "Policy", "Type"], policies.map((p) => [td(`<button class="link" ${attr}="${esc(p.id)}">${esc(p.name)}</button>`, "nowrap"), td(esc(p.typeLabel))])) +
        (total > policies.length ? `<p class="muted small">Showing the first ${policies.length}. Type more of the name.</p>` : "") + "</article>"
      : emptyBox(apps ? "No assigned app has that in its name." : "No policy has that in its name.");
  });
}

function findPolicy() {
  const q = $("#polexp-query").value.trim();
  if (!q) return;
  return findIndexed({ q, out: $("#polexp-results"), newRun: polRun, attr: "data-pol", open: openPolicy });
}

function openPolicy(id) {
  return runInto($("#polexp-results"), polRun, "Reading the policy...", async (current) => {
    const { policy, names, filters } = await send("policy/get", { id });
    if (!current()) return;
    appState.polDoc = policyDocument(policy, names, filters);
    return `<article class="card">
      <div class="toolbar tight">
        <h2>${link(policy.link, appState.polDoc.title)}</h2>
        <span class="spacer"></span>
        ${exportButtons("polexp")}
      </div>
      ${appState.polDoc.hasSettings ? "" : '<p class="muted small">This type of policy has no settings in the index.</p>'}
      <pre class="path" style="white-space:pre-wrap">${esc(appState.polDoc.markdown)}</pre>
    </article>`;
  });
}

$("#polexp-find").addEventListener("click", findPolicy);
onEnterOrClear($("#polexp-query"), findPolicy);
$("#polexp-results").addEventListener("click", async (e) => {
  const pick = e.target.closest("button[data-pol]");
  if (pick) openPolicy(pick.dataset.pol);
});
bindExport("polexp", () => appState.polDoc?.rows, () => `policy-${appState.polDoc.title.replace(/[^\w.-]+/g, "-")}.csv`);

// App details: one app's detection and requirement rules, commands, return codes, dependencies and assignments.

const appRun = newestOnly();

function findApp() {
  const q = $("#appdet-query").value.trim();
  if (!q) return;
  return findIndexed({ q, out: $("#appdet-results"), newRun: appRun, apps: true, attr: "data-app", open: openApp });
}

function openApp(id) {
  return runInto($("#appdet-results"), appRun, "Reading the app...", async (current) => {
    const [{ policy, names, filters }, { app, relationships }] = await Promise.all([send("policy/get", { id }), send("app/details", { id })]);
    if (!current()) return;
    const sections = appSections(app, relationships);
    appState.appDoc = policyDocument(policy, names, filters, sections);
    const assignments = appState.appDoc.rows.filter((r) => r[0] === "Assignment").map((r) => r[1]);
    const card = (title, body) => `<article class="card"><h2>${esc(title)}</h2>${body}</article>`;
    return `<article class="card">
      <div class="toolbar tight">
        <h2>${link(policy.link, appState.appDoc.title)}</h2>
        <span class="spacer"></span>
        ${exportButtons("appdet")}
      </div>
    </article>
    ${sections.map((s) => card(s.title, kvTable(s.rows) + (s.code || []).map((c) => `<h3>${esc(c.name)}</h3><pre class="path" style="white-space:pre-wrap">${esc(c.text)}</pre>`).join(""))).join("")}
    ${card("Assignments", `<ul>${assignments.map((a) => `<li>${esc(a)}</li>`).join("")}</ul>`)}`;
  });
}

$("#appdet-find").addEventListener("click", findApp);
onEnterOrClear($("#appdet-query"), findApp);
$("#appdet-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-app]");
  if (pick) openApp(pick.dataset.app);
});
bindExport("appdet", () => appState.appDoc?.rows, () => `app-${appState.appDoc.title.replace(/[^\w.-]+/g, "-")}.csv`);

// ------------------------------------------------------------------------------------------
// Baseline gap: one device's applied policy settings against a Microsoft security baseline.

const BL_BADGE = { match: ["ok", "Matches"], differs: ["bad", "Different"], conflict: ["bad", "Conflict"], review: ["warn", "Check value"], missing: ["", "Not configured"] };
let blResult = null; // last answer
let blDevice = null; // { id, name } of the device last checked
const blRun = newestOnly(); // only the latest check may draw

let blData = null; // { baselines, built } once loaded (lazy-data.js)

/** Loads the baselines the first time the tab opens, and fills the drop-down. */
async function baselineData() {
  if (!blData) {
    const data = await loadBaselines();
    if (blData) return blData; // another call filled it while this one waited
    blData = data;
    $("#bl-which").innerHTML = blData.baselines.map((b) => `<option value="${esc(b.id)}">${esc(`${b.name} ${b.version}`)}</option>`).join("");
  }
  return blData;
}

function findBaseline() {
  const q = $("#bl-query").value.trim().toLowerCase();
  if (!q) return;
  if (blDevice && q === blDevice.name.toLowerCase()) { runBaseline(blDevice.id); return; } // the same device, another baseline
  // The baselines are for Windows, so only Windows devices are offered.
  return findDevice({ q, out: $("#bl-results"), newRun: blRun, windowsOnly: true, attr: "data-bl", open: runBaseline });
}

function runBaseline(managedId) {
  return runInto($("#bl-results"), blRun, "Reading groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const [res, data] = await Promise.all([send("baseline/applied", { managedId, baseline: $("#bl-which").value }), baselineData()]);
    if (!current()) return;
    const baseline = data.baselines.find((b) => b.id === $("#bl-which").value) || data.baselines[0];
    const { applied, ...rest } = res;
    blResult = { ...rest, ...baselineGap(baseline, applied) };
    blDevice = { id: managedId, name: res.device.name };
    $("#bl-query").value = res.device.name;
    renderBaseline();
  });
}

const blShown = () => {
  const f = $("#bl-filter")?.value || "attention";
  return (blResult?.rows || []).filter((r) => f === "all" || (f === "attention" ? r.status !== "match" : r.status === f));
};

function renderBaseline() {
  const r = blResult;
  if (!r) return;
  const n = r.counts;
  const keep = $("#bl-filter")?.value || "attention";
  const sources = (row) => [...new Set(row.sources.map((s) => `${s.name}${s.certainty !== "applies" ? " (may not apply)" : ""}`))].join("; ");
  $("#bl-results").innerHTML = `<article class="card">
      <h2>${link(r.device.link, r.device.name)} <span class="muted small">${esc([r.device.user, friendlyOs(r.device.os, r.device.osVersion)].filter(Boolean).join(", "))}</span></h2>
      <p>${esc(`${r.baseline.name} ${r.baseline.version}`)}: <strong>${n.match.toLocaleString()}</strong> of ${r.total.toLocaleString()} recommendations are set as recommended by a policy that reaches this device.</p>
      <p>${badgeCounts(BL_BADGE, n)}</p>
      <p class="muted small" title="${esc(`Policy index read ${new Date(r.indexBuiltAt).toLocaleString()}. Group Policy, scripts and the built-in security baseline profiles are not seen. Check value: a policy sets it but the value could not be compared. Baseline data built ${blData?.built || "unknown"}.`)}">From ${r.appliedPolicies.toLocaleString()} policies that reach the device. Group Policy and scripts are not seen.</p>
      ${r.indexErrors.length ? `<p class="warn small">Some policy types could not be read (${esc(r.indexErrors.join(", "))}), so settings in them are missing here.</p>` : ""}
      ${r.notes.map((x) => `<p class="warn small">${esc(x)}</p>`).join("")}
      <div class="toolbar">
        <label>Show <select id="bl-filter"><option value="attention">Needs attention</option><option value="all">All</option>${Object.entries(BL_BADGE).map(([k, [, label]]) => `<option value="${k}">${esc(label)}</option>`).join("")}</select></label>
        <span class="muted small" id="bl-count"></span>
        ${exportButtons("bl", ["json"])}
      </div>
      <div id="bl-table"></div>
    </article>`;
  $("#bl-filter").value = keep;
  const rows = blShown();
  $("#bl-count").textContent = `${rows.length.toLocaleString()} of ${r.total.toLocaleString()} shown`;
  $("#bl-table").innerHTML = rows.length
    ? capped(rows, (shownRows) => tableHtml(["Status", "Setting", "Category", "Recommended", "Applied by Intune", "Set by", "Note"], shownRows.map((row) => [
      td(badge(BL_BADGE, row.status), "nowrap"), td(esc(row.title), "bl-setting"), td(esc(row.category), "bl-category"), td(esc(row.recommended)),
      td(esc(row.applied)), td(esc(sources(row)), "bl-sources"), td(esc(row.note), "bl-note"),
    ])), 1000, "Copy, CSV and JSON include all.")
    : emptyBox("Nothing to show with this filter.");
}

function blTableRows() {
  return [["Status", "Setting", "Category", "Recommended", "Applied by Intune", "Set by", "Note", "Setting id"],
    ...blShown().map((r) => [BL_BADGE[r.status][1], r.title, r.category, r.recommended, r.applied, r.sources.map((s) => s.name).join("; "), r.note, r.id])];
}

$("#bl-find").addEventListener("click", findBaseline);
onEnterOrClear($("#bl-query"), findBaseline);
$("#bl-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-bl]");
  if (pick) runBaseline(pick.dataset.bl);
});
const blFile = (ext) => `baseline-gap-${blDevice?.name || "device"}-${blResult?.baseline.id || ""}.${ext}`;
bindExport("bl", () => blTableRows(), () => blFile("csv"), undefined, () => ({ file: blFile("json"), data: { readAt: new Date().toISOString(), ...blResult } }));
$("#bl-results").addEventListener("input", (e) => { if (e.target.id === "bl-filter") renderBaseline(); });

// ------------------------------------------------------------------------------------------
// Failed apps and Failed policies: one report, two sources. Devices or users (never both at once), a minimum
// number of fails, a platform, sortable headings, Copy table and Save CSV.

const FAIL_ROW_LIMIT = 2000;

/** Set up one failed report: cfg names its ids (prefix), labels and how its rows are read. */
function failedReport(cfg) {
  const p = cfg.prefix;
  let data = null; // rows as read: { name, extra, platform, link, device: {fail, conflict?, ok} | null, user: ... }
  let mode = "device"; // "device" or "user"
  let sort = { key: "fails", dir: -1 }; // most fails first
  let view = []; // rows as shown, in the shown order

  const who = () => (mode === "user" ? "User" : "Device");
  const cols = () => [
    { key: "name", label: cfg.nameLabel },
    { key: "extra", label: cfg.extraLabel },
    { key: "pct", label: cfg.pctLabel, num: true },
    { key: "fails", label: `${who()} ${cfg.failWord}`, num: true },
    ...(cfg.conflicts ? [{ key: "conflicts", label: `${who()} conflicts`, num: true }] : []),
    { key: "ok", label: `${who()} ${cfg.okWord}`, num: true },
  ];

  /** The rows with this mode's counts. A row Intune has no user (or device) count for isn't in that mode. */
  const rowsFor = () => data.flatMap((r) => {
    const s = r[mode];
    if (!s) return [];
    const conflicts = s.conflict || 0;
    const total = s.fail + conflicts + s.ok;
    return [{ name: r.name, extra: r.extra, platform: r.platform, link: r.link, fails: s.fail, conflicts, ok: s.ok, pct: total ? s.fail / total * 100 : 0 }];
  });

  function render() {
    const out = $(`#${p}-results`);
    if (!data) return;
    const sel = $(`#${p}-os`);
    fillPlatforms(sel, [...new Set(data.map((r) => r.platform).filter(Boolean))].sort());
    const min = Number($(`#${p}-min`).value) || 0;
    const all = rowsFor();
    // Policies: a conflict counts too, so a policy that only conflicts is still listed.
    view = sortRows(all.filter((r) => (!sel.value || r.platform === sel.value) && r.fails + (cfg.conflicts ? r.conflicts : 0) > min),
      cols(), sort, (r, k) => r[k]);
    showExport(p, view.length > 0);
    $(`#${p}-count`).textContent = `${view.length.toLocaleString()} of ${all.length.toLocaleString()}`;
    if (!all.length) {
      out.innerHTML = emptyBox(mode === "user" && data.length ? "Intune gave no user counts for these. Try Devices." : `No ${cfg.noun} found.`);
      return;
    }
    const head = sortHead(cols(), sort);
    const draw = (rows) => tableWrap(head, rows.map((r) => `<tr>${[
      td(link(r.link, r.name), "nowrap"), td(esc(r.extra || "")), td(`${r.pct.toFixed(1)}%`, "num"), td(r.fails.toLocaleString(), "num"),
      ...(cfg.conflicts ? [td(r.conflicts.toLocaleString(), "num")] : []), td(r.ok.toLocaleString(), "num"),
    ].join("")}</tr>`).join(""));
    out.innerHTML = view.length
      ? capped(view, draw, FAIL_ROW_LIMIT)
      : emptyBox(`None have more than ${min.toLocaleString()} ${cfg.minWord}.`);
  }

  const tableRows = () => [[...cols().map((c) => c.label), "Platform"],
    ...view.map((r) => [r.name, r.extra, r.pct.toFixed(1), r.fails, ...(cfg.conflicts ? [r.conflicts] : []), r.ok, r.platform])];

  const run = oneAtATime($(`#${p}-run`), async () => {
    const out = $(`#${p}-results`);
    out.innerHTML = loading(`Reading ${cfg.noun}...`);
    try {
      data = await cfg.read(out);
      render();
    } catch (err) {
      out.innerHTML = errorBox(err);
      jobBar.done(p);
    }
  });

  $(`#${p}-run`).addEventListener("click", run);
  $(`#${p}-device`).addEventListener("change", (e) => {
    mode = e.currentTarget.checked ? "device" : "user"; // on = Devices (the default), off = Users
    $(`#${p}-who`).textContent = `Show ${who()} stats`;
    render();
  });
  $(`#${p}-min`).addEventListener("input", render);
  $(`#${p}-os`).addEventListener("input", render);
  $(`#${p}-results`).addEventListener("click", (e) => {
    const th = e.target.closest("th[data-sort]");
    if (!th || !data) return;
    const key = th.dataset.sort;
    sort = nextSort(sort, key, key === "name" || key === "extra" ? 1 : -1); // counts: most first
    render();
  });
  bindExport(p, () => tableRows(), () => `${cfg.file}.csv`);
}

failedReport({
  prefix: "fapps", noun: "apps", file: "failed-apps", nameLabel: "App name", extraLabel: "Version", pctLabel: "Install failure (%)",
  failWord: "failures", okWord: "installs", minWord: "fails", conflicts: false,
  async read() {
    const { rows } = await send("failed/apps");
    return rows.map((r) => ({ name: r.name, extra: r.version, platform: r.platform, link: r.link, device: r.device, user: r.user }));
  },
});

const FAILED_POLICY_CHUNK = 40; // policies per request to the worker, so progress and Stop respond between chunks
failedReport({
  prefix: "fpol", noun: "policies", file: "failed-policies", nameLabel: "Policy name", extraLabel: "Type", pctLabel: "Failure (%)",
  failWord: "failures", okWord: "successes", minWord: "fails or conflicts", conflicts: true,
  async read(out) {
    let stopped = false;
    const { items } = await send("failed/policies/list");
    const results = {};
    for (let i = 0; i < items.length && !stopped; i += FAILED_POLICY_CHUNK) {
      jobBar.set("fpol", { label: "Reading policy results", done: i, total: items.length, stop: () => { stopped = true; } });
      out.innerHTML = loading("Reading each policy's results. Stop keeps what is read so far.");
      Object.assign(results, (await send("failed/policies/read", { items: items.slice(i, i + FAILED_POLICY_CHUNK) })).results);
    }
    jobBar.done("fpol", stopped ? "Stopped. Kept what was read so far." : "");
    return items.filter((i) => results[i.id] && !results[i.id].retry).map((i) => ({
      name: i.name, extra: i.typeLabel, platform: i.platform, link: i.link, device: results[i.id].device, user: results[i.id].user,
    }));
  },
});

// ------------------------------------------------------------------------------------------
// App versions

const appverRun = newestOnly();
let appverApps = [];
let appverRows = []; // the device table shown, for copy and CSV

$("#appver-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const query = $("#appver-query").value.trim();
  const out = $("#appver-results");
  $("#appver-devices").innerHTML = "";
  $("#appver-tools").hidden = true;
  if (!query) { appverRun(); out.innerHTML = ""; return; } // also stops an earlier search from drawing
  runInto(out, appverRun, "Reading the discovered apps...", async (current) => {
    const res = await send("apps/versions", { query });
    if (!current()) return;
    appverApps = res.apps;
    drawAppVersions();
  });
});

function drawAppVersions() {
  const below = $("#appver-below").value.trim();
  const out = $("#appver-results");
  if (!appverApps.length) { out.innerHTML = emptyBox("No discovered app has that name."); return; }
  out.innerHTML = appverApps.map((app, ai) => {
    const older = below ? app.versions.filter((v) => isBelowVersion(v.version, below)) : [];
    const olderDevices = older.reduce((n, v) => n + v.devices, 0);
    return `<article class="card">
      <h2>${esc(app.name)}</h2>
      <div class="muted">${esc([app.publisher, app.platform].filter(Boolean).join(", "))}${app.publisher || app.platform ? " - " : ""}${app.total.toLocaleString()} devices, ${app.versions.length} version${app.versions.length === 1 ? "" : "s"}</div>
      ${tableHtml(["Version", { label: "Devices", num: true }, ""], app.versions.map((v, vi) => [
        td(esc(v.version || "(none)"), "mono"),
        td(v.devices.toLocaleString(), "num"),
        td(`${below && isBelowVersion(v.version, below) ? '<span class="badge warn">older</span> ' : ""}<button type="button" data-app="${ai}" data-ver="${vi}">List devices</button>`),
      ]))}
      ${app.versions.length > 1 ? `<p><button type="button" class="primary" data-app="${ai}" data-all="1">List all ${app.total.toLocaleString()} devices, every version</button></p>` : ""}
      ${older.length ? `<p><button type="button" class="primary" data-app="${ai}" data-below="1">List ${olderDevices.toLocaleString()} devices below ${esc(below)}</button></p>` : ""}
    </article>`;
  }).join("");
}

onEnterOrClear($("#appver-below"), () => { if (appverApps.length) drawAppVersions(); });

$("#appver-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-app]");
  if (!btn) return;
  const app = appverApps[Number(btn.dataset.app)];
  const below = $("#appver-below").value.trim();
  const picked = btn.dataset.all ? app.versions : btn.dataset.below ? app.versions.filter((v) => isBelowVersion(v.version, below)) : [app.versions[Number(btn.dataset.ver)]];
  $("#appver-tools").hidden = true;
  runInto($("#appver-devices"), appverRun, "Reading the devices...", async (current) => {
    const res = await send("apps/devices", { items: picked.map((v) => ({ id: v.id, version: v.version })) });
    if (!current()) return;
    // Graph may leave out primary user and check-in here, or send an empty date (0001-01-01): only then wait
    // for the whole device list to fill them.
    const known = !res.devices.some((d) => !(Date.parse(d.lastSync) > 864e5)) ? new Map() : await loadDevices().then((r) => new Map(r.devices.map((x) => [String(x.managedId).toLowerCase(), x]))).catch(() => new Map());
    if (!current()) return;
    const devices = await scoped(res.devices);
    if (!current()) return;
    for (const d of devices) {
      const full = known.get(String(d.managedId).toLowerCase());
      if (full) Object.assign(d, { upn: full.upn, displayName: full.displayName, lastSync: full.lastSync, compliance: full.compliance });
    }
    appverRows = [["Device", "Primary user", "UPN", "OS", "OS version", "Compliance", "Last check-in", "App", "App version"],
      ...devices.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.compliance, d.lastSync, app.name, d.appVersion])];
    $("#appver-tools").hidden = !devices.length;
    const count = scopeNote() ? `${devices.length.toLocaleString()} of ${res.devices.length.toLocaleString()} devices${scopeNote()}.` : `${devices.length.toLocaleString()} devices.`;
    return (res.failed ? `<p class="muted small">${res.failed} version${res.failed === 1 ? "" : "s"} couldn't be read.</p>` : "") + (devices.length
      ? `<p class="muted small">${count}</p>` + capped(devices, (rows) => tableHtml(["Device", "Primary user", "OS", "Last check-in", "App version"], rows.map((d) => [
        td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)), td(esc(d.appVersion), "mono"),
      ])))
      : emptyBox(`No device${scopeNote()} reported for that selection.`));
  });
});
bindExport("appver", () => appverRows, () => "app-versions.csv");

// ------------------------------------------------------------------------------------------
// Cleanup report

let cleanup = null;

$("#cleanup-run").addEventListener("click", oneAtATime($("#cleanup-run"), async () => {
  const out = $("#cleanup-results");
  showExport("cleanup", false);
  out.innerHTML = loading("Reading your policies and checking every group they use...");
  try {
    const res = await send("cleanup/report");
    cleanup = res.report;
    if (res.policies) renderIndexLine(res.policies);
    out.innerHTML = renderCleanup(cleanup);
    showExport("cleanup", true);
  } catch (err) {
    out.innerHTML = errorBox(err);
  } finally {
    $("#cleanup-run").textContent = "Run again";
  }
}));

function renderCleanup(r) {
  const s = r.summary;
  const target = (f) => (f.kind === "exclude" ? '<span class="badge warn">Exclude</span>'
    : `<span class="badge">${f.kind === "allDevices" ? "All devices" : f.kind === "allUsers" ? "All users" : "Include"}</span>${f.intent ? ` <span class="muted small">${esc(f.intent)}</span>` : ""}`);
  const section = (title, note, list, headers, row, { count = String(list.length), rowAttrs } = {}) => `<article class="card">
      <h2>${esc(title)} <span class="muted">· ${esc(count)}</span></h2>
      <p class="muted small" style="margin:2px 0 8px">${esc(note)}</p>
      ${list.length ? tableHtml(headers, list.map(row), rowAttrs) : '<p class="muted">None found.</p>'}
    </article>`;
  // Empty groups: includes (the problem, and what the tile counts) first; harmless excludes greyed out after.
  const emptyGroup = [...r.emptyGroup].sort((a, b) => Number(a.kind === "exclude") - Number(b.kind === "exclude"));
  const emptyExcludes = emptyGroup.length - s.emptyGroup;
  return `<div class="tiles">
      ${tile(s.deletedGroup, "assignments to deleted groups", s.deletedGroup ? "bad" : "ok")}
      ${tile(s.emptyGroup, "assigned to empty groups", s.emptyGroup ? "warn" : "ok")}
      ${tile(s.mixedGroup, "groups with devices and users", s.mixedGroup ? "warn" : "ok")}
      ${tile(s.excludeOnly, "exclude-only (target nobody)", s.excludeOnly ? "warn" : "ok")}
      ${tile(s.unassigned, "not assigned", s.unassigned ? "warn" : "ok")}
      ${s.filtersUnchecked ? "" : tile(s.deletedFilter, "assignments with deleted filters", s.deletedFilter ? "bad" : "ok")}
      ${s.filtersUnchecked ? "" : tile(s.unusedFilter, "unused filters", s.unusedFilter ? "warn" : "ok")}
    </div>
    <p class="muted small">Checked ${s.policies} policies, profiles, scripts and apps, and ${s.groups} groups they use.${s.unchecked ? ` ${s.unchecked} couldn't be checked: Graph wouldn't return their assignments.` : ""}${s.groupsUnchecked ? ` ${s.groupsUnchecked} group${s.groupsUnchecked === 1 ? "" : "s"} couldn't be sized (Graph was busy), so some empty groups may be missing. Run Cleanup again.` : ""}${s.filtersUnchecked ? " Assignment filters couldn't be read, so filters aren't checked." : ` Checked ${s.filters} assignment filter${s.filters === 1 ? "" : "s"}.`}</p>
    ${section("Assigned to deleted groups", "The group no longer exists, so this assignment does nothing. Safe to remove from the policy.", r.deletedGroup,
      ["Name", "Type", "Missing group ID", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(esc(f.groupId), "mono"), td(target(f))])}
    ${section("Assigned to empty groups", "The group has no members (including nested). An include reaches nobody; an exclude is harmless.", emptyGroup,
      ["Name", "Type", "Group", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(link(f.groupLink, f.groupName)), td(target(f))],
      { count: `${s.emptyGroup} include${s.emptyGroup === 1 ? "" : "s"}${emptyExcludes ? ` + ${emptyExcludes} harmless exclude${emptyExcludes === 1 ? "" : "s"}` : ""}`,
        rowAttrs: (i) => (emptyGroup[i].kind === "exclude" ? 'class="older"' : "") })}
    ${section("Groups with devices and users", "An assigned group holding both devices and users, counting nested groups. Most groups should hold one kind, so a mix is often a mistake: a user in a device group, or a device in a user group.", r.mixedGroup,
      ["Group", { label: "Devices", num: true }, { label: "Users", num: true }, { label: "Assignments", num: true }],
      (f) => [td(link(f.groupLink, f.groupName)), td(f.devices.toLocaleString(), "num"), td(f.users.toLocaleString(), "num"), td(String(f.uses), "num")])}
    ${section("Exclude-only", "Only exclusions, no includes, so it targets nobody.", r.excludeOnly,
      ["Name", "Type", { label: "Exclusions", num: true }], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(String(f.count), "num")])}
    ${section("Not assigned", "No assignments at all. Unassigned apps aren't listed (the app catalogue includes many built-in apps).", r.unassigned,
      ["Name", "Type"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel))])}
    ${s.filtersUnchecked ? "" : `${section("Assigned with deleted filters", "The assignment names a filter that no longer exists. Check the assignment in the policy and pick a filter again.", r.deletedFilter,
      ["Name", "Type", "Missing filter ID", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(esc(f.filterId), "mono"), td(target(f))])}
    ${section("Unused filters", "No assignment uses this filter. Safe to delete if nobody plans to use it.", r.unusedFilter,
      ["Filter", "Platform", "Rule"], (f) => [td(esc(f.name)), td(esc(platformName(f.platform))), td(esc(f.rule), "mono small")])}
    ${section("Filters in use", "Every assignment filter and what uses it: includes means only matching devices get it, excludes means matching devices don't.", r.filterUse.filter((f) => f.uses.length),
      ["Filter", "Platform", "Rule", "Used by"], (f) => [td(esc(f.name)), td(esc(platformName(f.platform))), td(esc(f.rule), "mono small"),
        td(f.uses.map((u) => `${link(u.link, u.policyName)} <span class="muted small">${u.mode === "exclude" ? "excludes" : "includes"}</span>`).join("<br>"))])}`}`;
}

function cleanupRows() {
  if (!cleanup) return null;
  const rows = [["Finding", "Name", "Type", "Group", "Group ID", "Target", "Filter", "Filter ID"]];
  for (const f of cleanup.deletedGroup) rows.push(["Assigned to deleted group", f.policyName, f.typeLabel, "", f.groupId, f.kind]);
  for (const f of cleanup.emptyGroup) rows.push(["Assigned to empty group", f.policyName, f.typeLabel, f.groupName, f.groupId, f.kind]);
  for (const f of cleanup.mixedGroup) rows.push(["Group with devices and users", "", "", f.groupName, f.groupId, `${f.devices} devices, ${f.users} users`]);
  for (const f of cleanup.excludeOnly) rows.push(["Exclude-only", f.policyName, f.typeLabel, "", "", `${f.count} exclusions`]);
  for (const f of cleanup.unassigned) rows.push(["Not assigned", f.policyName, f.typeLabel, "", "", ""]);
  for (const f of cleanup.deletedFilter || []) rows.push(["Assigned with deleted filter", f.policyName, f.typeLabel, "", f.groupId, f.kind, "", f.filterId]);
  for (const f of cleanup.unusedFilter || []) rows.push(["Unused filter", "", "", "", "", "", f.name, f.filterId]);
  for (const f of cleanup.filterUse || []) for (const u of f.uses) rows.push([`Filter ${u.mode === "exclude" ? "excludes" : "includes"}`, u.policyName, u.typeLabel, "", u.groupId, u.kind, f.name, f.filterId]);
  return rows;
}
bindExport("cleanup", cleanupRows, () => "intune-cleanup.csv");

// What each of these tabs does when it opens (selectTab in core.js calls it).
registerTab("changes", () => { if (shown && !changes) showChanges(); }); // results on screen from before a policy refresh
registerTab("baseline", () => { baselineData().catch((err) => { $("#bl-results").innerHTML = errorBox(err); }); }); // the baselines load on first use
