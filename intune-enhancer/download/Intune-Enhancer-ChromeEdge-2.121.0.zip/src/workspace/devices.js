// Device tools: the device list tabs (OS builds, Device explorer, Stale and duplicates, Low storage), Orphaned users,
// Compliance (with its failing devices), Hardware and Security posture. Moved out of workspace.js without changes to
// the code (see docs/workspace-split-plan.md).

import { osSpread, updateCheck, staleDevices, lowStorageDevices, duplicateDevices } from "../core/device-reports.js";
import { searchWords, hasAllWords } from "../core/format.js";
import { hardwareColumns, POSTURE_FIELDS } from "../core/hardware.js";
import { postureIssues, postureCounts } from "../core/security-posture.js";
import { EXPLORER_FIELDS, EXPLORER_DEFAULT, explorerRow } from "../core/device-explorer.js";
import { ageBucket, AGE_BUCKETS } from "../core/chip-filter.js";
import { $, $$, SAMPLE, ago, appState, badgeCounts, bindExport, capped, checkInCell, chipBar, complianceBadge, copyTsv, emptyBox, errorBox, esc, exportButtons, fillPlatforms, friendlyOs, jobBar, link, loadDevices, loading, newestOnly, nextSort, onEnterOrClear, oneAtATime, ownerLabel, registerTab, runInto, saveCsv, savePrefs, scopeIds, scopeNote, scoped, send, showBanner, showExport, sortHead, sortRows, tableHtml, tableWrap, td, userOf } from "./core.js";

// ------------------------------------------------------------------------------------------
// Device list (shared by OS builds and Stale & duplicates), loaded once per visit

function renderDeviceIndexLine() {
  for (const el of $$(".device-index-line")) {
    el.innerHTML = appState.devicesCache
      ? `Device list: ${appState.devicesCache.devices.length.toLocaleString()}${appState.scope ? ` of ${appState.devicesCache.total.toLocaleString()}` : ""} devices${appState.scope ? ` (scope: ${esc(appState.scope.name)})` : ""}, updated ${esc(ago(appState.devicesCache.builtAt))}. <button class="link" data-refresh-devices>Refresh</button>`
      : "";
  }
}

document.addEventListener("click", async (e) => {
  if (!e.target.closest?.("[data-refresh-devices]")) return;
  for (const el of $$(".device-index-line")) el.innerHTML = '<span class="spinner"></span>Reading devices...';
  try {
    if (!SAMPLE) await send("index/rebuild");
    await loadDevices(true);
    showDeviceTab(appState.currentTab);
  } catch (err) {
    for (const el of $$(".device-index-line")) el.textContent = err.message;
  }
});

/** The tools drawn from the device list (devices/list), redrawn when it is refreshed or the scope changes. */
export const DEVICE_TABS = ["os", "hygiene", "storage", "explorer"];

// What each tool does when its tab opens (selectTab in core.js calls it); returning true skips focusing the first field.
registerTab(DEVICE_TABS, (name) => { showDeviceTab(name); return true; }); // the device report tabs load the device list the first time they're shown
registerTab("orphans", () => { if (!orphans) runOrphans(); return true; });
registerTab(["hardware", "posture"], (name) => { if (!appState.hwData) loadSavedHardware(); else if (name === "posture") renderPosture(); return true; });

export async function showDeviceTab(name) {
  const out = $(name === "os" ? "#os-results" : name === "storage" ? "#storage-results" : name === "explorer" ? "#explorer-results" : "#stale-results");
  if (!appState.devicesCache) {
    out.innerHTML = loading("Reading your devices...");
    if (name === "hygiene") $("#dupe-results").innerHTML = "";
  }
  try {
    await loadDevices();
  } catch (err) {
    out.innerHTML = errorBox(err);
    return;
  }
  renderDeviceIndexLine();
  if (name === "os") renderOs();
  else if (name === "storage") renderStorage();
  else if (name === "explorer") renderExplorer();
  else renderHygiene();
}

// Device explorer: every device in the device list, with the columns the admin picks (saved as explorerColumns).

let exSort = { key: "name", dir: 1 };
let exColumns = EXPLORER_DEFAULT;

/** Take the column choice from the saved prefs. */
export function applyExplorerColumns(prefs) {
  exColumns = Array.isArray(prefs.explorerColumns) && prefs.explorerColumns.length ? prefs.explorerColumns : EXPLORER_DEFAULT;
  if (appState.currentTab === "explorer" && appState.devicesCache) renderExplorer();
}

// Pills over the explorer's rows (explorerRow text), picked and counted by chipBar.
const exChips = chipBar([
  { key: "os", label: "Platform", value: (r) => r.os },
  { key: "compliance", label: "Compliance", value: (r) => r.compliance },
  { key: "owner", label: "Ownership", value: (r) => r.owner },
  { key: "seen", label: "Last check-in", value: (r) => ageBucket(r.lastSync), order: AGE_BUCKETS },
], () => renderExplorer());

/** Pills for a list of devices from the device list (Low storage, Stale devices): compliance, ownership and last check-in, read with the explorer's own field getters. */
const deviceChips = (onChange) => chipBar([
  { key: "compliance", label: "Compliance", value: EXPLORER_FIELDS.find((f) => f.key === "compliance").get },
  { key: "owner", label: "Ownership", value: EXPLORER_FIELDS.find((f) => f.key === "owner").get },
  { key: "seen", label: "Last check-in", value: (d) => ageBucket(d.lastSync), order: AGE_BUCKETS },
], onChange);

/** The explorer's columns (only fields some device has), its matching rows in sort order, and every row. */
function exView() {
  const all = appState.devicesCache.devices.map((d) => explorerRow(d, globalThis.IEWindowsBuilds?.friendly));
  const present = hardwareColumns(all, EXPLORER_FIELDS);
  const cols = present.filter((f) => f.key === "name" || exColumns.includes(f.key));
  const words = searchWords($("#ex-filter").value);
  const searched = all.filter((r) => hasAllWords(cols.map((c) => r[c.key]).join("\n"), words));
  const rows = sortRows(searched.filter(exChips.test), cols, exSort, (r, key) => r[key]);
  return { all, searched, present, cols, rows };
}

function renderExplorer() {
  const { all, searched, present, cols, rows } = exView();
  $("#ex-cols").innerHTML = present.map((f) => `<label class="inline"><input type="checkbox" data-ex-col="${esc(f.key)}"${cols.includes(f) ? " checked" : ""}${f.key === "name" ? " disabled" : ""}> ${esc(f.label)}</label>`).join("");
  $("#ex-chips").innerHTML = exChips.html(searched);
  $("#ex-count").textContent = `${rows.length.toLocaleString()} of ${all.length.toLocaleString()} devices`;
  showExport("explorer", rows.length > 0);
  $("#explorer-results").innerHTML = rows.length
    ? capped(rows, (shown) => tableWrap(sortHead(cols, exSort, "data-ex-sort"), shown.map((r) => `<tr>${cols.map((c) => td(c.key === "name" ? link(r.link, r.name) : esc(r[c.key] ?? ""),
      c.num ? "num" : c.nowrap ? "nowrap" : "")).join("")}</tr>`).join("")), 2000)
    : emptyBox("No device matches the filter.");
}

onEnterOrClear($("#ex-filter"), renderExplorer);
$("#ex-chips").addEventListener("click", (e) => exChips.handle(e));
$("#ex-cols").addEventListener("change", () => {
  exColumns = $$("[data-ex-col]:checked", $("#ex-cols")).map((el) => el.dataset.exCol);
  savePrefs({ explorerColumns: exColumns }).catch((e) => showBanner(`Couldn't save the columns: ${e.message}`));
  renderExplorer();
});
$("#explorer-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-ex-sort]");
  if (th) { exSort = nextSort(exSort, th.dataset.exSort); renderExplorer(); }
});
bindExport("explorer", () => {
  const { cols, rows } = exView();
  return [cols.map((c) => c.label), ...rows.map((r) => cols.map((c) => r[c.key] ?? ""))];
}, () => "devices.csv");

// ------------------------------------------------------------------------------------------
// OS builds

let spread = null;

/** A table cell with a bar `value` / `max` long, and `title` on hover (OS builds, Update check). */
const barCell = (value, max, title) => td(`<div class="bar" title="${esc(title)}"><span style="width:${max ? (value / max * 100).toFixed(1) : 0}%"></span></div>`);

/** Opens or closes the hidden row under a Show button, filling it with fill() the first time it opens. labels: [closed, open]. */
function toggleSubRow(btn, row, fill, [closed, open]) {
  row.hidden = !row.hidden;
  btn.textContent = row.hidden ? closed : open;
  if (!row.hidden && !row.firstElementChild.innerHTML) row.firstElementChild.innerHTML = fill();
}

/** The devices under an OS builds or Update check row: the first 1,000, and a note when there are more. */
const releaseDeviceTable = (list) => tableHtml(["Device", "Primary user", "OS version", "Compliance", "Last check-in"], list.slice(0, 1000).map((d) => [
  td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
  td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)),
])) + (list.length > 1000 ? `<p class="muted small" style="margin:6px 10px">Showing 1,000 of ${list.length}. Copy or save includes all.</p>` : "");

function renderOs() {
  spread = osSpread(appState.devicesCache.devices, globalThis.IEWindowsBuilds?.friendly);
  if (upd && upd.list !== appState.devicesCache) { upd = null; $("#upd-results").innerHTML = ""; } // a refreshed list or a new scope
  if (!spread.total) { $("#os-results").innerHTML = emptyBox("No managed devices."); return; }
  $("#os-results").innerHTML = spread.platforms.map((p, pi) => {
    const top = Math.max(...p.releases.map((r) => r.count));
    const rows = p.releases.flatMap((r, ri) => [
      [
        td(esc(r.label)),
        td(r.count.toLocaleString(), "num"),
        td(`${(r.count / p.count * 100).toFixed(r.count / p.count < 0.1 ? 1 : 0)}%`, "num"),
        barCell(r.count, top, `${r.count} of ${p.count} ${p.os} devices`),
        td(`<button class="link" data-os="${pi}:${ri}">Show devices</button>`),
      ],
      [`<td colspan="5" data-os-sub="${pi}:${ri}"></td>`],
    ]);
    return `<article class="card">
      <h2>${esc(p.os)} <span class="muted">· ${p.count.toLocaleString()} device${p.count === 1 ? "" : "s"} (${(p.count / spread.total * 100).toFixed(0)}% of all)</span></h2>
      ${tableHtml(["Release", { label: "Devices", num: true }, { label: "Share", num: true }, "", ""], rows, (i) => (i % 2 ? 'class="sub" hidden' : ""))}
    </article>`;
  }).join("");
}

$("#os-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-os]");
  if (btn) {
    toggleSubRow(btn, $(`[data-os-sub="${btn.dataset.os}"]`).parentElement, () => {
      const [pi, ri] = btn.dataset.os.split(":").map(Number);
      const rel = spread.platforms[pi].releases[ri];
      return `<div class="toolbar" style="margin:8px 10px">
          <strong>${esc(rel.label)}</strong><span class="spacer"></span>
          <button class="export" data-os-copy="${btn.dataset.os}">Copy table</button><button class="export" data-os-csv="${btn.dataset.os}">Save CSV</button></div>` +
        releaseDeviceTable([...rel.devices].sort((a, b) => a.name.localeCompare(b.name)));
    }, ["Show devices", "Hide devices"]);
    return;
  }
  const exp = e.target.closest("button[data-os-copy], button[data-os-csv]");
  if (!exp) return;
  const [pi, ri] = (exp.dataset.osCopy || exp.dataset.osCsv).split(":").map(Number);
  const rel = spread.platforms[pi].releases[ri];
  const rows = [["Device", "Primary user", "UPN", "OS", "OS version", "Release", "Compliance", "Last check-in"],
    ...rel.devices.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, rel.label, d.compliance, d.lastSync])];
  if (exp.dataset.osCopy) copyTsv(exp, rows);
  else saveCsv(`os-build-${rel.label}.csv`, rows);
});

// Update check (OS builds): Windows devices behind the newest build on your devices, or a build typed. Runs on Enter or
// the button, from the device list the tab already reads (no Graph read of its own).
let upd = null; // { list: the devicesCache it was worked out from, result: updateCheck() }

$("#upd-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const out = $("#upd-results");
  try {
    if (!appState.devicesCache) out.innerHTML = loading("Reading your devices...");
    await loadDevices();
  } catch (err) { out.innerHTML = errorBox(err); return; }
  const result = updateCheck(appState.devicesCache.devices, globalThis.IEWindowsBuilds?.friendly, $("#upd-build").value);
  upd = result.error ? null : { list: appState.devicesCache, result };
  out.innerHTML = result.error ? emptyBox(result.error) : renderUpdateCheck(result);
});

/** The Update check card: one row per Windows release, with its behind devices under a Show behind row. */
function renderUpdateCheck(r) {
  if (!r.releases.length) {
    return emptyBox(r.target ? `No Windows device in the device list is on build ${r.target.split(".")[0]}.` : "No Windows device in the device list reports a build.");
  }
  const rows = r.releases.flatMap((rel, i) => {
    const total = rel.have + rel.behind.length;
    return [[
      td(esc(rel.label)), td(esc(rel.build)), td(rel.have.toLocaleString(), "num"),
      td(`<span class="badge ${rel.behind.length ? "bad" : "ok"}">${rel.behind.length.toLocaleString()}</span>`, "num"),
      barCell(rel.have, total, `${rel.have} of ${total} up to date`),
      td(rel.behind.length ? `<button class="link" data-upd="${i}">Show behind</button>` : ""),
    ], [`<td colspan="6" data-upd-sub="${i}"></td>`]];
  });
  const unknown = r.releases.reduce((n, rel) => n + rel.unknown, 0);
  const notes = [
    r.target ? "" : "Each release is checked against the newest build any of your devices on it reports, which may be an optional preview update. Type a build to check against a specific one (Microsoft's Windows release information page lists the build for each update).",
    r.others.length ? `Not checked against this build: ${r.others.map((o) => `${o.label} (${o.count})`).join(", ")}. Each release has its own build numbers.` : "",
    unknown ? `${unknown} device${unknown === 1 ? "" : "s"} reported no build revision and ${unknown === 1 ? "is" : "are"} left out.` : "",
    "Every monthly Windows update raises the build, so a device below it is missing that update or a later one. Other updates (.NET, Office) don't change the build.",
  ].filter(Boolean);
  return `<article class="card">
    <div class="toolbar tight"><h2 style="margin:0">Update check</h2>
      <span class="muted">${r.target ? `against build ${esc(r.target)}` : "against the newest build on your devices, per release"}</span>
      <span class="spacer"></span>${exportButtons("upd")}</div>
    ${tableHtml(["Release", "Checked against", { label: "Up to date", num: true }, { label: "Behind", num: true }, "", ""], rows, (i) => (i % 2 ? 'class="sub" hidden' : ""))}
    ${notes.map((n) => `<p class="muted small" style="margin:8px 0 0">${esc(n)}</p>`).join("")}
  </article>`;
}

$("#upd-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-upd]");
  if (!btn || !upd) return;
  toggleSubRow(btn, $(`[data-upd-sub="${btn.dataset.upd}"]`).parentElement,
    () => releaseDeviceTable(upd.result.releases[Number(btn.dataset.upd)].behind), ["Show behind", "Hide"]);
});

// Update check's Copy table and Save CSV: every Windows device checked, with whether it is up to date.
bindExport("upd", () => upd && [["Device", "Primary user", "UPN", "Release", "OS version", "Checked against", "Status", "Compliance", "Last check-in"],
  ...upd.result.releases.flatMap((rel) => {
    const behind = new Set(rel.behind);
    return rel.devices.map((d) => [d.name, d.displayName, d.upn, rel.label, d.osVersion, rel.build, behind.has(d) ? "Behind" : "Up to date", d.compliance, d.lastSync]);
  })], () => `update-check${upd?.result.target ? `-${upd.result.target}` : ""}.csv`);

// ------------------------------------------------------------------------------------------
// Compliance breakdown

let compData = null;
const compRun = newestOnly();

function renderCompliance(r) {
  if (!r.rows.length) return emptyBox(`No compliance setting is failing on any device${r.passing ? ` (${r.passing.toLocaleString()} settings checked)` : ""}.`);
  return `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${r.rows.length.toLocaleString()} failing setting${r.rows.length === 1 ? "" : "s"}; ${r.passing.toLocaleString()} with no failures</span>
      <span class="spacer"></span>
      ${exportButtons("comp")}
    </div>` +
    tableHtml(["Setting", "Platform", { label: "Failing", num: true }, { label: "Not compliant", num: true }, { label: "Error", num: true }, { label: "Conflict", num: true }, { label: "Compliant", num: true }, ""],
      r.rows.map((x) => [td(esc(x.setting)), td(esc(x.platform)), td(`<strong>${x.failing.toLocaleString()}</strong>`, "num"), td(x.nonCompliant.toLocaleString(), "num"),
        td(x.error.toLocaleString(), "num"), td(x.conflict.toLocaleString(), "num"), td(x.compliant.toLocaleString(), "num"),
        td(`<button class="link" data-comp="${esc(x.id)}" data-name="${esc(x.setting)}">Devices</button>`)])) + "</article>";
}

function compRows() {
  return [["Setting", "Platform", "Failing", "Not compliant", "Error", "Conflict", "Compliant"],
    ...(compData?.rows || []).map((x) => [x.setting, x.platform, x.failing, x.nonCompliant, x.error, x.conflict, x.compliant])];
}

// Pills over the devices failing one compliance setting; a new setting starts with none picked.
const compChips = chipBar([
  { key: "state", label: "State", value: (d) => d.state },
  { key: "os", label: "Platform", value: (d) => d.os },
  { key: "seen", label: "Last check-in", value: (d) => ageBucket(d.lastSync), order: AGE_BUCKETS },
], () => { $("#comp-devices").innerHTML = renderCompDevices(appState.compDevices.name, appState.compDevices.list); });
const compShown = () => (appState.compDevices?.list || []).filter(compChips.test);

function compDeviceRows() {
  return [["Device", "User", "UPN", "State", "OS", "Last check-in"], ...compShown().map((d) => [d.name, d.user, d.upn || "", d.state, d.os, d.lastSync])];
}

function renderCompDevices(name, all) {
  const list = all.filter(compChips.test);
  return `<article class="card">
    <div class="toolbar tight">
      <h2>${esc(name)}: ${list.length.toLocaleString()} failing device${list.length === 1 ? "" : "s"}${esc(scopeNote())}</h2>
      <span class="spacer"></span>
      ${exportButtons("compdev")}
    </div>${compChips.html(all)}` + (list.length
      ? capped(list, (rows) => tableHtml(["Device", "User", "State", "OS", "Last check-in"], rows.map((d) => [td(d.inList ? link(d.link, d.name) : esc(d.name), "nowrap"), td(esc(d.user)), td(esc(d.state)), td(esc(d.os)), td(d.lastSync ? checkInCell(d.lastSync) : '<span class="muted">unknown</span>')])))
      : '<p class="muted">No device is failing this setting now.</p>') + "</article>";
}

$("#comp-run").addEventListener("click", () => {
  $("#comp-devices").innerHTML = "";
  runInto($("#comp-results"), compRun, "Reading compliance results...", async (current) => {
    const r = await send("compliance/summary");
    if (!current()) return;
    compData = r;
    return renderCompliance(r);
  });
});
$("#comp-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-comp]");
  if (!pick) return;
  const out = $("#comp-devices");
  runInto(out, compRun, "Reading the devices failing this setting...", async (current) => {
    const { devices: all } = await send("compliance/devices", { id: pick.dataset.comp });
    const devices = await scoped(all); // a device not in the device list has no Intune id, so a scope leaves it out
    if (!current()) return;
    compChips.reset();
    appState.compDevices = { name: pick.dataset.name, list: devices };
    out.innerHTML = renderCompDevices(appState.compDevices.name, devices);
    out.scrollIntoView({ behavior: "smooth", block: "nearest" });
  });
});
$("#comp-devices").addEventListener("click", (e) => compChips.handle(e));
bindExport("comp", () => compRows(), () => "compliance-breakdown.csv");
bindExport("compdev", () => compDeviceRows(), () => "compliance-failing-devices.csv");

// Hardware report

const HW_CHUNK = 100; // devices per request to the worker, so progress and Stop respond between chunks
const HW_SHOWN = 1000;
let hwSort = { key: "name", dir: 1 };
let hwStop = false;

/** The Hardware rows inside the header's scope (a saved report may cover more devices). */
export const hwRows = () => (appState.hwData?.rows || []).filter((r) => !appState.scope?.ids || appState.scope.ids.has(r.id));
const hwChips = chipBar([
  { key: "os", label: "Platform", value: (r) => r.os },
  { key: "manufacturer", label: "Manufacturer", value: (r) => r.manufacturer },
  { key: "encrypted", label: "Encrypted", value: (r) => r.encrypted },
], () => renderHardware());
/** The Hardware rows the pills let through (what the table, Copy table and CSV hold). */
const hwShown = () => hwRows().filter(hwChips.test);
export function renderHardware() {
  const out = $("#hw-results");
  const all = hwRows();
  if (!all.length) { out.innerHTML = emptyBox(appState.hwData?.rows.length ? "No device in the scope group is in this report. Run it again." : "Nothing read yet."); return; }
  const rows = hwShown();
  const cols = hardwareColumns(all);
  const sorted = sortRows(rows, cols, hwSort, (r, key) => r[key]);
  const head = sortHead(cols, hwSort, "data-hw-sort");
  out.innerHTML = `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${rows.length.toLocaleString()} of ${all.length.toLocaleString()} devices, read ${esc(ago(appState.hwData.at))}. Click a heading to sort.</span>
      <span class="spacer"></span>
      ${exportButtons("hw")}
    </div>
    ${hwChips.html(all)}
    ${rows.length ? capped(sorted, (rows) => tableWrap(head, rows.map((r) => `<tr>${cols.map((c) => td(esc(r[c.key] ?? ""), c.num ? "num" : c.nowrap ? "nowrap" : "")).join("")}</tr>`).join("")), HW_SHOWN) : emptyBox("No device matches the filters.")}
  </article>`;
}

function hwTableRows() {
  const cols = hardwareColumns(hwRows());
  return [cols.map((c) => c.label), ...sortRows(hwShown(), cols, hwSort, (r, key) => r[key]).map((r) => cols.map((c) => r[c.key] ?? ""))];
}

export const runHardware = oneAtATime([$("#hw-run"), $("#posture-run")], async () => {
  hwStop = false;
  const out = $("#hw-results");
  out.innerHTML = loading("Reading your devices...");
  $("#posture-results").innerHTML = loading("Reading every device's record. Stop keeps what is read so far.");
  const rows = [];
  let failed = 0;
  try {
    await loadDevices();
    const ids = [...new Set(appState.devicesCache.devices.map((d) => d.managedId).filter(Boolean))];
    for (let i = 0; i < ids.length && !hwStop; i += HW_CHUNK) {
      jobBar.set("hardware", { label: "Reading hardware", done: i, total: ids.length, stop: () => { hwStop = true; } });
      out.innerHTML = loading("Reading hardware for every device. Stop keeps what is read so far.");
      const res = await send("hardware/read", { ids: ids.slice(i, i + HW_CHUNK) });
      rows.push(...res.rows);
      failed += res.failed;
    }
    appState.hwData = { at: Date.now(), rows };
    // Only a finished run replaces the saved report: a stopped one is shown but not saved, so a long earlier run isn't lost.
    if (!hwStop) await send("hardware/save", { rows });
    jobBar.done("hardware", hwStop ? `Stopped. Showing ${rows.length.toLocaleString()} of ${ids.length.toLocaleString()} devices; the saved report is unchanged.` : "");
    renderHardware();
    renderPosture();
    if (failed) out.insertAdjacentHTML("afterbegin", `<p class="muted small">${failed.toLocaleString()} devices couldn't be read and are left out.</p>`);
    if (hwStop) out.insertAdjacentHTML("afterbegin", '<p class="muted small">Stopped early: this is a partial list.</p>');
  } catch (err) {
    out.innerHTML = errorBox(err);
    jobBar.done("hardware"); // on success the try ended the job, with its "Stopped. Kept ..." message when stopped
    $("#posture-results").innerHTML = errorBox(err);
  }
});

async function loadSavedHardware() {
  try {
    const { saved } = await send("hardware/load");
    if (saved && !runHardware.busy()) {
      appState.hwData = saved;
      if (appState.scope) await scopeIds().catch(() => {}); // filter the saved report to the scope
      renderHardware();
      renderPosture();
    }
  } catch { /* nothing saved, or no session yet: the button still works */ }
}

$("#hw-run").addEventListener("click", runHardware);
$("#posture-run").addEventListener("click", runHardware);
$("#job-stop").addEventListener("click", () => jobBar.stop());
$("#hw-results").addEventListener("click", (e) => {
  if (hwChips.handle(e)) return;
  const th = e.target.closest("th[data-hw-sort]");
  if (th) {
    hwSort = { key: th.dataset.hwSort, dir: hwSort.key === th.dataset.hwSort ? -hwSort.dir : 1 };
    renderHardware();
    return;
  }
});
bindExport("hw", () => hwTableRows(), () => "hardware.csv");

// Security posture: the Hardware report's security columns (one read serves both tabs), what needs attention, counts.

let posSort = { key: "issues", dir: -1 };
const POSTURE_COUNT_BADGES = { pass: ["ok", "Pass"], fail: ["bad", "Fail"], unknown: ["", "Not reported"] };

/**
 * Windows and macOS rows of the Hardware report (in the scope), each with its issues. allCols: every posture column some
 * device has (Copy table, CSV); cols: those without the detail ones, with Needs attention after the user (the screen).
 */
const posChips = chipBar([
  { key: "os", label: "Platform", value: (r) => r.os },
  { key: "issue", label: "Needs attention for", value: (r) => r.issueList },
], () => renderPosture());
function posView() {
  const rows = hwRows().filter((r) => /windows|mac/i.test(r.os || "")).map((r) => { const issueList = postureIssues(r); return { ...r, issueList, issues: issueList.join("; ") }; });
  const present = hardwareColumns(rows, POSTURE_FIELDS);
  const issues = { key: "issues", label: "Needs attention" };
  const lead = present.filter((c) => c.key === "name" || c.key === "user");
  const cols = [...lead, issues, ...present.filter((c) => !c.detail && !lead.includes(c))];
  const allCols = [...lead, issues, ...present.filter((c) => !lead.includes(c))];
  const base = $("#posture-show")?.value === "all" ? rows : rows.filter((r) => r.issues);
  return { rows, base, cols, allCols, shown: sortRows(base.filter(posChips.test), allCols, posSort, (r, key) => r[key]) };
}

function renderPosture() {
  const out = $("#posture-results");
  if (!appState.hwData) { out.innerHTML = emptyBox("Nothing read yet. Read every device, or run the Hardware report: both use the same read."); return; }
  const { rows, base, cols, shown } = posView();
  if (!rows.length) { out.innerHTML = emptyBox("No Windows or macOS device is in this report."); return; }
  const c = postureCounts(rows);
  const old = !rows.some((r) => "credGuard" in r);
  const keep = $("#posture-show")?.value || "attention";
  out.innerHTML = `<article class="card">
      <p><strong>${c.withIssues.toLocaleString()}</strong> of ${c.devices.toLocaleString()} Windows and macOS devices need attention. Read ${esc(ago(appState.hwData.at))}.</p>
      ${old ? '<p class="warn small">This saved report is from before Security posture: read again to add the security details.</p>' : ""}
      ${tableHtml(["Check", "Devices"], c.checks.map((k) => [td(esc(k.label), "nowrap"), td(badgeCounts(POSTURE_COUNT_BADGES, k))]))}
      <div class="toolbar">
        <label>Show <select id="posture-show"><option value="attention">Needs attention</option><option value="all">All</option></select></label>
        <span class="muted small">${shown.length.toLocaleString()} shown</span>
        <span class="spacer"></span>
        ${exportButtons("posture")}
      </div>
      ${posChips.html(base)}
      ${shown.length ? capped(shown, (list) => tableWrap(sortHead(cols, posSort, "data-pos-sort"), list.map((r) => `<tr>${cols.map((col) => td(esc(r[col.key] ?? ""),
        col.nowrap ? "nowrap" : col.key === "issues" && r.issues ? "warn" : "")).join("")}</tr>`).join("")), 1000) : emptyBox("Nothing needs attention.")}
      <p class="muted small">From each device's own record (Device Health Attestation, Device Guard) and Intune's encryption report. Blank means Intune didn't report it, which isn't counted as a problem.</p>
    </article>`;
  $("#posture-show").value = keep;
}

$("#posture-results").addEventListener("input", (e) => { if (e.target.id === "posture-show") renderPosture(); });
$("#posture-results").addEventListener("click", (e) => {
  if (posChips.handle(e)) return;
  const th = e.target.closest("th[data-pos-sort]");
  if (th) { posSort = nextSort(posSort, th.dataset.posSort); renderPosture(); }
});
bindExport("posture", () => {
  const { allCols, shown } = posView();
  return [allCols.map((c) => c.label), ...shown.map((r) => allCols.map((c) => r[c.key] ?? ""))];
}, () => "security-posture.csv");

// ------------------------------------------------------------------------------------------
// Orphaned users

let orphans = null; // last answer: { devices, unknown, checked }

// One scan at a time: it checks every primary user.
const runOrphans = oneAtATime($("#orphans-run"), async () => {
  $("#orphans-results").innerHTML = loading("Checking each primary user...");
  $("#orphans-count").textContent = "";
  showExport("orphans", false);
  try {
    orphans = await send("devices/orphaned");
  } catch (err) {
    orphans = null;
    $("#orphans-results").innerHTML = errorBox(err);
    return;
  }
  renderOrphans();
});

/** Draws the Orphaned users answer, inside the header's scope when one is set (no new lookups when the scope changes). */
export async function renderOrphans() {
  if (!orphans) return;
  let devices;
  try {
    devices = orphans.shown = await scoped(orphans.devices);
  } catch (err) {
    $("#orphans-results").innerHTML = errorBox(err);
    return;
  }
  const { unknown, checked } = orphans;
  showExport("orphans", devices.length > 0);
  $("#orphans-count").textContent = `${devices.length.toLocaleString()} devices${scopeNote()}, from ${checked.toLocaleString()} users checked`
    + (unknown ? `, ${unknown.toLocaleString()} devices couldn't be checked` : "");
  $("#orphans-results").innerHTML = devices.length
    ? capped(devices, (rows) => tableHtml(["Device", "Primary user", "User", "OS", "Last check-in", "Ownership"], rows.map((d) => [
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))),
      td(d.userState === "deleted" ? '<span class="badge bad">Deleted</span>' : '<span class="badge warn">Disabled</span>'),
      td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ])))
    : emptyBox(scopeNote() ? `No device${scopeNote()} has a disabled or deleted primary user.` : "Every primary user is active.");
}

function orphanRows() {
  return [["Device", "Primary user", "UPN", "User", "OS", "OS version", "Last check-in", "Ownership", "Model"],
    ...(orphans?.shown || orphans?.devices || []).map((d) => [d.name, d.displayName, d.upn, d.userState, d.os, d.osVersion, d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#orphans-run").addEventListener("click", runOrphans);
bindExport("orphans", () => orphanRows(), () => "orphaned-users.csv");

// ------------------------------------------------------------------------------------------
// Low storage

let storageList = [];
let storageSort = { key: "free", dir: 1 }; // least free space first
const STORAGE_COLS = [{ key: "name", label: "Device" }, { key: "user", label: "Primary user" }, { key: "os", label: "OS" },
  { key: "free", label: "Free", num: true }, { key: "total", label: "Total", num: true }, { key: "pct", label: "Free %", num: true }, { key: "sync", label: "Last check-in" }];
const storageValue = (d, k) => ({ name: d.name, user: userOf(d), os: friendlyOs(d.os, d.osVersion), free: d.freeGb, total: d.totalGb, pct: d.freeGb / d.totalGb * 100, sync: d.lastSync }[k]);

const storageChips = deviceChips(() => appState.devicesCache && renderStorage());
function renderStorage() {
  const limit = Number($("#storage-gb").value) || 10;
  const sel = $("#storage-os");
  fillPlatforms(sel, appState.devicesCache.platforms);
  const { list, unknown } = lowStorageDevices(appState.devicesCache.devices, limit);
  const byPlatform = list.filter((d) => !sel.value || (d.os || "Unknown OS") === sel.value);
  $("#storage-chips").innerHTML = storageChips.html(byPlatform);
  storageList = sortRows(byPlatform.filter(storageChips.test), STORAGE_COLS, storageSort, storageValue);
  showExport("storage", storageList.length > 0);
  $("#storage-count").textContent = `${storageList.length.toLocaleString()} low` + (unknown ? `, ${unknown.toLocaleString()} report no storage` : "");
  $("#storage-results").innerHTML = storageList.length
    ? capped(storageList, (rows) => tableWrap(sortHead(STORAGE_COLS, storageSort), rows.map((d) => `<tr>${[
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(`${d.freeGb.toFixed(1)} GB`, "num"), td(`${d.totalGb.toFixed(0)} GB`, "num"), td(`${(d.freeGb / d.totalGb * 100).toFixed(0)}%`, "num"),
      td(checkInCell(d.lastSync)),
    ].join("")}</tr>`).join("")))
    : emptyBox(`No device has less than ${limit} GB free.`);
}

function storageRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Free GB", "Total GB", "Free %", "Last check-in", "Ownership", "Model"],
    ...storageList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.freeGb.toFixed(1), d.totalGb.toFixed(0),
      (d.freeGb / d.totalGb * 100).toFixed(0), d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#storage-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-sort]");
  if (th && appState.devicesCache) { storageSort = nextSort(storageSort, th.dataset.sort); renderStorage(); }
});
$("#storage-chips").addEventListener("click", (e) => storageChips.handle(e));
$("#storage-gb").addEventListener("input", () => appState.devicesCache && renderStorage());
$("#storage-os").addEventListener("input", () => appState.devicesCache && renderStorage());
bindExport("storage", () => storageRows(), () => "low-storage.csv");

// ------------------------------------------------------------------------------------------
// Stale & duplicates

let staleList = [];
let dupes = []; // found once per device list; the stale list reads it on every keystroke

function renderHygiene() {
  fillPlatforms($("#stale-os"), appState.devicesCache.platforms);
  dupes = duplicateDevices(appState.devicesCache.devices);
  renderStale();
  renderDupes();
}

const staleChips = deviceChips(() => appState.devicesCache && renderStale());
function renderStale() {
  const days = Number($("#stale-days").value) || 30;
  const os = $("#stale-os").value;
  const byPlatform = staleDevices(appState.devicesCache.devices, days).filter((d) => !os || (d.os || "Unknown OS") === os);
  $("#stale-chips").innerHTML = staleChips.html(byPlatform);
  staleList = byPlatform.filter(staleChips.test);
  // A stale record that has a newer record under the same name is usually a re-imaged device's
  // leftover, not a missing device. Say so.
  const olderRecords = new Set(dupes.flatMap((g) => g.records.filter((r) => !r.current).map((r) => r.managedId)));
  staleList.forEach((d) => { d.olderDuplicate = olderRecords.has(d.managedId); });
  showExport("stale", staleList.length > 0);
  $("#stale-count").textContent = `${staleList.length.toLocaleString()} of ${appState.devicesCache.devices.length.toLocaleString()}`;
  $("#stale-results").innerHTML = staleList.length
    ? capped(staleList, (rows) => tableHtml(["Device", "Primary user", "OS", "Compliance", "Last check-in", "Ownership"], rows.map((d) => [
      td(`${link(d.link, d.name)}${d.olderDuplicate ? ' <span class="badge" title="A newer Intune record has the same name">older duplicate</span>' : ""}`, "nowrap"),
      td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ])))
    : emptyBox(`Every device has checked in within ${days} days.`);
}

$("#stale-chips").addEventListener("click", (e) => staleChips.handle(e));
function staleRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Compliance", "Last check-in", "Days since", "Ownership", "Model", "Older duplicate"],
    ...staleList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.compliance, d.lastSync, d.age ?? "never",
      ownerLabel(d.owner), d.model, d.olderDuplicate ? "yes" : ""])];
}

function renderDupes() {
  const records = dupes.reduce((n, g) => n + g.count, 0);
  showExport("dupe", dupes.length > 0);
  $("#dupe-count").textContent = dupes.length ? `${dupes.length} names, ${records} records` : "";
  if (!dupes.length) { $("#dupe-results").innerHTML = emptyBox("No device name has more than one Intune record."); return; }
  const rows = [];
  const older = [];
  for (const g of dupes) {
    g.records.forEach((d, i) => {
      rows.push([
        td(i === 0 ? `<strong>${esc(g.name)}</strong> <span class="muted">×${g.count}</span>` : "", "nowrap"),
        td(link(d.link, "Open in Intune")),
        td(esc(userOf(d))),
        td(esc(d.enrolled ? new Date(d.enrolled).toLocaleDateString() : "")),
        td(checkInCell(d.lastSync)),
        td(d.current ? '<span class="badge ok">Current</span>' : '<span class="badge">Older record</span>'),
      ]);
      older.push(!d.current);
    });
  }
  $("#dupe-results").innerHTML = tableHtml(["Device name", "Record", "Primary user", "Enrolled", "Last check-in", ""], rows.slice(0, 3000), (i) => (older[i] ? 'class="older"' : ""));
}

function dupeRows() {
  return [["Device name", "Record", "Primary user", "UPN", "Enrolled", "Last check-in", "Days since", "Intune device ID"],
    ...dupes.flatMap((g) => g.records.map((d) => [g.name, d.current ? "Current" : "Older record", d.displayName, d.upn,
      d.enrolled, d.lastSync, d.age ?? "never", d.managedId]))];
}

$("#stale-days").addEventListener("input", () => appState.devicesCache && renderStale());
$("#stale-os").addEventListener("input", () => appState.devicesCache && renderStale());
bindExport("stale", () => staleRows(), () => "stale-devices.csv");
bindExport("dupe", () => dupeRows(), () => "duplicate-devices.csv");
