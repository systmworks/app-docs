// Workspace page: one tab per tool, plus Settings (turning it on, and the in-portal switches).
// All data comes from the service worker (which holds the Graph session). With ?sample=1 (hidden,
// for screenshots, previews and store reviewers), or when
// opened outside the extension, it answers from the fictional tenant in sample.js instead, sending
// nothing anywhere.

import { loadReports } from "./lazy-data.js";
import { PREFS_KEY } from "../core/prefs.js";
import { grantConsent } from "../shared/consent.js";
import { environmentOverview } from "../core/environment-overview.js";
import { docMarkdown, docHtml, docCsvRows, docPercent } from "../core/report-doc.js";
import { deviceUrl, reportUrl, setNewDeviceView, setPortalHost } from "../core/portal-links.js";
import { REPORT_CONFIG, catalogReport, filterReports, sortReports } from "../core/report-list.js";
import { setupRows, createTipCard } from "./setting-rows.js";
import { sheetDate } from "./sheet.js";
import { setupThemePicker } from "./themes.js";
import { dismissable } from "./popup.js";
import { $, $$, DEFAULT_TAB, SAMPLE, TABS, adminCenterLink, ago, appState, bindExport, chipButton, copyText, download, emptyBox, enableBaseline, errorBox, esc, exportButtons, exportDefs, inExtension, jobBar, link, loadDevices, loadPrefs, loading, oneAtATime, registerTab, renderScope, savePrefs, selectTab, send, showBanner, showOffBanner, tableHtml, td, tile } from "./core.js";
import { runErrorLookup, renderGov } from "./tenant.js";
import { setupPicker, runImpact } from "./lookups.js";
import { DEVICE_TABS, showDeviceTab, applyExplorerColumns, hwRows, renderHardware, runHardware, renderOrphans } from "./devices.js";
import { setIndexLines, renderIndexLine } from "./policies.js";

// Top bar: Demo on sample tenant / Leave demo, which reopens this page with or without ?sample=1. Only in the real
// extension: the preview page (opened from disk) is always sample data, so there is nothing to leave.
{
  const demo = $("#demo-toggle");
  demo.hidden = !inExtension;
  demo.classList.toggle("on", SAMPLE);
  if (SAMPLE) {
    $("#demo-text").textContent = "Leave demo";
    demo.title = "Back to your own tenant";
  }
  demo.addEventListener("click", () => {
    const url = new URL(location.href);
    if (SAMPLE) url.searchParams.delete("sample");
    else url.searchParams.set("sample", "1");
    location.assign(url.href);
  });
}

// ------------------------------------------------------------------------------------------
// Session and tabs

async function refreshSession() {
  // A dot on the Settings tab: green when there's a session, red when not; the text is its tooltip.
  const setSession = (text, live, who = "") => { const el = $("#session"); el.title = text; el.className = `session ${live ? "live" : "none"}`; $("#who").textContent = who; };
  try {
    const s = await send("status");
    if (s.portalHost) setPortalHost(s.portalHost);
    appState.turnedOff = !SAMPLE && !s.consented;
    if (SAMPLE) {
      setSession("Sample data (fictional)", true, "Sample data (fictional)");
      showBanner("You're looking at sample data for a fictional tenant. Nothing is read from or sent to any tenant.");
    } else if (!s.consented) {
      setSession("Turned off", false);
      showOffBanner();
    } else if (!s.signedIn) {
      setSession("No Intune session", false);
      showBanner("Sign in to the Intune admin center in another tab. This page uses that session.", adminCenterLink());
    } else {
      setSession(s.upn || "Signed in", true, s.upn || "");
      showBanner("");
    }
    renderIndexLine(s.policies);
    renderSettingsTab(s);
    return s;
  } catch (e) {
    setSession("Extension not reachable", false);
    return null;
  }
}

$$('[role="tab"], .settings-tab').forEach((btn) => btn.addEventListener("click", (e) => { if (!e.target.closest(".star")) selectTab(btn.dataset.tab); }));
// The toolbar icon and the admin center's "turned off" note open #settings, also in an open tab.
// "#impact/<group id>" (from the Used by button in the portal) opens Group assignments for that group.
function openFromHash() {
  const [tab, arg] = location.hash.slice(1).split("/");
  if (!TABS.includes(tab)) return false;
  selectTab(tab);
  if (tab === "errors" && arg) {
    let text = arg;
    try { text = decodeURIComponent(arg); } catch { /* malformed escape: use the raw text */ }
    $("#errors-input").value = text;
    runErrorLookup();
  }
  if (tab === "impact" && /^[0-9a-f-]{36}$/i.test(arg || "")) {
    $('[data-picker="impact"] input').value = arg;
    runImpact({ id: arg });
  }
  return true;
}
window.addEventListener("hashchange", openFromHash);

// ------------------------------------------------------------------------------------------
// All reports: Intune's own reports from data/reports.js (no tenant read). The search box filters on every
// keypress once it has REPORT_CONFIG.minSearchLength letters (the owner's one exception to "search on Enter").

let allReports = null; // loaded on first use (workspace/lazy-data.js)
let reportChip = "All";
const reportCols = 4; // name, star, category, description

// ------------------------------------------------------------------------------------------
// Stars: reports (All reports) and tools (the sidebar) the admin marks, saved in ie.prefs as lists of names
// (starredReports, starredTabs) with starredOnly for the sidebar's "Starred only". Grey outline off, gold on.

const STAR_SVG = '<svg class="star-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.85 5.95 6.55.85-4.8 4.55 1.2 6.5L12 17.35l-5.8 3.1 1.2-6.5-4.8-4.55 6.55-.85z"/></svg>';
const stars = { starredReports: new Set(), starredTabs: new Set(), starredOnly: false };
const starTitle = (on, what) => (on ? "Starred: click to unstar" : `Star this ${what}`);

/** The one star element: a report's button, or a sidebar tool's span (a button can't sit inside the tab button). */
function starHtml(on, tag, what, attrs = "") {
  return `<${tag} class="star${on ? " on" : ""}"${tag === "button" ? ' type="button"' : ""} ${attrs} title="${starTitle(on, what)}">${STAR_SVG}</${tag}>`;
}

/** Take the stars (and the folded sidebar sections) from the saved prefs and redraw what shows them. */
function applyStars(prefs) {
  stars.starredReports = new Set(Array.isArray(prefs.starredReports) ? prefs.starredReports : []);
  stars.starredTabs = new Set(Array.isArray(prefs.starredTabs) ? prefs.starredTabs : []);
  stars.starredOnly = prefs.starredOnly === true;
  folded = new Set(Array.isArray(prefs.collapsedSections) ? prefs.collapsedSections : []);
  renderTabStars();
  renderNavSections();
  if (allReports) renderReports();
}

/** Star or unstar one name in a list pref; shown at once, then saved. */
function toggleStar(key, name) {
  const set = stars[key];
  if (set.has(name)) set.delete(name); else set.add(name);
  savePrefs({ [key]: [...set] }).catch((e) => showBanner(`Couldn't save the star: ${e.message}`));
}

/** The sidebar: each tool's star, and "Starred only" (which hides nothing until at least one tool is starred). */
function renderTabStars() {
  for (const btn of $$('.tabs [role="tab"]')) {
    const on = stars.starredTabs.has(btn.dataset.tab);
    const star = $(".star", btn);
    star.classList.toggle("on", on);
    star.title = starTitle(on, "tool");
  }
  const filter = $("#star-filter");
  filter.setAttribute("aria-pressed", String(stars.starredOnly));
  filter.title = stars.starredTabs.size ? "Show only the starred tools" : "Star a tool (the star beside its name) to use this";
  $(".tabs").classList.toggle("starred-only", stars.starredOnly && stars.starredTabs.size > 0);
}

for (const btn of $$('.tabs [role="tab"]')) {
  btn.insertAdjacentHTML("beforeend", starHtml(false, "span", "tool"));
}
$("#star-filter").insertAdjacentHTML("afterbegin", STAR_SVG);

// Sidebar sections: click a heading (or Enter or Space on it) to fold its tools away. The folded headings are saved in
// ie.prefs as collapsedSections; the open tool stays visible (see workspace.css).
let folded = new Set();
let navSection = "";
for (const el of $(".tabs").children) {
  if (el.classList.contains("tab-head")) { navSection = el.textContent.trim(); el.setAttribute("role", "button"); el.tabIndex = 0; }
  else if (el.matches('[role="tab"]')) el.dataset.section = navSection;
}
function renderNavSections() {
  for (const head of $$(".tabs .tab-head")) head.setAttribute("aria-expanded", String(!folded.has(head.textContent.trim())));
  for (const btn of $$('.tabs [role="tab"]')) btn.classList.toggle("folded", folded.has(btn.dataset.section));
}
function toggleSection(head) {
  const name = head.textContent.trim();
  if (folded.has(name)) folded.delete(name); else folded.add(name);
  renderNavSections();
  savePrefs({ collapsedSections: [...folded] }).catch((e) => showBanner(`Couldn't save: ${e.message}`));
}
$(".tabs").addEventListener("keydown", (e) => {
  const head = e.target.closest(".tab-head");
  if (head && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); toggleSection(head); }
});

// The tool tabs: Up and Down move focus through the visible tools (Starred only and folded sections hide some), Home and End jump
// to the first and last. Focus only moves; Enter or Space opens the tool (some tools read from Microsoft when they open).
$(".tabs").addEventListener("keydown", (e) => {
  const tab = e.target.closest('[role="tab"]');
  if (!tab || e.ctrlKey || e.metaKey || e.altKey) return;
  const tabs = $$('.tabs [role="tab"]').filter((b) => b.offsetParent !== null);
  const i = tabs.indexOf(tab);
  const to = { ArrowDown: tabs[i + 1] || tabs[0], ArrowUp: tabs[i - 1] || tabs[tabs.length - 1], Home: tabs[0], End: tabs[tabs.length - 1] }[e.key];
  if (!to) return;
  e.preventDefault();
  to.focus();
});

$(".tabs").addEventListener("click", (e) => {
  const head = e.target.closest(".tab-head");
  if (head) { toggleSection(head); return; }
  const star = e.target.closest('[role="tab"] .star');
  if (star) { toggleStar("starredTabs", star.closest('[role="tab"]').dataset.tab); renderTabStars(); return; }
  if (e.target.closest("#star-filter")) {
    stars.starredOnly = !stars.starredOnly;
    renderTabStars();
    savePrefs({ starredOnly: stars.starredOnly }).catch((err) => showBanner(`Couldn't save: ${err.message}`));
  }
});

async function renderReports() {
  if (!allReports) {
    try {
      allReports = sortReports((await loadReports()).map(catalogReport)); // by category, then name
    } catch (err) {
      $("#reports-rows").innerHTML = `<tr><td colspan="${reportCols}">${errorBox(err)}</td></tr>`;
      return;
    }
  }
  const box = $("#reports-chips");
  if (!box.children.length) {
    const starred = REPORT_CONFIG.starredChip;
    box.innerHTML = ["All", starred, ...REPORT_CONFIG.chips].map((c) => chipButton(`${c === starred ? STAR_SVG : ""}${esc(c)}`, `data-chip="${esc(c)}"`)).join("");
  }
  for (const b of $$(".chip", box)) b.setAttribute("aria-pressed", String(b.dataset.chip === reportChip));
  const query = $("#reports-search").value;
  const rows = filterReports(allReports, reportChip, query, { starred: stars.starredReports });
  const starCell = (r) => {
    const on = stars.starredReports.has(r.name);
    return `<td class="star-col">${starHtml(on, "button", "report", `data-star="${esc(r.name)}" aria-pressed="${on}" aria-label="Star ${esc(r.name)}"`)}</td>`;
  };
  const none = reportChip === REPORT_CONFIG.starredChip && !stars.starredReports.size ? "No starred reports yet. Click the star beside a report to add it here." : "No reports match.";
  $("#reports-rows").innerHTML = rows.length
    ? rows.map((r) => `<tr><td>${link(reportUrl(r.path), r.name)}</td>${starCell(r)}<td><span class="badge">${esc(r.area)}</span></td><td class="muted">${esc(r.description)}</td></tr>`).join("")
    : `<tr><td colspan="${reportCols}" class="muted">${none}</td></tr>`;
  const typed = query.trim().length;
  $("#reports-count").textContent = `${rows.length} of ${allReports.length} reports` +
    (typed && typed < REPORT_CONFIG.minSearchLength ? ` (search starts at ${REPORT_CONFIG.minSearchLength} letters)` : "");
}
$("#reports-search").addEventListener("input", renderReports);
$("#reports-chips").addEventListener("click", (e) => {
  const b = e.target.closest(".chip");
  if (!b) return;
  reportChip = b.dataset.chip;
  renderReports();
});
$("#reports-rows").addEventListener("click", (e) => {
  const b = e.target.closest(".star");
  if (!b) return;
  toggleStar("starredReports", b.dataset.star);
  renderReports();
});

// Page export: Save HTML and Copy Markdown for a whole report tab, once near the top of the page (next to its heading),
// shown while the tab has a Copy table / Save CSV group on screen. The document is made from the rows each of those
// groups registered with bindExport (the same rows as its Copy table: all of them, not only the ones drawn), each titled
// by the heading above its buttons, so every report has it with no code of its own; core/report-doc.js writes the files.
// Left out: Settings and All reports (no report), Environment overview (its own document, with bars). Policy export and
// App details have a write-up of their own (policyDocument's `report`), used in place of reading the page.
const PAGE_EXPORT_SKIP = new Set(["settings", "reports", "overview"]);
const PAGE_DOCS = { polexport: () => appState.polDoc?.report, appdetails: () => appState.appDoc?.report };
/** The Save CSV buttons a tab shows right now (hidden ones and the page buttons excepted). */
const csvButtonsIn = (section) => $$('button[id$="-csv"]', section).filter((b) => !b.closest("[hidden], .page-export") && exportDefs[b.id.slice(0, -4)]);

/** The report on screen as a report document: the page's heading and intro, then one plain table per export group on it. */
function pageDoc(section) {
  const text = (el) => el.textContent.replace(/\s+/g, " ").trim();
  const title = text($("h1", section));
  const headingAbove = (el) => {
    for (; el && el !== section; el = el.parentElement) {
      for (let p = el.previousElementSibling; p; p = p.previousElementSibling) {
        const h = p.matches("h2, h3") ? p : $("h2, h3", p);
        if (h) return text(h);
      }
    }
    return title;
  };
  const sections = csvButtonsIn(section).map((b) => ({ b, rows: exportDefs[b.id.slice(0, -4)].rows() })).filter((x) => x.rows?.length > 1)
    .map(({ b, rows }) => ({ title: headingAbove(b), head: rows[0].map(String), cells: rows.slice(1).map((r) => r.map(sheetDate)) }));
  const intro = $(".intro p", section);
  return { title, subtitle: intro ? text(intro) : "", sections };
}

for (const section of $$("section.tab")) {
  const tab = section.id.replace(/^tab-/, "");
  const intro = $(".intro", section);
  if (PAGE_EXPORT_SKIP.has(tab) || !intro) continue;
  intro.insertAdjacentHTML("afterbegin", '<span class="page-export" hidden><button type="button" class="export" data-page-html>Save HTML</button><button type="button" class="export" data-page-md>Copy Markdown</button></span>');
  $(".page-export", intro).addEventListener("click", (e) => {
    const btn = e.target.closest("button");
    if (!btn) return;
    const doc = PAGE_DOCS[tab]?.() || pageDoc(section);
    if (btn.hasAttribute("data-page-md")) copyText(btn, docMarkdown(doc));
    else download(`${doc.title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || tab}-${new Date().toISOString().slice(0, 10)}.html`, new Blob([docHtml(doc)], { type: "text/html" }));
  });
}
// One observer for every tab: when a tab is shown, or a report shows or hides its export buttons, the visible tab's page
// buttons are shown or hidden to match.
const syncPageExport = () => {
  const section = $("section.tab:not([hidden])");
  const bar = section && $(".intro .page-export", section);
  const hide = !csvButtonsIn(section).length;
  if (bar && bar.hidden !== hide) bar.hidden = hide; // only when it changes: even setting the same value would wake this observer again
};
new MutationObserver(syncPageExport).observe($("section.tab").parentElement, { childList: true, subtree: true, attributes: true, attributeFilter: ["hidden"] });
syncPageExport();

// The tab openers that live here (the device, tenant and other tool files register their own).
registerTab("reports", () => { renderReports(); });

// Environment overview: a one or two page summary of the fleet from the device list (and the Hardware report when read),
// as Markdown, an HTML page (print it to PDF) or CSV, all written by core/report-doc.js.

let ovDoc = null;

const runOverview = oneAtATime($("#ov-run"), async () => {
  const out = $("#ov-results");
  out.innerHTML = loading("Reading your devices, policies and apps. The first time, the policy index can take a few minutes...");
  try {
    await loadDevices();
    if (!appState.hwData) {
      try {
        const { saved } = await send("hardware/load");
        if (saved) appState.hwData = saved;
      } catch { /* nothing saved: read it below */ }
    }
    // No device read yet: run it here (the Hardware and Security posture read, with the progress bar and Stop), so the
    // security checks need no visit to another tab. A stopped or failed read leaves them out, and the overview says so.
    if (!appState.hwData) {
      out.innerHTML = loading("Reading every device's security details (one request per device; Stop on the bar skips them)...");
      await runHardware();
      out.innerHTML = loading("Reading compliance results, policies and apps...");
    }
    // Firewall comes from the compliance results (Compliance breakdown's read); without them the overview says so.
    const [compliance, objects] = await Promise.all([send("compliance/summary").then((r) => r.all, () => null),
      send("overview/counts").then((r) => r, () => null)]); // policy and app counts; the first use builds the policy index
    ovDoc = environmentOverview(appState.devicesCache.devices, { friendly: globalThis.IEWindowsBuilds?.friendly,
      hardware: appState.hwData ? { at: appState.hwData.at, rows: hwRows() } : null, compliance, objects, scopeName: appState.scope?.name || "" });
    renderOverview();
  } catch (err) {
    out.innerHTML = errorBox(err);
  }
});

function renderOverview() {
  const d = ovDoc;
  const bar = (count, of) => `<span class="pctbar"><span style="width:${of ? Math.round((count / of) * 100) : 0}%"></span></span>`;
  $("#ov-results").innerHTML = `<p class="muted">${esc(d.subtitle)}</p>
    <div class="toolbar tight">
      <span class="spacer"></span>
      ${exportButtons("ov", ["md", "html"])}
    </div>
    <div class="tiles">${d.headline.map((h) => tile(h.value, h.label)).join("")}</div>
    <div class="overview-grid">${d.sections.map((s) => `<article class="card"><h2>${esc(s.title)}</h2>${s.rows.length
      ? tableHtml([s.labelHeading || "Value", { label: s.countHeading || "Devices", num: true }, { label: `% of ${s.ofLabel}`, num: true }],
        s.rows.map((r) => [td(esc(r.label)), td(r.count.toLocaleString(), "num"), td(`${docPercent(r.count, s.of)} ${bar(r.count, s.of)}`, "num nowrap")]))
      : ""}${s.note ? `<p class="muted small">${esc(s.note)}</p>` : ""}</article>`).join("")}</div>`;
}

$("#ov-run").addEventListener("click", runOverview);
$("#ov-results").addEventListener("click", (e) => {
  if (!ovDoc) return;
  if (e.target.closest("#ov-md")) copyText(e.target.closest("#ov-md"), docMarkdown(ovDoc));
  if (e.target.closest("#ov-html")) download(`environment-overview-${new Date().toISOString().slice(0, 10)}.html`, new Blob([docHtml(ovDoc)], { type: "text/html" }));
});
bindExport("ov", () => ovDoc && docCsvRows(ovDoc), () => "environment-overview.csv");

// ------------------------------------------------------------------------------------------
// The header shows the installed version beside the name, read from the manifest, without the trailing ".0"
// (2.79.0 reads "v2.79"; nothing to show in the sample preview page).
const appVersion = globalThis.chrome?.runtime?.getManifest?.().version;
if (appVersion) $("#app-version").textContent = `(v${appVersion.replace(/\.0$/, "")})`;

// Setting rows: each name labels its control and the i buttons open one shared card (setting-rows.js).
setupRows(document);
createTipCard($("#tipcard"), document);

// Settings: the disclosure until it's accepted, then status and the in-portal feature switches.
// Each switch saves its own key in ie.prefs (data-pref); every switch is on unless saved as false
// (the content scripts read them the same way). In sample mode nothing is saved.

// Device links follow the "New device view" switch; links already built into the device list are redone.
function applyDeviceView(prefs) {
  setNewDeviceView(prefs.newDeviceView);
  if (appState.devicesCache) for (const d of appState.devicesCache.devices) d.link = deviceUrl(d.managedId);
}

// The controls are set from storage once, then follow storage changes (below). A device list build sends
// a progress update every 1,000 devices, and re-setting them each time would snap a slider back mid-drag.
let prefsShown = false;

async function renderSettingsTab(s) {
  const on = SAMPLE || s.consented;
  $("#consent").hidden = on;
  $("#settings-main").hidden = !on;
  if (!on) return;
  const ix = s.index || {};
  $("#set-count").textContent = ix.building ? `building... ${ix.count || 0}` : (ix.count || 0).toLocaleString();
  $("#set-built").textContent = ago(ix.builtAt);
  $("#set-rebuild").disabled = Boolean(ix.building) || !s.signedIn;
  $("#set-error").textContent = ix.error || "";
  $("#set-error").hidden = !ix.error;
  renderGov();
  if (!prefsShown) {
    prefsShown = true;
    await showPrefs();
  }
}

/** Set every switch, dropdown and slider from the saved prefs. */
async function showPrefs() {
  const prefs = await loadPrefs();
  applyDeviceView(prefs);
  applyStars(prefs);
  applyExplorerColumns(prefs);
  for (const el of $$("[data-pref]")) {
    if (el.type === "checkbox") el.checked = prefs[el.dataset.pref] !== false;
    else el.value = prefs[el.dataset.pref];
  }
  if ((prefs.workspaceScope === true) !== appState.scopeEnabled) enableScope(prefs.workspaceScope === true); // changed in another tab
  if ((prefs.baselineGap === true) !== appState.baselineEnabled) enableBaseline(prefs.baselineGap === true);
  showWidths();
}

loadPrefs().then(applyStars).catch(() => {}); // the sidebar's stars, before Settings is ever opened

// A column width dragged in the admin center (or a change in another workspace tab) shows here at once.
if (!SAMPLE) {
  chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes[PREFS_KEY]) showPrefs(); });
}

// A slider's percentage beside it.
const showWidths = () => $$("output[data-for]").forEach((o) => { o.textContent = `${$(`[data-pref="${o.dataset.for}"]`).value}%`; });

for (const el of $$("[data-pref]")) {
  const value = () => (el.type === "checkbox" ? el.checked : el.type === "range" ? Number(el.value) : el.value);
  el.addEventListener("change", () => savePrefs({ [el.dataset.pref]: value() }).catch((e) => { $("#set-error").textContent = e.message; $("#set-error").hidden = false; }));
  if (el.type === "range") el.addEventListener("input", showWidths);
}

// #set-error sits in the part of Settings that is hidden until consent, so a failure here uses the banner.
$("#agree").addEventListener("click", async () => {
  try {
    await grantConsent();
  } catch (e) {
    showBanner(`Couldn't turn on: ${e.message}`);
    return;
  }
  $("#all-set").hidden = false;
  await refreshSession();
});

$("#set-rebuild").addEventListener("click", async () => {
  $("#set-rebuild").disabled = true;
  await send("index/rebuild").catch((e) => { $("#set-error").textContent = e.message; $("#set-error").hidden = false; });
  appState.devicesCache = null; // OS builds and Stale & duplicates read the new list
  refreshSession();
});

// Every setting back to its default: the worker removes ie.prefs, the theme choice goes, and the page reloads so
// every control, star and the theme are drawn from the defaults. Stored data and US Government access are kept.
// Footer > Credits. Escape closes a modal dialog by itself; so does a click on the dimmed page around it.
$("#credits-open").addEventListener("click", (e) => { e.preventDefault(); $("#credits").showModal(); });
$("#credits-close").addEventListener("click", () => $("#credits").close());
$("#credits").addEventListener("click", (e) => {
  const box = e.currentTarget.getBoundingClientRect();
  if (e.clientX < box.left || e.clientX > box.right || e.clientY < box.top || e.clientY > box.bottom) e.currentTarget.close();
});

// Settings > Reset to defaults: what it does is said in the question.
$("#set-reset").addEventListener("click", async () => {
  const ask = "Reset all Intune Enhancer settings to their defaults?\n\nSwitches, dropdowns, column widths, stars and the theme go back to how they were at install. Stored data and US Government cloud access are kept.";
  if (!confirm(ask)) return;
  try {
    if (!SAMPLE) await send("prefs/reset");
  } catch (e) {
    $("#set-error").textContent = `Couldn't reset: ${e.message}`;
    $("#set-error").hidden = false;
    return;
  }
  try { localStorage.removeItem("ie.theme"); } catch { /* storage unavailable */ }
  location.reload();
});

// What the reports show from the cleared data goes too (the Hardware report holds serials, IP and MAC addresses;
// Autopilot rows, Device 360, comparisons and rosters hold names): the page reloads, so nothing read before stays.
$("#set-clear").addEventListener("click", async () => {
  try {
    if (!SAMPLE) await send("data/clear");
  } catch (e) {
    $("#set-error").textContent = `Couldn't clear: ${e.message}`;
    $("#set-error").hidden = false;
    return;
  }
  location.reload();
});

// ------------------------------------------------------------------------------------------
// Scope (header): limits the workspace's device lists to one device group, nested groups included. A view filter
// only: the saved group id and name are in ie.prefs, the member list is read once per visit and kept in memory.

function openScopePanel(open) {
  $("#scope-panel").hidden = !open;
  $("#scope-pill").setAttribute("aria-expanded", String(open));
  if (open) $('[data-picker="scope"] input').focus();
}

/** Set (a group from the picker) or clear (null) the scope, then redraw what the device list feeds. */
function setScope(g) {
  appState.scope = g ? { id: g.id, name: g.displayName || "Group", ids: null } : null;
  savePrefs({ scopeGroupId: g?.id || "", scopeGroupName: (g?.displayName || "").slice(0, 64) }).catch(() => {});
  openScopePanel(false);
  renderScope();
  appState.devicesCache = null;
  if (DEVICE_TABS.includes(appState.currentTab)) showDeviceTab(appState.currentTab);
  if (appState.currentTab === "hardware") loadDevices().then(renderHardware, () => {});
  else if (appState.hwData) loadDevices().catch(() => {}); // so the Hardware report is filtered when it is next opened
  renderOrphans(); // redrawn from the answer already read
  if (ovDoc) { ovDoc = null; $("#ov-results").innerHTML = emptyBox("The scope changed. Build the overview again."); }
  $("#comp-devices").innerHTML = ""; appState.compDevices = null; // pick the setting again to see its devices in the new scope
}

/** The Settings switch: on shows the Scope control; off hides it and clears the scope, so every list is whole again. */
function enableScope(on) {
  appState.scopeEnabled = on;
  if (!on && appState.scope) setScope(null);
  else { if (!on) openScopePanel(false); renderScope(); }
}

$('[data-pref="baselineGap"]').addEventListener("change", (e) => enableBaseline(e.target.checked));

setupPicker("scope", setScope);
$('[data-pref="workspaceScope"]').addEventListener("change", (e) => enableScope(e.target.checked));
$("#scope-pill").addEventListener("click", () => openScopePanel($("#scope-panel").hidden));
$("#scope-clear").addEventListener("click", () => setScope(null));
dismissable($("#scope"), () => !$("#scope-panel").hidden, () => openScopePanel(false), $("#scope-pill"));

// ------------------------------------------------------------------------------------------
// Theme dropdown (theme-init.js has already applied the saved theme; themes.js builds the menu and paints the pattern)

setupThemePicker();

// ------------------------------------------------------------------------------------------
// Start

// Not in sample mode: a real build running in another workspace tab broadcasts its progress to every extension page.
if (inExtension && !SAMPLE) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "policies/progress") {
      if (msg.building) {
        // One plain label while the index walks the item types; the settings stage keeps its type's name.
        const what = / settings$/.test(msg.step || "") ? msg.step : "policy types";
        setIndexLines(`<span class="spinner"></span>Reading ${esc(what)}${msg.total ? ` (${msg.done} of ${msg.total})` : ""}...`);
        jobBar.set("policies", { label: `Reading ${what}`, done: msg.done || 0, total: msg.total || 0, stop: true });
      } else {
        jobBar.done("policies");
      }
    }
    if (msg?.type === "index/progress") {
      if (msg.building) jobBar.set("devices", { label: "Reading your devices", done: msg.count || 0, total: 0, stop: true });
      else jobBar.done("devices");
    }
    if (msg?.type === "job/progress") jobBar.set(msg.key, { label: msg.label, done: msg.done, total: msg.total, stop: true });
    if (msg?.type === "job/done") jobBar.done(msg.key);
    if (msg?.type === "index/progress" && appState.currentTab === "settings") refreshSession();
  });
}

let initialTab = DEFAULT_TAB;
try { initialTab = localStorage.getItem("ie.workspace.tab") || initialTab; } catch { /* storage unavailable */ }
appState.lastTab = initialTab;
// Until it's turned on, the only useful place is Settings. Ask first, so a restored tool doesn't start a read that
// the worker refuses and flash a "turned off" error before Settings opens.
refreshSession().then((s) => {
  if (s && !s.consented && !SAMPLE) selectTab("settings");
  else if (!openFromHash()) selectTab(TABS.includes(initialTab) ? initialTab : DEFAULT_TAB);
});
