// Workspace page: one tab per tool, plus Settings (turning it on, and the in-portal switches).
// All data comes from the service worker (which holds the Graph session). With ?sample=1 (hidden,
// for screenshots, previews and store reviewers), or when
// opened outside the extension, it answers from the fictional tenant in sample.js instead, sending
// nothing anywhere.

import { sampleSend } from "./sample.js";
import { osSpread, updateCheck, staleDevices, lowStorageDevices, duplicateDevices, ageDays, activityLevel, ageText } from "../core/device-reports.js";
import { failedItems } from "../core/autopilot.js";
import { lookupError, codesInText } from "../core/error-codes.js";
import { baselineGap } from "../core/baseline-gap.js";
import { loadErrorCodes, loadBaselines, loadReports } from "./lazy-data.js";
import { settingArea } from "../core/setting-search.js";
import { groupKind } from "../core/group-tools.js";
import { deviceSearchText, pickerDevice } from "../core/resolve.js";
import { searchWords, hasAllWords, platformName } from "../core/format.js";
import { PREFS_KEY } from "../core/prefs.js";
import { isBelowVersion } from "../core/app-versions.js";
import { grantConsent } from "../shared/consent.js";
import { POLICY_TYPES } from "../core/policy-types.js";
import { policyDocument } from "../core/policy-export.js";
import { appSections } from "../core/app-details.js";
import { hardwareColumns, POSTURE_FIELDS } from "../core/hardware.js";
import { postureIssues, postureCounts } from "../core/security-posture.js";
import { environmentOverview } from "../core/environment-overview.js";
import { docMarkdown, docHtml, docCsvRows, docPercent } from "../core/report-doc.js";
import { EXPLORER_FIELDS, EXPLORER_DEFAULT, explorerRow } from "../core/device-explorer.js";
import { GOV } from "../core/clouds.js";
import { deviceUrl, reportUrl, setNewDeviceView, setPortalHost } from "../core/portal-links.js";
import { REPORT_CONFIG, catalogReport, filterReports, sortReports } from "../core/report-list.js";
import { setupRows, createTipCard } from "./setting-rows.js";
import { csvText, tsvText } from "./sheet.js";
import { createJobBar } from "./job-bar.js";

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESCAPES[c]);

const inExtension = Boolean(globalThis.chrome?.runtime?.id);
const SAMPLE = !inExtension || new URLSearchParams(location.search).has("sample");

// Top bar: Demo on sample tenant / Leave demo, which reopens this page with or without ?sample=1. Only in the real
// extension: the preview page (opened from disk) is always sample data, so there is nothing to leave.
{
  const demo = $("#demo-toggle");
  demo.hidden = !inExtension;
  demo.classList.toggle("on", SAMPLE);
  if (SAMPLE) {
    $("#demo-text").textContent = "Leave demo";
    demo.title = "Back to your own tenant";
  }
  demo.addEventListener("click", () => {
    const url = new URL(location.href);
    if (SAMPLE) url.searchParams.delete("sample");
    else url.searchParams.set("sample", "1");
    location.assign(url.href);
  });
}

// The progress bar along the bottom (job-bar.js). Stop on a worker job asks the worker.
const jobBar = createJobBar({ stopWorker: () => send("job/stop").catch(() => {}) });

// Reads the worker does in one go, with no count to show: just a line on the bar while they run.
const LONG_READS = {
  "device/360": "Reading the device's groups and policies",
  "baseline/applied": "Reading the device's groups and policies",
  "devices/compare": "Reading both devices' groups and policies",
  "users/compare": "Reading both users' groups",
  "policies/duplicates": "Comparing every policy",
  "compliance/summary": "Reading compliance results",
  "compliance/devices": "Reading the devices failing this setting",
  "tenant/health": "Checking tokens, certificates and connectors",
  "devices/orphaned": "Checking primary users", // the worker reports its count as it goes
  "failed/apps": "Reading app install results",
  "autopilot/events": "Reading Autopilot events and their enrollment status details",
};

function send(type, payload = {}) {
  const label = LONG_READS[type];
  const key = label ? `read:${type}` : "";
  // devices/orphaned and anything else that builds an index can be stopped, so those lines get Stop too.
  if (key) jobBar.set(key, { label, stop: type === "devices/orphaned" || undefined });
  const reply = SAMPLE ? sampleSend(type, payload) : chrome.runtime.sendMessage({ type, ...payload }).then((res) => {
    if (!res) throw new Error("No response from the extension. Try reloading this tab.");
    if (res.ok === false) throw Object.assign(new Error(res.error || "Request failed."), { code: res.code });
    return res;
  });
  return key ? Promise.resolve(reply).finally(() => jobBar.done(key)) : reply;
}

// ------------------------------------------------------------------------------------------
// Small helpers

/** How long ago a time (ms) was: "just now", "5 min ago", "3 h ago", or the date after two days. */
function ago(ms) {
  if (!ms) return "never";
  const mins = Math.round((Date.now() - ms) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  return hours < 48 ? `${hours} h ago` : new Date(ms).toLocaleDateString();
}
const checkInText = (iso) => ageText(iso) || "never";
/** Last check-in with its activity traffic light (green 8 hours, yellow 7 days, orange 30, red older or never). */
const checkInCell = (iso) => `<span class="nowrap"><span class="light ${activityLevel(iso)}" aria-hidden="true"></span>${esc(checkInText(iso))}</span>`;
const friendlyOs = (os, version) => globalThis.IEWindowsBuilds.friendlyOs(os, version); // shared/windows-builds.js
const COMPLIANCE_BADGES = {
  // The same words as Device quick facts (COMPLIANCE_TEXT in content/primary-user-labels.js).
  compliant: ["ok", "Compliant"], noncompliant: ["bad", "Not compliant"], inGracePeriod: ["warn", "In grace period"],
  conflict: ["warn", "Conflict"], error: ["bad", "Error"], unknown: ["", "Unknown"], configManager: ["", "Config Manager"],
};
/** A badge from a table of { key: [class, text] }; the class (ok, warn, bad or none) colours it. An unknown key shows itself. */
const badge = (map, key) => {
  const [cls, text] = map[key] || ["", key || "Unknown"];
  return `<span class="badge ${cls}">${esc(text)}</span>`;
};
const complianceBadge = (c) => badge(COMPLIANCE_BADGES, c);
const VALUE_SHOWN = 120;
/**
 * A setting value's cell (Setting check, Device 360's Settings card): monospace and wrapping anywhere, and a long one
 * (a certificate, a script) cut to its start with its length, so it can't push the other columns off the card. Copy
 * table and Save CSV keep the whole value.
 */
const valueCell = (value) => { const v = String(value ?? ""); return td(v.length > VALUE_SHOWN ? `${esc(v.slice(0, VALUE_SHOWN))}... <span class="muted">(${v.length.toLocaleString()} characters)</span>` : esc(v), "mono"); };
/** " N Intune records" after a device name that has more than one record (Group roster, User 360), else nothing. */
const recordsBadge = (n) => (n > 1 ? ` <span class="badge warn">${n} Intune records</span>` : "");
/**
 * For a tool whose answers can arrive out of order (the first search can take a minute while an
 * index builds): `const current = run();` when a request starts, and `if (!current()) return;` before
 * writing its answer, so a slower, older request never replaces a newer one.
 */
function newestOnly() {
  let latest = 0;
  return () => {
    const mine = ++latest;
    return () => mine === latest;
  };
}
/**
 * For a long read that must not run twice at once (a second click, or coming back to its tab): returns a function that
 * does nothing while run() is going, and otherwise runs it with `button` disabled until it settles. .busy() says
 * whether a run is going.
 */
function oneAtATime(button, run) {
  let running = false;
  const buttons = [].concat(button); // one button, or several that start the same run (Hardware and Security posture)
  const start = async () => {
    if (running) return;
    running = true;
    buttons.forEach((b) => { b.disabled = true; });
    try {
      await run();
    } finally {
      running = false;
      buttons.forEach((b) => { b.disabled = false; });
    }
  };
  start.busy = () => running;
  return start;
}
const loading = (text) => `<div class="empty"><span class="spinner"></span>${esc(text)}</div>`;
const emptyBox = (text) => `<div class="empty">${esc(text)}</div>`;
const errorBox = (e) => emptyBox(e?.message || e);
/**
 * One run of a tool whose answers can arrive out of order: starts a run of `newRun` (a newestOnly()), shows `text`
 * with a spinner in `out`, then writes the HTML work(current) returns, or the error, only while this run is still the
 * newest. work checks current() itself before it keeps anything (a report for Copy table, say) or draws `out` itself.
 */
async function runInto(out, newRun, text, work) {
  const current = newRun();
  out.innerHTML = loading(text);
  try {
    const html = await work(current);
    if (current() && typeof html === "string") out.innerHTML = html;
  } catch (err) {
    if (current()) out.innerHTML = errorBox(err);
  }
}
// The note under a table that was cut to its first rows; Copy table and Save CSV still carry every row.
const limitNote = (shown, total, exports = "Copy and Save CSV include all.") => `<p class="muted small">Showing the first ${shown.toLocaleString()} of ${total.toLocaleString()}. ${exports}</p>`;
/** A long list drawn from its first `max` rows (draw(rows) makes the table), with the limitNote when rows were left out. */
const capped = (list, draw, max = 2000, exports = undefined) => draw(list.slice(0, max)) + (list.length > max ? limitNote(max, list.length, exports) : "");

// Copy table / Save CSV: one markup helper, and one registry served by one click listener. A report registers its
// button prefix with bindExport(prefix, rows, file); rows and file are functions so they read the report on screen.
// csvRows is only for a report whose CSV holds more than its Copy table.
const exportButtons = (prefix) => `<button type="button" id="${prefix}-copy">Copy table</button><button type="button" id="${prefix}-csv">Save CSV</button>`;
for (const el of $$("[data-export]")) el.innerHTML = exportButtons(el.dataset.export); // the toolbars' placeholders
const exportDefs = {};
const bindExport = (prefix, rows, file, csvRows = rows) => { exportDefs[prefix] = { rows, file, csvRows }; };
document.addEventListener("click", (e) => {
  const btn = e.target.closest?.('button[id$="-copy"], button[id$="-csv"]');
  const m = btn && /^(.+)-(copy|csv)$/.exec(btn.id);
  const def = m && exportDefs[m[1]];
  if (!def) return;
  const rows = (m[2] === "copy" ? def.rows : def.csvRows)();
  if (!rows) return;
  if (m[2] === "copy") copyTsv(btn, rows);
  else saveCsv(def.file(), rows);
});
const link = (href, text) => (href ? `<a href="${esc(href)}" target="_blank" rel="noopener">${esc(text)}</a>` : esc(text));

function showBanner(text) {
  const b = $("#banner");
  b.textContent = text;
  b.hidden = !text;
}

// While it's turned off the banner points to the Settings tab, or below when that tab is open.
let turnedOff = false;
const showOffBanner = () => showBanner(currentTab === "settings"
  ? "Intune Enhancer is turned off. Read what it does below, then turn it on."
  : "Intune Enhancer is turned off. Read what it does on the Settings tab, then turn it on.");

// ------------------------------------------------------------------------------------------
// Session and tabs

async function refreshSession() {
  // A dot on the Settings tab: green when there's a session, red when not; the text is its tooltip.
  const setSession = (text, live) => { const el = $("#session"); el.title = text; el.className = `session ${live ? "live" : "none"}`; };
  try {
    const s = await send("status");
    if (s.portalHost) setPortalHost(s.portalHost);
    turnedOff = !SAMPLE && !s.consented;
    if (SAMPLE) {
      setSession("Sample data (fictional)", true);
      showBanner("You're looking at sample data for a fictional tenant. Nothing is read from or sent to any tenant.");
    } else if (!s.consented) {
      setSession("Turned off", false);
      showOffBanner();
    } else if (!s.signedIn) {
      setSession("No Intune session", false);
      showBanner("Open the Intune admin center (intune.microsoft.com, or your US Government cloud address) in another tab and sign in. This page uses that session.");
    } else {
      setSession(s.upn || "Signed in", true);
      showBanner("");
    }
    renderIndexLine(s.policies);
    renderSettingsTab(s);
    return s;
  } catch (e) {
    setSession("Extension not reachable", false);
    return null;
  }
}

const TABS = ["baseline", "setting", "changes", "cleanup", "polexport", "dupes", "impact", "roster", "d360", "cmpdevices", "cmpusers", "os", "hygiene", "storage", "explorer", "hardware", "posture", "compliance", "orphans", "user360", "appdetails", "appver", "failedapps", "failedpolicies", "autopilot", "health", "decode", "errors", "reports", "overview", "settings"];
const DEFAULT_TAB = "d360"; // the first tool in the sidebar; where a fresh open lands
let currentTab = DEFAULT_TAB;
let lastTab = DEFAULT_TAB; // the tab saved from the last visit (Baseline gap can only open once prefs are read)

function selectTab(name) {
  if (name === "baseline" && !baselineEnabled) name = DEFAULT_TAB; // Baseline gap is off (Settings > Advanced)
  currentTab = name;
  for (const btn of $$('[role="tab"]')) btn.setAttribute("aria-selected", String(btn.dataset.tab === name));
  for (const sec of $$(".tab")) sec.hidden = sec.id !== `tab-${name}`;
  try { localStorage.setItem("ie.workspace.tab", name); } catch { /* storage unavailable */ }
  if (turnedOff) showOffBanner();
  // The device report tabs load the device list the first time they're shown.
  if (DEVICE_TABS.includes(name)) { showDeviceTab(name); return; }
  if (name === "orphans") { if (!orphans) runOrphans(); return; }
  if (name === "hardware" || name === "posture") { if (!hwData) loadSavedHardware(); else if (name === "posture") renderPosture(); return; }
  if (name === "health") { if (!health) runHealth(); return; }
  if (name === "errors" || name === "autopilot") errorCodes();
  if (name === "reports") renderReports();
  if (name === "changes" && shown && !changes) showChanges(); // results on screen from before a policy refresh
  if (name === "baseline") baselineData().catch((err) => { $("#bl-results").innerHTML = errorBox(err); }); // the baselines load on first use
  const first = $(`#tab-${name} input[type="search"], #tab-${name} textarea`);
  first?.focus();
}
$$('[role="tab"]').forEach((btn) => btn.addEventListener("click", (e) => { if (!e.target.closest(".star")) selectTab(btn.dataset.tab); }));
// The toolbar icon and the admin center's "turned off" note open #settings, also in an open tab.
// "#impact/<group id>" (from the Used by button in the portal) opens Group assignments for that group.
function openFromHash() {
  const [tab, arg] = location.hash.slice(1).split("/");
  if (!TABS.includes(tab)) return false;
  selectTab(tab);
  if (tab === "errors" && arg) {
    let text = arg;
    try { text = decodeURIComponent(arg); } catch { /* malformed escape: use the raw text */ }
    $("#errors-input").value = text;
    runErrorLookup();
  }
  if (tab === "impact" && /^[0-9a-f-]{36}$/i.test(arg || "")) {
    $('[data-picker="impact"] input').value = arg;
    runImpact({ id: arg });
  }
  return true;
}
window.addEventListener("hashchange", openFromHash);

// ------------------------------------------------------------------------------------------
// All reports: Intune's own reports from data/reports.js (no tenant read). The search box filters on every
// keypress once it has REPORT_CONFIG.minSearchLength letters (the owner's one exception to "search on Enter").

let allReports = null; // loaded on first use (workspace/lazy-data.js)
let reportChip = "All";
const reportCols = 4; // name, star, category, description

// ------------------------------------------------------------------------------------------
// Stars: reports (All reports) and tools (the sidebar) the admin marks, saved in ie.prefs as lists of names
// (starredReports, starredTabs) with starredOnly for the sidebar's "Starred only". Grey outline off, gold on.

const STAR_SVG = '<svg class="star-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.85 5.95 6.55.85-4.8 4.55 1.2 6.5L12 17.35l-5.8 3.1 1.2-6.5-4.8-4.55 6.55-.85z"/></svg>';
const stars = { starredReports: new Set(), starredTabs: new Set(), starredOnly: false };
const starTitle = (on, what) => (on ? "Starred: click to unstar" : `Star this ${what}`);

/** The one star element: a report's button, or a sidebar tool's span (a button can't sit inside the tab button). */
function starHtml(on, tag, what, attrs = "") {
  return `<${tag} class="star${on ? " on" : ""}"${tag === "button" ? ' type="button"' : ""} ${attrs} title="${starTitle(on, what)}">${STAR_SVG}</${tag}>`;
}

/** Take the stars from the saved prefs and redraw what shows them. */
function applyStars(prefs) {
  stars.starredReports = new Set(Array.isArray(prefs.starredReports) ? prefs.starredReports : []);
  stars.starredTabs = new Set(Array.isArray(prefs.starredTabs) ? prefs.starredTabs : []);
  stars.starredOnly = prefs.starredOnly === true;
  renderTabStars();
  if (allReports) renderReports();
}

/** Star or unstar one name in a list pref; shown at once, then saved. */
function toggleStar(key, name) {
  const set = stars[key];
  if (set.has(name)) set.delete(name); else set.add(name);
  savePrefs({ [key]: [...set] }).catch((e) => showBanner(`Couldn't save the star: ${e.message}`));
}

/** The sidebar: each tool's star, and "Starred only" (which hides nothing until at least one tool is starred). */
function renderTabStars() {
  for (const btn of $$('.tabs [role="tab"]')) {
    const on = stars.starredTabs.has(btn.dataset.tab);
    const star = $(".star", btn);
    star.classList.toggle("on", on);
    star.title = starTitle(on, "tool");
  }
  const filter = $("#star-filter");
  filter.setAttribute("aria-pressed", String(stars.starredOnly));
  filter.title = stars.starredTabs.size ? "Show only the starred tools" : "Star a tool (the star beside its name) to use this";
  $(".tabs").classList.toggle("starred-only", stars.starredOnly && stars.starredTabs.size > 0);
}

for (const btn of $$('.tabs [role="tab"]')) {
  btn.insertAdjacentHTML("beforeend", starHtml(false, "span", "tool"));
}
$("#star-filter").insertAdjacentHTML("afterbegin", STAR_SVG);
$(".tabs").addEventListener("click", (e) => {
  const star = e.target.closest('[role="tab"] .star');
  if (star) { toggleStar("starredTabs", star.closest('[role="tab"]').dataset.tab); renderTabStars(); return; }
  if (e.target.closest("#star-filter")) {
    stars.starredOnly = !stars.starredOnly;
    renderTabStars();
    savePrefs({ starredOnly: stars.starredOnly }).catch((err) => showBanner(`Couldn't save: ${err.message}`));
  }
});

async function renderReports() {
  if (!allReports) {
    try {
      allReports = sortReports((await loadReports()).map(catalogReport)); // by category, then name
    } catch (err) {
      $("#reports-rows").innerHTML = `<tr><td colspan="${reportCols}">${errorBox(err)}</td></tr>`;
      return;
    }
  }
  const box = $("#reports-chips");
  if (!box.children.length) {
    const starred = REPORT_CONFIG.starredChip;
    box.innerHTML = ["All", starred, ...REPORT_CONFIG.chips].map((c) => `<button type="button" class="chip" data-chip="${esc(c)}">${c === starred ? STAR_SVG : ""}${esc(c)}</button>`).join("");
  }
  for (const b of $$(".chip", box)) b.setAttribute("aria-pressed", String(b.dataset.chip === reportChip));
  const query = $("#reports-search").value;
  const rows = filterReports(allReports, reportChip, query, { starred: stars.starredReports });
  const starCell = (r) => {
    const on = stars.starredReports.has(r.name);
    return `<td class="star-col">${starHtml(on, "button", "report", `data-star="${esc(r.name)}" aria-pressed="${on}" aria-label="Star ${esc(r.name)}"`)}</td>`;
  };
  const none = reportChip === REPORT_CONFIG.starredChip && !stars.starredReports.size ? "No starred reports yet. Click the star beside a report to add it here." : "No reports match.";
  $("#reports-rows").innerHTML = rows.length
    ? rows.map((r) => `<tr><td>${link(reportUrl(r.path), r.name)}</td>${starCell(r)}<td><span class="badge">${esc(r.area)}</span></td><td class="muted">${esc(r.description)}</td></tr>`).join("")
    : `<tr><td colspan="${reportCols}" class="muted">${none}</td></tr>`;
  const typed = query.trim().length;
  $("#reports-count").textContent = `${rows.length} of ${allReports.length} reports` +
    (typed && typed < REPORT_CONFIG.minSearchLength ? ` (search starts at ${REPORT_CONFIG.minSearchLength} letters)` : "");
}
$("#reports-search").addEventListener("input", renderReports);
$("#reports-chips").addEventListener("click", (e) => {
  const b = e.target.closest(".chip");
  if (!b) return;
  reportChip = b.dataset.chip;
  renderReports();
});
$("#reports-rows").addEventListener("click", (e) => {
  const b = e.target.closest(".star");
  if (!b) return;
  toggleStar("starredReports", b.dataset.star);
  renderReports();
});

// ------------------------------------------------------------------------------------------
// Setting check

// The policy index line, on every tab that reads the policy index.
const setIndexLines = (html) => $$(".policy-index-line").forEach((el) => { el.innerHTML = html; });

/** Group ids named in the assignments of a Setting check or deprecated-settings answer. */
const settingGroupIds = (res) => [...new Set(res.settings.flatMap((s) => s.hits.flatMap((h) => h.assignments.map((a) => a.groupId))))];

function renderIndexLine(p) {
  if (!p) { setIndexLines(""); return; }
  if (p.building) { setIndexLines('<span class="spinner"></span>Reading your policies...'); return; }
  const errs = Object.keys(p.errors || {}).filter((k) => !k.includes(":"));
  setIndexLines(p.builtAt
    ? `Policy index: ${p.count} policies, updated ${esc(ago(p.builtAt))}${p.stale ? " (refresh recommended)" : ""}. <button class="link" data-refresh-policies>Refresh</button>${errs.length ? `<br>Couldn't read: ${esc(errs.join(", "))}. Results don't include those.` : ""}`
    : 'Your policies are read the first time you use a tool that needs them. <button class="link" data-refresh-policies>Read them now</button>');
}

async function rebuildPolicies() {
  renderIndexLine({ building: true });
  try {
    const res = await send("policies/build");
    renderIndexLine(res.policies);
    changes = null; // re-read with the new index
    if (shown && currentTab === "changes") showChanges(); // refresh results already on screen; a hidden tab re-reads when opened
  } catch (e) {
    setIndexLines(esc(e.message));
  }
}
document.addEventListener("click", (e) => { if (e.target.closest?.("[data-refresh-policies]")) rebuildPolicies(); });

let groupNameCache = {}; // group id -> name (null when Graph has none); not groupNames, a core/group-tools.js export
async function namesFor(ids) {
  const missing = ids.filter((id) => id && !(id in groupNameCache));
  if (missing.length) {
    try {
      const found = (await send("groups/names", { ids: missing })).names;
      // An id Graph doesn't know (a deleted group) is remembered as null, so it isn't asked for on every redraw.
      for (const id of missing) groupNameCache[id] = found[id] ?? null;
    } catch { /* show ids, and ask again next time */ }
  }
  return groupNameCache;
}

function assignmentText(assignments) {
  if (!assignments?.length) return '<span class="muted">Not assigned</span>';
  return assignments.map((a) => {
    const filter = a.filterId ? ` <span class="muted">(filter ${esc(a.filterType || "")})</span>` : "";
    if (a.kind === "allDevices") return `All devices${filter}`;
    if (a.kind === "allUsers") return `All users${filter}`;
    const name = groupNameCache[a.groupId] || a.groupId;
    return `${a.kind === "exclude" ? '<span class="badge warn">Exclude</span> ' : ""}${esc(name)}${filter}`;
  }).join("<br>");
}

const settingRun = newestOnly(); // Check and Deprecated settings share one results area

$("#setting-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query = $("#setting-query").value.trim();
  const out = $("#setting-results");
  if (!query) { settingRun(); out.innerHTML = ""; return; } // also stops an earlier search from drawing
  runInto(out, settingRun, "Searching your policies (the first search reads them, which can take a minute)...", async () => {
    const res = await send("settings/search", { query });
    renderIndexLine(res.policies);
    await namesFor(settingGroupIds(res));
    return renderSettings(query, res);
  });
});

function renderSettings(query, res) {
  if (!res.settings.length) {
    return `<div class="card"><h2>Not configured</h2>
      <p>No setting matching <strong>${esc(query)}</strong> is configured in any of the ${res.policyCount} policies with settings (${res.settingCount.toLocaleString()} configured settings checked).</p>
      <p class="muted">This searches settings that are <em>set</em> in a policy. A setting that exists in the catalog but isn't set anywhere won't appear, so check the spelling if you expected a match.</p></div>`;
  }
  const indexed = res.policies?.count ? ` of the ${res.policies.count} indexed (apps, scripts and similar have no settings)` : "";
  return `<p class="muted">${res.total} matching setting${res.total === 1 ? "" : "s"}${res.truncated ? `, showing the first ${res.settings.length}` : ""}. Checked the ${res.policyCount} policies that configure settings${indexed}.</p>` + settingCards(res.settings);
}

function renderDeprecated(res) {
  if (!res.settings.length) {
    return `<div class="card"><h2>No deprecated settings found</h2>
      <p>None of the ${res.settingCount.toLocaleString()} settings configured in your ${res.policyCount} policies is marked deprecated.</p></div>`;
  }
  const uses = res.settings.reduce((n, s) => n + s.hits.length, 0);
  return `<p class="muted">${res.total} deprecated setting${res.total === 1 ? " is" : "s are"} still configured, ${uses} time${uses === 1 ? "" : "s"} across your policies${res.truncated ? ` (showing the first ${res.settings.length})` : ""}. Found by "Deprecated" in the setting's name or catalog description: plan to remove or replace them.</p>` + settingCards(res.settings);
}

function settingCards(settings) {
  const sameName = new Map();
  for (const s of settings) sameName.set(s.name, (sameName.get(s.name) || 0) + 1);
  // Settings that share a name (one per Office app, say) are told apart by the product in their path.
  const hint = (s) => (sameName.get(s.name) > 1 && settingArea(s.path) ? ` <span class="muted small">${esc(settingArea(s.path))}</span>` : "");
  return settings.map((s) => `
    <article class="card">
      <h2>${esc(s.name)}${hint(s)}</h2>
      <div class="path">${esc(s.path)}</div>
      <div class="badges">
        <span class="badge ok">Configured in ${s.hits.length} polic${s.hits.length === 1 ? "y" : "ies"}</span>
        ${s.differs ? '<span class="badge warn">Values differ between policies</span>' : ""}
      </div>
      ${tableHtml(["Policy", "Type", "Value", "Assigned to"], s.hits.map((h) => [
        td(link(h.link, h.policyName)), td(esc(h.typeLabel)), valueCell(h.value || "(set)"), td(assignmentText(h.assignments)),
      ]))}
    </article>`).join("");
}

$("#deprecated-run").addEventListener("click", () => runInto($("#setting-results"), settingRun,
  "Looking for deprecated settings (the first run reads your policies, which can take a minute)...", async () => {
    const res = await send("settings/deprecated");
    renderIndexLine(res.policies);
    await namesFor(settingGroupIds(res));
    return renderDeprecated(res);
  }));

// ------------------------------------------------------------------------------------------
// Recent changes

let changes = null;
let changesLoading = null;
let shown = null; // rows of the last search, for Copy table and Save CSV

// Every type up front, so it can be picked before the first search.
$("#changes-type").innerHTML = '<option value="">All types</option>' +
  POLICY_TYPES.map((t) => t.label).sort().map((t) => `<option>${esc(t)}</option>`).join("");

async function showChanges() {
  if (!changes) {
    $("#changes-results").innerHTML = loading("Reading your policies (the first time can take a minute)...");
    try {
      if (!changesLoading) changesLoading = send("policies/changes").finally(() => { changesLoading = null; });
      const res = await changesLoading;
      renderIndexLine(res.policies);
      await namesFor([...new Set(res.items.flatMap((i) => i.assignments.map((a) => a.groupId)))]);
      changes = res.items;
    } catch (err) {
      $("#changes-results").innerHTML = errorBox(err);
      return;
    }
  }
  drawChanges();
}

function changesView() {
  const days = Number($("#changes-days").value) || 7;
  const by = $("#changes-by").value;
  const type = $("#changes-type").value;
  const words = searchWords($("#changes-filter").value);
  const since = new Date(Date.now() - days * 864e5).toISOString();
  return changes
    .filter((i) => i[by] && i[by] >= since && (!type || i.typeLabel === type) && hasAllWords(i.name, words))
    .sort((a, b) => b[by].localeCompare(a[by]));
}

const dateAgo = (iso) => (iso ? `${esc(new Date(iso).toLocaleDateString())} <span class="muted small">${esc(checkInText(iso))}</span>` : '<span class="muted">unknown</span>');

function drawChanges() {
  const rows = (shown = changesView());
  const days = Number($("#changes-days").value) || 7;
  const undated = changes.filter((i) => !i.modified).length;
  $("#changes-count").textContent = `${rows.length} of ${changes.length}`;
  showExport("changes", rows.length > 0);
  $("#changes-results").innerHTML = (rows.length
    ? tableHtml(["Name", "Type", "Modified", "Created", "Assigned to"], rows.map((i) => [
      td(link(i.link, i.name)), td(esc(i.typeLabel)), td(dateAgo(i.modified), "nowrap"), td(dateAgo(i.created), "nowrap"), td(assignmentText(i.assignments)),
    ]))
    : emptyBox(`Nothing ${$("#changes-by").value === "created" ? "created" : "changed"} in the last ${days} days.`)) +
    (undated ? `<p class="muted small">${undated} item${undated === 1 ? " has" : "s have"} no dates in Graph, so ${undated === 1 ? "isn't" : "aren't"} listed.</p>` : "");
}

// Runs on Show changes or Enter only, so the period and filters can be set first.
$("#changes-form").addEventListener("submit", (e) => { e.preventDefault(); showChanges(); });

function changesRows() {
  const target = (a) => (a.kind === "allDevices" ? "All devices" : a.kind === "allUsers" ? "All users"
    : `${a.kind === "exclude" ? "Exclude: " : ""}${groupNameCache[a.groupId] || a.groupId}`);
  return [["Name", "Type", "Modified", "Created", "Assigned to", "ID"],
    ...shown.map((i) => [i.name, i.typeLabel, i.modified, i.created, i.assignments.map(target).join("; "), i.id])];
}
bindExport("changes", () => shown && changesRows(), () => "recent-changes.csv");

// ------------------------------------------------------------------------------------------
// Group picker (shared by Group assignments and Group roster)

function setupPicker(name, onPick, search) {
  const root = $(`[data-picker="${name}"]`);
  // A picker written as an empty form gets its box here: data-ph and data-label, or the group search wording.
  if (!root.firstElementChild) root.innerHTML = `<input type="search" placeholder="${esc(root.dataset.ph ?? "Search groups by name, then press Enter")}" autocomplete="off" aria-label="${esc(root.dataset.label ?? "Group")}"><button class="primary" type="submit">Search</button><ul class="picker-list" hidden></ul>`;
  const input = $("input", root);
  const button = $("button", root);
  const list = $(".picker-list", root);
  let items = [];
  let active = -1;
  let empty = "No groups found";

  const close = () => { list.hidden = true; active = -1; };
  const draw = () => {
    list.innerHTML = items.length
      ? items.map((g, i) => `<li role="option" data-i="${i}" aria-selected="${i === active}">${esc(g.displayName)}<span class="sub">${esc(g.userPrincipalName ?? kindOf(g))}</span></li>`).join("")
      : `<li class="muted">${esc(empty)}</li>`;
    list.hidden = false;
  };
  // A user shows with their sign-in name, since the same person can exist under more than one domain.
  const pick = (g) => { input.value = root.dataset.key === "users" && g.userPrincipalName ? `${g.displayName} (${g.userPrincipalName})` : g.displayName; close(); onPick(g); };

  // Searches on Enter or the Search button only, one at a time, so answers can't arrive out of order.
  root.addEventListener("submit", async (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q || button.disabled) return;
    button.disabled = true;
    try {
      const key = root.dataset.key || "groups";
      items = search ? await search(q) : (await send(root.dataset.search || "groups/search", { query: q }))[key] || [];
      empty = `No ${key} found${search ? scopeNote() : ""}`;
    } catch (err) {
      items = [];
      empty = err.message;
    } finally {
      button.disabled = false;
    }
    active = -1;
    draw();
  });
  input.addEventListener("keydown", (e) => {
    if (list.hidden) return;
    if (e.key === "ArrowDown") { active = Math.min(items.length - 1, active + 1); draw(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { active = Math.max(0, active - 1); draw(); e.preventDefault(); }
    else if (e.key === "Enter" && items[active]) { pick(items[active]); e.preventDefault(); }
    else if (e.key === "Escape") close();
  });
  list.addEventListener("click", (e) => {
    const li = e.target.closest("li[data-i]");
    if (li) pick(items[Number(li.dataset.i)]);
  });
  document.addEventListener("click", (e) => { if (!root.contains(e.target)) close(); });
}

const kindOf = (g) => `${groupKind(g, { short: true })}${g.description ? `: ${g.description}` : ""}`;

// ------------------------------------------------------------------------------------------
// Group assignments

// Copy table / Save CSV buttons appear only once a report has rows, on every report.
const showExport = (prefix, on) => { $(`[data-export="${prefix}"]`).hidden = !on; };

const impactRun = newestOnly();
let impactExport = null; // rows and file name of the report on screen, for its Copy table / Save CSV buttons
bindExport("impact", () => impactExport?.rows, () => impactExport.file);

function runImpact(g) {
  return runInto($("#impact-results"), impactRun, "Checking everything that references this group...", async (current) => {
    const { report } = await send("group/impact", { groupId: g.id });
    if (!current()) return;
    impactExport = { rows: impactRows(report), file: `group-assignments-${report.group.name}.csv` };
    return renderImpact(report);
  });
}
setupPicker("impact", runImpact);

// "All devices" / "All users" buttons: Intune assignments only (they are not groups).
function runBroad(target) {
  return runInto($("#impact-results"), impactRun, "Checking what is assigned to this target...", async (current) => {
    const { report } = await send("group/broad", { target });
    if (!current()) return;
    impactExport = { rows: impactRows(report), file: `assigned-to-${report.target.name}.csv` };
    return renderBroad(report);
  });
}
$("#impact-broad").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-broad]");
  if (b) runBroad(b.dataset.broad);
});

function renderBroad(r) {
  return `
    <article class="card">
      <div class="toolbar flush"><h2>${esc(r.target.name)}: Intune assignments</h2><span class="spacer"></span>${r.intune.length ? exportButtons("impact") : ""}</div>
      <p class="muted">${r.intune.length} assigned. Exclusions of groups are not shown here; open the policy to see them. Policy index from ${esc(ago(r.policyIndexBuiltAt))}.</p>
      ${r.policyErrors.length ? `<p class="muted">Some policy types couldn't be read, so this list may be incomplete: ${esc(r.policyErrors.join(", "))}</p>` : ""}
      ${r.intune.length ? tableHtml(["Name", "Type", "Intent", "Filter"], r.intune.map((i) => [
        td(link(i.link, i.policyName)), td(esc(i.typeLabel)), td(esc(i.intent || "")), td(i.filterId ? esc(i.filterType || "yes") : ""),
      ]), undefined, ' style="margin-top:8px"') : '<p class="muted">Nothing is assigned to this target.</p>'}
    </article>`;
}

const ICON = { clear: "✅", "in-use": "⚠️", unknown: "❔" };

function renderImpact(r) {
  const verdictText = {
    clear: ["Looks safe to retire", "Nothing found that references this group."],
    unknown: ["Couldn't check everything", "Nothing found so far, but some checks couldn't run. See below."],
    "in-use": ["In use", "Retiring this group would change what the items below apply to."],
  }[r.verdict];
  const members = (n) => (n === null || n === undefined ? "?" : n.toLocaleString());
  const section = (title, rows) => (rows ? `<h3>${esc(title)}</h3>${rows}` : "");
  const simpleList = (arr, fmt) => (arr?.length ? `<ul>${arr.map((x) => `<li>${fmt(x)}</li>`).join("")}</ul>` : "");

  return `
    <article class="card">
      <h2>${link(r.link, r.group.name)}</h2>
      <div class="muted">${esc(r.group.kind)}${r.group.synced ? ", synced from on-premises" : ""}</div>
      ${r.group.description ? `<div>${esc(r.group.description)}</div>` : ""}
      ${r.group.rule ? `<div class="path">Rule: ${esc(r.group.rule)}</div>` : ""}
      <div class="facts">
        <div><span>Devices (incl. nested)</span>${members(r.members.devices)}</div>
        <div><span>Users (incl. nested)</span>${members(r.members.users)}</div>
        <div><span>Owners</span>${r.owners ? esc(r.owners.join(", ") || "None") : "?"}</div>
        <div><span>Created</span>${r.group.created ? esc(new Date(r.group.created).toLocaleDateString()) : "?"}</div>
      </div>
    </article>

    <div class="verdict ${esc(r.verdict)}"><div>${ICON[r.verdict]}</div><div><strong>${esc(verdictText[0])}</strong>${esc(verdictText[1])}</div></div>

    <article class="card">
      <h2>Retirement checklist</h2>
      <ul class="checklist">${r.checklist.map((c) => `
        <li><span>${ICON[c.status]}</span><span>${esc(c.label)}</span><span>${c.count === null ? "?" : c.count}</span>
        ${c.detail && c.status !== "clear" ? `<span class="detail">${esc(c.detail)}</span>` : ""}</li>`).join("")}
      </ul>
      <p class="muted">Policy index from ${esc(ago(r.policyIndexBuiltAt))}. Refresh it on the Setting check tab if policies changed since.</p>
    </article>

    <article class="card">
      <div class="toolbar flush"><h2>Intune assignments</h2><span class="spacer"></span>${r.intune.length || r.inherited?.length ? exportButtons("impact") : ""}</div>
      ${r.intune.length ? tableHtml(["Name", "Type", "Target", "Intent", "Filter"], r.intune.map((i) => [
        td(link(i.link, i.policyName)), td(esc(i.typeLabel)),
        td(i.kind === "exclude" ? '<span class="badge warn">Exclude</span>' : '<span class="badge">Include</span>'),
        td(esc(i.intent || "")), td(i.filterId ? esc(i.filterType || "yes") : ""),
      ]), undefined, ' style="margin-top:8px"') : `<p class="muted">No Intune policy, app, script or profile is assigned to this group${r.inherited?.length ? " itself" : ""}.</p>`}
      ${r.inherited?.length ? section("Through parent groups", '<p class="muted small">This group is a member of these groups, so its members get what they are assigned too.</p>'
        + tableHtml(["Name", "Type", "Target", "Through", "Intent", "Filter"], r.inherited.map((i) => [
          td(link(i.link, i.policyName)), td(esc(i.typeLabel)),
          td(i.kind === "exclude" ? '<span class="badge warn">Exclude</span>' : '<span class="badge">Include</span>'),
          td(esc(i.viaGroup) + (i.viaPath ? `<div class="muted small">nested, via ${esc(i.viaPath)}</div>` : "")),
          td(esc(i.intent || "")), td(i.filterId ? esc(i.filterType || "yes") : ""),
        ]))) : ""}
      ${section("Conditional Access", simpleList(r.conditionalAccess, (p) => `${esc(p.name)} <span class="muted">(${esc(p.mode)}, ${esc(p.state)})</span>`))}
      ${section("Enterprise apps", simpleList(r.appAssignments, esc))}
      ${section("Licences", simpleList(r.licenses, esc))}
      ${section("Intune role assignments", simpleList(r.roleAssignments, (x) => `${esc(x.name)} <span class="muted">(as ${esc(x.as)})</span>`))}
      ${section("Member of", simpleList(r.parents, (x) => esc(x.displayName)))}
      ${section("Contains groups", simpleList(r.children, (x) => esc(x.displayName)))}
    </article>`;
}

function impactRows(r) {
  return [
    ["Name", "Type", "Target", "Intent", "Filter type", "Through group"],
    ...r.intune.map((i) => [i.policyName, i.typeLabel, i.kind, i.intent, i.filterType, ""]),
    ...(r.inherited || []).map((i) => [i.policyName, i.typeLabel, i.kind, i.intent, i.filterType, i.viaPath ? `${i.viaGroup} (via ${i.viaPath})` : i.viaGroup]),
  ];
}

// ------------------------------------------------------------------------------------------
// Group roster

let roster = null;

const rosterRun = newestOnly();

setupPicker("roster", (g) => {
  $("#roster-tools").hidden = true;
  return runInto($("#roster-results"), rosterRun, "Reading members...", async (current) => {
    const answer = (await send("group/roster", { groupId: g.id })).roster;
    if (!current()) return;
    roster = answer;
    $("#roster-tools").hidden = false;
    drawRoster();
  });
});

function rosterView() {
  if (!roster) return [];
  const words = searchWords($("#roster-filter").value);
  const type = $("#roster-type").value;
  const stale = $("#roster-stale").checked ? Number($("#roster-days").value) || 30 : null;
  return roster.rows.filter((r) => {
    if (type && r.type !== type) return false;
    if (stale !== null) {
      // Devices by their own check-in; users by their most recent device. Users with no devices
      // and groups have nothing to be stale.
      if (r.type === "Group" || (r.type === "User" && !r.deviceCount)) return false;
      const d = ageDays(r.lastCheckIn);
      if (d !== null && d <= stale) return false;
    }
    if (!hasAllWords(rosterHaystack(r), words)) return false;
    return true;
  });
}

// The lowercased text the filter looks in, built once per row (not on every filter run).
const rosterTexts = new WeakMap();
function rosterHaystack(r) {
  let text = rosterTexts.get(r);
  if (text === undefined) {
    text = [r.type, r.name, r.upn, r.primaryUser, r.department, r.jobTitle, r.compliance, r.os, r.osVersion,
      ...(r.devices || []).map((d) => d.name)].filter(Boolean).join(" ").toLowerCase();
    rosterTexts.set(r, text);
  }
  return text;
}

// Rows with a check-in to show: Intune devices, and users by their most recent device.
const hasCheckIn = (r) => (r.type === "Device" && r.intune) || (r.type === "User" && r.deviceCount > 0);

// One definition per column, used by the table, Copy table and Save CSV.
const ROSTER_COLUMNS = [
  ["Type", (r) => r.type],
  ["Name", (r) => r.name],
  ["Primary user / UPN", (r) => (r.type === "Device" ? r.primaryUser : r.upn || "")],
  ["Devices", (r) => (r.type === "User" ? (r.devices || []).map((d) => d.name).join("; ") : "")],
  ["Compliance", (r) => (hasCheckIn(r) ? r.compliance || "" : "")],
  ["OS", (r) => (hasCheckIn(r) ? friendlyOs(r.os?.split(" ")[0], r.osVersion) : "")],
  ["Last check-in", (r) => (hasCheckIn(r) ? checkInText(r.lastCheckIn) : r.type === "Device" ? "not in Intune" : "")],
  ["Department", (r) => r.department || ""],
  ["Job title", (r) => r.jobTitle || ""],
];
const COL = Object.fromEntries(ROSTER_COLUMNS.map(([h, f]) => [h, f]));

function userDevicesCell(r) {
  if (r.type !== "User") return "";
  if (!r.deviceCount) return '<span class="muted">None</span>';
  const shown = r.devices.slice(0, 3).map((d) => `<span class="nowrap">${link(d.link, d.name)}</span>`).join(", ");
  return r.deviceCount > 3 ? `${shown} <span class="muted">+${r.deviceCount - 3} more</span>` : shown;
}

function drawRoster() {
  const rows = rosterView();
  $("#roster-count").textContent = `${rows.length} of ${roster.rows.length}`;
  if (!rows.length) { $("#roster-results").innerHTML = emptyBox("No members match."); return; }
  const hasUsers = rows.some((r) => r.type === "User");
  const head = headCells(["Type", "Name", "Primary user / UPN", ...(hasUsers ? ["Devices"] : []), "Compliance", "OS", "Last check-in"]);
  $("#roster-results").innerHTML = capped(rows, (shownRows) => tableWrap(head, shownRows.map((r) => {
      const sub = r.type === "User" ? [r.jobTitle, r.department].filter(Boolean).join(", ") : "";
      return `<tr>
      <td>${esc(r.type)}</td>
      <td>${r.link ? link(r.link, r.name) : esc(r.name)}${recordsBadge(r.duplicates)}${sub ? `<div class="muted small">${esc(sub)}</div>` : ""}</td>
      <td>${esc(COL["Primary user / UPN"](r))}${r.type === "User" && r.enabled === false ? ' <span class="badge">Disabled</span>' : ""}</td>
      ${hasUsers ? `<td>${userDevicesCell(r)}</td>` : ""}
      <td>${hasCheckIn(r) ? complianceBadge(r.compliance) : ""}</td>
      <td>${esc(COL.OS(r))}</td>
      <td>${hasCheckIn(r) ? checkInCell(r.lastCheckIn) : esc(COL["Last check-in"](r))}</td></tr>`;
  }).join("")));
}

/**
 * Run fn on Enter, and when the box is emptied (its clear button, or deleting the text). Not the "search" event:
 * Firefox never fires it.
 */
function onEnterOrClear(el, fn) {
  el.addEventListener("keydown", (e) => { if (e.key === "Enter") fn(); });
  el.addEventListener("input", () => { if (!el.value) fn(); });
}

// The text filter runs on Enter or when cleared, like the other searches; the dropdown, checkbox and day count
// apply at once.
onEnterOrClear($("#roster-filter"), drawRoster);
["#roster-type", "#roster-stale", "#roster-days"].forEach((sel) => $(sel).addEventListener("input", drawRoster));

function rosterTable() {
  return [ROSTER_COLUMNS.map(([h]) => h).concat("Object ID"), ...rosterView().map((r) => ROSTER_COLUMNS.map(([, f]) => f(r)).concat(r.objectId))];
}
bindExport("roster", () => rosterTable(), () => `group-roster-${roster?.group?.name || "group"}.csv`);

function flash(btn, text) {
  const old = btn.textContent;
  btn.textContent = text;
  setTimeout(() => { btn.textContent = old; }, 1500);
}

const saveCsv = (filename, rows) => download(filename, new Blob(["\uFEFF" + csvText(rows)], { type: "text/csv;charset=utf-8" }));

function download(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement("a"), { href: url, download: filename.replace(/[\\/:*?"<>|]+/g, "_") });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ------------------------------------------------------------------------------------------
// Error code lookup: Microsoft's published error tables, shipped inside the extension (data/error-codes.js).

let ecData = null; // { index, sources, built } once loaded (lazy-data.js)
const ecSource = (i) => ecData?.sources[i] || { label: "Microsoft Learn", url: "" };

/** Loads the error tables the first time they are needed (Error code lookup, Autopilot details). Null if they fail to load. */
async function errorCodes() {
  if (ecData) return ecData;
  try {
    ecData = await loadErrorCodes();
  } catch {
    return null;
  }
  $("#errors-source").textContent = `Adapted from Microsoft Learn (CC BY 4.0), shortened. ${ecData.index.list.length.toLocaleString()} codes, built ${ecData.built}. Not every code is documented.`;
  return ecData;
}

/** A table of matches: code, name, meaning, fix, the page it came from. */
function errorTable(matches, showVia = true) {
  const fixes = matches.some((m) => m.fix); // the Windows system error tables have no fixes
  return tableHtml(["Code", "Name", "Meaning", ...(fixes ? ["Fix"] : []), "Source"], matches.map((m) => [
    td(`<span class="mono">${esc(m.code)}</span>${showVia && m.via ? `<div class="muted small">${esc(m.via)}</div>` : ""}`, "nowrap"),
    td(esc(m.name)), td(esc(m.desc)), ...(fixes ? [td(esc(m.fix))] : []), td(link(ecSource(m.source).url, ecSource(m.source).label)),
  ]));
}

async function runErrorLookup() {
  const text = $("#errors-input").value;
  const out = $("#errors-results");
  const data = await errorCodes();
  if (!data) { out.innerHTML = emptyBox("The error tables could not be loaded. Reload the page and try again."); return; }
  const res = lookupError(text, data.index);
  if (res.kind === "empty") { out.innerHTML = emptyBox("Type an error code or a few words."); return; }
  if (!res.matches.length) {
    out.innerHTML = emptyBox(`${res.kind === "code" ? `No entry for ${res.interpretations.map((i) => i.label).join(" or ")} in Microsoft's published tables.` : "No error text contains all of those words."} The codes Microsoft does not document are not listed. Search the code on the web, or in the device's logs.`);
    return;
  }
  out.innerHTML = errorTable(res.matches, res.kind === "code")
    + (res.more ? `<p class="muted small">${res.more.toLocaleString()} more match. Add words to narrow it down.</p>` : "");
}
$("#errors-form").addEventListener("submit", (e) => { e.preventDefault(); runErrorLookup(); });

/** What the lookup knows about the error codes written in these texts, as a Details section. */
function apErrorCodes(texts) {
  const index = ecData?.index; // loaded when the Autopilot tab opens
  if (!index) return "";
  const rows = [];
  for (const code of [...new Set(texts.flatMap((t) => codesInText(t)))]) {
    const hit = lookupError(code, index).matches[0];
    rows.push(`<tr>${td(`<a href="#errors/${encodeURIComponent(code)}">${esc(code)}</a>`, "nowrap")}${td(esc(hit ? `${hit.name}: ${hit.desc}` : "Not in Microsoft's published tables"))}${td(esc(hit?.fix || ""))}</tr>`);
  }
  return rows.length ? `<h3>Error codes in this event</h3>${tableWrap(headCells(["Code", "Meaning", "Fix"]), rows.join(""))}` : "";
}

// ------------------------------------------------------------------------------------------
// ID decoder

const decodeRun = newestOnly(); // a second lookup started before the first answers wins
$("#decode-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const text = $("#decode-input").value;
  runInto($("#decode-results"), decodeRun, "Looking these up...", async () => {
    const res = await send("ids/decode", { text });
    if (!res.ids.length) return emptyBox(res.message);
    return res.ids.map((x) => `
      <article class="card">
        <h2 class="mono">${esc(x.guid)}</h2>
        ${x.hint ? `<div class="muted">The link labels this as: ${esc(x.hint)}</div>` : ""}
        ${x.matches.length ? tableHtml(["What it is", "Name", "Details"], x.matches.map((m) => [
          td(esc(m.kind)), td(link(m.link, m.name)),
          td(`${esc(m.extra)}${m.assigned ? `<div class="small" style="margin-top:2px">${esc(m.assigned)}</div>` : ""}`),
        ]), undefined, ' style="margin-top:8px"') : '<p class="muted">Not found as any object type this tool checks, or your role can\'t read it.</p>'}
      </article>`).join("") + (!res.policyIndexBuiltAt && res.ids.some((x) => x.matches.some((m) => /polic|profile|script|app|update|configuration|remediation/i.test(m.kind)))
      ? '<p class="muted">Tip: run a Setting check once (it reads your policies) and the decoder will also show who each policy is assigned to.</p>' : "");
  });
});

// ------------------------------------------------------------------------------------------
// Shared table helpers for the report tabs

/**
 * The frame every report table sits in: header cells and body rows as HTML (already escaped), with no header row when
 * head is "". attrs go on the scrolling frame (e.g. ' style="margin-top:8px"').
 */
const tableWrap = (head, body, attrs = "") =>
  `<div class="tablewrap"${attrs}><table>${head ? `<thead><tr>${head}</tr></thead>` : ""}<tbody>${body}</tbody></table></div>`;

/** Header cells from labels: [label | { label, num }]. */
const headCells = (headers) => headers.map((h) => (typeof h === "string" ? `<th>${esc(h)}</th>` : `<th class="${h.num ? "num" : ""}">${esc(h.label)}</th>`)).join("");

/** headers: [label | { label, num }], rows: arrays of cell HTML (already escaped). */
function tableHtml(headers, rows, rowAttrs = () => "", attrs = "") {
  return tableWrap(headCells(headers), rows.map((r, i) => `<tr ${rowAttrs(i)}>${r.join("")}</tr>`).join(""), attrs);
}
const td = (html, cls = "") => `<td${cls ? ` class="${cls}"` : ""}>${html}</td>`;

// Sortable report tables: click a heading to sort, click again to reverse. cols: [{ key, label, num? }];
// state: { key, dir } with dir 1 ascending, -1 descending. Empty values sort last either way; ties keep their order.
function sortRows(rows, cols, state, value) {
  const col = cols.find((c) => c.key === state.key);
  const empty = (v) => v === "" || v === undefined || v === null || Number.isNaN(v);
  return [...rows].sort((a, b) => {
    const x = value(a, state.key);
    const y = value(b, state.key);
    if (empty(x)) return empty(y) ? 0 : 1;
    if (empty(y)) return -1;
    return (col?.num ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true })) * state.dir;
  });
}
const sortHead = (cols, state, attr = "data-sort") => cols.map((c) => `<th ${attr}="${esc(c.key)}" class="${c.num ? "num " : ""}sortable" aria-sort="${state.key === c.key ? (state.dir > 0 ? "ascending" : "descending") : "none"}">${esc(c.label)}${state.key === c.key ? (state.dir > 0 ? " ▲" : " ▼") : ""}</th>`).join("");
/** Fill a platform dropdown, keeping the choice. Redone only when the list of names changed, so a pick isn't reset on every redraw. */
function fillPlatforms(sel, platforms) {
  if (sel.options.length && [...sel.options].slice(1).map((o) => o.value).join("\n") === platforms.join("\n")) return;
  const keep = sel.value;
  sel.innerHTML = '<option value="">All platforms</option>' + platforms.map((p) => `<option>${esc(p)}</option>`).join("");
  sel.value = platforms.includes(keep) ? keep : "";
}
const nextSort = (state, key, firstDir = 1) => ({ key, dir: state.key === key ? -state.dir : firstDir });

async function copyText(btn, text) {
  try {
    await navigator.clipboard.writeText(text);
    flash(btn, "Copied");
  } catch {
    flash(btn, "Copy failed");
  }
}
const copyTsv = (btn, rows) => copyText(btn, tsvText(rows));

const ownerLabel = (o) => ({ company: "Corporate", personal: "Personal" }[o] || o || "");
const userOf = (d) => d.displayName || d.upn || "";

// ------------------------------------------------------------------------------------------
// Device list (shared by OS builds and Stale & duplicates), loaded once per visit

let devicesCache = null;
let devicesLoading = null;

function loadDevices(force = false) {
  if (devicesCache && !force) return Promise.resolve(devicesCache);
  if (!devicesLoading) {
    const want = scope;
    const load = Promise.all([send("devices/list"), scopeIds(force)])
      .then(([res, ids]) => {
        // The scope changed while this was read: read again for the new one, so no list lands in the wrong scope.
        if (scope !== want) { devicesLoading = null; return loadDevices(); }
        // Links and the platform list are made here, once per list, not in the worker or on every redraw.
        for (const d of res.devices) d.link ||= deviceUrl(d.managedId);
        res.total = res.devices.length;
        if (ids) res.devices = res.devices.filter((d) => ids.has(d.managedId)); // the header's scope
        res.platforms = [...new Set(res.devices.map((d) => d.os || "Unknown OS"))].sort();
        devicesCache = res;
        return res;
      })
      .finally(() => { if (devicesLoading === load) devicesLoading = null; });
    devicesLoading = load;
  }
  return devicesLoading;
}

function renderDeviceIndexLine() {
  for (const el of $$(".device-index-line")) {
    el.innerHTML = devicesCache
      ? `Device list: ${devicesCache.devices.length.toLocaleString()}${scope ? ` of ${devicesCache.total.toLocaleString()}` : ""} devices${scope ? ` (scope: ${esc(scope.name)})` : ""}, updated ${esc(ago(devicesCache.builtAt))}. <button class="link" data-refresh-devices>Refresh</button>`
      : "";
  }
}

document.addEventListener("click", async (e) => {
  if (!e.target.closest?.("[data-refresh-devices]")) return;
  for (const el of $$(".device-index-line")) el.innerHTML = '<span class="spinner"></span>Reading devices...';
  try {
    if (!SAMPLE) await send("index/rebuild");
    await loadDevices(true);
    showDeviceTab(currentTab);
  } catch (err) {
    for (const el of $$(".device-index-line")) el.textContent = err.message;
  }
});

/** The tools drawn from the device list (devices/list), redrawn when it is refreshed or the scope changes. */
const DEVICE_TABS = ["os", "hygiene", "storage", "explorer"];

async function showDeviceTab(name) {
  const out = $(name === "os" ? "#os-results" : name === "storage" ? "#storage-results" : name === "explorer" ? "#explorer-results" : "#stale-results");
  if (!devicesCache) {
    out.innerHTML = loading("Reading your devices...");
    if (name === "hygiene") $("#dupe-results").innerHTML = "";
  }
  try {
    await loadDevices();
  } catch (err) {
    out.innerHTML = errorBox(err);
    return;
  }
  renderDeviceIndexLine();
  if (name === "os") renderOs();
  else if (name === "storage") renderStorage();
  else if (name === "explorer") renderExplorer();
  else renderHygiene();
}

// Device explorer: every device in the device list, with the columns the admin picks (saved as explorerColumns).

let exSort = { key: "name", dir: 1 };
let exColumns = EXPLORER_DEFAULT;

/** Take the column choice from the saved prefs. */
function applyExplorerColumns(prefs) {
  exColumns = Array.isArray(prefs.explorerColumns) && prefs.explorerColumns.length ? prefs.explorerColumns : EXPLORER_DEFAULT;
  if (currentTab === "explorer" && devicesCache) renderExplorer();
}

/** The explorer's columns (only fields some device has), its matching rows in sort order, and every row. */
function exView() {
  const all = devicesCache.devices.map((d) => explorerRow(d, globalThis.IEWindowsBuilds?.friendly));
  const present = hardwareColumns(all, EXPLORER_FIELDS);
  const cols = present.filter((f) => f.key === "name" || exColumns.includes(f.key));
  const words = searchWords($("#ex-filter").value);
  const rows = sortRows(all.filter((r) => hasAllWords(cols.map((c) => r[c.key]).join("\n"), words)), cols, exSort, (r, key) => r[key]);
  return { all, present, cols, rows };
}

function renderExplorer() {
  const { all, present, cols, rows } = exView();
  $("#ex-cols").innerHTML = present.map((f) => `<label class="inline"><input type="checkbox" data-ex-col="${esc(f.key)}"${cols.includes(f) ? " checked" : ""}${f.key === "name" ? " disabled" : ""}> ${esc(f.label)}</label>`).join("");
  $("#ex-count").textContent = `${rows.length.toLocaleString()} of ${all.length.toLocaleString()} devices`;
  showExport("explorer", rows.length > 0);
  $("#explorer-results").innerHTML = rows.length
    ? capped(rows, (shown) => tableWrap(sortHead(cols, exSort, "data-ex-sort"), shown.map((r) => `<tr>${cols.map((c) => td(c.key === "name" ? link(r.link, r.name) : esc(r[c.key] ?? ""),
      c.num ? "num" : c.nowrap ? "nowrap" : "")).join("")}</tr>`).join("")), 2000)
    : emptyBox("No device matches the filter.");
}

onEnterOrClear($("#ex-filter"), renderExplorer);
$("#ex-cols").addEventListener("change", () => {
  exColumns = $$("[data-ex-col]:checked", $("#ex-cols")).map((el) => el.dataset.exCol);
  savePrefs({ explorerColumns: exColumns }).catch((e) => showBanner(`Couldn't save the columns: ${e.message}`));
  renderExplorer();
});
$("#explorer-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-ex-sort]");
  if (th) { exSort = nextSort(exSort, th.dataset.exSort); renderExplorer(); }
});
bindExport("explorer", () => {
  const { cols, rows } = exView();
  return [cols.map((c) => c.label), ...rows.map((r) => cols.map((c) => r[c.key] ?? ""))];
}, () => "devices.csv");

// ------------------------------------------------------------------------------------------
// OS builds

let spread = null;

/** A table cell with a bar `value` / `max` long, and `title` on hover (OS builds, Update check). */
const barCell = (value, max, title) => td(`<div class="bar" title="${esc(title)}"><span style="width:${max ? (value / max * 100).toFixed(1) : 0}%"></span></div>`);

/** Opens or closes the hidden row under a Show button, filling it with fill() the first time it opens. labels: [closed, open]. */
function toggleSubRow(btn, row, fill, [closed, open]) {
  row.hidden = !row.hidden;
  btn.textContent = row.hidden ? closed : open;
  if (!row.hidden && !row.firstElementChild.innerHTML) row.firstElementChild.innerHTML = fill();
}

/** The devices under an OS builds or Update check row: the first 1,000, and a note when there are more. */
const releaseDeviceTable = (list) => tableHtml(["Device", "Primary user", "OS version", "Compliance", "Last check-in"], list.slice(0, 1000).map((d) => [
  td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
  td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)),
])) + (list.length > 1000 ? `<p class="muted small" style="margin:6px 10px">Showing 1,000 of ${list.length}. Copy or save includes all.</p>` : "");

function renderOs() {
  spread = osSpread(devicesCache.devices, globalThis.IEWindowsBuilds?.friendly);
  if (upd && upd.list !== devicesCache) { upd = null; $("#upd-results").innerHTML = ""; } // a refreshed list or a new scope
  if (!spread.total) { $("#os-results").innerHTML = emptyBox("No managed devices."); return; }
  $("#os-results").innerHTML = spread.platforms.map((p, pi) => {
    const top = Math.max(...p.releases.map((r) => r.count));
    const rows = p.releases.flatMap((r, ri) => [
      [
        td(esc(r.label)),
        td(r.count.toLocaleString(), "num"),
        td(`${(r.count / p.count * 100).toFixed(r.count / p.count < 0.1 ? 1 : 0)}%`, "num"),
        barCell(r.count, top, `${r.count} of ${p.count} ${p.os} devices`),
        td(`<button class="link" data-os="${pi}:${ri}">Show devices</button>`),
      ],
      [`<td colspan="5" data-os-sub="${pi}:${ri}"></td>`],
    ]);
    return `<article class="card">
      <h2>${esc(p.os)} <span class="muted">· ${p.count.toLocaleString()} device${p.count === 1 ? "" : "s"} (${(p.count / spread.total * 100).toFixed(0)}% of all)</span></h2>
      ${tableHtml(["Release", { label: "Devices", num: true }, { label: "Share", num: true }, "", ""], rows, (i) => (i % 2 ? 'class="sub" hidden' : ""))}
    </article>`;
  }).join("");
}

$("#os-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-os]");
  if (btn) {
    toggleSubRow(btn, $(`[data-os-sub="${btn.dataset.os}"]`).parentElement, () => {
      const [pi, ri] = btn.dataset.os.split(":").map(Number);
      const rel = spread.platforms[pi].releases[ri];
      return `<div class="toolbar" style="margin:8px 10px">
          <strong>${esc(rel.label)}</strong><span class="spacer"></span>
          <button data-os-copy="${btn.dataset.os}">Copy table</button><button data-os-csv="${btn.dataset.os}">Save CSV</button></div>` +
        releaseDeviceTable([...rel.devices].sort((a, b) => a.name.localeCompare(b.name)));
    }, ["Show devices", "Hide devices"]);
    return;
  }
  const exp = e.target.closest("button[data-os-copy], button[data-os-csv]");
  if (!exp) return;
  const [pi, ri] = (exp.dataset.osCopy || exp.dataset.osCsv).split(":").map(Number);
  const rel = spread.platforms[pi].releases[ri];
  const rows = [["Device", "Primary user", "UPN", "OS", "OS version", "Release", "Compliance", "Last check-in"],
    ...rel.devices.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, rel.label, d.compliance, d.lastSync])];
  if (exp.dataset.osCopy) copyTsv(exp, rows);
  else saveCsv(`os-build-${rel.label}.csv`, rows);
});

// Update check (OS builds): Windows devices behind the newest build on your devices, or a build typed. Runs on Enter or
// the button, from the device list the tab already reads (no Graph read of its own).
let upd = null; // { list: the devicesCache it was worked out from, result: updateCheck() }

$("#upd-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const out = $("#upd-results");
  try {
    if (!devicesCache) out.innerHTML = loading("Reading your devices...");
    await loadDevices();
  } catch (err) { out.innerHTML = errorBox(err); return; }
  const result = updateCheck(devicesCache.devices, globalThis.IEWindowsBuilds?.friendly, $("#upd-build").value);
  upd = result.error ? null : { list: devicesCache, result };
  out.innerHTML = result.error ? emptyBox(result.error) : renderUpdateCheck(result);
});

/** The Update check card: one row per Windows release, with its behind devices under a Show behind row. */
function renderUpdateCheck(r) {
  if (!r.releases.length) {
    return emptyBox(r.target ? `No Windows device in the device list is on build ${r.target.split(".")[0]}.` : "No Windows device in the device list reports a build.");
  }
  const rows = r.releases.flatMap((rel, i) => {
    const total = rel.have + rel.behind.length;
    return [[
      td(esc(rel.label)), td(esc(rel.build)), td(rel.have.toLocaleString(), "num"),
      td(`<span class="badge ${rel.behind.length ? "bad" : "ok"}">${rel.behind.length.toLocaleString()}</span>`, "num"),
      barCell(rel.have, total, `${rel.have} of ${total} up to date`),
      td(rel.behind.length ? `<button class="link" data-upd="${i}">Show behind</button>` : ""),
    ], [`<td colspan="6" data-upd-sub="${i}"></td>`]];
  });
  const unknown = r.releases.reduce((n, rel) => n + rel.unknown, 0);
  const notes = [
    r.target ? "" : "Each release is checked against the newest build any of your devices on it reports, which may be an optional preview update. Type a build to check against a specific one (Microsoft's Windows release information page lists the build for each update).",
    r.others.length ? `Not checked against this build: ${r.others.map((o) => `${o.label} (${o.count})`).join(", ")}. Each release has its own build numbers.` : "",
    unknown ? `${unknown} device${unknown === 1 ? "" : "s"} reported no build revision and ${unknown === 1 ? "is" : "are"} left out.` : "",
    "Every monthly Windows update raises the build, so a device below it is missing that update or a later one. Other updates (.NET, Office) don't change the build.",
  ].filter(Boolean);
  return `<article class="card">
    <div class="toolbar tight"><h2 style="margin:0">Update check</h2>
      <span class="muted">${r.target ? `against build ${esc(r.target)}` : "against the newest build on your devices, per release"}</span>
      <span class="spacer"></span>${exportButtons("upd")}</div>
    ${tableHtml(["Release", "Checked against", { label: "Up to date", num: true }, { label: "Behind", num: true }, "", ""], rows, (i) => (i % 2 ? 'class="sub" hidden' : ""))}
    ${notes.map((n) => `<p class="muted small" style="margin:8px 0 0">${esc(n)}</p>`).join("")}
  </article>`;
}

$("#upd-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-upd]");
  if (!btn || !upd) return;
  toggleSubRow(btn, $(`[data-upd-sub="${btn.dataset.upd}"]`).parentElement,
    () => releaseDeviceTable(upd.result.releases[Number(btn.dataset.upd)].behind), ["Show behind", "Hide"]);
});

// Update check's Copy table and Save CSV: every Windows device checked, with whether it is up to date.
bindExport("upd", () => upd && [["Device", "Primary user", "UPN", "Release", "OS version", "Checked against", "Status", "Compliance", "Last check-in"],
  ...upd.result.releases.flatMap((rel) => {
    const behind = new Set(rel.behind);
    return rel.devices.map((d) => [d.name, d.displayName, d.upn, rel.label, d.osVersion, rel.build, behind.has(d) ? "Behind" : "Up to date", d.compliance, d.lastSync]);
  })], () => `update-check${upd?.result.target ? `-${upd.result.target}` : ""}.csv`);

// ------------------------------------------------------------------------------------------
// Compliance breakdown

let compData = null;
let compDevices = null;
const compRun = newestOnly();

function renderCompliance(r) {
  if (!r.rows.length) return emptyBox(`No compliance setting is failing on any device${r.passing ? ` (${r.passing.toLocaleString()} settings checked)` : ""}.`);
  return `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${r.rows.length.toLocaleString()} failing setting${r.rows.length === 1 ? "" : "s"}; ${r.passing.toLocaleString()} with no failures</span>
      <span class="spacer"></span>
      ${exportButtons("comp")}
    </div>` +
    tableHtml(["Setting", "Platform", { label: "Failing", num: true }, { label: "Not compliant", num: true }, { label: "Error", num: true }, { label: "Conflict", num: true }, { label: "Compliant", num: true }, ""],
      r.rows.map((x) => [td(esc(x.setting)), td(esc(x.platform)), td(`<strong>${x.failing.toLocaleString()}</strong>`, "num"), td(x.nonCompliant.toLocaleString(), "num"),
        td(x.error.toLocaleString(), "num"), td(x.conflict.toLocaleString(), "num"), td(x.compliant.toLocaleString(), "num"),
        td(`<button class="link" data-comp="${esc(x.id)}" data-name="${esc(x.setting)}">Devices</button>`)])) + "</article>";
}

function compRows() {
  return [["Setting", "Platform", "Failing", "Not compliant", "Error", "Conflict", "Compliant"],
    ...(compData?.rows || []).map((x) => [x.setting, x.platform, x.failing, x.nonCompliant, x.error, x.conflict, x.compliant])];
}

function compDeviceRows() {
  return [["Device", "User", "UPN", "State", "OS", "Last check-in"], ...(compDevices?.list || []).map((d) => [d.name, d.user, d.upn || "", d.state, d.os, d.lastSync])];
}

function renderCompDevices(name, list) {
  return `<article class="card">
    <div class="toolbar tight">
      <h2>${esc(name)}: ${list.length.toLocaleString()} failing device${list.length === 1 ? "" : "s"}${esc(scopeNote())}</h2>
      <span class="spacer"></span>
      ${exportButtons("compdev")}
    </div>` + (list.length
      ? capped(list, (rows) => tableHtml(["Device", "User", "State", "OS", "Last check-in"], rows.map((d) => [td(d.inList ? link(d.link, d.name) : esc(d.name), "nowrap"), td(esc(d.user)), td(esc(d.state)), td(esc(d.os)), td(d.lastSync ? checkInCell(d.lastSync) : '<span class="muted">unknown</span>')])))
      : '<p class="muted">No device is failing this setting now.</p>') + "</article>";
}

$("#comp-run").addEventListener("click", () => {
  $("#comp-devices").innerHTML = "";
  runInto($("#comp-results"), compRun, "Reading compliance results...", async (current) => {
    const r = await send("compliance/summary");
    if (!current()) return;
    compData = r;
    return renderCompliance(r);
  });
});
$("#comp-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-comp]");
  if (!pick) return;
  const out = $("#comp-devices");
  runInto(out, compRun, "Reading the devices failing this setting...", async (current) => {
    const { devices: all } = await send("compliance/devices", { id: pick.dataset.comp });
    const devices = await scoped(all); // a device not in the device list has no Intune id, so a scope leaves it out
    if (!current()) return;
    compDevices = { list: devices };
    out.innerHTML = renderCompDevices(pick.dataset.name, devices);
    out.scrollIntoView({ behavior: "smooth", block: "nearest" });
  });
});
bindExport("comp", () => compRows(), () => "compliance-breakdown.csv");
bindExport("compdev", () => compDeviceRows(), () => "compliance-failing-devices.csv");

// Hardware report


const HW_CHUNK = 100; // devices per request to the worker, so progress and Stop respond between chunks
const HW_SHOWN = 1000;
let hwData = null; // { at, rows } as saved
let hwSort = { key: "name", dir: 1 };
let hwStop = false;

/** The Hardware rows inside the header's scope (a saved report may cover more devices). */
const hwRows = () => (hwData?.rows || []).filter((r) => !scope?.ids || scope.ids.has(r.id));
function renderHardware() {
  const out = $("#hw-results");
  const rows = hwRows();
  if (!rows.length) { out.innerHTML = emptyBox(hwData?.rows.length ? "No device in the scope group is in this report. Run it again." : "Nothing read yet."); return; }
  const cols = hardwareColumns(rows);
  const sorted = sortRows(rows, cols, hwSort, (r, key) => r[key]);
  const head = sortHead(cols, hwSort, "data-hw-sort");
  out.innerHTML = `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${rows.length.toLocaleString()} devices, read ${esc(ago(hwData.at))}. Click a heading to sort.</span>
      <span class="spacer"></span>
      ${exportButtons("hw")}
    </div>
    ${capped(sorted, (rows) => tableWrap(head, rows.map((r) => `<tr>${cols.map((c) => td(esc(r[c.key] ?? ""), c.num ? "num" : c.nowrap ? "nowrap" : "")).join("")}</tr>`).join("")), HW_SHOWN)}
  </article>`;
}

function hwTableRows() {
  const cols = hardwareColumns(hwRows());
  return [cols.map((c) => c.label), ...sortRows(hwRows(), cols, hwSort, (r, key) => r[key]).map((r) => cols.map((c) => r[c.key] ?? ""))];
}

const runHardware = oneAtATime([$("#hw-run"), $("#posture-run")], async () => {
  hwStop = false;
  const out = $("#hw-results");
  out.innerHTML = loading("Reading your devices...");
  $("#posture-results").innerHTML = loading("Reading every device's record. Stop keeps what is read so far.");
  const rows = [];
  let failed = 0;
  try {
    await loadDevices();
    const ids = [...new Set(devicesCache.devices.map((d) => d.managedId).filter(Boolean))];
    for (let i = 0; i < ids.length && !hwStop; i += HW_CHUNK) {
      jobBar.set("hardware", { label: "Reading hardware", done: i, total: ids.length, stop: () => { hwStop = true; } });
      out.innerHTML = loading("Reading hardware for every device. Stop keeps what is read so far.");
      const res = await send("hardware/read", { ids: ids.slice(i, i + HW_CHUNK) });
      rows.push(...res.rows);
      failed += res.failed;
    }
    hwData = { at: Date.now(), rows };
    // Only a finished run replaces the saved report: a stopped one is shown but not saved, so a long earlier run isn't lost.
    if (!hwStop) await send("hardware/save", { rows });
    jobBar.done("hardware", hwStop ? `Stopped. Showing ${rows.length.toLocaleString()} of ${ids.length.toLocaleString()} devices; the saved report is unchanged.` : "");
    renderHardware();
    renderPosture();
    if (failed) out.insertAdjacentHTML("afterbegin", `<p class="muted small">${failed.toLocaleString()} devices couldn't be read and are left out.</p>`);
    if (hwStop) out.insertAdjacentHTML("afterbegin", '<p class="muted small">Stopped early: this is a partial list.</p>');
  } catch (err) {
    out.innerHTML = errorBox(err);
    jobBar.done("hardware"); // on success the try ended the job, with its "Stopped. Kept ..." message when stopped
    $("#posture-results").innerHTML = errorBox(err);
  }
});

async function loadSavedHardware() {
  try {
    const { saved } = await send("hardware/load");
    if (saved && !runHardware.busy()) {
      hwData = saved;
      if (scope) await scopeIds().catch(() => {}); // filter the saved report to the scope
      renderHardware();
      renderPosture();
    }
  } catch { /* nothing saved, or no session yet: the button still works */ }
}

$("#hw-run").addEventListener("click", runHardware);
$("#posture-run").addEventListener("click", runHardware);
$("#job-stop").addEventListener("click", () => jobBar.stop());
$("#hw-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-hw-sort]");
  if (th) {
    hwSort = { key: th.dataset.hwSort, dir: hwSort.key === th.dataset.hwSort ? -hwSort.dir : 1 };
    renderHardware();
    return;
  }
});
bindExport("hw", () => hwTableRows(), () => "hardware.csv");

// Security posture: the Hardware report's security columns (one read serves both tabs), what needs attention, counts.

let posSort = { key: "issues", dir: -1 };
const POSTURE_COUNT_BADGES = { pass: ["ok", "Pass"], fail: ["bad", "Fail"], unknown: ["", "Not reported"] };

/**
 * Windows and macOS rows of the Hardware report (in the scope), each with its issues. allCols: every posture column some
 * device has (Copy table, CSV); cols: those without the detail ones, with Needs attention after the user (the screen).
 */
function posView() {
  const rows = hwRows().filter((r) => /windows|mac/i.test(r.os || "")).map((r) => ({ ...r, issues: postureIssues(r).join("; ") }));
  const present = hardwareColumns(rows, POSTURE_FIELDS);
  const issues = { key: "issues", label: "Needs attention" };
  const lead = present.filter((c) => c.key === "name" || c.key === "user");
  const cols = [...lead, issues, ...present.filter((c) => !c.detail && !lead.includes(c))];
  const allCols = [...lead, issues, ...present.filter((c) => !lead.includes(c))];
  const shown = $("#posture-show")?.value === "all" ? rows : rows.filter((r) => r.issues);
  return { rows, cols, allCols, shown: sortRows(shown, allCols, posSort, (r, key) => r[key]) };
}

function renderPosture() {
  const out = $("#posture-results");
  if (!hwData) { out.innerHTML = emptyBox("Nothing read yet. Read every device, or run the Hardware report: both use the same read."); return; }
  const { rows, cols, shown } = posView();
  if (!rows.length) { out.innerHTML = emptyBox("No Windows or macOS device is in this report."); return; }
  const c = postureCounts(rows);
  const old = !rows.some((r) => "credGuard" in r);
  const keep = $("#posture-show")?.value || "attention";
  out.innerHTML = `<article class="card">
      <p><strong>${c.withIssues.toLocaleString()}</strong> of ${c.devices.toLocaleString()} Windows and macOS devices need attention. Read ${esc(ago(hwData.at))}.</p>
      ${old ? '<p class="warn small">This saved report is from before Security posture: read again to add the security details.</p>' : ""}
      ${tableHtml(["Check", "Devices"], c.checks.map((k) => [td(esc(k.label), "nowrap"), td(badgeCounts(POSTURE_COUNT_BADGES, k))]))}
      <div class="toolbar">
        <label>Show <select id="posture-show"><option value="attention">Needs attention</option><option value="all">All</option></select></label>
        <span class="muted small">${shown.length.toLocaleString()} shown</span>
        <span class="spacer"></span>
        ${exportButtons("posture")}
      </div>
      ${shown.length ? capped(shown, (list) => tableWrap(sortHead(cols, posSort, "data-pos-sort"), list.map((r) => `<tr>${cols.map((col) => td(esc(r[col.key] ?? ""),
        col.nowrap ? "nowrap" : col.key === "issues" && r.issues ? "warn" : "")).join("")}</tr>`).join("")), 1000) : emptyBox("Nothing needs attention.")}
      <p class="muted small">From each device's own record (Device Health Attestation, Device Guard) and Intune's encryption report. Blank means Intune didn't report it, which isn't counted as a problem.</p>
    </article>`;
  $("#posture-show").value = keep;
}

$("#posture-results").addEventListener("input", (e) => { if (e.target.id === "posture-show") renderPosture(); });
$("#posture-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-pos-sort]");
  if (th) { posSort = nextSort(posSort, th.dataset.posSort); renderPosture(); }
});
bindExport("posture", () => {
  const { allCols, shown } = posView();
  return [allCols.map((c) => c.label), ...shown.map((r) => allCols.map((c) => r[c.key] ?? ""))];
}, () => "security-posture.csv");

// Duplicate policies

let dupPolReport = null;
const dupPolRun = newestOnly();
const DUP_POL_MATCH = { identical: ["bad", "Identical"], inside: ["warn", "One is inside the other"], partial: ["", "Partly the same"] };

function renderDupPolicies(r) {
  if (!r.pairs.length) return emptyBox("No two policies set the same values.");
  return `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${r.total.toLocaleString()} pair${r.total === 1 ? "" : "s"}${r.total > r.pairs.length ? `, showing the first ${r.pairs.length}` : ""}${r.skippedValues
        ? `. ${r.skippedValues.toLocaleString()} setting value${r.skippedValues === 1 ? " is" : "s are"} set by so many policies that ${r.skippedValues === 1 ? "it isn't" : "they aren't"} counted in Same settings` : ""}${r.partialPolicies?.length
        ? `. Only part of the settings of ${esc(r.partialPolicies.join(", "))} could be read, so their matches may be off; rebuild the policy list to try again` : ""}</span>
      <span class="spacer"></span>
      ${exportButtons("dupes")}
    </div>` +
    tableHtml(["Policy", "Other policy", "Same settings", "Match", "Same assignments", "Examples"], r.pairs.map((p) => [
      td(link(p.a.link, p.a.name) + `<div class="muted small">${esc(p.a.typeLabel)}</div>`), td(link(p.b.link, p.b.name) + `<div class="muted small">${esc(p.b.typeLabel)}</div>`),
      td(`${p.shared} of ${p.sizeA} and ${p.sizeB}`, "nowrap"), td(badge(DUP_POL_MATCH, p.match)),
      td(p.sameAssignments ? "Yes" : "No"), td(esc(p.sample.join("; ")), "small")])) + "</article>";
}

function dupPolRows() {
  return [["Policy", "Type", "Other policy", "Other type", "Same settings", "Settings in first", "Settings in second", "Match", "Same assignments", "Examples"],
    ...(dupPolReport?.pairs || []).map((p) => [p.a.name, p.a.typeLabel, p.b.name, p.b.typeLabel, p.shared, p.sizeA, p.sizeB, DUP_POL_MATCH[p.match][1], p.sameAssignments ? "Yes" : "No", p.sample.join("; ")])];
}

$("#dupes-run").addEventListener("click", () => runInto($("#dupes-results"), dupPolRun,
  "Comparing every policy. The first time, the policy index can take a few minutes to build...", async (current) => {
    const r = await send("policies/duplicates");
    if (!current()) return;
    dupPolReport = r;
    return renderDupPolicies(r);
  }));
bindExport("dupes", () => dupPolRows(), () => "duplicate-policies.csv");

// Policy export

let polDoc = null;
const polRun = newestOnly();

/**
 * Shared by Policy export and App details: search the policy index by name (only apps when apps is true) and either
 * open the one hit or list up to 50 to pick from. The pick buttons carry `attr` (data-pol / data-app).
 */
function findIndexed({ q, out, newRun, apps = false, attr, open }) {
  return runInto(out, newRun, "Searching the policy index. The first time, it can take a few minutes to build...", async (current) => {
    const { policies, total } = await send("policy/find", { query: q, apps });
    if (!current()) return;
    if (policies.length === 1) { open(policies[0].id); return; }
    return policies.length
      ? `<article class="card"><p class="muted">${total.toLocaleString()} ${apps ? "apps" : "policies"} match. Pick one.</p>` +
        tableHtml([apps ? "App" : "Policy", "Type"], policies.map((p) => [td(`<button class="link" ${attr}="${esc(p.id)}">${esc(p.name)}</button>`, "nowrap"), td(esc(p.typeLabel))])) +
        (total > policies.length ? `<p class="muted small">Showing the first ${policies.length}. Type more of the name.</p>` : "") + "</article>"
      : emptyBox(apps ? "No assigned app has that in its name." : "No policy has that in its name.");
  });
}

function findPolicy() {
  const q = $("#polexp-query").value.trim();
  if (!q) return;
  return findIndexed({ q, out: $("#polexp-results"), newRun: polRun, attr: "data-pol", open: openPolicy });
}

function openPolicy(id) {
  return runInto($("#polexp-results"), polRun, "Reading the policy...", async (current) => {
    const { policy, names, filters } = await send("policy/get", { id });
    if (!current()) return;
    polDoc = policyDocument(policy, names, filters);
    return `<article class="card">
      <div class="toolbar tight">
        <h2>${link(policy.link, polDoc.title)}</h2>
        <span class="spacer"></span>
        <button id="polexp-md">Copy Markdown</button>
        ${exportButtons("polexp")}
      </div>
      ${polDoc.hasSettings ? "" : '<p class="muted small">This type of policy has no settings in the index.</p>'}
      <pre class="path" style="white-space:pre-wrap">${esc(polDoc.markdown)}</pre>
    </article>`;
  });
}

$("#polexp-find").addEventListener("click", findPolicy);
onEnterOrClear($("#polexp-query"), findPolicy);
$("#polexp-results").addEventListener("click", async (e) => {
  const pick = e.target.closest("button[data-pol]");
  if (pick) { openPolicy(pick.dataset.pol); return; }
  if (!polDoc) return;
  if (e.target.closest("#polexp-md")) copyText(e.target.closest("#polexp-md"), polDoc.markdown);
});
bindExport("polexp", () => polDoc?.rows, () => `policy-${polDoc.title.replace(/[^\w.-]+/g, "-")}.csv`);

// App details: one app's detection and requirement rules, commands, return codes, dependencies and assignments.

let appDoc = null;
const appRun = newestOnly();

function findApp() {
  const q = $("#appdet-query").value.trim();
  if (!q) return;
  return findIndexed({ q, out: $("#appdet-results"), newRun: appRun, apps: true, attr: "data-app", open: openApp });
}

function openApp(id) {
  return runInto($("#appdet-results"), appRun, "Reading the app...", async (current) => {
    const [{ policy, names, filters }, { app, relationships }] = await Promise.all([send("policy/get", { id }), send("app/details", { id })]);
    if (!current()) return;
    const sections = appSections(app, relationships);
    appDoc = policyDocument(policy, names, filters, sections);
    const assignments = appDoc.rows.filter((r) => r[0] === "Assignment").map((r) => r[1]);
    const card = (title, body) => `<article class="card"><h2>${esc(title)}</h2>${body}</article>`;
    return `<article class="card">
      <div class="toolbar tight">
        <h2>${link(policy.link, appDoc.title)}</h2>
        <span class="spacer"></span>
        <button id="appdet-md">Copy Markdown</button>
        ${exportButtons("appdet")}
      </div>
    </article>
    ${sections.map((s) => card(s.title, kvTable(s.rows) + (s.code || []).map((c) => `<h3>${esc(c.name)}</h3><pre class="path" style="white-space:pre-wrap">${esc(c.text)}</pre>`).join(""))).join("")}
    ${card("Assignments", `<ul>${assignments.map((a) => `<li>${esc(a)}</li>`).join("")}</ul>`)}`;
  });
}

$("#appdet-find").addEventListener("click", findApp);
onEnterOrClear($("#appdet-query"), findApp);
$("#appdet-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-app]");
  if (pick) { openApp(pick.dataset.app); return; }
  if (appDoc && e.target.closest("#appdet-md")) copyText(e.target.closest("#appdet-md"), appDoc.markdown);
});
bindExport("appdet", () => appDoc?.rows, () => `app-${appDoc.title.replace(/[^\w.-]+/g, "-")}.csv`);

// Compare devices

const cmpDevPicked = {};
let cmpDevReport = null;
const cmpDevRun = newestOnly();
const CMP_DEV_STATE = { applies: "Applies", filter: "Depends on filter", uncertain: "Uncertain", excluded: "Excluded" };

for (const side of ["cmpda", "cmpdb"]) {
  setupPicker(side, (d) => { cmpDevPicked[side] = d; $("#cmpdevices-run").disabled = !(cmpDevPicked.cmpda && cmpDevPicked.cmpdb); },
    async (q) => { await loadDevices(); return matchDevices(q).slice(0, 25).map(pickerDevice); }); // the Workspace scope applies
  // Typing in the box drops the earlier pick, so Run never compares a device the box no longer shows.
  $(`[data-picker="${side}"] input`).addEventListener("input", () => { cmpDevPicked[side] = null; $("#cmpdevices-run").disabled = true; });
}

function renderCompareDevices(r) {
  const a = r.a.name;
  const b = r.b.name;
  const how = (g) => (g.direct ? "direct" : `nested${g.via ? `, via ${g.via}` : ""}`);
  const groupCards = (title, g) => {
    if (g.unreadable) return `<article class="card"><h2>${esc(title)}</h2><p class="muted">Couldn't be read for one of the devices, so nothing is compared.</p></article>`;
    const list = (groups, none, text) => (groups.length ? `<ul>${groups.map((x) => `<li>${link(x.link, x.name)} <span class="muted">${esc(text(x))}</span></li>`).join("")}</ul>` : `<p class="muted">${esc(none)}</p>`);
    return `<article class="card"><h2>${esc(title)}</h2>
      <h3>In both (${g.both.length})</h3>${list(g.both, "None in common.", (x) => `${a}: ${how(x)}; ${b}: ${how(x.other)}`)}
      <h3>Only ${esc(a)} (${g.onlyA.length})</h3>${list(g.onlyA, "None.", how)}
      <h3>Only ${esc(b)} (${g.onlyB.length})</h3>${list(g.onlyB, "None.", how)}</article>`;
  };
  const p = r.policies;
  const state = (s) => esc(CMP_DEV_STATE[s] || "");
  const notAssigned = '<span class="muted">not assigned</span>';
  const polTable = (title, list, headers, cols) => `<h3>${esc(title)} (${list.length})</h3>` + (list.length
    ? tableHtml(headers, list.map((x) => [td(link(x.link, x.name)), td(esc(x.typeLabel)), ...cols(x)])) : '<p class="muted">None.</p>');
  const notes = r.notes.length ? `<article class="card"><h2>Not everything could be checked</h2><ul>${r.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul></article>` : "";
  const unknown = '<span class="muted">unknown</span>';
  return `${notes}
    <article class="card"><h2>Details</h2>${tableHtml(["", a, b], r.facts.map((f) => [td(esc(f.label)), td(esc(f.a) || unknown, f.differs ? "differs" : ""), td(esc(f.b) || unknown, f.differs ? "differs" : "")]))}</article>
    ${groupCards("Device groups", r.deviceGroups)}
    ${groupCards("Primary users' groups", r.userGroups)}
    <article class="card">
      <div class="toolbar tight"><h2>Policies, apps and scripts</h2><span class="spacer"></span>
        ${exportButtons("cmpdevices")}</div>
      ${polTable("Reach both", p.both, ["Name", "Type", a, b], (x) => [td(state(x.stateA)), td(state(x.stateB))])}
      ${polTable(`Only ${a}`, p.onlyA, ["Name", "Type", "State", `On ${b}`], (x) => [td(state(x.state)), td(x.otherState ? state(x.otherState) : notAssigned)])}
      ${polTable(`Only ${b}`, p.onlyB, ["Name", "Type", "State", `On ${a}`], (x) => [td(state(x.state)), td(x.otherState ? state(x.otherState) : notAssigned)])}
      ${r.otherPlatform.a || r.otherPlatform.b ? `<p class="muted small">Policies for other platforms are left out: ${r.otherPlatform.a} for ${esc(a)}, ${r.otherPlatform.b} for ${esc(b)}.</p>` : ""}
    </article>`;
}

function cmpDevRows() {
  const r = cmpDevReport;
  if (!r) return [];
  const g = (title, s) => (s.unreadable ? [[title, "Couldn't be read", "", ""]]
    : [...s.both.map((x) => [title, x.name, "Both", ""]), ...s.onlyA.map((x) => [title, x.name, `Only ${r.a.name}`, ""]), ...s.onlyB.map((x) => [title, x.name, `Only ${r.b.name}`, ""])]);
  const pol = r.policies;
  return [["Section", "Item", r.a.name, r.b.name],
    ...r.facts.map((f) => ["Details", f.label, f.a, f.b]),
    ...g("Device group", r.deviceGroups), ...g("User group", r.userGroups),
    ...pol.both.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.stateA], CMP_DEV_STATE[x.stateB]]),
    ...pol.onlyA.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.state], CMP_DEV_STATE[x.otherState] || "Not assigned"]),
    ...pol.onlyB.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.otherState] || "Not assigned", CMP_DEV_STATE[x.state]])];
}

$("#cmpdevices-run").addEventListener("click", () => {
  const out = $("#cmpdevices-results");
  if (cmpDevPicked.cmpda.id === cmpDevPicked.cmpdb.id) {
    cmpDevRun(); // an earlier compare still running must not replace this note
    out.innerHTML = emptyBox("Both sides are the same device. Pick two different devices to compare.");
    return;
  }
  runInto(out, cmpDevRun, "Reading both devices' groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const r = await send("devices/compare", { a: cmpDevPicked.cmpda.id, b: cmpDevPicked.cmpdb.id });
    if (!current()) return;
    cmpDevReport = r;
    return renderCompareDevices(r);
  });
});
bindExport("cmpdevices", () => cmpDevRows(), () => `compare-${cmpDevReport?.a.name}-${cmpDevReport?.b.name}.csv`);

// Compare users

const cmpPicked = {};
let cmpReport = null;
const cmpRun = newestOnly();

for (const side of ["cmpa", "cmpb"]) {
  setupPicker(side, (u) => { cmpPicked[side] = u; $("#cmpusers-run").disabled = !(cmpPicked.cmpa && cmpPicked.cmpb); });
  // Typing in the box drops the earlier pick, so Run never compares a user the box no longer shows.
  $(`[data-picker="${side}"] input`).addEventListener("input", () => { cmpPicked[side] = null; $("#cmpusers-run").disabled = true; });
}

const userLabel = (u) => (u?.userPrincipalName ? `${u.displayName} (${u.userPrincipalName})` : u?.displayName || "");

// r.users is { a, b }: the two users compared, kept with the answer so picking again doesn't relabel it.
function renderCompare(r) {
  const { a: ua, b: ub } = r.users;
  const a = userLabel(ua);
  const b = userLabel(ub);
  // Short names inside the lists, unless the two share a name (the same person under two domains).
  const sameName = ua.displayName === ub.displayName;
  const shortA = sameName ? ua.userPrincipalName : ua.displayName;
  const shortB = sameName ? ub.userPrincipalName : ub.displayName;
  const warnings = [r.unreadable.a && a, r.unreadable.b && b].filter(Boolean).map((n) => `${n}'s groups couldn't be read.`);
  if (r.unreadable.a || r.unreadable.b) return emptyBox(`${warnings.join(" ")} Nothing is compared, so it isn't guessed.`);
  const how = (g) => (g.direct ? "direct" : `nested${g.via ? `, via ${g.via}` : ""}`);
  const card = (title, groups, none, extra = () => "") => `<article class="card"><h2>${esc(title)} (${groups.length})</h2>${groups.length
    ? `<ul>${groups.map((g) => `<li>${link(g.link, g.name)} <span class="muted">${esc(extra(g) || how(g))}</span></li>`).join("")}</ul>`
    : `<p class="muted">${esc(none)}</p>`}</article>`;
  return card("In both", r.both, "No group in common.", (g) => `${shortA}: ${how(g)}; ${shortB}: ${how(g.other)}`) +
    card(`Only ${a}`, r.onlyA, `Everything ${a} is in, ${b} is in too.`) +
    card(`Only ${b}`, r.onlyB, `Everything ${b} is in, ${a} is in too.`) +
    `<div class="toolbar">${exportButtons("cmpusers")}</div>`;
}

function cmpRows() {
  const r = cmpReport;
  const a = userLabel(r?.users.a) || "A";
  const b = userLabel(r?.users.b) || "B";
  return [["Group", "Result"], ...(r ? [
    ...r.both.map((g) => [g.name, "Both"]), ...r.onlyA.map((g) => [g.name, `Only ${a}`]), ...r.onlyB.map((g) => [g.name, `Only ${b}`])] : [])];
}

$("#cmpusers-run").addEventListener("click", () => {
  const out = $("#cmpusers-results");
  if (cmpPicked.cmpa.id === cmpPicked.cmpb.id) {
    cmpRun(); // an earlier compare still running must not replace this note
    out.innerHTML = emptyBox("Both sides are the same user. Pick two different users to compare.");
    return;
  }
  const users = { a: cmpPicked.cmpa, b: cmpPicked.cmpb };
  runInto(out, cmpRun, "Reading both users' groups...", async (current) => {
    const r = await send("users/compare", { a: users.a.id, b: users.b.id });
    if (!current()) return;
    cmpReport = { ...r, users };
    return renderCompare(cmpReport);
  });
});
bindExport("cmpusers", () => cmpRows(), () => `compare-${cmpReport?.users.a.displayName}-${cmpReport?.users.b.displayName}.csv`);

// Device 360

let d360Report = null;
const d360Run = newestOnly(); // only the latest search may draw
const D360_BADGE = {
  applies: ["ok", "Applies"], filter: ["warn", "Depends on filter"],
  uncertain: ["warn", "Uncertain"], excluded: ["", "Excluded"],
};
let d360SetSort = { key: "", dir: 1 }; // "" keeps the report's order: conflicts first, then by setting

/** Why a policy reaches the device: its groups, the filter that decides, and an unknown platform. Device 360 and its Settings card. */
const d360FilterText = (f) => `${f.mode === "exclude" ? "Unless" : "Only if"} filter "${f.name}" matches`;
const d360WhyCell = (row) => [...row.why.map((w) => esc(w)),
  ...row.filters.map((f) => `<span title="${esc(f.rule)}">${esc(d360FilterText(f))}</span>`),
  ...(row.platformUnknown ? ['<span class="muted">Platform not known, may not apply to this device</span>'] : [])].join("<br>");

/**
 * Shared by the Device 360 and Baseline gap searches: load the devices, match the name or primary user, and either
 * open the one hit or list up to 50 to pick from. The pick buttons carry `attr` (data-d360 / data-bl).
 * newRun() starts a run and returns a function that says whether it is still the newest.
 */
/** Devices in the loaded (scoped) device list whose name or primary user holds every word of q, A to Z. */
function matchDevices(q, windowsOnly = false) {
  const words = searchWords(q);
  return devicesCache.devices
    .filter((d) => (!windowsOnly || /windows/i.test(d.os || "")) && hasAllWords(deviceSearchText(d), words))
    .sort((x, y) => x.name.localeCompare(y.name));
}

function findDevice({ q, out, newRun, windowsOnly, attr, open }) {
  return runInto(out, newRun, "Reading your devices...", async (current) => {
    await loadDevices();
    if (!current()) return;
    const kind = windowsOnly ? "Windows device" : "device";
    const hits = matchDevices(q, windowsOnly);
    if (hits.length === 1) { open(hits[0].managedId); return; }
    return hits.length
      ? `<article class="card"><p class="muted">${hits.length.toLocaleString()} ${kind}s match. Pick one.</p>` +
        tableHtml(["Device", "Primary user", "OS", "Last check-in"], hits.slice(0, 50).map((d) => [
          td(`<button class="link" ${attr}="${esc(d.managedId)}">${esc(d.name)}</button>`, "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)),
        ])) + (hits.length > 50 ? '<p class="muted small">Showing the first 50. Search for more of the name.</p>' : "") + "</article>"
      : emptyBox(`No ${kind} matches that name or primary user.`);
  });
}

function findD360() {
  const q = $("#d360-query").value.trim().toLowerCase();
  if (!q) return;
  return findDevice({ q, out: $("#d360-results"), newRun: d360Run, attr: "data-d360", open: runD360 });
}

async function runD360(managedId) {
  await runInto($("#d360-results"), d360Run, "Reading groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const { report } = await send("device/360", { managedId });
    if (!current()) return;
    d360Report = report;
    d360SetSort = { key: "", dir: 1 };
    return renderD360(report);
  });
  const filter = $("#d360set-filter");
  if (filter) { onEnterOrClear(filter, drawD360Settings); drawD360Settings(); }
}

/** The Settings card: every setting the policies reaching this device configure, which policy sets it, and conflicts. */
function d360SettingsCard(s) {
  const notes = [
    ...(s.noSettings ? [`${s.noSettings} other item${s.noSettings === 1 ? "" : "s"} (apps, scripts and similar) reach the device but have no settings in the index.`] : []),
    ...(s.partial.length ? [`Only part of the settings of ${s.partial.join(", ")} could be read, so a conflict with them may be missed.`] : []),
  ];
  return `<article class="card">
      <div class="toolbar tight">
        <h2>Settings that reach this device</h2>
        <span class="muted">${s.settings.toLocaleString()} settings from ${s.policies.toLocaleString()} policies${s.conflicts ? `, <strong>${s.conflicts.toLocaleString()} in conflict</strong>` : ", no conflicts"}${s.same ? `, ${s.same.toLocaleString()} set the same by several` : ""}</span>
        <span class="spacer"></span>
        ${exportButtons("d360set")}
      </div>
      <div class="toolbar">
        <label>Show <select id="d360set-show"><option value="conflict"${s.conflicts ? " selected" : ""}>Conflicts (different values)</option><option value="same">Same value, several policies</option><option value="all"${s.conflicts ? "" : " selected"}>All</option></select></label>
        <input id="d360set-filter" type="search" placeholder="Filter settings, then press Enter" aria-label="Filter settings">
        <span class="muted small" id="d360set-count"></span>
      </div>
      <div id="d360set-table"></div>
      ${notes.map((n) => `<p class="muted small">${esc(n)}</p>`).join("")}
      <p class="muted small">A conflict is the same setting set to different values by two policies that reach this device; Intune reports it as a conflict on the device. Group Policy and scripts are not seen.</p>
    </article>`;
}

const D360SET_COLS = [{ key: "name", label: "Setting" }, { key: "value", label: "Value" }, { key: "policy", label: "Policy" }, { key: "certainty", label: "Result" }, { key: "why", label: "Reached through" }];
const d360SetValue = (r, key) => (key === "policy" ? r.policy.name : key === "certainty" ? D360_BADGE[r.certainty]?.[1] : key === "why" ? r.why.join(" ") : r[key]);

/** The Settings card's rows after its Show choice and filter, in the chosen sort order. */
function d360SetShown() {
  const s = d360Report?.settings;
  if (!s) return [];
  const words = searchWords($("#d360set-filter")?.value || "");
  const show = $("#d360set-show")?.value; // conflict, same or all
  return sortRows(s.rows.filter((r) => (show === "conflict" ? r.conflict : show === "same" ? r.same : true) && hasAllWords(`${r.name}\n${r.path}\n${r.value}\n${r.policy.name}`, words)),
    D360SET_COLS, d360SetSort, d360SetValue);
}

function drawD360Settings() {
  const out = $("#d360set-table");
  if (!out) return;
  const rows = d360SetShown();
  $("#d360set-count").textContent = `${rows.length.toLocaleString()} of ${d360Report.settings.rows.length.toLocaleString()} shown`;
  out.innerHTML = rows.length
    ? capped(rows, (shown) => tableWrap(sortHead(D360SET_COLS, d360SetSort, "data-d360set-sort"), shown.map((r) => `<tr>${[
      td(`${r.conflict ? '<span class="badge bad">Conflict</span> ' : r.same ? '<span class="badge">Same value</span> ' : ""}${esc(r.name)}${r.path && r.path !== r.name ? `<div class="muted small path">${esc(r.path)}</div>` : ""}`),
      valueCell(r.value), td(link(r.policy.link, r.policy.name) + `<div class="muted small">${esc(r.policy.typeLabel)}</div>`),
      td(badge(D360_BADGE, r.certainty), "nowrap"), td(d360WhyCell(r)),
    ].join("")}</tr>`).join("")), 1000)
    : emptyBox("Nothing to show with this choice and filter.");
}

function d360SetRows() {
  return [["Setting", "Path", "Value", "Policy", "Type", "Result", "Reached through", "Overlap"],
    ...d360SetShown().map((r) => [r.name, r.path, r.value, r.policy.name, r.policy.typeLabel, D360_BADGE[r.certainty]?.[1] || "", r.why.join("; "), r.conflict ? "Conflict" : r.same ? "Same value" : ""])];
}

/** A list of groups (direct, or nested with the group they come through), "Couldn't be read" for null. Device 360, User 360. */
const groupsCard = (title, groups, none) => `<article class="card"><h2>${esc(title)}</h2>${groups === null ? '<p class="muted">Couldn\'t be read.</p>'
  : groups.length ? `<ul>${groups.map((g) => `<li>${link(g.link, g.name)}${g.direct ? "" : ` <span class="muted">nested${g.via ? `, via ${esc(g.via)}` : ""}</span>`}</li>`).join("")}</ul>`
    : `<p class="muted">${esc(none)}</p>`}</article>`;

/** What a 360 report could not check (its notes, unreadable assignments, policy types the index couldn't read), as a card. */
function notCheckedCard(r) {
  const warnings = [...r.notes,
    ...(r.unreadable ? [`${r.unreadable} policies' assignments couldn't be read, so they aren't checked.`] : []),
    ...(r.indexErrors.length ? [`The policy index couldn't read: ${r.indexErrors.join(", ")}. Those aren't checked.`] : [])];
  return warnings.length ? `<article class="card"><h2>Not everything could be checked</h2><ul>${warnings.map((w) => `<li>${esc(w)}</li>`).join("")}</ul></article>` : "";
}

/** The "what reaches" card of a 360 report: counts, the table, export buttons under `prefix`, and a note (HTML). */
function reachCard(r, title, prefix, empty, noteHtml) {
  const { applies, filter, uncertain, excluded } = r.counts;
  return `<article class="card">
      <div class="toolbar tight">
        <h2>${esc(title)}</h2>
        <span class="muted">${applies} apply, ${filter} depend on a filter, ${uncertain} uncertain, ${excluded} excluded</span>
        <span class="spacer"></span>
        ${exportButtons(prefix)}
      </div>
      ${r.rows.length ? tableHtml(["Name", "Type", "Result", "Why", "Intent"], r.rows.map((row) => [
    td(link(row.link, row.name)), td(esc(row.typeLabel)), td(badge(D360_BADGE, row.state)), td(d360WhyCell(row)), td(esc(row.intents.join(", "))),
  ])) : emptyBox(empty)}
      <p class="muted small">${noteHtml}</p>
    </article>`;
}

function renderD360(r) {
  const d = r.device;
  return `
    <article class="card">
      <h2>${link(d.link, d.name)}</h2>
      <div class="facts">
        <div><span>Primary user</span>${esc(userOf(d) || "None")}</div>
        <div><span>OS</span>${esc(friendlyOs(d.os, d.osVersion))}</div>
        <div><span>Compliance</span>${complianceBadge(d.compliance)}</div>
        <div><span>Last check-in</span>${checkInCell(d.lastSync)}</div>
      </div>
    </article>
    ${notCheckedCard(r)}
    ${reachCard(r, "What reaches this device", "d360", "Nothing in the policy index reaches this device.",
      `User targeting is worked out for the primary user; it really follows whoever signs in. Filters aren't evaluated, so those rows say which filter decides.${r.otherPlatform ? ` ${r.otherPlatform} assigned to other platforms left out.` : ""} Policy index from ${esc(ago(r.policyIndexBuiltAt))}.`)}
    ${r.settings ? d360SettingsCard(r.settings) : ""}
    ${groupsCard("Device groups", r.deviceGroups, "This device isn't in any group.")}
    ${r.hasUser ? groupsCard("Primary user's groups", r.userGroups, "The primary user isn't in any group.") : ""}`;
}

/** Copy table / Save CSV rows of a 360 report's "what reaches" table (Device 360, User 360). */
function reachTableRows(report) {
  return [["Name", "Type", "Result", "Why", "Filter", "Intent"],
    ...(report?.rows || []).map((row) => [row.name, row.typeLabel, D360_BADGE[row.state][1], row.why.join("; "),
      row.filters.map((f) => `${f.mode} ${f.name}`).join("; "), row.intents.join(", ")])];
}

$("#d360-find").addEventListener("click", findD360);
onEnterOrClear($("#d360-query"), findD360);
$("#d360-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-d360]");
  if (pick) { runD360(pick.dataset.d360); return; }
  const th = e.target.closest("th[data-d360set-sort]");
  if (th) { d360SetSort = nextSort(d360SetSort, th.dataset.d360setSort); drawD360Settings(); }
});
$("#d360-results").addEventListener("input", (e) => { if (e.target.id === "d360set-show") drawD360Settings(); });
bindExport("d360", () => reachTableRows(d360Report), () => `device-360-${d360Report?.device.name || "device"}.csv`);

// User 360: one user's devices, groups, and what reaches them through their groups or All users.

let u360Report = null;
const u360Run = newestOnly();

function runUser360(u) {
  return runInto($("#u360-results"), u360Run, "Reading the user's groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const { report } = await send("user/360", { userId: u.id });
    if (!current()) return;
    u360Report = report;
    return renderUser360(report);
  });
}

function renderUser360(r) {
  const u = r.user;
  return `
    <article class="card">
      <h2>${link(u.link, u.displayName || u.userPrincipalName)}</h2>
      <div class="facts">
        <div><span>Sign-in name</span>${esc(u.userPrincipalName || "")}</div>
        <div><span>Account</span>${u.accountEnabled === false ? '<span class="badge bad">Disabled</span>' : u.accountEnabled ? '<span class="badge ok">Enabled</span>' : "?"}</div>
        <div><span>Job title</span>${esc(u.jobTitle || "-")}</div>
        <div><span>Department</span>${esc(u.department || "-")}</div>
      </div>
    </article>
    ${notCheckedCard(r)}
    <article class="card">
      <h2>Devices <span class="muted">· ${r.devices.length}</span></h2>
      ${r.devices.length ? tableHtml(["Device", "OS", "Compliance", "Last check-in"], r.devices.map((d) => [
        td(link(d.link, d.name) + recordsBadge(d.records), "nowrap"), td(esc(friendlyOs(d.os, d.osVersion))), td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)),
      ])) : '<p class="muted">This user is not the primary user of any device in the device list.</p>'}
    </article>
    ${reachCard(r, "What reaches this user", "u360", "Nothing in the policy index reaches this user through their groups or All users.",
      `Through the user's groups and All users. Assignments to devices (device groups, All devices) are on each device's Device 360. Filters aren't evaluated. Policy index from ${esc(ago(r.policyIndexBuiltAt))}.`)}
    ${groupsCard("Groups", r.userGroups, "This user isn't in any group.")}`;
}

setupPicker("u360", runUser360);
bindExport("u360", () => reachTableRows(u360Report), () => `user-360-${u360Report?.user.userPrincipalName || "user"}.csv`);
bindExport("d360set", () => d360SetRows(), () => `device-settings-${d360Report?.device.name || "device"}.csv`);

// ------------------------------------------------------------------------------------------
// Baseline gap: one device's applied policy settings against a Microsoft security baseline.

/** A count per status as badges ("Pass: 12 Fail: 3"): map is { key: [class, label] }, counts { key: n }. Baseline gap and Security posture. */
// A zero count is greyed (muted), so the counts that matter keep their colour.
const badgeCounts = (map, counts) => Object.entries(map).map(([k, [cls, label]]) => {
  const n = counts[k] || 0;
  return `<span class="badge ${n ? cls : "muted"}">${esc(label)}: ${n.toLocaleString()}</span>`;
}).join(" ");

const BL_BADGE = { match: ["ok", "Matches"], differs: ["bad", "Different"], conflict: ["bad", "Conflict"], review: ["warn", "Check value"], missing: ["", "Not configured"] };
let blResult = null; // last answer
let blDevice = null; // { id, name } of the device last checked
const blRun = newestOnly(); // only the latest check may draw

let blData = null; // { baselines, built } once loaded (lazy-data.js)

/** Loads the baselines the first time the tab opens, and fills the drop-down. */
async function baselineData() {
  if (!blData) {
    const data = await loadBaselines();
    if (blData) return blData; // another call filled it while this one waited
    blData = data;
    $("#bl-which").innerHTML = blData.baselines.map((b) => `<option value="${esc(b.id)}">${esc(`${b.name} ${b.version}`)}</option>`).join("");
  }
  return blData;
}

function findBaseline() {
  const q = $("#bl-query").value.trim().toLowerCase();
  if (!q) return;
  if (blDevice && q === blDevice.name.toLowerCase()) { runBaseline(blDevice.id); return; } // the same device, another baseline
  // The baselines are for Windows, so only Windows devices are offered.
  return findDevice({ q, out: $("#bl-results"), newRun: blRun, windowsOnly: true, attr: "data-bl", open: runBaseline });
}

function runBaseline(managedId) {
  return runInto($("#bl-results"), blRun, "Reading groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const [res, data] = await Promise.all([send("baseline/applied", { managedId, baseline: $("#bl-which").value }), baselineData()]);
    if (!current()) return;
    const baseline = data.baselines.find((b) => b.id === $("#bl-which").value) || data.baselines[0];
    const { applied, ...rest } = res;
    blResult = { ...rest, ...baselineGap(baseline, applied) };
    blDevice = { id: managedId, name: res.device.name };
    $("#bl-query").value = res.device.name;
    renderBaseline();
  });
}

const blShown = () => {
  const f = $("#bl-filter")?.value || "attention";
  return (blResult?.rows || []).filter((r) => f === "all" || (f === "attention" ? r.status !== "match" : r.status === f));
};

function renderBaseline() {
  const r = blResult;
  if (!r) return;
  const n = r.counts;
  const keep = $("#bl-filter")?.value || "attention";
  const sources = (row) => [...new Set(row.sources.map((s) => `${s.name}${s.certainty !== "applies" ? " (may not apply)" : ""}`))].join("; ");
  $("#bl-results").innerHTML = `<article class="card">
      <h2>${link(r.device.link, r.device.name)} <span class="muted small">${esc([r.device.user, friendlyOs(r.device.os, r.device.osVersion)].filter(Boolean).join(", "))}</span></h2>
      <p>${esc(`${r.baseline.name} ${r.baseline.version}`)}: <strong>${n.match.toLocaleString()}</strong> of ${r.total.toLocaleString()} recommendations are set as recommended by a policy that reaches this device.</p>
      <p>${badgeCounts(BL_BADGE, n)}</p>
      <p class="muted small" title="${esc(`Policy index read ${new Date(r.indexBuiltAt).toLocaleString()}. Group Policy, scripts and the built-in security baseline profiles are not seen. Check value: a policy sets it but the value could not be compared. Baseline data built ${blData?.built || "unknown"}.`)}">From ${r.appliedPolicies.toLocaleString()} policies that reach the device. Group Policy and scripts are not seen.</p>
      ${r.indexErrors.length ? `<p class="warn small">Some policy types could not be read (${esc(r.indexErrors.join(", "))}), so settings in them are missing here.</p>` : ""}
      ${r.notes.map((x) => `<p class="warn small">${esc(x)}</p>`).join("")}
      <div class="toolbar">
        <label>Show <select id="bl-filter"><option value="attention">Needs attention</option><option value="all">All</option>${Object.entries(BL_BADGE).map(([k, [, label]]) => `<option value="${k}">${esc(label)}</option>`).join("")}</select></label>
        <span class="muted small" id="bl-count"></span>
        ${exportButtons("bl")}<button id="bl-json">Save JSON</button>
      </div>
      <div id="bl-table"></div>
    </article>`;
  $("#bl-filter").value = keep;
  const rows = blShown();
  $("#bl-count").textContent = `${rows.length.toLocaleString()} of ${r.total.toLocaleString()} shown`;
  $("#bl-table").innerHTML = rows.length
    ? capped(rows, (shownRows) => tableHtml(["Status", "Setting", "Category", "Recommended", "Applied by Intune", "Set by", "Note"], shownRows.map((row) => [
      td(badge(BL_BADGE, row.status), "nowrap"), td(esc(row.title), "bl-setting"), td(esc(row.category), "bl-category"), td(esc(row.recommended)),
      td(esc(row.applied)), td(esc(sources(row)), "bl-sources"), td(esc(row.note), "bl-note"),
    ])), 1000, "Copy, CSV and JSON include all.")
    : emptyBox("Nothing to show with this filter.");
}

function blTableRows() {
  return [["Status", "Setting", "Category", "Recommended", "Applied by Intune", "Set by", "Note", "Setting id"],
    ...blShown().map((r) => [BL_BADGE[r.status][1], r.title, r.category, r.recommended, r.applied, r.sources.map((s) => s.name).join("; "), r.note, r.id])];
}

$("#bl-find").addEventListener("click", findBaseline);
onEnterOrClear($("#bl-query"), findBaseline);
$("#bl-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-bl]");
  if (pick) { runBaseline(pick.dataset.bl); return; }
  if (e.target.closest("#bl-json")) saveJson(`baseline-gap-${blDevice?.name || "device"}-${blResult?.baseline.id || ""}.json`, { readAt: new Date().toISOString(), ...blResult });
});
bindExport("bl", () => blTableRows(), () => `baseline-gap-${blDevice?.name || "device"}-${blResult?.baseline.id || ""}.csv`);
$("#bl-results").addEventListener("input", (e) => { if (e.target.id === "bl-filter") renderBaseline(); });

// ------------------------------------------------------------------------------------------
// Tenant health

let health = null; // last answer: { rows }
const HEALTH_BADGE = {
  expired: ["bad", "Expired"], soon: ["warn", "Expires soon"], attention: ["warn", "Needs a look"],
  ok: ["ok", "OK"], none: ["", "Not set up"], error: ["bad", "Couldn't check"],
};

// One check at a time: coming back to the tab or clicking Check again doesn't start another.
const runHealth = oneAtATime($("#health-run"), async () => {
  $("#health-results").innerHTML = loading("Checking tokens, certificates and connectors...");
  $("#health-count").textContent = "";
  showExport("health", false);
  try {
    health = await send("tenant/health");
  } catch (err) {
    health = null;
    $("#health-results").innerHTML = errorBox(err);
    return;
  }
  const worried = health.rows.filter((r) => r.status === "expired" || r.status === "soon").length;
  showExport("health", health.rows.length > 0);
  $("#health-count").textContent = worried ? `${worried} need action` : "Nothing expiring soon";
  $("#health-results").innerHTML = tableHtml(["Area", "Name", "Status", "Expires", { label: "Days left", num: true }, "Detail"], health.rows.map((r) => [
    td(esc(r.area), "nowrap"), td(esc(r.name)), td(badge(HEALTH_BADGE, r.status)),
    td(r.expires ? esc(new Date(r.expires).toLocaleDateString()) : ""), td(r.daysLeft === null ? "" : String(r.daysLeft), "num"), td(esc(r.detail)),
  ]));
});

function healthRowsOut() {
  return [["Area", "Name", "Status", "Expires", "Days left", "Detail"],
    ...(health?.rows || []).map((r) => [r.area, r.name, HEALTH_BADGE[r.status][1], r.expires, r.daysLeft ?? "", r.detail])];
}

$("#health-run").addEventListener("click", runHealth);
bindExport("health", () => healthRowsOut(), () => "tenant-health.csv");

// ------------------------------------------------------------------------------------------
// Orphaned users

let orphans = null; // last answer: { devices, unknown, checked }

// One scan at a time: it checks every primary user.
const runOrphans = oneAtATime($("#orphans-run"), async () => {
  $("#orphans-results").innerHTML = loading("Checking each primary user...");
  $("#orphans-count").textContent = "";
  showExport("orphans", false);
  try {
    orphans = await send("devices/orphaned");
  } catch (err) {
    orphans = null;
    $("#orphans-results").innerHTML = errorBox(err);
    return;
  }
  renderOrphans();
});

/** Draws the Orphaned users answer, inside the header's scope when one is set (no new lookups when the scope changes). */
async function renderOrphans() {
  if (!orphans) return;
  let devices;
  try {
    devices = orphans.shown = await scoped(orphans.devices);
  } catch (err) {
    $("#orphans-results").innerHTML = errorBox(err);
    return;
  }
  const { unknown, checked } = orphans;
  showExport("orphans", devices.length > 0);
  $("#orphans-count").textContent = `${devices.length.toLocaleString()} devices${scopeNote()}, from ${checked.toLocaleString()} users checked`
    + (unknown ? `, ${unknown.toLocaleString()} devices couldn't be checked` : "");
  $("#orphans-results").innerHTML = devices.length
    ? capped(devices, (rows) => tableHtml(["Device", "Primary user", "User", "OS", "Last check-in", "Ownership"], rows.map((d) => [
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))),
      td(d.userState === "deleted" ? '<span class="badge bad">Deleted</span>' : '<span class="badge warn">Disabled</span>'),
      td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ])))
    : emptyBox(scopeNote() ? `No device${scopeNote()} has a disabled or deleted primary user.` : "Every primary user is active.");
}

function orphanRows() {
  return [["Device", "Primary user", "UPN", "User", "OS", "OS version", "Last check-in", "Ownership", "Model"],
    ...(orphans?.shown || orphans?.devices || []).map((d) => [d.name, d.displayName, d.upn, d.userState, d.os, d.osVersion, d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#orphans-run").addEventListener("click", runOrphans);
bindExport("orphans", () => orphanRows(), () => "orphaned-users.csv");

// ------------------------------------------------------------------------------------------
// Low storage

let storageList = [];
let storageSort = { key: "free", dir: 1 }; // least free space first
const STORAGE_COLS = [{ key: "name", label: "Device" }, { key: "user", label: "Primary user" }, { key: "os", label: "OS" },
  { key: "free", label: "Free", num: true }, { key: "total", label: "Total", num: true }, { key: "pct", label: "Free %", num: true }, { key: "sync", label: "Last check-in" }];
const storageValue = (d, k) => ({ name: d.name, user: userOf(d), os: friendlyOs(d.os, d.osVersion), free: d.freeGb, total: d.totalGb, pct: d.freeGb / d.totalGb * 100, sync: d.lastSync }[k]);

function renderStorage() {
  const limit = Number($("#storage-gb").value) || 10;
  const sel = $("#storage-os");
  fillPlatforms(sel, devicesCache.platforms);
  const { list, unknown } = lowStorageDevices(devicesCache.devices, limit);
  storageList = sortRows(list.filter((d) => !sel.value || (d.os || "Unknown OS") === sel.value), STORAGE_COLS, storageSort, storageValue);
  showExport("storage", storageList.length > 0);
  $("#storage-count").textContent = `${storageList.length.toLocaleString()} low` + (unknown ? `, ${unknown.toLocaleString()} report no storage` : "");
  $("#storage-results").innerHTML = storageList.length
    ? capped(storageList, (rows) => tableWrap(sortHead(STORAGE_COLS, storageSort), rows.map((d) => `<tr>${[
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(`${d.freeGb.toFixed(1)} GB`, "num"), td(`${d.totalGb.toFixed(0)} GB`, "num"), td(`${(d.freeGb / d.totalGb * 100).toFixed(0)}%`, "num"),
      td(checkInCell(d.lastSync)),
    ].join("")}</tr>`).join("")))
    : emptyBox(`No device has less than ${limit} GB free.`);
}

function storageRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Free GB", "Total GB", "Free %", "Last check-in", "Ownership", "Model"],
    ...storageList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.freeGb.toFixed(1), d.totalGb.toFixed(0),
      (d.freeGb / d.totalGb * 100).toFixed(0), d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#storage-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-sort]");
  if (th && devicesCache) { storageSort = nextSort(storageSort, th.dataset.sort); renderStorage(); }
});
$("#storage-gb").addEventListener("input", () => devicesCache && renderStorage());
$("#storage-os").addEventListener("input", () => devicesCache && renderStorage());
bindExport("storage", () => storageRows(), () => "low-storage.csv");

// ------------------------------------------------------------------------------------------
// Autopilot failures: Intune's Autopilot deployment events for the last N days, with the enrollment status page
// (ESP) items and the device's Autopilot record. Every field Intune sends is kept (Details, CSV and JSON), so the
// layout can be decided from real data.

const AP_STATE = { failure: ["bad", "Failed"], success: ["ok", "Success"], inprogress: ["warn", "In progress"], unknown: ["", "Unknown"] };
const AP_COLS = [
  { key: "when", label: "Date" }, { key: "name", label: "Device name" }, { key: "serial", label: "Serial number" }, { key: "user", label: "User" },
  { key: "stateLabel", label: "Status" }, { key: "method", label: "Method" }, { key: "profile", label: "Profile" },
  { key: "espCheck", label: "ESP check" }, { key: "attempts", label: "Attempts" }, { key: "entraText", label: "Entra" }, { key: "lastSync", label: "Last sync" },
  { key: "secs", label: "Duration", num: true }, { key: "failedText", label: "Failed items" }, { key: "notes", label: "Notes" }, { key: "model", label: "Model" }, { key: "os", label: "OS version" },
];
let apRows = null; // as read: [{ id, when, state, event, details, detailsNote, identity }]
let apAll = []; // apRows as table rows (apBuild)
let apSort = { key: "when", dir: -1 }; // newest first
let apView = []; // rows as shown
const apOpen = new Set(); // ids whose Details are open

/** "PT1H34M48S" as "1 hr 34 min 48 sec", and its seconds. Pure. */
function isoDuration(text) {
  const m = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?$/i.exec(String(text || ""));
  if (!m) return { secs: NaN, text: String(text || "") };
  const [d, h, mi, s] = [m[1], m[2], m[3], m[4]].map((x) => Number(x) || 0);
  const secs = d * 86400 + h * 3600 + mi * 60 + s;
  const parts = [d && `${d} d`, h && `${h} hr`, mi && `${mi} min`, (s || !secs) && `${Math.round(s)} sec`].filter(Boolean);
  return { secs, text: parts.join(" ") };
}

/**
 * What the data says about an event that did not succeed, in plain words. Real tenant data showed hybrid-join
 * deployments that end after a second with state "unknown" (no result ever reported), often with the device still
 * named DESKTOP-xxxx or by its id, and a later success for the same serial; those are told apart from a real failure.
 * lastOk: lower-case serial -> ISO time of that device's latest successful deployment.
 */
function apNotes(r, v, lastOk) {
  if (v.state === "success") return "";
  const out = [];
  if (v.state === "unknown" && v.secs <= 2) out.push(`Ended after ${v.durText || "0 sec"} with no result reported`);
  const ok = lastOk.get(v.serial.toLowerCase());
  out.push(ok && ok >= v.when ? `Succeeded later (${new Date(ok).toLocaleDateString()})` : "No success since");
  if (!r.identity) out.push("No Autopilot record for this serial number");
  else if (/notcontacted/i.test(r.identity.enrollmentState || "") || /^0001/.test(r.identity.lastContactedDateTime || "")) out.push("Autopilot record has never contacted Intune");
  if (/^DESKTOP-/i.test(v.name) || /^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(v.name)) out.push("Device name not set yet");
  if (/^default$/i.test(r.event?.windows10EnrollmentCompletionPageConfigurationDisplayName || "")) out.push("Used the Default enrollment status page, not an assigned one");
  if (r.esp?.agrees === false) out.push(`Expected enrollment status page "${r.esp.expectedName}", used "${r.esp.actualName || "none"}"${r.joinNotes?.entraNewer ? " (Entra record is newer than the event, so unproven)" : ""}`);
  if (/hybrid/i.test(r.profile?.kind || "") && /^azureadjoined$/i.test(r.device?.joinType || "")) out.push("Intune says Entra joined but the profile is hybrid: the domain join did not happen");
  else if (r.esp?.agrees === true && /^default$/i.test(r.esp.actualName || "")) out.push("Default is what the groups say should apply");
  if (r.entra && /offlinedomainjoined/i.test(v.method) && r.entra.trustType && r.entra.trustType !== "ServerAd") out.push("Not hybrid joined in Entra yet");
  if (!r.device && r.joinNotes?.device) out.push("No Intune managed device record");
  if (v.attemptCount > 1) out.push(`Attempt ${r.history.position} of ${v.attemptCount} for this serial`);
  const inProfile = r.profile?.assignedGroups?.filter((g) => !g.excluded);
  if (inProfile?.length && inProfile.every((g) => g.deviceIsMember === false)) out.push("Device is not in the profile's assigned group now");
  return out.join("; ");
}

function apRow(r, lastOk = new Map()) {
  const e = r.event || {};
  const dur = isoDuration(e.deploymentDuration);
  const failed = failedItems(r.details).map((d) => d.displayName || d.policyId || d.id || "(unnamed)");
  const v = {
    id: r.id, raw: r, when: r.when, name: e.managedDeviceName || "", serial: e.deviceSerialNumber || "", user: e.userPrincipalName || "",
    state: r.state, stateLabel: AP_STATE[r.state][1], method: e.enrollmentType || "", profile: e.windowsAutopilotDeploymentProfileDisplayName || "",
    secs: dur.secs, durText: dur.text, failedText: failed.join(", "), model: r.identity?.model || "", os: e.osVersion || "",
    espCheck: !r.esp ? "" : r.esp.agrees === true ? `OK: ${r.esp.actualName || "Default"}` : r.esp.agrees === false ? `Mismatch: expected ${r.esp.expectedName}` : "Unknown",
    attemptCount: r.history?.attempts || 0, attempts: r.history ? `${r.history.attempts}${r.history.laterSuccess ? ", later success" : r.history.attempts > 1 ? ", no success since" : ""}` : "",
    entraText: r.entra ? ({ ServerAd: "Hybrid joined", AzureAd: "Entra joined", Workplace: "Registered" }[r.entra.trustType] || r.entra.trustType || "Found") : r.joinNotes?.entra ? "No Entra record" : "",
    lastSync: r.device?.lastSyncDateTime || "",
  };
  v.notes = apNotes(r, v, lastOk);
  return v;
}

const apCell = (v) => (v !== null && typeof v === "object" ? JSON.stringify(v) : v === null || v === undefined ? "" : String(v));
const kvTable = (obj) => tableWrap("", (Array.isArray(obj) ? obj : Object.entries(obj || {})).map(([k, v]) => `<tr><td class="nowrap">${esc(k)}</td><td>${esc(apCell(v))}</td></tr>`).join(""));

/** Details sections for the joined data: attempts, the ESP check, the profile, the device and Entra records, groups. */
function apJoined(r) {
  const out = [];
  const h = r.history;
  if (h) out.push(`<h3>Attempts for this serial number</h3><p class="small">${h.attempts} in this period (first ${esc(new Date(h.first).toLocaleString())}, last ${esc(new Date(h.last).toLocaleString())}); ${h.failedOrUnknown} not successful.`
    + ` ${h.laterSuccess ? `A later deployment succeeded (${esc(new Date(h.laterSuccess).toLocaleString())}).` : "No later success."}</p>`);
  if (r.esp) {
    const c = r.esp.candidates || [];
    out.push(`<h3>Enrollment status page check</h3><p class="small">Used: ${esc(r.esp.actualName || r.esp.actualId || "none")}. Expected from the groups now: ${esc(r.esp.expectedName || "cannot tell")}.${r.esp.note ? ` ${esc(r.esp.note)}` : ""}</p>`
      + (c.length ? tableWrap(headCells(["Assigned page", { label: "Priority", num: true }, "Targets this device or user", "Through"]), c.map((x) => `<tr>${td(esc(x.name))}${td(String(x.priority), "num")}${td(x.matches === null ? "unknown" : x.matches ? "yes" : "no")}${td(esc(x.via))}</tr>`).join("")) : ""));
  }
  if (r.profile) {
    const { assignedGroups, ...rest } = r.profile;
    out.push(`<h3>Autopilot profile${r.profile.kind ? ` (${esc(r.profile.kind)})` : ""}</h3>${kvTable(rest)}`
      + (assignedGroups?.length ? tableWrap(headCells(["Assigned group", "", "Device in it now", "Dynamic rule"]), assignedGroups.map((g) => `<tr>${td(esc(g.name))}${td(g.excluded ? "excluded" : "")}${td(g.deviceIsMember === null ? "unknown" : g.deviceIsMember ? "yes" : "no")}${td(esc(g.rule))}</tr>`).join("")) : ""));
  }
  if (r.device) out.push(`<h3>Intune managed device record</h3>${kvTable(r.device)}`);
  if (r.entra) out.push(`<h3>Entra device record</h3>${kvTable(r.entra)}`);
  const names = (list) => (list ? list.map((g) => g.name).sort((a, b) => a.localeCompare(b)).join(", ") || "(none)" : "could not be read");
  if (r.deviceGroups || r.userGroups) out.push(`<h3>Groups now</h3><p class="small">Device: ${esc(names(r.deviceGroups))}</p><p class="small">User: ${esc(names(r.userGroups))}</p>`);
  const notes = Object.values(r.joinNotes || {});
  if (notes.length) out.push(`<p class="muted small">${notes.map(esc).join("<br>")}</p>`);
  return out.join("");
}

function apDetail(v) {
  const r = v.raw;
  const esp = Array.isArray(r.details) && r.details.length
    ? `<h3>Enrollment status page items (${r.details.length})</h3>` + (() => {
      const keys = [...new Set(r.details.flatMap((d) => Object.keys(d)))];
      return tableWrap(headCells(keys), r.details.map((d) => `<tr>${keys.map((k) => td(esc(apCell(d[k])))).join("")}</tr>`).join(""));
    })()
    : `<p class="muted small">No enrollment status page items from Intune${r.detailsNote ? `: ${esc(r.detailsNote)}` : "."}</p>`;
  const codeTexts = [r.event?.enrollmentFailureDetails, ...(Array.isArray(r.details) ? r.details.map((d) => (d?.errorCode && Number(d.errorCode) !== 0 ? String(d.errorCode) : "")) : [])].filter(Boolean);
  return `${apJoined(r)}${apErrorCodes(codeTexts)}<h3>Deployment event</h3>${kvTable(r.event)}${esp}` +
    (r.identity ? `<h3>Autopilot device record</h3>${kvTable(r.identity)}` : '<p class="muted small">No Autopilot device record found for this serial number.</p>');
}

/** The table rows for the events just read, made once (not on every search or filter change). */
function apBuild(rows) {
  const lastOk = new Map();
  for (const r of rows) {
    const serial = String(r.event?.deviceSerialNumber || "").toLowerCase();
    if (r.state === "success" && serial && r.when > (lastOk.get(serial) || "")) lastOk.set(serial, r.when);
  }
  return rows.map((r) => apRow(r, lastOk));
}

function apFilter() {
  const words = searchWords($("#ap-search").value);
  const status = $("#ap-status").value;
  return apAll.filter((v) => (status === "all" || v.state === "failure" || (status === "unknown" && v.state === "unknown"))
    && hasAllWords(`${v.name}\n${v.serial}\n${v.user}`, words));
}

function renderAutopilot() {
  const out = $("#ap-results");
  if (!apRows) return;
  apView = sortRows(apFilter(), AP_COLS, apSort, (v, k) => v[k]);
  showExport("ap", apView.length > 0);
  $("#ap-json").hidden = !apView.length;
  $("#ap-count").textContent = `${apView.length.toLocaleString()} of ${apRows.length.toLocaleString()} events`;
  if (!apView.length) {
    out.innerHTML = emptyBox(apRows.length ? "No event matches." : "Intune has no Autopilot events in this period.");
    return;
  }
  const head = `<th></th>${sortHead(AP_COLS, apSort)}`;
  const draw = (rows) => tableWrap(head, rows.map((v) => {
    const open = apOpen.has(v.id);
    return `<tr><td><button class="link" data-ap-open="${esc(v.id)}" aria-expanded="${open}">${open ? "Hide" : "Details"}</button></td>`
      + td(v.when ? `${esc(new Date(v.when).toLocaleString())}` : "", "nowrap") + td(esc(v.name), "nowrap") + td(esc(v.serial), "nowrap") + td(esc(v.user), "nowrap")
      + td(badge(AP_STATE, v.state)) + td(esc(v.method), "nowrap") + td(esc(v.profile), "nowrap")
      + td(esc(v.espCheck), "nowrap") + td(esc(v.attempts), "nowrap") + td(esc(v.entraText), "nowrap") + td(v.lastSync ? esc(new Date(v.lastSync).toLocaleString()) : "", "nowrap") + td(esc(v.durText), "num nowrap")
      + td(esc(v.failedText || (v.state === "failure" ? "no ESP detail" : "")), "ap-failed") + td(esc(v.notes), "ap-notes") + td(esc(v.model), "nowrap") + td(esc(v.os), "nowrap") + "</tr>"
      + (open ? `<tr><td colspan="${AP_COLS.length + 1}"><div class="ap-detail">${apDetail(v)}</div></td></tr>` : "");
  }).join(""));
  out.innerHTML = capped(apView, draw, 1000, "Copy, Save CSV and Save JSON include all.");
}

function apTableRows() {
  return [[...AP_COLS.map((c) => c.label)], ...apView.map((v) => AP_COLS.map((c) => (c.key === "secs" ? v.durText : v[c.key])))];
}

/** Every field of every shown event: the table columns, then each event field, ESP items and Autopilot record field. */
function apFullRows() {
  const eventKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.event || {})))];
  const idKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.identity || {})))];
  const devKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.device || {})))];
  const entraKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.entra || {})))];
  const json = (x) => (x ? JSON.stringify(x) : "");
  return [
    [...AP_COLS.map((c) => c.label), "ESP items (JSON)", "ESP check (JSON)", "Attempts (JSON)", "Profile (JSON)", "Device groups", "User groups", "Join notes",
      ...eventKeys.map((k) => `event.${k}`), ...idKeys.map((k) => `autopilot.${k}`), ...devKeys.map((k) => `device.${k}`), ...entraKeys.map((k) => `entra.${k}`)],
    ...apView.map((v) => [...AP_COLS.map((c) => (c.key === "secs" ? v.durText : v[c.key])), json(v.raw.details), json(v.raw.esp), json(v.raw.history), json(v.raw.profile),
      (v.raw.deviceGroups || []).map((g) => g.name).join("; "), (v.raw.userGroups || []).map((g) => g.name).join("; "), Object.values(v.raw.joinNotes || {}).join(" "),
      ...eventKeys.map((k) => apCell(v.raw.event?.[k])), ...idKeys.map((k) => apCell(v.raw.identity?.[k])),
      ...devKeys.map((k) => apCell(v.raw.device?.[k])), ...entraKeys.map((k) => apCell(v.raw.entra?.[k]))]),
  ];
}

const saveJson = (filename, data) => download(filename, new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));

$("#ap-run").addEventListener("click", oneAtATime($("#ap-run"), async () => {
  const days = Math.min(30, Math.max(1, Math.floor(Number($("#ap-days").value)) || 7));
  $("#ap-days").value = days;
  $("#ap-results").innerHTML = loading("Reading Autopilot events...");
  try {
    const rows = (await send("autopilot/events", { days })).rows;
    apAll = apBuild(rows);
    apRows = rows;
    apOpen.clear();
    renderAutopilot();
  } catch (err) {
    $("#ap-results").innerHTML = errorBox(err);
  }
}));
onEnterOrClear($("#ap-search"), renderAutopilot); // on Enter or when cleared, like the other searches
$("#ap-status").addEventListener("input", renderAutopilot);
$("#ap-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-sort]");
  if (th && apRows) { apSort = nextSort(apSort, th.dataset.sort, th.dataset.sort === "when" ? -1 : 1); renderAutopilot(); return; }
  const b = e.target.closest("button[data-ap-open]");
  if (b) { const id = b.dataset.apOpen; if (apOpen.has(id)) apOpen.delete(id); else apOpen.add(id); renderAutopilot(); }
});
bindExport("ap", () => apTableRows(), () => "autopilot-failures.csv", () => apFullRows());
$("#ap-json").addEventListener("click", () => saveJson("autopilot-events.json", { readAt: new Date().toISOString(), rows: apRows })); // every event read, whatever the filter

// ------------------------------------------------------------------------------------------
// Failed apps and Failed policies: one report, two sources. Devices or users (never both at once), a minimum
// number of fails, a platform, sortable headings, Copy table and Save CSV.

const FAIL_ROW_LIMIT = 2000;

/** Set up one failed report: cfg names its ids (prefix), labels and how its rows are read. */
function failedReport(cfg) {
  const p = cfg.prefix;
  let data = null; // rows as read: { name, extra, platform, link, device: {fail, conflict?, ok} | null, user: ... }
  let mode = "device"; // "device" or "user"
  let sort = { key: "fails", dir: -1 }; // most fails first
  let view = []; // rows as shown, in the shown order

  const who = () => (mode === "user" ? "User" : "Device");
  const cols = () => [
    { key: "name", label: cfg.nameLabel },
    { key: "extra", label: cfg.extraLabel },
    { key: "pct", label: cfg.pctLabel, num: true },
    { key: "fails", label: `${who()} ${cfg.failWord}`, num: true },
    ...(cfg.conflicts ? [{ key: "conflicts", label: `${who()} conflicts`, num: true }] : []),
    { key: "ok", label: `${who()} ${cfg.okWord}`, num: true },
  ];

  /** The rows with this mode's counts. A row Intune has no user (or device) count for isn't in that mode. */
  const rowsFor = () => data.flatMap((r) => {
    const s = r[mode];
    if (!s) return [];
    const conflicts = s.conflict || 0;
    const total = s.fail + conflicts + s.ok;
    return [{ name: r.name, extra: r.extra, platform: r.platform, link: r.link, fails: s.fail, conflicts, ok: s.ok, pct: total ? s.fail / total * 100 : 0 }];
  });

  function render() {
    const out = $(`#${p}-results`);
    if (!data) return;
    const sel = $(`#${p}-os`);
    fillPlatforms(sel, [...new Set(data.map((r) => r.platform).filter(Boolean))].sort());
    const min = Number($(`#${p}-min`).value) || 0;
    const all = rowsFor();
    // Policies: a conflict counts too, so a policy that only conflicts is still listed.
    view = sortRows(all.filter((r) => (!sel.value || r.platform === sel.value) && r.fails + (cfg.conflicts ? r.conflicts : 0) > min),
      cols(), sort, (r, k) => r[k]);
    showExport(p, view.length > 0);
    $(`#${p}-count`).textContent = `${view.length.toLocaleString()} of ${all.length.toLocaleString()}`;
    if (!all.length) {
      out.innerHTML = emptyBox(mode === "user" && data.length ? "Intune gave no user counts for these. Try Devices." : `No ${cfg.noun} found.`);
      return;
    }
    const head = sortHead(cols(), sort);
    const draw = (rows) => tableWrap(head, rows.map((r) => `<tr>${[
      td(link(r.link, r.name), "nowrap"), td(esc(r.extra || "")), td(`${r.pct.toFixed(1)}%`, "num"), td(r.fails.toLocaleString(), "num"),
      ...(cfg.conflicts ? [td(r.conflicts.toLocaleString(), "num")] : []), td(r.ok.toLocaleString(), "num"),
    ].join("")}</tr>`).join(""));
    out.innerHTML = view.length
      ? capped(view, draw, FAIL_ROW_LIMIT)
      : emptyBox(`None have more than ${min.toLocaleString()} ${cfg.minWord}.`);
  }

  const tableRows = () => [[...cols().map((c) => c.label), "Platform"],
    ...view.map((r) => [r.name, r.extra, r.pct.toFixed(1), r.fails, ...(cfg.conflicts ? [r.conflicts] : []), r.ok, r.platform])];

  const run = oneAtATime($(`#${p}-run`), async () => {
    const out = $(`#${p}-results`);
    out.innerHTML = loading(`Reading ${cfg.noun}...`);
    try {
      data = await cfg.read(out);
      render();
    } catch (err) {
      out.innerHTML = errorBox(err);
      jobBar.done(p);
    }
  });

  $(`#${p}-run`).addEventListener("click", run);
  $(`#${p}-device`).addEventListener("change", (e) => {
    mode = e.currentTarget.checked ? "device" : "user"; // on = Devices (the default), off = Users
    $(`#${p}-who`).textContent = `Show ${who()} stats`;
    render();
  });
  $(`#${p}-min`).addEventListener("input", render);
  $(`#${p}-os`).addEventListener("input", render);
  $(`#${p}-results`).addEventListener("click", (e) => {
    const th = e.target.closest("th[data-sort]");
    if (!th || !data) return;
    const key = th.dataset.sort;
    sort = nextSort(sort, key, key === "name" || key === "extra" ? 1 : -1); // counts: most first
    render();
  });
  bindExport(p, () => tableRows(), () => `${cfg.file}.csv`);
}

failedReport({
  prefix: "fapps", noun: "apps", file: "failed-apps", nameLabel: "App name", extraLabel: "Version", pctLabel: "Install failure (%)",
  failWord: "failures", okWord: "installs", minWord: "fails", conflicts: false,
  async read() {
    const { rows } = await send("failed/apps");
    return rows.map((r) => ({ name: r.name, extra: r.version, platform: r.platform, link: r.link, device: r.device, user: r.user }));
  },
});

const FAILED_POLICY_CHUNK = 40; // policies per request to the worker, so progress and Stop respond between chunks
failedReport({
  prefix: "fpol", noun: "policies", file: "failed-policies", nameLabel: "Policy name", extraLabel: "Type", pctLabel: "Failure (%)",
  failWord: "failures", okWord: "successes", minWord: "fails or conflicts", conflicts: true,
  async read(out) {
    let stopped = false;
    const { items } = await send("failed/policies/list");
    const results = {};
    for (let i = 0; i < items.length && !stopped; i += FAILED_POLICY_CHUNK) {
      jobBar.set("fpol", { label: "Reading policy results", done: i, total: items.length, stop: () => { stopped = true; } });
      out.innerHTML = loading("Reading each policy's results. Stop keeps what is read so far.");
      Object.assign(results, (await send("failed/policies/read", { items: items.slice(i, i + FAILED_POLICY_CHUNK) })).results);
    }
    jobBar.done("fpol", stopped ? "Stopped. Kept what was read so far." : "");
    return items.filter((i) => results[i.id] && !results[i.id].retry).map((i) => ({
      name: i.name, extra: i.typeLabel, platform: i.platform, link: i.link, device: results[i.id].device, user: results[i.id].user,
    }));
  },
});

// ------------------------------------------------------------------------------------------
// Stale & duplicates

let staleList = [];
let dupes = []; // found once per device list; the stale list reads it on every keystroke

function renderHygiene() {
  fillPlatforms($("#stale-os"), devicesCache.platforms);
  dupes = duplicateDevices(devicesCache.devices);
  renderStale();
  renderDupes();
}

function renderStale() {
  const days = Number($("#stale-days").value) || 30;
  const os = $("#stale-os").value;
  staleList = staleDevices(devicesCache.devices, days).filter((d) => !os || (d.os || "Unknown OS") === os);
  // A stale record that has a newer record under the same name is usually a re-imaged device's
  // leftover, not a missing device. Say so.
  const olderRecords = new Set(dupes.flatMap((g) => g.records.filter((r) => !r.current).map((r) => r.managedId)));
  staleList.forEach((d) => { d.olderDuplicate = olderRecords.has(d.managedId); });
  showExport("stale", staleList.length > 0);
  $("#stale-count").textContent = `${staleList.length.toLocaleString()} of ${devicesCache.devices.length.toLocaleString()}`;
  $("#stale-results").innerHTML = staleList.length
    ? capped(staleList, (rows) => tableHtml(["Device", "Primary user", "OS", "Compliance", "Last check-in", "Ownership"], rows.map((d) => [
      td(`${link(d.link, d.name)}${d.olderDuplicate ? ' <span class="badge" title="A newer Intune record has the same name">older duplicate</span>' : ""}`, "nowrap"),
      td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ])))
    : emptyBox(`Every device has checked in within ${days} days.`);
}

function staleRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Compliance", "Last check-in", "Days since", "Ownership", "Model", "Older duplicate"],
    ...staleList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.compliance, d.lastSync, d.age ?? "never",
      ownerLabel(d.owner), d.model, d.olderDuplicate ? "yes" : ""])];
}

function renderDupes() {
  const records = dupes.reduce((n, g) => n + g.count, 0);
  showExport("dupe", dupes.length > 0);
  $("#dupe-count").textContent = dupes.length ? `${dupes.length} names, ${records} records` : "";
  if (!dupes.length) { $("#dupe-results").innerHTML = emptyBox("No device name has more than one Intune record."); return; }
  const rows = [];
  const older = [];
  for (const g of dupes) {
    g.records.forEach((d, i) => {
      rows.push([
        td(i === 0 ? `<strong>${esc(g.name)}</strong> <span class="muted">×${g.count}</span>` : "", "nowrap"),
        td(link(d.link, "Open in Intune")),
        td(esc(userOf(d))),
        td(esc(d.enrolled ? new Date(d.enrolled).toLocaleDateString() : "")),
        td(checkInCell(d.lastSync)),
        td(d.current ? '<span class="badge ok">Current</span>' : '<span class="badge">Older record</span>'),
      ]);
      older.push(!d.current);
    });
  }
  $("#dupe-results").innerHTML = tableHtml(["Device name", "Record", "Primary user", "Enrolled", "Last check-in", ""], rows.slice(0, 3000), (i) => (older[i] ? 'class="older"' : ""));
}

function dupeRows() {
  return [["Device name", "Record", "Primary user", "UPN", "Enrolled", "Last check-in", "Days since", "Intune device ID"],
    ...dupes.flatMap((g) => g.records.map((d) => [g.name, d.current ? "Current" : "Older record", d.displayName, d.upn,
      d.enrolled, d.lastSync, d.age ?? "never", d.managedId]))];
}

$("#stale-days").addEventListener("input", () => devicesCache && renderStale());
$("#stale-os").addEventListener("input", () => devicesCache && renderStale());
bindExport("stale", () => staleRows(), () => "stale-devices.csv");
bindExport("dupe", () => dupeRows(), () => "duplicate-devices.csv");

// ------------------------------------------------------------------------------------------
// App versions

const appverRun = newestOnly();
let appverApps = [];
let appverRows = []; // the device table shown, for copy and CSV

$("#appver-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const query = $("#appver-query").value.trim();
  const out = $("#appver-results");
  $("#appver-devices").innerHTML = "";
  $("#appver-tools").hidden = true;
  if (!query) { appverRun(); out.innerHTML = ""; return; } // also stops an earlier search from drawing
  runInto(out, appverRun, "Reading the discovered apps...", async (current) => {
    const res = await send("apps/versions", { query });
    if (!current()) return;
    appverApps = res.apps;
    drawAppVersions();
  });
});

function drawAppVersions() {
  const below = $("#appver-below").value.trim();
  const out = $("#appver-results");
  if (!appverApps.length) { out.innerHTML = emptyBox("No discovered app has that name."); return; }
  out.innerHTML = appverApps.map((app, ai) => {
    const older = below ? app.versions.filter((v) => isBelowVersion(v.version, below)) : [];
    const olderDevices = older.reduce((n, v) => n + v.devices, 0);
    return `<article class="card">
      <h2>${esc(app.name)}</h2>
      <div class="muted">${esc([app.publisher, app.platform].filter(Boolean).join(", "))}${app.publisher || app.platform ? " - " : ""}${app.total.toLocaleString()} devices, ${app.versions.length} version${app.versions.length === 1 ? "" : "s"}</div>
      ${tableHtml(["Version", { label: "Devices", num: true }, ""], app.versions.map((v, vi) => [
        td(esc(v.version || "(none)"), "mono"),
        td(v.devices.toLocaleString(), "num"),
        td(`${below && isBelowVersion(v.version, below) ? '<span class="badge warn">older</span> ' : ""}<button type="button" data-app="${ai}" data-ver="${vi}">List devices</button>`),
      ]))}
      ${app.versions.length > 1 ? `<p><button type="button" class="primary" data-app="${ai}" data-all="1">List all ${app.total.toLocaleString()} devices, every version</button></p>` : ""}
      ${older.length ? `<p><button type="button" class="primary" data-app="${ai}" data-below="1">List ${olderDevices.toLocaleString()} devices below ${esc(below)}</button></p>` : ""}
    </article>`;
  }).join("");
}

onEnterOrClear($("#appver-below"), () => { if (appverApps.length) drawAppVersions(); });

$("#appver-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-app]");
  if (!btn) return;
  const app = appverApps[Number(btn.dataset.app)];
  const below = $("#appver-below").value.trim();
  const picked = btn.dataset.all ? app.versions : btn.dataset.below ? app.versions.filter((v) => isBelowVersion(v.version, below)) : [app.versions[Number(btn.dataset.ver)]];
  $("#appver-tools").hidden = true;
  runInto($("#appver-devices"), appverRun, "Reading the devices...", async (current) => {
    const res = await send("apps/devices", { items: picked.map((v) => ({ id: v.id, version: v.version })) });
    if (!current()) return;
    // Graph may leave out primary user and check-in here, or send an empty date (0001-01-01): only then wait
    // for the whole device list to fill them.
    const known = !res.devices.some((d) => !(Date.parse(d.lastSync) > 864e5)) ? new Map() : await loadDevices().then((r) => new Map(r.devices.map((x) => [String(x.managedId).toLowerCase(), x]))).catch(() => new Map());
    if (!current()) return;
    const devices = await scoped(res.devices);
    if (!current()) return;
    for (const d of devices) {
      const full = known.get(String(d.managedId).toLowerCase());
      if (full) Object.assign(d, { upn: full.upn, displayName: full.displayName, lastSync: full.lastSync, compliance: full.compliance });
    }
    appverRows = [["Device", "Primary user", "UPN", "OS", "OS version", "Compliance", "Last check-in", "App", "App version"],
      ...devices.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.compliance, d.lastSync, app.name, d.appVersion])];
    $("#appver-tools").hidden = !devices.length;
    const count = scopeNote() ? `${devices.length.toLocaleString()} of ${res.devices.length.toLocaleString()} devices${scopeNote()}.` : `${devices.length.toLocaleString()} devices.`;
    return (res.failed ? `<p class="muted small">${res.failed} version${res.failed === 1 ? "" : "s"} couldn't be read.</p>` : "") + (devices.length
      ? `<p class="muted small">${count}</p>` + capped(devices, (rows) => tableHtml(["Device", "Primary user", "OS", "Last check-in", "App version"], rows.map((d) => [
        td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)), td(esc(d.appVersion), "mono"),
      ])))
      : emptyBox(`No device${scopeNote()} reported for that selection.`));
  });
});
bindExport("appver", () => appverRows, () => "app-versions.csv");

// ------------------------------------------------------------------------------------------
// Cleanup report

let cleanup = null;

$("#cleanup-run").addEventListener("click", oneAtATime($("#cleanup-run"), async () => {
  const out = $("#cleanup-results");
  showExport("cleanup", false);
  out.innerHTML = loading("Reading your policies and checking every group they use...");
  try {
    const res = await send("cleanup/report");
    cleanup = res.report;
    if (res.policies) renderIndexLine(res.policies);
    out.innerHTML = renderCleanup(cleanup);
    showExport("cleanup", true);
  } catch (err) {
    out.innerHTML = errorBox(err);
  } finally {
    $("#cleanup-run").textContent = "Run again";
  }
}));

/** A headline number with its label (Cleanup's findings, Environment overview's summary); cls colours it (ok, warn, bad). */
const tile = (value, label, cls = "") => `<div class="tile ${cls}"><strong>${esc(value)}</strong>${esc(label)}</div>`;

function renderCleanup(r) {
  const s = r.summary;
  const target = (f) => (f.kind === "exclude" ? '<span class="badge warn">Exclude</span>'
    : `<span class="badge">${f.kind === "allDevices" ? "All devices" : f.kind === "allUsers" ? "All users" : "Include"}</span>${f.intent ? ` <span class="muted small">${esc(f.intent)}</span>` : ""}`);
  const section = (title, note, list, headers, row, { count = String(list.length), rowAttrs } = {}) => `<article class="card">
      <h2>${esc(title)} <span class="muted">· ${esc(count)}</span></h2>
      <p class="muted small" style="margin:2px 0 8px">${esc(note)}</p>
      ${list.length ? tableHtml(headers, list.map(row), rowAttrs) : '<p class="muted">None found.</p>'}
    </article>`;
  // Empty groups: includes (the problem, and what the tile counts) first; harmless excludes greyed out after.
  const emptyGroup = [...r.emptyGroup].sort((a, b) => Number(a.kind === "exclude") - Number(b.kind === "exclude"));
  const emptyExcludes = emptyGroup.length - s.emptyGroup;
  return `<div class="tiles">
      ${tile(s.deletedGroup, "assignments to deleted groups", s.deletedGroup ? "bad" : "ok")}
      ${tile(s.emptyGroup, "assigned to empty groups", s.emptyGroup ? "warn" : "ok")}
      ${tile(s.excludeOnly, "exclude-only (target nobody)", s.excludeOnly ? "warn" : "ok")}
      ${tile(s.unassigned, "not assigned", s.unassigned ? "warn" : "ok")}
      ${s.filtersUnchecked ? "" : tile(s.deletedFilter, "assignments with deleted filters", s.deletedFilter ? "bad" : "ok")}
      ${s.filtersUnchecked ? "" : tile(s.unusedFilter, "unused filters", s.unusedFilter ? "warn" : "ok")}
    </div>
    <p class="muted small">Checked ${s.policies} policies, profiles, scripts and apps, and ${s.groups} groups they use.${s.unchecked ? ` ${s.unchecked} couldn't be checked: Graph wouldn't return their assignments.` : ""}${s.groupsUnchecked ? ` ${s.groupsUnchecked} group${s.groupsUnchecked === 1 ? "" : "s"} couldn't be sized (Graph was busy), so some empty groups may be missing. Run Cleanup again.` : ""}${s.filtersUnchecked ? " Assignment filters couldn't be read, so filters aren't checked." : ` Checked ${s.filters} assignment filter${s.filters === 1 ? "" : "s"}.`}</p>
    ${section("Assigned to deleted groups", "The group no longer exists, so this assignment does nothing. Safe to remove from the policy.", r.deletedGroup,
      ["Name", "Type", "Missing group ID", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(esc(f.groupId), "mono"), td(target(f))])}
    ${section("Assigned to empty groups", "The group has no members (including nested). An include reaches nobody; an exclude is harmless.", emptyGroup,
      ["Name", "Type", "Group", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(link(f.groupLink, f.groupName)), td(target(f))],
      { count: `${s.emptyGroup} include${s.emptyGroup === 1 ? "" : "s"}${emptyExcludes ? ` + ${emptyExcludes} harmless exclude${emptyExcludes === 1 ? "" : "s"}` : ""}`,
        rowAttrs: (i) => (emptyGroup[i].kind === "exclude" ? 'class="older"' : "") })}
    ${section("Exclude-only", "Only exclusions, no includes, so it targets nobody.", r.excludeOnly,
      ["Name", "Type", { label: "Exclusions", num: true }], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(String(f.count), "num")])}
    ${section("Not assigned", "No assignments at all. Unassigned apps aren't listed (the app catalogue includes many built-in apps).", r.unassigned,
      ["Name", "Type"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel))])}
    ${s.filtersUnchecked ? "" : `${section("Assigned with deleted filters", "The assignment names a filter that no longer exists. Check the assignment in the policy and pick a filter again.", r.deletedFilter,
      ["Name", "Type", "Missing filter ID", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(esc(f.filterId), "mono"), td(target(f))])}
    ${section("Unused filters", "No assignment uses this filter. Safe to delete if nobody plans to use it.", r.unusedFilter,
      ["Filter", "Platform", "Rule"], (f) => [td(esc(f.name)), td(esc(platformName(f.platform))), td(esc(f.rule), "mono small")])}
    ${section("Filters in use", "Every assignment filter and what uses it: includes means only matching devices get it, excludes means matching devices don't.", r.filterUse.filter((f) => f.uses.length),
      ["Filter", "Platform", "Rule", "Used by"], (f) => [td(esc(f.name)), td(esc(platformName(f.platform))), td(esc(f.rule), "mono small"),
        td(f.uses.map((u) => `${link(u.link, u.policyName)} <span class="muted small">${u.mode === "exclude" ? "excludes" : "includes"}</span>`).join("<br>"))])}`}`;
}

function cleanupRows() {
  if (!cleanup) return null;
  const rows = [["Finding", "Name", "Type", "Group", "Group ID", "Target", "Filter", "Filter ID"]];
  for (const f of cleanup.deletedGroup) rows.push(["Assigned to deleted group", f.policyName, f.typeLabel, "", f.groupId, f.kind]);
  for (const f of cleanup.emptyGroup) rows.push(["Assigned to empty group", f.policyName, f.typeLabel, f.groupName, f.groupId, f.kind]);
  for (const f of cleanup.excludeOnly) rows.push(["Exclude-only", f.policyName, f.typeLabel, "", "", `${f.count} exclusions`]);
  for (const f of cleanup.unassigned) rows.push(["Not assigned", f.policyName, f.typeLabel, "", "", ""]);
  for (const f of cleanup.deletedFilter || []) rows.push(["Assigned with deleted filter", f.policyName, f.typeLabel, "", f.groupId, f.kind, "", f.filterId]);
  for (const f of cleanup.unusedFilter || []) rows.push(["Unused filter", "", "", "", "", "", f.name, f.filterId]);
  for (const f of cleanup.filterUse || []) for (const u of f.uses) rows.push([`Filter ${u.mode === "exclude" ? "excludes" : "includes"}`, u.policyName, u.typeLabel, "", u.groupId, u.kind, f.name, f.filterId]);
  return rows;
}
bindExport("cleanup", cleanupRows, () => "intune-cleanup.csv");

// Environment overview: a one or two page summary of the fleet from the device list (and the Hardware report when read),
// as Markdown, an HTML page (print it to PDF) or CSV, all written by core/report-doc.js.

let ovDoc = null;

const runOverview = oneAtATime($("#ov-run"), async () => {
  const out = $("#ov-results");
  out.innerHTML = loading("Reading your devices, policies and apps. The first time, the policy index can take a few minutes...");
  try {
    await loadDevices();
    if (!hwData) {
      try {
        const { saved } = await send("hardware/load");
        if (saved) hwData = saved;
      } catch { /* nothing saved: read it below */ }
    }
    // No device read yet: run it here (the Hardware and Security posture read, with the progress bar and Stop), so the
    // security checks need no visit to another tab. A stopped or failed read leaves them out, and the overview says so.
    if (!hwData) {
      out.innerHTML = loading("Reading every device's security details (one request per device; Stop on the bar skips them)...");
      await runHardware();
      out.innerHTML = loading("Reading compliance results, policies and apps...");
    }
    // Firewall comes from the compliance results (Compliance breakdown's read); without them the overview says so.
    const [compliance, objects] = await Promise.all([send("compliance/summary").then((r) => r.all, () => null),
      send("overview/counts").then((r) => r, () => null)]); // policy and app counts; the first use builds the policy index
    ovDoc = environmentOverview(devicesCache.devices, { friendly: globalThis.IEWindowsBuilds?.friendly,
      hardware: hwData ? { at: hwData.at, rows: hwRows() } : null, compliance, objects, scopeName: scope?.name || "" });
    renderOverview();
  } catch (err) {
    out.innerHTML = errorBox(err);
  }
});

function renderOverview() {
  const d = ovDoc;
  const bar = (count, of) => `<span class="pctbar"><span style="width:${of ? Math.round((count / of) * 100) : 0}%"></span></span>`;
  $("#ov-results").innerHTML = `<p class="muted">${esc(d.subtitle)}</p>
    <div class="toolbar tight">
      <span class="spacer"></span>
      <button id="ov-md">Copy Markdown</button>
      <button id="ov-html">Save HTML</button>
      ${exportButtons("ov")}
    </div>
    <div class="tiles">${d.headline.map((h) => tile(h.value, h.label)).join("")}</div>
    <div class="overview-grid">${d.sections.map((s) => `<article class="card"><h2>${esc(s.title)}</h2>${s.rows.length
      ? tableHtml([s.labelHeading || "Value", { label: s.countHeading || "Devices", num: true }, { label: `% of ${s.ofLabel}`, num: true }],
        s.rows.map((r) => [td(esc(r.label)), td(r.count.toLocaleString(), "num"), td(`${docPercent(r.count, s.of)} ${bar(r.count, s.of)}`, "num nowrap")]))
      : ""}${s.note ? `<p class="muted small">${esc(s.note)}</p>` : ""}</article>`).join("")}</div>`;
}

$("#ov-run").addEventListener("click", runOverview);
$("#ov-results").addEventListener("click", (e) => {
  if (!ovDoc) return;
  if (e.target.closest("#ov-md")) copyText(e.target.closest("#ov-md"), docMarkdown(ovDoc));
  if (e.target.closest("#ov-html")) download(`environment-overview-${new Date().toISOString().slice(0, 10)}.html`, new Blob([docHtml(ovDoc)], { type: "text/html" }));
});
bindExport("ov", () => ovDoc && docCsvRows(ovDoc), () => "environment-overview.csv");

// ------------------------------------------------------------------------------------------
// The header shows the installed version beside the name, read from the manifest, without the trailing ".0"
// (2.79.0 reads "v2.79"; nothing to show in the sample preview page).
const appVersion = globalThis.chrome?.runtime?.getManifest?.().version;
if (appVersion) $("#app-version").textContent = `(v${appVersion.replace(/\.0$/, "")})`;

// Setting rows: each name labels its control and the i buttons open one shared card (setting-rows.js).
setupRows(document);
createTipCard($("#tipcard"), document);

// ------------------------------------------------------------------------------------------
// US Government clouds: optional host permissions the admin grants here (core/clouds.js). The worker then
// registers the portal scripts for them (background.js, syncGovScripts).

async function renderGov() {
  // Only the US Government row needs the permissions API; the card's other switches always show.
  const row = $("#gov-row");
  row.hidden = SAMPLE || !chrome.permissions?.contains;
  if (row.hidden) return;
  const on = await chrome.permissions.contains({ origins: GOV.origins }).catch(() => false);
  $("#gov-control").innerHTML = `<span class="muted small">${on ? "allowed" : "not allowed"}</span> ` +
    `<button data-gov data-on="${on ? 1 : 0}">${on ? "Remove access" : "Allow access"}</button>`;
}

$("#gov-list").addEventListener("click", async (e) => {
  const b = e.target.closest("button[data-gov]");
  if (!b) return;
  $("#gov-error").hidden = true;
  try {
    // Must be called straight from the click (a browser rule), so nothing is awaited before it.
    const ok = b.dataset.on === "1" ? await chrome.permissions.remove({ origins: GOV.origins }) : await chrome.permissions.request({ origins: GOV.origins });
    if (!ok && b.dataset.on !== "1") { $("#gov-error").textContent = "Access was not granted."; $("#gov-error").hidden = false; }
  } catch (err) {
    $("#gov-error").textContent = `Could not change access: ${err.message}`; $("#gov-error").hidden = false;
  }
  renderGov();
});

// Settings: the disclosure until it's accepted, then status and the in-portal feature switches.
// Each switch saves its own key in ie.prefs (data-pref); every switch is on unless saved as false
// (the content scripts read them the same way). In sample mode nothing is saved.

// Dropdowns and sliders, with their defaults. Switches need none: they're on unless saved as false.
const DEFAULT_PREFS = {
  primaryUserLabels: "name", lastLoggedOnUser: "icon", friendlyOsVersions: "full", groupSizeHints: "all",
  freeStorageFlags: "10", appInstallStatus: "all", policyStatus: "all", widthDeviceName: 150, widthPolicyName: 150, widthGroupName: 150, widthAppName: 200,
  widthScriptName: 200,
  widthMemberName: 250,
  workspaceScope: false, // the header's Scope control; most admins don't need it
  baselineGap: false, // the Baseline gap tab (Settings > Advanced, experimental)
  remediationDates: false, // in-portal switch that is off until turned on: also in DEFAULT_OFF (content/kit.js)
};
let samplePrefs = { ...DEFAULT_PREFS };

// Device links follow the "New device view" switch; links already built into the device list are redone.
function applyDeviceView(prefs) {
  setNewDeviceView(prefs.newDeviceView);
  if (devicesCache) for (const d of devicesCache.devices) d.link = deviceUrl(d.managedId);
}

async function loadPrefs() {
  if (SAMPLE) return samplePrefs;
  const saved = (await chrome.storage.local.get(PREFS_KEY))[PREFS_KEY] || {};
  return { ...DEFAULT_PREFS, ...saved };
}

async function savePrefs(patch) {
  if (SAMPLE) { samplePrefs = { ...samplePrefs, ...patch }; return; }
  // Only what the admin changed is saved, so a later version's new defaults still apply to the rest. The worker
  // writes it (core/prefs.js), one change after another, so changes close together don't overwrite each other.
  await send("prefs/set", { patch });
}

// The controls are set from storage once, then follow storage changes (below). A device list build sends
// a progress update every 1,000 devices, and re-setting them each time would snap a slider back mid-drag.
let prefsShown = false;

async function renderSettingsTab(s) {
  const on = SAMPLE || s.consented;
  $("#consent").hidden = on;
  $("#settings-main").hidden = !on;
  if (!on) return;
  const ix = s.index || {};
  $("#set-session").textContent = SAMPLE ? "Sample data (fictional)" : s.signedIn ? s.upn || "Signed in" : "Not signed in: open the Intune admin center";
  $("#set-count").textContent = ix.building ? `building... ${ix.count || 0}` : (ix.count || 0).toLocaleString();
  $("#set-built").textContent = ago(ix.builtAt);
  $("#set-rebuild").disabled = Boolean(ix.building) || !s.signedIn;
  $("#set-error").textContent = ix.error || "";
  $("#set-error").hidden = !ix.error;
  renderGov();
  if (!prefsShown) {
    prefsShown = true;
    await showPrefs();
  }
}

/** Set every switch, dropdown and slider from the saved prefs. */
async function showPrefs() {
  const prefs = await loadPrefs();
  applyDeviceView(prefs);
  applyStars(prefs);
  applyExplorerColumns(prefs);
  for (const el of $$("[data-pref]")) {
    if (el.type === "checkbox") el.checked = prefs[el.dataset.pref] !== false;
    else el.value = prefs[el.dataset.pref];
  }
  if ((prefs.workspaceScope === true) !== scopeEnabled) enableScope(prefs.workspaceScope === true); // changed in another tab
  if ((prefs.baselineGap === true) !== baselineEnabled) enableBaseline(prefs.baselineGap === true);
  showWidths();
}

loadPrefs().then(applyStars).catch(() => {}); // the sidebar's stars, before Settings is ever opened

// A column width dragged in the admin center (or a change in another workspace tab) shows here at once.
if (!SAMPLE) {
  chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes[PREFS_KEY]) showPrefs(); });
}

// A slider's percentage beside it.
const showWidths = () => $$("output[data-for]").forEach((o) => { o.textContent = `${$(`[data-pref="${o.dataset.for}"]`).value}%`; });

for (const el of $$("[data-pref]")) {
  const value = () => (el.type === "checkbox" ? el.checked : el.type === "range" ? Number(el.value) : el.value);
  el.addEventListener("change", () => savePrefs({ [el.dataset.pref]: value() }).catch((e) => { $("#set-error").textContent = e.message; $("#set-error").hidden = false; }));
  if (el.type === "range") el.addEventListener("input", showWidths);
}

// #set-error sits in the part of Settings that is hidden until consent, so a failure here uses the banner.
$("#agree").addEventListener("click", async () => {
  try {
    await grantConsent();
  } catch (e) {
    showBanner(`Couldn't turn on: ${e.message}`);
    return;
  }
  $("#all-set").hidden = false;
  await refreshSession();
});

$("#set-rebuild").addEventListener("click", async () => {
  $("#set-rebuild").disabled = true;
  await send("index/rebuild").catch((e) => { $("#set-error").textContent = e.message; $("#set-error").hidden = false; });
  devicesCache = null; // OS builds and Stale & duplicates read the new list
  refreshSession();
});

// Every setting back to its default: the worker removes ie.prefs, the theme choice goes, and the page reloads so
// every control, star and the theme are drawn from the defaults. Stored data and US Government access are kept.
// Footer > Credits. Escape closes a modal dialog by itself; so does a click on the dimmed page around it.
$("#credits-open").addEventListener("click", (e) => { e.preventDefault(); $("#credits").showModal(); });
$("#credits-close").addEventListener("click", () => $("#credits").close());
$("#credits").addEventListener("click", (e) => {
  const box = e.currentTarget.getBoundingClientRect();
  if (e.clientX < box.left || e.clientX > box.right || e.clientY < box.top || e.clientY > box.bottom) e.currentTarget.close();
});

// Top bar > Reset to defaults: what it does is said in the question.
$("#set-reset").addEventListener("click", async () => {
  const ask = "Reset all Intune Enhancer settings to their defaults?\n\nSwitches, dropdowns, column widths, stars and the theme go back to how they were at install. Stored data and US Government cloud access are kept.";
  if (!confirm(ask)) return;
  try {
    if (!SAMPLE) await send("prefs/reset");
  } catch (e) {
    selectTab("settings"); // the button is in the top bar, so the error may be asked for from any tool
    $("#set-error").textContent = `Couldn't reset: ${e.message}`;
    $("#set-error").hidden = false;
    return;
  }
  try { localStorage.removeItem("ie.theme"); } catch { /* storage unavailable */ }
  location.reload();
});

// What the reports show from the cleared data goes too (the Hardware report holds serials, IP and MAC addresses;
// Autopilot rows, Device 360, comparisons and rosters hold names): the page reloads, so nothing read before stays.
$("#set-clear").addEventListener("click", async () => {
  try {
    if (!SAMPLE) await send("data/clear");
  } catch (e) {
    $("#set-error").textContent = `Couldn't clear: ${e.message}`;
    $("#set-error").hidden = false;
    return;
  }
  location.reload();
});

// ------------------------------------------------------------------------------------------
// Scope (header): limits the workspace's device lists to one device group, nested groups included. A view filter
// only: the saved group id and name are in ie.prefs, the member list is read once per visit and kept in memory.

let scopeEnabled = false; // Settings > Advanced > Workspace scope (off by default)
let scope = null; // { id, name, ids: Set of Intune device ids once read }; only while enabled
const scopeReady = loadPrefs().then((p) => {
  scopeEnabled = p.workspaceScope === true;
  if (scopeEnabled && p.scopeGroupId) scope = { id: p.scopeGroupId, name: p.scopeGroupName || "Group", ids: null };
  renderScope();
  enableBaseline(p.baselineGap === true, true);
}).catch(() => {});

/** The scope's Intune device ids (null when there is no scope), read once per visit or when the list is refreshed. */
async function scopeIds(force = false) {
  await scopeReady;
  if (!scopeEnabled || !scope) return null;
  if (scope.ids && !force) return scope.ids;
  const want = scope;
  let res;
  try {
    res = await send("scope/devices", { groupId: want.id });
  } catch (err) {
    throw new Error(`The scope group "${want.name}" could not be read (${err.message}). Clear the scope at the top of the page, or pick another group.`);
  }
  if (scope !== want) return scopeIds(); // the scope changed while this was read
  scope.ids = new Set(res.managedIds);
  scope.name = res.group.name || scope.name;
  renderScope();
  return scope.ids;
}

/** Rows inside the scope (every row when there is none). idOf gives a row's Intune device id. */
async function scoped(rows, idOf = (r) => r.managedId) {
  const ids = await scopeIds();
  return ids ? (rows || []).filter((r) => ids.has(idOf(r))) : rows || [];
}
const scopeNote = () => (scopeEnabled && scope ? ` in ${scope.name}` : "");

function renderScope() {
  $("#scope").hidden = !scopeEnabled;
  const on = !!scope;
  $("#scope").classList.toggle("on", on);
  $("#scope-clear").hidden = !on;
  const text = on ? `Scope: ${scope.name}${scope.ids ? ` (${scope.ids.size.toLocaleString()})` : ""}` : "Scope: All devices";
  $("#scope-text").textContent = text;
  $("#scope-pill").title = on ? `${text}. The workspace's device lists show only this group's devices. Click to change.` : "Show only one device group's devices in the workspace's device lists";
}

function openScopePanel(open) {
  $("#scope-panel").hidden = !open;
  $("#scope-pill").setAttribute("aria-expanded", String(open));
  if (open) $('[data-picker="scope"] input').focus();
}

/** Set (a group from the picker) or clear (null) the scope, then redraw what the device list feeds. */
function setScope(g) {
  scope = g ? { id: g.id, name: g.displayName || "Group", ids: null } : null;
  savePrefs({ scopeGroupId: g?.id || "", scopeGroupName: (g?.displayName || "").slice(0, 64) }).catch(() => {});
  openScopePanel(false);
  renderScope();
  devicesCache = null;
  if (DEVICE_TABS.includes(currentTab)) showDeviceTab(currentTab);
  if (currentTab === "hardware") loadDevices().then(renderHardware, () => {});
  else if (hwData) loadDevices().catch(() => {}); // so the Hardware report is filtered when it is next opened
  renderOrphans(); // redrawn from the answer already read
  if (ovDoc) { ovDoc = null; $("#ov-results").innerHTML = emptyBox("The scope changed. Build the overview again."); }
  $("#comp-devices").innerHTML = ""; compDevices = null; // pick the setting again to see its devices in the new scope
}

/** The Settings switch: on shows the Scope control; off hides it and clears the scope, so every list is whole again. */
function enableScope(on) {
  scopeEnabled = on;
  if (!on && scope) setScope(null);
  else { if (!on) openScopePanel(false); renderScope(); }
}

// Baseline gap: its tab shows only when Settings > Advanced (experimental) turns it on. The worker checks the same setting.
let baselineEnabled = false;
function enableBaseline(on, atStart = false) {
  baselineEnabled = on;
  $('[data-tab="baseline"]').hidden = !on;
  if (!on && currentTab === "baseline") selectTab(DEFAULT_TAB);
  // Prefs load after the first tab is chosen, so a link or the last-used tab that was Baseline gap opens it now.
  if (on && atStart && currentTab === DEFAULT_TAB && (location.hash === "#baseline" || lastTab === "baseline")) selectTab("baseline");
}
$('[data-pref="baselineGap"]').addEventListener("change", (e) => enableBaseline(e.target.checked));

setupPicker("scope", setScope);
$('[data-pref="workspaceScope"]').addEventListener("change", (e) => enableScope(e.target.checked));
$("#scope-pill").addEventListener("click", () => openScopePanel($("#scope-panel").hidden));
$("#scope-clear").addEventListener("click", () => setScope(null));
document.addEventListener("click", (e) => { if (!$("#scope").contains(e.target)) openScopePanel(false); });
$("#scope").addEventListener("keydown", (e) => { if (e.key === "Escape" && !$("#scope-panel").hidden) { openScopePanel(false); $("#scope-pill").focus(); } });

// ------------------------------------------------------------------------------------------
// Theme toggle (theme-init.js has already applied the saved or OS theme)

function syncThemeButton() {
  const dark = document.documentElement.dataset.theme === "dark";
  const label = dark ? "Switch to light theme" : "Switch to dark theme";
  const btn = $("#theme-toggle");
  btn.setAttribute("aria-label", label);
  btn.title = label;
}
$("#theme-toggle").addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem("ie.theme", next); } catch { /* storage unavailable: still switches for this visit */ }
  syncThemeButton();
});
syncThemeButton();

// ------------------------------------------------------------------------------------------
// Start

// Not in sample mode: a real build running in another workspace tab broadcasts its progress to every extension page.
if (inExtension && !SAMPLE) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "policies/progress") {
      if (msg.building) {
        // One plain label while the index walks the item types; the settings stage keeps its type's name.
        const what = / settings$/.test(msg.step || "") ? msg.step : "policy types";
        setIndexLines(`<span class="spinner"></span>Reading ${esc(what)}${msg.total ? ` (${msg.done} of ${msg.total})` : ""}...`);
        jobBar.set("policies", { label: `Reading ${what}`, done: msg.done || 0, total: msg.total || 0, stop: true });
      } else {
        jobBar.done("policies");
      }
    }
    if (msg?.type === "index/progress") {
      if (msg.building) jobBar.set("devices", { label: "Reading your devices", done: msg.count || 0, total: 0, stop: true });
      else jobBar.done("devices");
    }
    if (msg?.type === "job/progress") jobBar.set(msg.key, { label: msg.label, done: msg.done, total: msg.total, stop: true });
    if (msg?.type === "job/done") jobBar.done(msg.key);
    if (msg?.type === "index/progress" && currentTab === "settings") refreshSession();
  });
}

let initialTab = DEFAULT_TAB;
try { initialTab = localStorage.getItem("ie.workspace.tab") || initialTab; } catch { /* storage unavailable */ }
lastTab = initialTab;
// Until it's turned on, the only useful place is Settings. Ask first, so a restored tool doesn't start a read that
// the worker refuses and flash a "turned off" error before Settings opens.
refreshSession().then((s) => {
  if (s && !s.consented && !SAMPLE) selectTab("settings");
  else if (!openFromHash()) selectTab(TABS.includes(initialTab) ? initialTab : DEFAULT_TAB);
});
