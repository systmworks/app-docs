// Sample data for the workspace: a small fictional tenant ("Fabrikam") so the tools can be tried
// without an Intune account (store reviewers, demos, offline UI testing). Answers go through the
// same search and assignment logic as real data. Nothing is read from or sent to any tenant.

import { rollupApps } from "../core/app-versions.js";
import { searchSettings, policiesForGroup, deprecatedSettings, changedPolicies, findPolicies, assignmentCounts, BROAD_TARGETS } from "../core/setting-search.js";
import { broadImpact, groupKind, impactVerdict, compareGroups, inheritedAssignments } from "../core/group-tools.js";
import { parseIds, assignmentSummary } from "../core/id-decoder.js";
import { buildCleanup, referencedGroupIds } from "../core/cleanup.js";
import { orphanedDevices } from "../core/orphaned-users.js";
import { loadBaselines } from "./lazy-data.js";
import { healthRows } from "../core/tenant-health.js";
import { buildDevice360, buildUser360 } from "../core/device-360.js";
import { policyRef } from "../core/portal-links.js";
import { duplicatePolicies } from "../core/duplicate-policies.js";
import { hardwareRow } from "../core/hardware.js";
import { compareDevices } from "../core/device-compare.js";
import { rankSettings, failingDevices } from "../core/compliance-breakdown.js";
import { appliedPolicies, settingsReaching } from "../core/baseline-gap.js";

const today = Date.now();
const iso = (daysAgo) => new Date(today - daysAgo * 86400000).toISOString();

const G = {
  corp: "11111111-aaaa-4000-8000-000000000001",
  pilot: "11111111-aaaa-4000-8000-000000000002",
  kiosk: "11111111-aaaa-4000-8000-000000000003",
  old: "11111111-aaaa-4000-8000-000000000004",
  finance: "11111111-aaaa-4000-8000-000000000005",
};
const inc = (groupId, extra = {}) => ({ kind: "include", groupId, ...extra });
const exc = (groupId) => ({ kind: "exclude", groupId });

const GROUPS = [
  { id: G.corp, displayName: "SG-Devices-Windows-Corporate", groupTypes: [], securityEnabled: true, description: "All corporate Windows devices; holds the Pilot group" },
  { id: G.pilot, displayName: "SG-Devices-Windows-Pilot", groupTypes: [], securityEnabled: true, description: "Early update ring" },
  { id: G.kiosk, displayName: "SG-Devices-Kiosk", groupTypes: [], securityEnabled: true },
  { id: G.old, displayName: "SG-Devices-Legacy-VPN", groupTypes: [], securityEnabled: true, description: "Old VPN rollout, probably unused" },
  { id: G.finance, displayName: "SG-Users-Finance", groupTypes: [], securityEnabled: true },
];

const INDEX = {
  builtAt: Date.now() - 40 * 60000,
  errors: {},
  policies: [
    { id: "p1", type: "settingsCatalog", name: "WIN - BitLocker - Corporate", assignments: [inc(G.corp), exc(G.kiosk)], meta: { platforms: "windows10", technologies: "mdm", templateId: "" }, settings: [
      { d: "device_vendor_msft_bitlocker_requiredeviceencryption", n: "Require Device Encryption", p: "./Device/Vendor/MSFT/BitLocker/RequireDeviceEncryption", v: "Enabled" },
      { d: "device_vendor_msft_bitlocker_encryptionmethodbydrivetype", n: "Choose drive encryption method and cipher strength", p: "./Device/Vendor/MSFT/BitLocker/EncryptionMethodByDriveType", v: "XTS-AES 256-bit" },
    ] },
    { id: "p2", type: "settingsCatalog", name: "WIN - BitLocker - Pilot", assignments: [inc(G.pilot)], settings: [
      { d: "device_vendor_msft_bitlocker_requiredeviceencryption", n: "Require Device Encryption", p: "./Device/Vendor/MSFT/BitLocker/RequireDeviceEncryption", v: "Enabled" },
      { d: "device_vendor_msft_bitlocker_encryptionmethodbydrivetype", n: "Choose drive encryption method and cipher strength", p: "./Device/Vendor/MSFT/BitLocker/EncryptionMethodByDriveType", v: "XTS-AES 128-bit" },
    ] },
    { id: "p3", type: "settingsCatalog", name: "WIN - Device lock", assignments: [{ kind: "allDevices", filterId: "f1", filterType: "exclude" }], settings: [
      { d: "device_vendor_msft_policy_config_devicelock_maxinactivitytimedevicelock", n: "Max Inactivity Time Device Lock", p: "./Device/Vendor/MSFT/Policy/Config/DeviceLock/MaxInactivityTimeDeviceLock", v: "15" },
      { d: "device_vendor_msft_policy_config_devicelock_mindevicepasswordlength", n: "Min Device Password Length", p: "./Device/Vendor/MSFT/Policy/Config/DeviceLock/MinDevicePasswordLength", v: "12" },
      { d: "device_vendor_msft_policy_config_devicelock_allowsimpledevicepassword", n: "Allow Simple Device Password (Deprecated)", p: "./Device/Vendor/MSFT/Policy/Config/DeviceLock/AllowSimpleDevicePassword", v: "Block" },
    ] },
    { id: "p4", type: "adminTemplate", name: "WIN - Edge baseline (ADMX)", assignments: [inc(G.corp)], settings: [
      { d: "edge-homepage", n: "Configure the home page URL", p: "Computer: Microsoft Edge/Startup, home page and new tab page", v: "Enabled" },
      { d: "edge-smartscreen", n: "Configure Microsoft Defender SmartScreen", p: "Computer: Microsoft Edge/SmartScreen settings", v: "Enabled" },
    ] },
    { id: "p5", type: "deviceConfig", name: "WIN - Custom OMA - Legacy VPN", assignments: [inc(G.old)], settings: [
      { d: "oma:./Vendor/MSFT/VPNv2/FabrikamVPN/ProfileXML", n: "Fabrikam VPN profile", p: "./Vendor/MSFT/VPNv2/FabrikamVPN/ProfileXML", v: "<VPNProfile>...</VPNProfile>" },
    ] },
    { id: "p6", type: "compliance", name: "WIN - Compliance - Corporate", assignments: [inc(G.corp)], settings: [
      { d: "windows10CompliancePolicy.bitLockerEnabled", n: "Bit locker enabled", p: "windows10CompliancePolicy.bitLockerEnabled", v: "true" },
      { d: "windows10CompliancePolicy.passwordMinimumLength", n: "Password minimum length", p: "windows10CompliancePolicy.passwordMinimumLength", v: "12" },
    ] },
    { id: "p15", type: "compliance", name: "WIN - Compliance - Corporate (copy)", assignments: [inc(G.pilot)], settings: [
      { d: "windows10CompliancePolicy.bitLockerEnabled", n: "Bit locker enabled", p: "windows10CompliancePolicy.bitLockerEnabled", v: "true" },
      { d: "windows10CompliancePolicy.passwordMinimumLength", n: "Password minimum length", p: "windows10CompliancePolicy.passwordMinimumLength", v: "12" },
    ] },
    { id: "p7", type: "remediation", name: "Clear Teams cache", assignments: [inc(G.pilot)] },
    { id: "p8", type: "app", name: "Fabrikam VPN client", assignments: [inc(G.old, { intent: "required" })] },
    { id: "p9", type: "app", name: "Company Portal", assignments: [{ kind: "allUsers", intent: "available" }] },
    { id: "p10", type: "featureUpdate", name: "Windows 11 24H2 - Broad", assignments: [inc(G.corp), exc(G.pilot)] },
    // Cleanup findings
    { id: "p11", type: "settingsCatalog", name: "WIN - Old proxy settings (test)", assignments: [], settings: [] },
    { id: "p12", type: "windowsScript", name: "Map legacy drives", assignments: [inc("99999999-dead-4000-8000-000000000001", { filterId: "f9", filterType: "include" })] },
    { id: "p13", type: "compliance", name: "WIN - Compliance - Kiosk", assignments: [inc(G.kiosk)], settings: [] },
    { id: "p14", type: "remediation", name: "Disable SMBv1 (paused)", assignments: [exc(G.corp)] },
  ],
};
// Created and modified dates for Recent changes: a spread over the last few months.
const AGES = [2, 5, 9, 15, 26, 40, 61, 3, 120, 12, 33, 200, 7, 1, 18];
INDEX.policies.forEach((p, i) => {
  const age = AGES[i % AGES.length];
  p.modified = iso(age);
  p.created = iso(age + 30 + i * 9);
  // Every sample policy is for Windows, so Device 360 can tell its platform.
  if (p.type === "settingsCatalog") p.meta ||= { platforms: "windows10", technologies: "mdm", templateId: "" };
  else p.odataType = p.type === "app" ? "#microsoft.graph.win32LobApp" : "#microsoft.graph.windows10CustomConfiguration";
});

// The deleted group (p12) has no entry here; the kiosk group is empty.
const SAMPLE_SIZES = {
  [G.corp]: { devices: 1204, users: 0, groups: 0 }, [G.pilot]: { devices: 42, users: 0, groups: 0 },
  [G.kiosk]: { devices: 0, users: 0, groups: 0 }, [G.old]: { devices: 3, users: 0, groups: 0 },
  [G.finance]: { devices: 0, users: 4, groups: 0 },
};

// A small mixed fleet for OS builds and Stale & duplicates.
/** Every fourth Windows device is one or two monthly updates behind (a lower build revision), for the Update check. */
const behindBy = (os, version, n) => (os === "Windows" && n % 4 === 1 ? version.replace(/\d+$/, (r) => String(Number(r) - (n % 8 === 1 ? 150 : 310))) : version);
const SAMPLE_DEVICES = (() => {
  const mix = [
    ["Windows", "10.0.26100.4349", 40], ["Windows", "10.0.26200.6584", 5], ["Windows", "10.0.22631.5472", 18], ["Windows", "10.0.19045.5965", 9],
    ["iOS", "18.6.2", 10], ["iOS", "17.7.1", 3], ["Android", "15", 6], ["Android", "14", 2], ["macOS", "15.6", 4],
  ];
  const people = ["Ana Lima", "Ben Okafor", "Chen Wei", "Dana Smith", "Eli Novak", "Farah Haddad", "Gus Moreau", "Hana Sato"];
  const compliance = ["compliant", "compliant", "compliant", "compliant", "noncompliant", "inGracePeriod"];
  const list = [];
  let n = 0;
  for (const [os, osVersion, count] of mix) {
    for (let i = 0; i < count; i++, n++) {
      const who = people[n % people.length];
      const prefix = os === "Windows" ? "FAB-LT" : os === "macOS" ? "FAB-MAC" : os === "iOS" ? "FAB-IPH" : "FAB-AND";
      // Days since check-in: mostly recent, some 8-30 (orange), some long gone (red).
      const stale = n % 11 === 0 ? 40 + (n % 5) * 25 : n % 7 === 0 ? 10 + (n % 3) * 6 : n % 4;
      list.push({
        managedId: `md-${n}`, name: `${prefix}-${String(100 + n).padStart(4, "0")}`, displayName: who,
        upn: `${who.toLowerCase().replace(" ", ".")}@fabrikam.example`, os, osVersion: behindBy(os, osVersion, n), compliance: compliance[n % compliance.length],
        lastSync: n === 7 ? "" : iso(stale), enrolled: iso(200 + n * 3), owner: n % 9 === 0 ? "personal" : "company", model: os === "Windows" ? (n % 4 ? "Surface Laptop 6" : "Latitude 7450") : "",
        // 256 GB or 512 GB disks, mostly roomy, some nearly full
        userId: `user-${n % people.length}`,
        // Management details (Device explorer)
        manufacturer: os === "Windows" ? (n % 4 ? "Microsoft" : "Dell Inc.") : os === "Android" ? "Samsung" : "Apple",
        joinType: os === "Windows" ? (n % 5 ? "azureADJoined" : "hybridAzureADJoined") : "",
        enrolType: os === "Windows" ? "windowsAzureADJoin" : os === "iOS" ? "appleBulkWithUser" : os === "Android" ? "androidEnterpriseFullyManaged" : "appleUserEnrollment",
        enrolProfile: os === "Windows" && n % 3 === 0 ? "Autopilot - Corporate" : "", agent: "mdm", category: n % 6 === 0 ? "Shared" : "",
        encrypted: n % 7 !== 0, supervised: os === "iOS" ? true : null, autopilot: os === "Windows" ? n % 3 === 0 : null,
        certExpiry: iso(-(30 + n * 4)), graceEnd: compliance[n % compliance.length] === "inGracePeriod" ? iso(-3) : "",
        totalBytes: (n % 3 ? 256 : 512) * 1024 ** 3, freeBytes: (n % 5 === 0 ? 2 + (n % 4) * 3 : 40 + (n % 7) * 20) * 1024 ** 3,
        link: "",
      });
    }
  }
  // Re-imaged devices leave older records behind.
  for (const k of [3, 12, 25]) list.push({ ...list[k], managedId: `md-old-${k}`, lastSync: iso(160 + k), enrolled: iso(700 + k), compliance: "noncompliant" });
  return list;
})();

// Every Windows device in the sample fleet.
const SAMPLE_WINDOWS = SAMPLE_DEVICES.filter((d) => d.os === "Windows");
// The Pilot ring: the first six Windows devices (FAB-LT-0100 to FAB-LT-0105). Pilot is a member of Corporate, so these
// devices are in Pilot directly and in Corporate through it; every other Windows device is in Corporate directly.
const SAMPLE_PILOT = SAMPLE_WINDOWS.slice(0, 6);
const PILOT_IDS = new Set(SAMPLE_PILOT.map((d) => d.managedId));

const ROSTERS = {
  [G.corp]: [
    { type: "Device", name: "FAB-LT-0142", objectId: "o-1", primaryUser: "Ana Lima", upn: "ana.lima@fabrikam.example", compliance: "compliant", os: "Windows", osVersion: "10.0.26100.4349", lastCheckIn: iso(0), managedId: "md-1", intune: true },
    { type: "Device", name: "FAB-LT-0177", objectId: "o-2", primaryUser: "Ben Okafor", upn: "ben.okafor@fabrikam.example", compliance: "noncompliant", os: "Windows", osVersion: "10.0.22631.5472", lastCheckIn: iso(3), managedId: "md-2", intune: true },
    { type: "Device", name: "FAB-LT-0201", objectId: "o-3", primaryUser: "", upn: "", compliance: "compliant", os: "Windows", osVersion: "10.0.26100.4349", lastCheckIn: iso(1), managedId: "md-3", intune: true },
    { type: "Device", name: "FAB-DT-0033", objectId: "o-4", primaryUser: "Chen Wei", upn: "chen.wei@fabrikam.example", compliance: "inGracePeriod", os: "Windows", osVersion: "10.0.19045.5965", lastCheckIn: iso(47), managedId: "md-4", intune: true, duplicates: 2 },
    { type: "Device", name: "FAB-LT-0099", objectId: "o-5", primaryUser: "", upn: "", compliance: "", os: "Windows", osVersion: "", lastCheckIn: "", managedId: "", intune: false },
  ],
  [G.finance]: [
    { type: "User", name: "Ana Lima", objectId: "u-1", upn: "ana.lima@fabrikam.example", enabled: true, department: "Finance", jobTitle: "Accountant",
      devices: [{ name: "FAB-LT-0142" }], deviceCount: 1, compliance: "compliant", os: "Windows", osVersion: "10.0.26100.4349", lastCheckIn: iso(0) },
    { type: "User", name: "Ben Okafor", objectId: "u-2", upn: "ben.okafor@fabrikam.example", enabled: true, department: "Finance", jobTitle: "Finance Manager",
      devices: [{ name: "FAB-LT-0177" }, { name: "FAB-TAB-0012" }], deviceCount: 2, compliance: "noncompliant", os: "Windows", osVersion: "10.0.22631.5472", lastCheckIn: iso(3) },
    { type: "User", name: "Chen Wei", objectId: "u-3", upn: "chen.wei@fabrikam.example", enabled: false, department: "Finance", jobTitle: "Analyst",
      devices: [{ name: "FAB-DT-0033" }], deviceCount: 1, compliance: "inGracePeriod", os: "Windows", osVersion: "10.0.19045.5965", lastCheckIn: iso(47) },
    { type: "User", name: "Dana Smith", objectId: "u-4", upn: "dana.smith@fabrikam.example", enabled: true, department: "Finance", jobTitle: "Contractor", devices: [], deviceCount: 0 },
  ],
};

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

/** A sample group as Device 360 and compareGroups take it: [id, { id, name, direct, via }]. */
const sampleGroup = (id, direct = true, via = "") => [id, { id, name: GROUPS.find((x) => x.id === id).displayName, direct, via }];

// App details for the sample apps: a Win32 app with every kind of rule, and a store app.
const SAMPLE_APPS = {
  p8: {
    app: {
      "@odata.type": "#microsoft.graph.win32LobApp", publisher: "Fabrikam", displayVersion: "4.2.1", fileName: "FabrikamVPN.intunewin", size: 48234496,
      installCommandLine: "msiexec /i FabrikamVPN.msi /qn /norestart", uninstallCommandLine: "msiexec /x {6E0B3E4A-1C2D-4E5F-8A9B-0C1D2E3F4A5B} /qn",
      installExperience: { runAsAccount: "system", deviceRestartBehavior: "basedOnReturnCode", maxRunTimeInMinutes: 60 },
      allowedArchitectures: "x64,arm64", minimumSupportedWindowsRelease: "21H2", minimumFreeDiskSpaceInMB: 500,
      createdDateTime: iso(320), lastModifiedDateTime: iso(26),
      rules: [
        { "@odata.type": "#microsoft.graph.win32LobAppFileSystemRule", ruleType: "detection", path: "C:\\Program Files\\Fabrikam\\VPN", fileOrFolderName: "fabvpn.exe", operationType: "version", operator: "greaterThanOrEqual", comparisonValue: "4.2.1" },
        { "@odata.type": "#microsoft.graph.win32LobAppPowerShellScriptRule", ruleType: "detection", displayName: "Service check", runAs32Bit: false, enforceSignatureCheck: false,
          scriptContent: btoa("$svc = Get-Service -Name FabVPN -ErrorAction SilentlyContinue\nif ($svc) { Write-Output 'Installed' }") },
        { "@odata.type": "#microsoft.graph.win32LobAppRegistryRule", ruleType: "requirement", keyPath: "HKEY_LOCAL_MACHINE\\SOFTWARE\\Fabrikam", valueName: "Licensed", operationType: "exists" },
      ],
      returnCodes: [{ returnCode: 0, type: "success" }, { returnCode: 1707, type: "success" }, { returnCode: 3010, type: "softReboot" }, { returnCode: 1641, type: "hardReboot" }, { returnCode: 1618, type: "retry" }],
    },
    relationships: [
      { "@odata.type": "#microsoft.graph.mobileAppDependency", targetDisplayName: "Fabrikam VPN prerequisites", targetDisplayVersion: "1.0", targetType: "child", dependencyType: "autoInstall" },
      { "@odata.type": "#microsoft.graph.mobileAppSupersedence", targetDisplayName: "Fabrikam VPN client", targetDisplayVersion: "3.9", targetType: "child", supersedenceType: "update" },
    ],
  },
  p9: {
    app: { "@odata.type": "#microsoft.graph.winGetApp", publisher: "Microsoft Corporation", packageIdentifier: "9WZDNCRFJ3PZ", createdDateTime: iso(400), lastModifiedDateTime: iso(90),
      installExperience: { runAsAccount: "user" } },
    relationships: [],
  },
};

// Assignment filters: f1 is used by p3, f2 by nothing, and p12 names f9, which no longer exists.
const SAMPLE_FILTERS = [
  { id: "f1", name: "Exclude kiosks", rule: '(device.deviceCategory -eq "Kiosk")', platform: "windows10AndLater" },
  { id: "f2", name: "Surface devices only", rule: '(device.model -startsWith "Surface")', platform: "windows10AndLater" },
];

/** A sample device's groups: Pilot devices are in Corporate through Pilot, other Windows devices in Corporate only. */
const sampleDeviceGroups = (device) => (device.os !== "Windows" ? []
  : PILOT_IDS.has(device.managedId) ? [sampleGroup(G.pilot), sampleGroup(G.corp, false, "SG-Devices-Windows-Pilot")] : [sampleGroup(G.corp)]);

/** Device 360 for a sample device in the given device and user groups, with the sample filters. */
const sample360 = (device, deviceGroups, userGroups) => buildDevice360(device, INDEX, {
  deviceGroups: new Map(deviceGroups), userGroups: new Map(userGroups),
  filters: new Map(SAMPLE_FILTERS.map((f) => [f.id, f])), notes: [] });

export async function sampleSend(type, payload) {
  await delay(250);
  const policies = { count: INDEX.policies.length, builtAt: INDEX.builtAt, stale: false, building: false, errors: {} };
  switch (type) {
    case "status":
      return { ok: true, consented: true, signedIn: true, upn: "admin@fabrikam.example", policies, index: { count: SAMPLE_DEVICES.length, builtAt: Date.now() - 25 * 60000 } };
    case "policies/build":
      return { ok: true, policies };
    case "settings/search":
      return { ok: true, ...searchSettings(INDEX, payload.query), policies };
    case "settings/deprecated":
      return { ok: true, ...deprecatedSettings(INDEX), policies };
    case "overview/counts":
      return { ok: true, ...assignmentCounts(INDEX, { total: 46, assigned: 2 }) };
    case "policies/changes":
      return { ok: true, items: changedPolicies(INDEX), policies };
    case "groups/search": {
      const q = String(payload.query || "").toLowerCase();
      return { ok: true, groups: GROUPS.filter((g) => g.displayName.toLowerCase().includes(q)) };
    }
    case "scope/devices": {
      const group = GROUPS.find((g) => g.id === payload.groupId);
      if (!group) return { ok: false, error: "That group no longer exists." };
      const ids = { [G.corp]: SAMPLE_WINDOWS, [G.pilot]: SAMPLE_PILOT }[group.id] || [];
      return { ok: true, group: { id: group.id, name: group.displayName }, managedIds: ids.map((d) => d.managedId), members: ids.length };
    }
    case "job/stop":
      return { ok: true };
    case "groups/names":
      return { ok: true, names: Object.fromEntries(GROUPS.map((g) => [g.id, g.displayName])) };
    case "autopilot/events": {
      const ago = (h) => new Date(Date.now() - h * 36e5).toISOString();
      const ev = (id, name, serial, user, hours, state, secs, extra = {}) => ({ id, state, when: ago(hours), details: null, detailsNote: "", identity: null,
        event: { id, managedDeviceName: name, deviceSerialNumber: serial, userPrincipalName: user, enrollmentStartDateTime: ago(hours), enrollmentType: "azureADJoinUsingDeviceAuth",
          windowsAutopilotDeploymentProfileDisplayName: "Fabrikam Autopilot Hybrid", deploymentState: state, deploymentDuration: `PT${secs}S`, osVersion: "10.0.26100.4349", deviceSetupStatus: state === "failure" ? "failed" : "success", accountSetupStatus: state === "failure" ? "notStarted" : "success", targetedAppCount: 6, targetedPolicyCount: 12, ...extra } });
      const rows = [
        ev("e1", "FAB-LT-0142", "5CG40715K5", "ana.lima@fabrikam.example", 5, "failure", 1310, { enrollmentFailureDetails: "Something went wrong during device setup (0x80070774)" }),
        ev("e2", "FAB-LT-0125", "5CG5490V4R", "ben.okafor@fabrikam.example", 20, "failure", 2410),
        ev("e3", "DESKTOP-M4TORUM", "5CG3432GY5", "chen.wei@fabrikam.example", 31, "unknown", 1),
        ev("e4", "FAB-LT-0150", "5CG61223YS", "dana.smith@fabrikam.example", 55, "success", 392),
        ev("e5", "FAB-LT-0173", "5CG4240YTL", "ana.lima@fabrikam.example", 100, "failure", 3010),
      ];
      const item = (displayName, policyType, complianceStatus, errorCode) => ({ displayName, policyType, complianceStatus, errorCode, trackedOnEnrollmentStatus: true, lastReportedDateTime: ago(4) });
      rows[0].details = [item("Company Portal", "app", "installed", 0), item("Fabrikam VPN Client", "app", "failed", -2016281112), item("WIN - Security - BitLocker", "policy", "compliant", 0)];
      rows[1].details = [item("Fabrikam VPN Client", "app", "failed", -2016281112), item("Microsoft 365 Apps", "app", "failed", -2147023436)];
      rows[4].details = [item("Fabrikam VPN Client", "app", "failed", -2016281112)];
      rows[0].identity = { serialNumber: "5CG40715K5", model: "Surface Laptop 6", manufacturer: "Microsoft Corporation", groupTag: "Hybrid-Corp", deploymentProfileAssignmentStatus: "assignedUnkownSyncState", lastContactedDateTime: ago(5) };
      rows[1].identity = { serialNumber: "5CG5490V4R", model: "Surface Laptop 6", manufacturer: "Microsoft Corporation", groupTag: "Hybrid-Corp", lastContactedDateTime: ago(20) };
      const hist = (n, later) => ({ attempts: n, position: n, failedOrUnknown: n, first: ago(30), last: ago(5), laterSuccess: later ? ago(2) : "" });
      const espOf = (agrees) => ({ actualId: "x_Default", actualName: "Default", expectedId: agrees ? "x_Default" : "e-hybrid", expectedName: agrees ? "Default" : "Fabrikam Hybrid ESP", agrees,
        candidates: [{ id: "e-hybrid", name: "Fabrikam Hybrid ESP", priority: 1, assigned: true, matches: !agrees, via: agrees ? "" : "FAB-Autopilot-Laptops" }],
        note: agrees ? "The Default enrollment status page applies: no assigned page targets this device or its user (read now)." : 'Expected "Fabrikam Hybrid ESP" (FAB-Autopilot-Laptops) but the event used "Default". Membership is read now, not as at enrollment.' });
      const entra = (trust) => ({ id: "00000000-1111-2222-3333-444444444444", displayName: "FAB-LT-0142", trustType: trust, accountEnabled: true, approximateLastSignInDateTime: ago(3), registrationDateTime: ago(300) });
      const device = { id: "d1", deviceName: "FAB-LT-0142", lastSyncDateTime: ago(3), complianceState: "compliant", managementState: "managed", operatingSystem: "Windows" };
      const profile = { displayName: "Fabrikam Autopilot Hybrid", kind: "Hybrid Azure AD join", deviceNameTemplate: "FAB-LT-%SERIAL%", assignedGroups: [{ id: "g1", name: "FAB-Autopilot-Laptops", rule: '(device.devicePhysicalIds -any (_ -eq "[OrderID]:Laptop"))', excluded: false, deviceIsMember: true }] };
      rows[0].history = hist(2, true); rows[0].esp = espOf(false); rows[0].entra = entra("ServerAd"); rows[0].device = device; rows[0].profile = profile;
      rows[0].deviceGroups = [{ id: "g1", name: "FAB-Autopilot-Laptops" }]; rows[0].userGroups = [{ id: "g2", name: "All Staff" }]; rows[0].joinNotes = {};
      rows[1].history = hist(1, false); rows[1].esp = espOf(true); rows[1].entra = entra("AzureAd"); rows[1].device = { ...device, deviceName: "FAB-LT-0125" }; rows[1].joinNotes = {};
      rows[2].history = hist(3, true); rows[2].esp = espOf(true); rows[2].joinNotes = { entra: "Entra has no record of this device (a stale Autopilot stub was removed, or the join has not finished)." };
      for (const r of rows.slice(3)) { r.history = hist(1, false); r.joinNotes = {}; }
      const days = Math.min(30, Math.max(1, Number(payload.days) || 7));
      return { ok: true, days, at: Date.now(), rows: rows.filter((r) => Date.now() - Date.parse(r.when) < days * 864e5) };
    }
    case "failed/apps": {
      const app = (id, name, version, platform, df, di, uf, ui) => ({ id, name, version, platform, link: "", device: { fail: df, ok: di }, user: { fail: uf, ok: ui } });
      return { ok: true, at: Date.now(), rows: [
        app("a1", "Microsoft Teams (new)", "25306.805", "Windows", 38, 1190, 31, 1020),
        app("a2", "Adobe Acrobat Reader DC", "25.001.20643", "Windows", 21, 498, 19, 470),
        app("a3", "Google Chrome", "141.0.7390.123", "Windows", 4, 574, 4, 560),
        app("a4", "Zoom Workplace", "6.6.10", "macOS", 12, 120, 12, 118),
        app("a5", "Microsoft Outlook", "4.2540.0", "iOS/iPadOS", 9, 210, 9, 205),
        app("a6", "Company Portal", "5.0.6", "Android", 6, 95, 6, 94),
        app("a7", "7-Zip", "25.01", "Windows", 0, 574, 0, 560),
        app("a8", "Slack", "4.46.99", "macOS", 2, 66, 2, 66),
      ] };
    }
    case "failed/policies/list": {
      const item = (id, name, platform, typeLabel) => ({ id, name, kind: "catalog", platform, typeLabel, link: "" });
      return { ok: true, items: [
        item("p1", "WIN - Security - BitLocker OS Drive Encryption", "Windows", "Settings catalog"),
        item("p2", "WIN - Security - Attack Surface Reduction Rules", "Windows", "Settings catalog"),
        item("p3", "WIN - Config - Edge Browser Settings", "Windows", "Administrative template"),
        item("p4", "MAC - Security - FileVault", "macOS", "Settings catalog"),
        item("p5", "IOS - Config - Wi-Fi Corporate", "iOS/iPadOS", "Device configuration (template)"),
        item("p6", "AND - Config - Work Profile", "Android", "Device configuration (template)"),
        item("p7", "WIN - Config - Time Zone", "Windows", "Settings catalog"),
      ] };
    }
    case "failed/policies/read": {
      const c = (fail, conflict, ok) => ({ fail, conflict, ok });
      const table = {
        p1: { device: c(15, 3, 574), user: c(14, 2, 560) },
        p2: { device: c(0, 9, 560), user: c(0, 8, 548) },
        p3: { device: c(3, 0, 571), user: c(3, 0, 560) },
        p4: { device: c(7, 1, 120), user: c(7, 1, 118) },
        p5: { device: c(0, 0, 88), user: null },
        p6: { device: c(2, 0, 40), user: c(2, 0, 40) },
        p7: { device: c(0, 0, 574), user: c(0, 0, 560) },
      };
      return { ok: true, results: Object.fromEntries((payload.items || []).map((i) => [i.id, table[i.id] || { device: null, user: null }])) };
    }
    case "group/broad":
      if (!Object.hasOwn(BROAD_TARGETS, payload.target)) return { ok: false, error: "Bad request." };
      return { ok: true, report: broadImpact(INDEX, payload.target), policies };
    case "group/impact": {
      const g = GROUPS.find((x) => x.id === payload.groupId);
      if (!g) return { ok: false, error: "That group no longer exists." };
      const intune = policiesForGroup(INDEX, payload.groupId);
      const isOld = g.id === G.old;
      // The pilot group is a member of the corporate group, so it gets the corporate group's assignments too.
      const parentGroups = g.id === G.pilot ? [{ id: G.corp, name: "SG-Devices-Windows-Corporate", direct: true, via: "" }] : [];
      const inherited = inheritedAssignments(INDEX, parentGroups);
      const checklist = [
        { label: "Intune assignments", count: intune.length, status: intune.length ? "in-use" : "clear", detail: `${intune.filter((i) => i.kind === "include").length} include, ${intune.filter((i) => i.kind === "exclude").length} exclude` },
        { label: "Assignments through parent groups", count: inherited.length, status: inherited.length ? "in-use" : "clear", detail: "Its members also get these, through groups this group is in" },
        { label: "Conditional Access policies", count: g.id === G.corp ? 1 : 0, status: g.id === G.corp ? "in-use" : "clear", detail: "" },
        { label: "Enterprise app assignments", count: 0, status: "clear", detail: "" },
        { label: "Group-based licences", count: 0, status: "clear", detail: "" },
        { label: "Intune role assignments", count: null, status: "unknown", detail: "Couldn't check (your role or session doesn't have access): sample of a permission gap" },
        { label: "Member of other groups", count: parentGroups.length, status: parentGroups.length ? "in-use" : "clear", detail: "Removing this group changes the membership of these parent groups" },
        { label: "Contains other groups", count: 0, status: "clear", detail: "" },
      ];
      const verdict = impactVerdict(checklist);
      return { ok: true, report: {
        group: { id: g.id, name: g.displayName, description: g.description || "", kind: groupKind(g), rule: "", synced: false, created: iso(900) },
        members: { devices: isOld ? 3 : g.id === G.corp ? 1204 : 42, users: 0 },
        owners: ["Dana Smith"],
        intune,
        inherited,
        conditionalAccess: g.id === G.corp ? [{ name: "Require compliant device for Office", mode: "include", state: "enabled" }] : [],
        appAssignments: [], licenses: [], roleAssignments: [], parents: parentGroups.map((p) => ({ id: p.id, displayName: p.name })), children: [],
        checklist, verdict, policyIndexBuiltAt: INDEX.builtAt, link: "",
      } };
    }
    case "group/roster": {
      const g = GROUPS.find((x) => x.id === payload.groupId);
      if (!g) return { ok: false, error: "That group no longer exists." };
      return { ok: true, roster: { group: { id: g.id, name: g.displayName }, rows: ROSTERS[g.id] || ROSTERS[G.corp] } };
    }
    case "apps/versions": {
      const apps = [["Google Chrome", "Google LLC", [["141.0.7390.123", 566], ["140.0.7339.208", 24], ["138.0.7204.101", 6]]],
        ["7-Zip", "Igor Pavlov", [["25.01", 410], ["24.09", 120], ["23.01", 44]]]];
      const q = String(payload.query || "").toLowerCase();
      return { ok: true, apps: rollupApps(apps.filter(([name]) => name.toLowerCase().includes(q)).flatMap(([displayName, publisher, versions]) =>
        versions.map(([version, deviceCount], i) => ({ id: `00000000-0000-4000-8000-${String(displayName.length * 10 + i).padStart(12, "0")}`, displayName, publisher, version, deviceCount, platform: "windows" })))) };
    }
    case "apps/devices":
      return { ok: true, failed: 0, devices: SAMPLE_DEVICES.slice(0, 8).map((d, i) => ({ ...d, appVersion: payload.items[i % payload.items.length].version })) };
    case "devices/list":
      return { ok: true, devices: SAMPLE_DEVICES.map((d) => ({ ...d })), builtAt: Date.now() - 25 * 60000 };
    case "devices/orphaned": {
      // Two of the eight sample people have left: one deleted, one disabled.
      const states = new Map([["user-2", "deleted"], ["user-5", "disabled"]]);
      const { list, unknown } = orphanedDevices(SAMPLE_DEVICES, states);
      return { ok: true, devices: list, unknown, checked: 8, builtAt: Date.now() - 25 * 60000 };
    }
    case "compliance/summary":
      return { ok: true, ...rankSettings([
        { id: "c1", setting: "Windows10CompliancePolicy.BitLockerEnabled", platformType: "windows10", nonCompliantDeviceCount: 14, errorDeviceCount: 1, conflictDeviceCount: 0, compliantDeviceCount: 71, remediatedDeviceCount: 0 },
        { id: "c2", setting: "Windows10CompliancePolicy.PasswordMinimumLength", platformType: "windows10", nonCompliantDeviceCount: 5, errorDeviceCount: 0, conflictDeviceCount: 2, compliantDeviceCount: 80, remediatedDeviceCount: 0 },
        { id: "c3", setting: "Windows10CompliancePolicy.SecureBootEnabled", platformType: "windows10", nonCompliantDeviceCount: 0, errorDeviceCount: 0, conflictDeviceCount: 0, compliantDeviceCount: 86, remediatedDeviceCount: 0 },
        { id: "c4", setting: "Windows10CompliancePolicy.ActiveFirewallRequired", platformType: "windows10", nonCompliantDeviceCount: 3, errorDeviceCount: 1, conflictDeviceCount: 0, compliantDeviceCount: 71, remediatedDeviceCount: 0 },
      ]) };
    case "compliance/devices": {
      const states = SAMPLE_DEVICES.slice(0, payload.id === "c1" ? 8 : 4).map((d, i) => ({ deviceId: d.managedId, deviceName: d.name, userPrincipalName: d.upn, state: i % 5 === 4 ? "error" : "nonCompliant" }));
      return { ok: true, devices: failingDevices(states, SAMPLE_DEVICES) };
    }
    case "devices/compare": {
      const a = SAMPLE_DEVICES.find((d) => d.managedId === payload.a);
      const b = SAMPLE_DEVICES.find((d) => d.managedId === payload.b);
      if (!a || !b) return { ok: false, error: "That device is not in the sample data." };
      return { ok: true, ...compareDevices(
        sample360(a, sampleDeviceGroups(a), [sampleGroup(G.finance)]),
        sample360(b, [sampleGroup(G.corp), sampleGroup(G.kiosk)], [])) };
    }
    case "hardware/load":
      return { ok: true, saved: null };
    case "hardware/save":
      return { ok: true };
    case "hardware/read": {
      const rows = payload.ids.map((id) => SAMPLE_DEVICES.find((d) => d.managedId === id)).filter(Boolean).map((d, i) => hardwareRow({
        id: d.managedId, deviceName: d.name, userPrincipalName: d.upn, userDisplayName: d.displayName, manufacturer: d.manufacturer, model: d.model, operatingSystem: d.os, osVersion: d.osVersion,
        physicalMemoryInBytes: [8, 16, 32][i % 3] * 1024 ** 3, totalStorageSpaceInBytes: d.totalBytes, freeStorageSpaceInBytes: d.freeBytes,
        isEncrypted: d.encrypted, enrolledDateTime: d.enrolled, lastSyncDateTime: d.lastSync, managedDeviceOwnerType: d.owner,
        hardwareInformation: { tpmSpecificationVersion: d.os !== "Windows" ? "" : i % 11 === 5 ? "1.2" : "2.0", batteryHealthPercentage: 70 + (i * 3) % 30,
          deviceGuardVirtualizationBasedSecurityState: d.os !== "Windows" ? "" : i % 6 === 0 ? "notConfigured" : "running",
          deviceGuardLocalSystemAuthorityCredentialGuardState: d.os !== "Windows" ? "" : i % 4 === 0 ? "notConfigured" : "running" },
        deviceHealthAttestationState: d.os !== "Windows" ? null : { secureBoot: i % 9 === 0 ? "disabled" : "enabled", bitLockerStatus: d.encrypted ? "enabled" : "disabled",
          codeIntegrity: "enabled", lastUpdateDateTime: d.lastSync },
        _encryption: { encryptionState: d.encrypted ? "encrypted" : "notEncrypted", encryptionReadinessState: d.os === "Windows" && i % 13 === 0 ? "notReady" : "ready",
          advancedBitLockerStates: d.os === "Windows" && !d.encrypted ? "osVolumeUnprotected, recoveryKeyBackupFailed" : "" } }));
      return { ok: true, rows, failed: 0 };
    }
    case "policies/duplicates":
      return { ok: true, ...duplicatePolicies(INDEX), builtAt: INDEX.builtAt };
    case "policy/find":
      return { ok: true, ...findPolicies(INDEX, payload.query, 50, { apps: payload.apps === true }) };
    case "policy/get": {
      const policy = INDEX.policies.find((p) => p.id === payload.id);
      if (!policy) return { ok: false, error: "That policy is not in the sample data." };
      return { ok: true, policy: { ...policy, ...policyRef(policy) }, names: Object.fromEntries(GROUPS.map((g) => [g.id, g.displayName])),
        filters: Object.fromEntries(SAMPLE_FILTERS.map((f) => [f.id, { name: f.name }])) };
    }
    case "app/details": {
      const policy = INDEX.policies.find((p) => p.id === payload.id && p.type === "app");
      if (!policy) return { ok: false, error: "That app is not in the sample data." };
      return { ok: true, ...SAMPLE_APPS[policy.id] };
    }
    case "users/search": {
      const q = String(payload.query || "").toLowerCase();
      const people = ["Ana Lima", "Ben Okafor", "Chen Wei", "Dana Smith"];
      return { ok: true, users: people.map((n, i) => ({ id: `user-${i}`, displayName: n, userPrincipalName: `${n.toLowerCase().replace(" ", ".")}@fabrikam.example` })).filter((u) => u.displayName.toLowerCase().includes(q)) };
    }
    case "user/360": {
      const people = ["Ana Lima", "Ben Okafor", "Chen Wei", "Dana Smith"];
      const i = people.findIndex((_, n) => `user-${n}` === payload.userId);
      if (i < 0) return { ok: false, error: "That user is not in the sample data." };
      const upn = `${people[i].toLowerCase().replace(" ", ".")}@fabrikam.example`;
      const user = { id: payload.userId, displayName: people[i], userPrincipalName: upn, accountEnabled: i !== 2, jobTitle: "Analyst", department: "Finance" };
      return { ok: true, report: buildUser360(user, SAMPLE_DEVICES.filter((d) => d.upn === upn), INDEX, {
        userGroups: new Map([sampleGroup(G.finance)]), filters: new Map(SAMPLE_FILTERS.map((f) => [f.id, f])), notes: [] }) };
    }
    case "users/compare":
      return { ok: true, ...compareGroups(new Map([sampleGroup(G.finance), sampleGroup(G.corp, false, "SG-Users-Finance")]),
        new Map([sampleGroup(G.finance), sampleGroup(G.kiosk)])), unreadable: { a: false, b: false } };
    case "device/360": {
      const device = SAMPLE_DEVICES.find((d) => d.managedId === payload.managedId);
      if (!device) return { ok: false, error: "That device is not in the sample data." };
      const report = sample360(device, sampleDeviceGroups(device), [sampleGroup(G.finance)]);
      return { ok: true, report: { ...report, settings: settingsReaching(appliedPolicies(report, INDEX)) } };
    }
    case "baseline/applied": {
      const { baselines } = await loadBaselines();
      const baseline = baselines.find((b) => b.id === payload.baseline) || baselines[0];
      // A few fictional policies that set some of this baseline's recommendations, so the report has every status.
      const set = (row, v, r) => ({ d: row[0], n: row[1], p: row[8] ? `./Device/${row[8]}` : row[1], v, ...(r !== undefined ? { r } : {}) });
      const rows = baseline.rows;
      const pick = (n) => rows.filter((r) => r[8]).slice(n, n + 1)[0];
      const settings = [set(pick(0), pick(0)[4] || "Enabled"), set(pick(1), pick(1)[4] === "Enabled" ? "Disabled" : "Enabled"), set(pick(2), pick(2)[4] || "Enabled"), set(pick(3), "Enabled")];
      const applied = [
        { id: "p1", name: "WIN - Security - Baseline settings", typeKey: "settingsCatalog", certainty: "applies", settings },
        { id: "p2", name: "WIN - Security - Extra hardening", typeKey: "settingsCatalog", certainty: "filter", settings: [set(pick(4), pick(4)[4] || "Enabled")] },
      ];
      return { ok: true, device: { name: "FAB-LT-0142", user: "Ana Lima", os: "Windows", osVersion: "10.0.26100.4349", link: "" }, indexBuiltAt: Date.now() - 36e5, indexErrors: [], applied };
    }
    case "tenant/health": {
      const inDays = (n) => new Date(Date.now() + n * 86400000).toISOString();
      const answers = new Map([
        ["apple", { status: 200, body: { appleIdentifier: "mdm@fabrikam.example", expirationDateTime: inDays(12) } }],
        ["vpp", { status: 200, body: { value: [{ organizationName: "Fabrikam Education", expirationDateTime: inDays(210), state: "valid" }] } }],
        ["ade", { status: 200, body: { value: [{ tokenName: "Fabrikam ADE", tokenExpirationDateTime: inDays(-3) }] } }],
        ["play", { status: 200, body: { ownerUserPrincipalName: "admin@fabrikam.example", bindStatus: "boundAndValidated" } }],
        ["ndes", { status: 403 }],
        ["domainjoin", { status: 200, body: { value: [{ displayName: "FAB-CONNECTOR01", state: "active", lastConnectionDateTime: new Date(Date.now() - 36e5).toISOString(), version: "6.2504.2001.8" }] } }],
      ]);
      return { ok: true, rows: healthRows(answers), at: Date.now() };
    }
    case "index/rebuild":
    case "data/clear":
      return { ok: true };
    case "cleanup/report": {
      const known = new Set(GROUPS.map((g) => g.id));
      const names = Object.fromEntries(referencedGroupIds(INDEX).filter((id) => known.has(id)).map((id) => [id, GROUPS.find((g) => g.id === id).displayName]));
      return { ok: true, report: buildCleanup(INDEX, names, SAMPLE_SIZES, SAMPLE_FILTERS), policies };
    }
    case "ids/decode": {
      const ids = parseIds(payload.text);
      if (!ids.length) return { ok: true, ids: [], message: "No IDs found. Paste an ID (a GUID) or an admin center link." };
      const names = Object.fromEntries(GROUPS.map((g) => [g.id, g.displayName]));
      return { ok: true, policyIndexBuiltAt: INDEX.builtAt, ids: ids.map(({ guid, hint }) => {
        const group = GROUPS.find((x) => x.id === guid);
        if (group) return { guid, hint, matches: [{ kind: "Group", name: group.displayName, extra: group.description || "", link: "" }] };
        // Any other id decodes as the sample BitLocker policy, to show the policy details.
        const p = INDEX.policies[0];
        return { guid, hint, matches: [{ kind: "Settings catalog", name: p.name, link: "",
          extra: `Windows · ${p.settings.length} settings · modified ${new Date(today - 9 * 86400000).toLocaleDateString()}`,
          assigned: assignmentSummary(p.assignments, names) }] };
      }) };
    }
    default:
      return { ok: false, error: `Sample mode doesn't handle ${type}` };
  }
}
