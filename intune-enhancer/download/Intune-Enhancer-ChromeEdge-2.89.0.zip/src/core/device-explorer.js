// Device explorer: every device in the device list as one table, with the columns the admin picks. The fields come
// from the device index (devices/list), so nothing more is read from Graph; the field list uses the Hardware report's
// format ({ key, label, num, get }) so both reports share hardwareColumns (columns nobody has a value for are left
// out). `on` marks the columns shown until the admin picks others (saved in ie.prefs as explorerColumns). Pure.

import { day, words, gb } from "./format.js";
import { releaseOf } from "./device-reports.js";

/** A management agent as its usual name: "MDM", "EAS and MDM", "Co-managed (Configuration Manager)", else as words. */
export const agentName = (agent) => ({ mdm: "MDM", eas: "EAS", easMdm: "EAS and MDM", configurationManagerClient: "Configuration Manager",
  configurationManagerClientMdm: "Co-managed (Configuration Manager)", configurationManagerClientMdmEas: "Co-managed (Configuration Manager), EAS",
  intuneClient: "Intune PC client", jamf: "Jamf", googleCloudDevicePolicyController: "Google device policy" })[agent] || words(agent || "");

const exYes = (v) => (typeof v === "boolean" ? (v ? "Yes" : "No") : "");
const exGb = (bytes) => (Number(bytes) > 0 ? Math.round(gb(bytes) * 10) / 10 : "");

export const EXPLORER_FIELDS = [
  { key: "name", label: "Device", on: true, nowrap: true, get: (d) => d.name || "" },
  { key: "user", label: "Primary user", on: true, nowrap: true, get: (d) => d.displayName || d.upn || "" },
  { key: "upn", label: "Primary user UPN", get: (d) => d.upn || "" },
  { key: "os", label: "OS", on: true, get: (d) => d.os || "" },
  { key: "release", label: "Release", on: true, get: (d, friendly) => (d.osVersion ? releaseOf(d, friendly).label : "") },
  { key: "osVersion", label: "OS version", get: (d) => d.osVersion || "" },
  { key: "compliance", label: "Compliance", on: true, get: (d) => words(d.compliance || "") },
  { key: "lastSync", label: "Last check-in", on: true, get: (d) => day(d.lastSync) },
  { key: "enrolled", label: "Enrolled", get: (d) => day(d.enrolled) },
  { key: "owner", label: "Ownership", on: true, get: (d) => words(d.owner || "") },
  { key: "joinType", label: "Join type", on: true, get: (d) => words(d.joinType || "") },
  { key: "enrolType", label: "Enrolment type", get: (d) => words(d.enrolType || "") },
  { key: "enrolProfile", label: "Enrolment profile", get: (d) => d.enrolProfile || "" },
  { key: "agent", label: "Management agent", get: (d) => agentName(d.agent) },
  { key: "manufacturer", label: "Manufacturer", on: true, get: (d) => d.manufacturer || "" },
  { key: "model", label: "Model", on: true, get: (d) => d.model || "" },
  { key: "serial", label: "Serial number", on: true, get: (d) => d.serial || "" },
  { key: "category", label: "Category", get: (d) => d.category || "" },
  { key: "encrypted", label: "Encrypted", on: true, get: (d) => exYes(d.encrypted) },
  { key: "supervised", label: "Supervised", get: (d) => exYes(d.supervised) },
  { key: "autopilot", label: "Autopilot", get: (d) => exYes(d.autopilot) },
  { key: "certExpiry", label: "MDM certificate expires", on: true, get: (d) => day(d.certExpiry) },
  { key: "graceEnd", label: "Grace period ends", get: (d) => day(d.graceEnd) },
  { key: "freeGb", label: "Free (GB)", num: true, get: (d) => exGb(d.freeBytes) },
  { key: "totalGb", label: "Storage (GB)", num: true, get: (d) => exGb(d.totalBytes) },
  { key: "managedId", label: "Intune device ID", get: (d) => d.managedId || "" },
  { key: "aadId", label: "Entra device ID", get: (d) => d.aadId || "" },
];

/** The column keys shown until the admin picks others. */
export const EXPLORER_DEFAULT = EXPLORER_FIELDS.filter((f) => f.on).map((f) => f.key);

/** One device from the device list as a flat row of every explorer field (friendly: Windows build to release name). */
export function explorerRow(device, friendly) {
  const row = { id: device.managedId, link: device.link || "" };
  for (const f of EXPLORER_FIELDS) row[f.key] = f.get(device, friendly);
  return row;
}
