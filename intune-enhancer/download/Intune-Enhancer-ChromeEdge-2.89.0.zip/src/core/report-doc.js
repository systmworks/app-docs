// One report, three files: a report document ({ title, subtitle, headline, sections }) written as Markdown, as a
// self-contained HTML page (opens anywhere, and the browser's Print saves it as a PDF), or as CSV rows. Each section
// is a small count table: { title, of, ofLabel, labelHeading, countHeading, note, rows: [{ label, count }] }, its
// percentages taken of `of` (countHeading: what is counted, "Devices" unless the section says otherwise).
// The HTML uses the workspace's light theme colours (copied from workspace.css, defined once in its :root) on a white
// page whatever theme the workspace is in, and asks the browser to keep the box fills when it prints. Pure.

const rdEsc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const rdCell = (s) => String(s ?? "").replace(/\s*\r?\n\s*/g, " ").replace(/\|/g, "\\|");

/** A count as a percentage of a base, "37%" (one decimal under 10%), "" without a base. */
export const docPercent = (count, of) => {
  if (!of) return "";
  const p = (count / of) * 100;
  return `${p > 0 && p < 10 ? p.toFixed(1) : Math.round(p)}%`;
};

/** The report as Markdown: title, headline facts, one table per section. */
export function docMarkdown(doc) {
  const md = [`# ${doc.title}`, "", ...(doc.subtitle ? [doc.subtitle, ""] : []), ...(doc.headline || []).map((h) => `- ${h.label}: ${h.value}`)];
  for (const s of doc.sections) {
    md.push("", `## ${s.title}`, "");
    if (s.rows.length) md.push(`| ${rdCell(s.labelHeading || "Value")} | ${rdCell(s.countHeading || "Devices")} | % of ${rdCell(s.ofLabel || "devices")} |`, "|---|---:|---:|", ...s.rows.map((r) => `| ${rdCell(r.label)} | ${r.count} | ${docPercent(r.count, s.of)} |`));
    if (s.note) md.push("", s.note);
  }
  return md.join("\n") + "\n";
}

/** The report as one HTML page with its own small stylesheet: two sections side by side, each kept on one page. */
export function docHtml(doc) {
  const head = (doc.headline || []).map((h) => `<div><strong>${rdEsc(h.value)}</strong>${rdEsc(h.label)}</div>`).join("");
  const sections = doc.sections.map((s) => `<section><h2>${rdEsc(s.title)}</h2>${s.rows.length
    ? `<table><tr><th>${rdEsc(s.labelHeading || "Value")}</th><th class="n">${rdEsc(s.countHeading || "Devices")}</th><th class="n">%</th><th class="b"></th></tr>${s.rows.map((r) => {
      const p = s.of ? Math.round((r.count / s.of) * 100) : 0;
      return `<tr><td>${rdEsc(r.label)}</td><td class="n">${r.count.toLocaleString()}</td><td class="n">${docPercent(r.count, s.of)}</td><td class="b"><span style="width:${p}%"></span></td></tr>`;
    }).join("")}</table>` : ""}${s.note ? `<p class="note">${rdEsc(s.note)}</p>` : ""}</section>`).join("");
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${rdEsc(doc.title)}</title><style>
:root{--page:#ffffff;--fg:#10203c;--muted:#46628a;--line:#aec7ea;--fill:#e9f1fc;--accent:#175cd3;--bar:#008aff;color-scheme:light}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font:13px/1.4 system-ui,"Segoe UI",sans-serif;margin:24px auto;max-width:960px;padding:0 16px;background:var(--page);color:var(--fg)}
h1{font-size:22px;margin:0}h2{font-size:15px;margin:0 0 6px;color:var(--accent)}.sub,.note{color:var(--muted)}.note{font-size:12px;margin:6px 0 0}
.head{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:16px 0}
.head div{border:1px solid var(--line);border-radius:8px;padding:8px 12px;background:var(--fill);color:var(--muted)}.head strong{display:block;font-size:20px;color:var(--accent)}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
section{border:1px solid var(--line);border-radius:8px;padding:10px 12px;break-inside:avoid;background:var(--fill)}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:2px 6px;border-bottom:1px solid var(--line)}th{font-weight:600;color:var(--muted)}
.n{text-align:right;white-space:nowrap}td.b{width:25%}td.b span{display:block;height:6px;border-radius:3px;background:var(--bar)}
@page{margin:12mm}@media print{body{margin:0}}
</style></head><body><h1>${rdEsc(doc.title)}</h1>${doc.subtitle ? `<p class="sub">${rdEsc(doc.subtitle)}</p>` : ""}<div class="head">${head}</div><div class="grid">${sections}</div></body></html>`;
}

/** The report as CSV rows: Section, Value, Count, %. */
export function docCsvRows(doc) {
  return [["Section", "Value", "Count", "%"],
    ...(doc.headline || []).map((h) => ["Summary", h.label, h.value, ""]),
    ...doc.sections.flatMap((s) => s.rows.map((r) => [s.title, r.label, r.count, docPercent(r.count, s.of)]))];
}
