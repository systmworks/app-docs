// Environment overview: a one or two page summary of the device fleet for a manager or an audit, as a report document
// (core/report-doc.js writes it as Markdown, HTML or CSV). Everything comes from the device list (devices/list, with the
// management details since 2.68.0) and, when it has been read, the Hardware report (security checks from
// postureCounts), so nothing more is read from Graph. Pure.

import { osSpread, activityLevel } from "./device-reports.js";
import { postureCounts } from "./security-posture.js";
import { words } from "./format.js";
import { agentName } from "./device-explorer.js";

const TOP = 10; // manufacturers and models: the most common, then "Other"
const evNone = "Not reported";

/** Count devices by a value, most first; empty values as "Not reported" (last); past `top`, the rest as "Other". */
function countBy(devices, valueOf, top = Infinity) {
  const counts = new Map();
  for (const d of devices) {
    const v = valueOf(d) || evNone;
    counts.set(v, (counts.get(v) || 0) + 1);
  }
  const rows = [...counts].map(([label, count]) => ({ label, count }))
    .sort((a, b) => Number(a.label === evNone) - Number(b.label === evNone) || b.count - a.count || a.label.localeCompare(b.label));
  if (rows.length <= top) return rows;
  const rest = rows.slice(top).reduce((n, r) => n + r.count, 0);
  return [...rows.slice(0, top), { label: "Other", count: rest }];
}

const evYes = (v) => (v === true ? "Yes" : v === false ? "No" : "");
const evWindows = (d) => /^windows/i.test(d.os || "");
const CHECK_IN = { green: "Within 8 hours", yellow: "Within 7 days", orange: "Within 30 days", red: "Over 30 days, or never" };

/**
 * @param devices      the device list (in the workspace scope, if one is set)
 * @param friendly     Windows build number to release name (shared/windows-builds.js), for the releases
 * @param hardware     { at, rows } of the Hardware report, or null when it hasn't been read
 * @param scopeName    the scope group's name, when one is set
 * @param compliance   rankSettings().all (every compliance setting's device counts), or null when it couldn't be read
 * @param objects      assignmentCounts() (policies and apps, assigned or not), or null when not read
 * @returns a report document: { title, subtitle, headline, sections }
 */
export function environmentOverview(devices, { friendly, hardware = null, compliance = null, objects = null, scopeName = "", now = Date.now() } = {}) {
  const total = devices.length;
  const windows = devices.filter(evWindows);
  const spread = osSpread(devices, friendly);
  const share = (n) => (total ? `${Math.round((n / total) * 100)}%` : "-");
  const compliant = devices.filter((d) => d.compliance === "compliant").length;
  const encrypted = devices.filter((d) => d.encrypted === true).length;
  const recent = devices.filter((d) => ["green", "yellow"].includes(activityLevel(d.lastSync, now))).length;
  const section = (title, rows, extra = {}) => ({ title, rows, of: total, ofLabel: "devices", ...extra });
  const sections = [
    section("Platforms", spread.platforms.map((p) => ({ label: p.os, count: p.count })), { labelHeading: "Platform" }),
    // Windows releases name themselves ("Win11 24H2"); other platforms' versions get the platform in front once.
    section("OS releases", spread.platforms.flatMap((p) => p.releases.map((r) => ({ label: evWindows(p) || r.label.toLowerCase().startsWith(p.os.toLowerCase()) ? r.label : `${p.os} ${r.label}`, count: r.count }))), { labelHeading: "Release" }),
    section("Manufacturers", countBy(devices, (d) => d.manufacturer, TOP), { labelHeading: "Manufacturer" }),
    section("Models", countBy(devices, (d) => d.model, TOP), { labelHeading: "Model" }),
    section("Compliance", countBy(devices, (d) => words(d.compliance || "")), { labelHeading: "State" }),
    section("Encrypted", countBy(devices, (d) => evYes(d.encrypted)), { labelHeading: "Encrypted" }),
    section("Last check-in", Object.entries(CHECK_IN).map(([level, label]) => ({ label, count: devices.filter((d) => activityLevel(d.lastSync, now) === level).length })), { labelHeading: "Checked in" }),
    section("Ownership", countBy(devices, (d) => words(d.owner || "")), { labelHeading: "Owner" }),
    section("Join type (Windows)", countBy(windows, (d) => words(d.joinType || "")), { labelHeading: "Join type", of: windows.length, ofLabel: "Windows devices" }),
    section("Autopilot (Windows)", countBy(windows, (d) => evYes(d.autopilot)), { labelHeading: "Registered", of: windows.length, ofLabel: "Windows devices" }),
    section("Management agent", countBy(devices, (d) => agentName(d.agent)), { labelHeading: "Agent" }),
  ];
  const hwRows = hardware?.rows?.length ? hardware.rows : null;
  if (hwRows) {
    const checks = postureCounts(hwRows.filter((r) => /windows|mac/i.test(r.os || ""))).checks;
    for (const c of checks) {
      const of = c.pass + c.fail + c.unknown;
      if (of) sections.push(section(c.label, [{ label: "Yes", count: c.pass }, { label: "No", count: c.fail }, { label: evNone, count: c.unknown }].filter((r) => r.count),
        { labelHeading: "Result", of, ofLabel: "devices read", note: "From the Hardware report's read." }));
    }
  }
  // Firewall: from the compliance policies that require it (Intune's result per setting, tenant-wide, not scoped).
  const firewall = (compliance || []).filter((c) => /firewall/i.test(c.name));
  for (const c of firewall) {
    sections.push(section(firewall.length > 1 ? `Firewall (${c.platform || c.setting})` : "Firewall", [
      { label: "On (compliant)", count: c.compliant }, { label: "Off (not compliant)", count: c.nonCompliant }, { label: "Error or conflict", count: c.error + c.conflict },
    ].filter((r) => r.count), { labelHeading: "Firewall", of: c.total, ofLabel: "devices checked", note: `From the compliance policy setting "${c.setting}", for the whole tenant.` }));
  }
  if (!firewall.length) {
    sections.push(section("Firewall", [], { note: compliance
      ? "No compliance policy checks the firewall. Require the firewall in a compliance policy (Windows: System Security > Firewall) and its result shows here."
      : "Not shown: the compliance results couldn't be read." }));
  }
  // Policies and apps (tenant-wide, not scoped): assigned or not.
  const pol = objects?.policies, apps = objects?.apps;
  if (pol?.total) {
    sections.unshift(section("Policies, profiles and scripts", [{ label: "Assigned", count: pol.assigned }, { label: "Not assigned (or exclude-only)", count: pol.notAssigned },
      { label: "Assignments couldn't be read", count: pol.unknown }].filter((r) => r.count), { labelHeading: "Status", countHeading: "Items", of: pol.total, ofLabel: "items",
      note: "Every configuration and compliance policy, profile, script and similar item, for the whole tenant." }));
  }
  if (apps?.total) {
    sections.unshift(section("Apps", [{ label: "Assigned", count: apps.assigned }, { label: "Not assigned", count: apps.total - apps.assigned }].filter((r) => r.count),
      { labelHeading: "Status", countHeading: "Apps", of: apps.total, ofLabel: "apps", note: "Every app in the Intune app catalogue, built-in ones included, for the whole tenant." }));
  }
  return {
    title: "Environment overview",
    subtitle: `${total.toLocaleString()} devices${scopeName ? ` in ${scopeName}` : ""}, ${new Date(now).toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" })}.${hwRows ? "" : " TPM and Credential Guard aren't included: the device read was stopped or couldn't run."}`,
    headline: [
      { label: "Devices", value: total.toLocaleString() },
      { label: "Windows", value: share(windows.length) },
      { label: "Compliant", value: share(compliant) },
      { label: "Encrypted", value: share(encrypted) },
      { label: "Checked in within 7 days", value: share(recent) },
      ...(pol?.total ? [{ label: "Policies, profiles and scripts", value: pol.total.toLocaleString() }] : []),
      ...(apps?.total ? [{ label: "Apps", value: apps.total.toLocaleString() }] : []),
    ],
    sections: sections.filter((s) => s.rows.length || s.note),
  };
}
