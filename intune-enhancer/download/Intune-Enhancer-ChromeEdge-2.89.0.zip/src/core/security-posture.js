// Security posture: what in a device's Hardware report row needs attention, and how many devices pass each check.
// The values come from the Hardware report's read (each device's full record, plus Intune's encryption state for it),
// so this reads nothing itself. Empty means Intune didn't report it, which is never counted as a problem. Pure.

const spOn = (v) => /^(enabled|on|true|running)$/i.test(String(v || "").trim());

/** The checks, in the order shown: A to Z, except Ready for encryption sits just before Encrypted (owner's choice). Each has a
 * key, label, the issue's words, and whether a row passes, fails or isn't known (true, false, null). */
export const POSTURE_CHECKS = [
  { key: "credGuard", label: "Credential Guard", issue: "Credential Guard not running", windows: true, test: (r) => (spOn(r.credGuard) ? true : r.credGuard ? false : null) },
  { key: "encReady", label: "Ready for encryption", issue: "Not ready for encryption", windows: true, test: (r) => (/^ready$/i.test(r.encReady) ? true : /not ?ready/i.test(r.encReady) ? false : null) },
  { key: "encrypted", label: "Encrypted", issue: "Not encrypted", test: (r) => (r.encrypted === "Yes" ? true : r.encrypted === "No" ? false : null) },
  // Intune's version text is "2.0, 0, 1.59" (spec, level, revision); an older TPM says which version it is.
  { key: "tpm", label: "TPM 2.0", issue: (r) => (/^1/.test(r.tpm) ? `TPM ${r.tpm.split(",")[0].trim()}` : "No TPM 2.0"), windows: true, test: (r) => (r.tpm ? /^2/.test(r.tpm) : null) },
  { key: "vbs", label: "Virtualization-based security", issue: "VBS not running", windows: true, test: (r) => (spOn(r.vbs) ? true : r.vbs ? false : null) },
];

const spWindows = (r) => /windows/i.test(r.os || "");

/** The checks a row fails, as their labels (Windows-only checks only for Windows devices). */
export function postureIssues(row) {
  return POSTURE_CHECKS.filter((c) => (!c.windows || spWindows(row)) && c.test(row) === false).map((c) => (typeof c.issue === "function" ? c.issue(row) : c.issue))
    .concat(row.encIssues ? [row.encIssues] : []);
}

/** Per check: how many devices pass, fail or aren't reported, and how many devices have any issue. */
export function postureCounts(rows) {
  const checks = POSTURE_CHECKS.map((c) => {
    const n = { key: c.key, label: c.label, pass: 0, fail: 0, unknown: 0 };
    for (const r of rows) {
      if (c.windows && !spWindows(r)) continue;
      const v = c.test(r);
      if (v === true) n.pass++; else if (v === false) n.fail++; else n.unknown++;
    }
    return n;
  });
  return { devices: rows.length, withIssues: rows.filter((r) => postureIssues(r).length).length, checks };
}
