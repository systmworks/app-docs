// Failed apps and Failed policies reports: per app and per configuration policy, how many devices and users
// succeeded and failed, from Intune's own summary reports (the ones behind each app's and policy's Overview).
// Reports are read with POST, but nothing is changed. Column names are matched loosely, and the columns the
// report returned are logged once, because Intune names them slightly differently between tenants and versions.

import { isTransient, sayOnce, reportRows } from "./graph.js";
import { statusParts, policyNames, policyReportBody } from "./policy-status.js";
import { policyRef } from "./portal-links.js";
import { platformName } from "./format.js";

const APP_PAGE = 100; // rows per request to the app install summary report
const MAX_APP_PAGES = 100;

const num = (v) => Number(v) || 0;

/** One row of the app install summary report as an app's counts. Pure. */
export function appRow(row) {
  return {
    id: String(row.applicationid || row.appid || row.id || ""),
    name: String(row.displayname || row.appname || row.name || row.application || ""),
    version: String(row.appversion || row.displayversion || row.version || ""),
    platform: platformName(row.platform || row.platformtype || ""),
    device: { fail: num(row.faileddevicecount), ok: num(row.installeddevicecount) },
    user: { fail: num(row.failedusercount), ok: num(row.installedusercount) },
  };
}

/** Every app with install counts, all pages of the app install summary report. */
export async function appFailures(graph) {
  const rows = [];
  for (let page = 0; page < MAX_APP_PAGES; page++) {
    const body = await graph.post("/beta/deviceManagement/reports/getAppsInstallSummaryReport", { select: [], skip: page * APP_PAGE, top: APP_PAGE });
    const got = reportRows(body);
    if (page === 0 && got[0]) sayOnce("failed-apps-columns", "info", "App install summary report columns:", Object.keys(got[0]).join(", "));
    rows.push(...got);
    if (got.length < APP_PAGE) break;
  }
  return rows.map(appRow).filter((r) => r.id || r.name);
}

/** The counts of one summary-report row as { fail, conflict, ok }, or null for no row. Pure. */
export function policyCounts(row) {
  if (!row) return null;
  const { succeeded, errors, conflicts } = statusParts(row);
  return { fail: errors, conflict: conflicts, ok: succeeded };
}

// The policy index type key for each kind policyNames() reads, so policyRef() can label and link it.
const FAILED_KIND_TYPE = { catalog: "settingsCatalog", template: "deviceConfig", admx: "adminTemplate" };

/**
 * The configuration policies the Failed policies report reads, each once (two may share a name):
 * [{ id, kind, name, platform, typeLabel, link }]. The workspace then reads their status in chunks.
 */
export async function failedPolicyList(graph) {
  const seen = new Set();
  const items = [];
  for (const list of (await policyNames(graph)).values()) {
    for (const p of list) {
      if (seen.has(p.id)) continue;
      seen.add(p.id);
      const { typeLabel, link } = policyRef({ type: FAILED_KIND_TYPE[p.kind], id: p.id, meta: p.meta || {}, assignments: [] });
      items.push({ id: p.id, kind: p.kind, name: p.name, platform: p.platform, typeLabel, link });
    }
  }
  return items;
}

/**
 * Device and user status for configuration policies. items: [{ id, kind }]. Returns
 * { [id]: { device: {fail, conflict, ok} | null, user: {...} | null } | { retry: true } }.
 * The user report is asked for too; if Intune refuses it, user is null for that policy.
 */
export async function policyFailures(graph, items) {
  const requests = [];
  items.forEach((p, n) => {
    const body = policyReportBody(p.id);
    requests.push({ id: `d${n}`, url: "/deviceManagement/reports/getConfigurationPolicyDeviceSummaryReport", body });
    requests.push({ id: `u${n}`, url: "/deviceManagement/reports/getConfigurationPolicyUserSummaryReport", body });
  });
  const res = await graph.batch(requests);
  const out = {};
  items.forEach((p, n) => {
    const d = res.get(`d${n}`);
    const u = res.get(`u${n}`);
    if (isTransient(d) || isTransient(u)) { out[p.id] = { retry: true }; return; }
    const read = (r, label) => {
      if (!r || r.status !== 200) {
        if (r && !isTransient(r)) sayOnce(`failed-policies-${label}`, "warn", `Policy ${label} status unavailable:`, r.status, JSON.stringify(r.body ?? "").slice(0, 200));
        return null;
      }
      const rows = reportRows(r.body);
      if (rows[0]) sayOnce(`failed-policies-${label}-columns`, "info", `Policy ${label} report columns:`, Object.keys(rows[0]).join(", "));
      return policyCounts(rows[0] || null);
    };
    out[p.id] = { device: read(d, "device"), user: read(u, "user") };
  });
  return out;
}
