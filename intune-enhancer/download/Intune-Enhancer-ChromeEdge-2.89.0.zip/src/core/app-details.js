// App details: what Intune holds about one app beyond its name and assignments, laid out for troubleshooting an
// install: how a Win32 app is detected, what it requires, how it installs and uninstalls, which return codes mean
// what, and which apps it depends on or supersedes. Pure: the worker reads the app and its relationships from Graph
// (app/details) and this turns them into titled key/value sections, which App details shows and Policy export's
// writer (policyDocument's extra sections) puts into the Markdown and CSV.

import { day, words } from "./format.js";

const adText = (v) => (v === undefined || v === null ? "" : String(v).trim());
const adYes = (v) => (typeof v === "boolean" ? (v ? "Yes" : "No") : "");
const adType = (odata) => words(String(odata || "").replace(/^#microsoft\.graph\./, "").replace(/LobApp$/, " app").replace(/StoreApp$/, " store app"));

/** Base64 script text (Intune keeps detection and requirement scripts that way) as readable text; "" when it isn't base64. */
export function decodeScript(b64) {
  try {
    const bytes = Uint8Array.from(atob(String(b64 || "").trim()), (c) => c.charCodeAt(0));
    const utf16 = bytes.length > 1 && bytes[0] === 0xff && bytes[1] === 0xfe;
    return new TextDecoder(utf16 ? "utf-16le" : "utf-8").decode(bytes).replace(/^﻿/, "");
  } catch {
    return "";
  }
}

/** An operator such as "greaterThanOrEqual" as ">=". */
const adOp = (op) => ({ equal: "=", notEqual: "!=", greaterThan: ">", greaterThanOrEqual: ">=", lessThan: "<", lessThanOrEqual: "<=" })[op] || words(op || "");

/** One detection or requirement rule, new (rules) or older (detectionRules, requirementRules) shape, as [kind, detail, script?]. */
function adRule(r) {
  const type = String(r["@odata.type"] || "").toLowerCase();
  const compare = (what) => [what, r.operator && r.operator !== "notConfigured" ? `${adOp(r.operator)} ${adText(r.comparisonValue)}` : ""].filter(Boolean).join(" ");
  const bits = r.check32BitOn64System ? " (32-bit view)" : "";
  const check = (op) => (op === "exists" || op === "doesNotExist" ? words(op) : compare(words(op)));
  if (type.includes("filesystem")) {
    const target = [adText(r.path), adText(r.fileOrFolderName)].filter(Boolean).join("\\");
    return ["File or folder", `${target}${bits}: ${check(r.operationType || r.detectionType || "")}`];
  }
  if (type.includes("registry")) {
    const target = [adText(r.keyPath), adText(r.valueName)].filter(Boolean).join(" \\ ");
    return ["Registry", `${target}${bits}: ${check(r.operationType || r.detectionType || "")}`];
  }
  if (type.includes("productcode") || type.includes("msi")) {
    const version = r.productVersion ? ` version ${adOp(r.productVersionOperator)} ${adText(r.productVersion)}` : "";
    return ["MSI product code", `${adText(r.productCode)}${version}`];
  }
  if (type.includes("script")) {
    const how = [r.runAs32Bit ? "32-bit" : "", r.enforceSignatureCheck ? "signature checked" : "", r.runAsAccount ? `as ${r.runAsAccount}` : "",
      r.operationType && r.operationType !== "notConfigured" ? `output ${compare(words(r.operationType))}` : ""].filter(Boolean).join(", ");
    return ["Script", `${adText(r.displayName) || "PowerShell script"}${how ? ` (${how})` : ""}`, decodeScript(r.scriptContent)];
  }
  return [adType(r["@odata.type"]) || "Rule", JSON.stringify(r)];
}

/** A rules section: rows [kind, detail], plus any script texts. */
function adRules(title, rules) {
  const rows = [], code = [];
  for (const r of rules || []) {
    const [kind, detail, script] = adRule(r);
    rows.push([kind, detail]);
    if (script) code.push({ name: detail, text: script });
  }
  return rows.length ? [{ title, rows, code }] : [];
}

/**
 * @param app            a mobileApp from Graph (any type; Win32 gets the most)
 * @param relationships  its mobileAppRelationship list (dependencies and supersedence), or null when unreadable
 * @returns [{ title, rows: [[label, value]], code?: [{ name, text }] }], empty sections left out
 */
export function appSections(app, relationships = []) {
  const a = app || {};
  const ix = a.installExperience || {};
  const msi = a.msiInformation || {};
  const summary = [
    ["Type", adType(a["@odata.type"])],
    ["Publisher", adText(a.publisher)],
    ["Version", adText(a.displayVersion || a.versionNumber || a.productVersion || a.version)],
    ["File", adText(a.fileName)],
    ["Size (MB)", Number(a.size) > 0 ? String(Math.round((Number(a.size) / 1048576) * 10) / 10) : ""],
    ["Architectures", adText(a.allowedArchitectures || a.applicableArchitectures)],
    ["Minimum Windows", adText(a.minimumSupportedWindowsRelease)],
    ["Minimum free disk (MB)", adText(a.minimumFreeDiskSpaceInMB)],
    ["Minimum memory (MB)", adText(a.minimumMemoryInMB)],
    ["Store or package id", adText(a.packageIdentifier || a.bundleId || a.packageId || a.appStoreUrl || a.appUrl)],
    ["Created", day(a.createdDateTime)],
    ["Last modified", day(a.lastModifiedDateTime)],
  ].filter(([, v]) => v);
  const install = [
    ["Install command", adText(a.installCommandLine)],
    ["Uninstall command", adText(a.uninstallCommandLine)],
    ["Setup file", adText(a.setupFilePath)],
    ["Runs as", words(ix.runAsAccount || "")],
    ["Restart", words(ix.deviceRestartBehavior || "")],
    ["Time limit (minutes)", adText(ix.maxRunTimeInMinutes)],
    ["MSI product code", adText(msi.productCode)],
    ["MSI upgrade code", adText(msi.upgradeCode)],
    ["MSI needs a restart", adYes(msi.requiresReboot)],
  ].filter(([, v]) => v);
  const rules = Array.isArray(a.rules) && a.rules.length ? a.rules : null;
  const detection = rules ? rules.filter((r) => r.ruleType === "detection") : a.detectionRules;
  const requirement = rules ? rules.filter((r) => r.ruleType === "requirement") : a.requirementRules;
  const codes = (a.returnCodes || []).map((c) => [adText(c.returnCode), words(c.type || "")]);
  const rel = (relationships || []).map((r) => {
    const name = [adText(r.targetDisplayName) || adText(r.targetId), adText(r.targetDisplayVersion)].filter(Boolean).join(" ");
    const isDep = /dependency/i.test(r["@odata.type"] || "");
    const child = r.targetType !== "parent"; // child: this app depends on, or supersedes, the target
    const how = isDep ? words(r.dependencyType || "") : words(r.supersedenceType || "");
    const label = isDep ? (child ? "Depends on" : "Needed by") : (child ? "Supersedes" : "Superseded by");
    return { isDep, row: [label, `${name}${how ? ` (${how.toLowerCase()})` : ""}`] };
  });
  return [
    { title: "Summary", rows: summary },
    { title: "Install", rows: install },
    ...adRules("Detection rules", detection),
    ...adRules("Requirement rules", requirement),
    { title: "Return codes", rows: codes },
    { title: "Dependencies", rows: rel.filter((r) => r.isDep).map((r) => r.row) },
    { title: "Supersedence", rows: rel.filter((r) => !r.isDep).map((r) => r.row) },
    ...(relationships === null ? [{ title: "Dependencies and supersedence", rows: [["Note", "Couldn't be read."]] }] : []),
  ].filter((s) => s.rows.length);
}
