// Hardware report: the hardware facts Graph gives for each managed device. The device list holds only a
// few of them; memory and the rest of the hardware details are in each device's full record, so the
// report reads one record per device (batched) when asked. Only values Graph returned are kept, and a
// column nobody has a value for is left out, so nothing is invented. Pure apart from readHardware.

import { gb, day, words } from "./format.js";
import { humanize } from "./settings-extract.js";

const hwText = (value) => {
  const s = value === undefined || value === null ? "" : String(value).trim();
  return s === "" || s.toLowerCase() === "unknown" ? "" : s;
};
const hwGb = (bytes) => (Number(bytes) > 0 ? Math.round(gb(bytes) * 10) / 10 : "");
const hwNum = (value) => (value === undefined || value === null || value === "" || !Number.isFinite(Number(value)) ? "" : Number(value));
const hwWords = (value) => words(hwText(value));
const hwHardware = (rec) => rec?.hardwareInformation || {};
const hwHealth = (rec) => rec?.deviceHealthAttestationState || {};
const hwEnc = (rec) => rec?._encryption || {}; // the device's managedDeviceEncryptionStates entry, attached by readHardware
/** advancedBitLockerStates / fileVaultStates flags ("osVolumeUnprotected, recoveryKeyBackupFailed") in sentence case, as
 * Security posture's other issues are: "OS volume unprotected; Recovery key backup failed". */
const hwFlags = (value) => String(value || "").split(",").map((s) => s.trim()).filter((s) => s && s !== "success")
  .map((s) => humanize(s).replace(/\b(os|tpm|pin)\b/gi, (w) => w.toUpperCase())).join("; ");

/** Every column the report can show: [key, label, number?, read from a managedDevice record]. */
/** Where the Hardware report's saved rows live (one entry per tenant); "Clear stored data" removes this prefix. */
export const HARDWARE_KEY = "hardware|";
export const hardwareKey = (tid) => `${HARDWARE_KEY}${tid}`;

const HARDWARE_FIELDS = [
  { key: "name", label: "Device", nowrap: true, get: (r) => hwText(r.deviceName) },
  // The name (shorter, no domain), on screen and in the CSV; the UPN only when Graph gives no name.
  { key: "user", label: "Primary user", nowrap: true, get: (r) => hwText(r.userDisplayName || r.userPrincipalName) },
  { key: "manufacturer", label: "Manufacturer", get: (r) => hwText(r.manufacturer) },
  { key: "model", label: "Model", get: (r) => hwText(r.model) },
  { key: "chassis", label: "Chassis", get: (r) => hwWords(r.chassisType) },
  { key: "serial", label: "Serial number", get: (r) => hwText(r.serialNumber) },
  { key: "os", label: "OS", get: (r) => hwText(r.operatingSystem) },
  { key: "osVersion", label: "OS version", get: (r) => hwText(r.osVersion) },
  { key: "edition", label: "OS edition", get: (r) => hwText(hwHardware(r).operatingSystemEdition) },
  { key: "arch", label: "Processor", get: (r) => hwText(r.processorArchitecture) },
  { key: "ramGb", label: "Memory (GB)", num: true, get: (r) => hwGb(r.physicalMemoryInBytes) },
  { key: "totalGb", label: "Storage (GB)", num: true, get: (r) => hwGb(r.totalStorageSpaceInBytes) },
  { key: "freeGb", label: "Free (GB)", num: true, get: (r) => (Number(r.totalStorageSpaceInBytes) > 0 ? hwGb(r.freeStorageSpaceInBytes) : "") },
  { key: "encrypted", label: "Encrypted", get: (r) => (typeof r.isEncrypted === "boolean" ? (r.isEncrypted ? "Yes" : "No") : "") },
  { key: "tpm", label: "TPM version", get: (r) => hwText(hwHardware(r).tpmSpecificationVersion) },
  { key: "tpmMaker", label: "TPM maker", get: (r) => hwText(hwHardware(r).tpmManufacturer) },
  { key: "bios", label: "BIOS version", get: (r) => hwText(hwHardware(r).systemManagementBIOSVersion) },
  { key: "battery", label: "Battery health (%)", num: true, get: (r) => hwNum(hwHardware(r).batteryHealthPercentage) },
  { key: "cycles", label: "Battery cycles", num: true, get: (r) => hwNum(hwHardware(r).batteryChargeCycles) },
  { key: "ip", label: "IP address", get: (r) => hwText(hwHardware(r).ipAddressV4 || (hwHardware(r).wiredIPv4Addresses || [])[0]) },
  { key: "wifiMac", label: "Wi-Fi MAC", get: (r) => hwText(r.wiFiMacAddress) },
  { key: "ethMac", label: "Ethernet MAC", get: (r) => hwText(r.ethernetMacAddress) },
  { key: "join", label: "Join type", get: (r) => hwWords(r.joinType) },
  { key: "enrolment", label: "Enrolment type", get: (r) => hwWords(r.deviceEnrollmentType) },
  { key: "owner", label: "Ownership", get: (r) => hwWords(r.managedDeviceOwnerType) },
  { key: "enrolled", label: "Enrolled", nowrap: true, get: (r) => day(r.enrolledDateTime) },
  { key: "lastSync", label: "Last check-in", nowrap: true, get: (r) => day(r.lastSyncDateTime) },
  // Security posture (2.69.0): shown on the Security posture tab, not in the Hardware table. detail: in its Copy table
  // and CSV only, so the on-screen table fits.
  { key: "encState", label: "Encryption state", group: "security", detail: true, get: (r) => hwWords(hwEnc(r).encryptionState) },
  { key: "encReady", label: "Encryption readiness", group: "security", get: (r) => hwWords(hwEnc(r).encryptionReadinessState) },
  { key: "encIssues", label: "Encryption issues", group: "security", detail: true, get: (r) => hwFlags(hwEnc(r).advancedBitLockerStates) || hwFlags(hwEnc(r).fileVaultStates) },
  { key: "bitLocker", label: "BitLocker (attested)", group: "security", detail: true, get: (r) => hwWords(hwHealth(r).bitLockerStatus) },
  { key: "codeIntegrity", label: "Code integrity", group: "security", detail: true, get: (r) => hwWords(hwHealth(r).codeIntegrity) },
  { key: "memoryIntegrity", label: "Memory integrity", group: "security", detail: true, get: (r) => hwWords(hwHealth(r).memoryIntegrityProtection) },
  { key: "vbs", label: "Virtualization-based security", group: "security", get: (r) => hwWords(hwHardware(r).deviceGuardVirtualizationBasedSecurityState) },
  { key: "credGuard", label: "Credential Guard", group: "security", get: (r) => hwWords(hwHardware(r).deviceGuardLocalSystemAuthorityCredentialGuardState) },
  { key: "attested", label: "Health attested", group: "security", detail: true, get: (r) => day(hwHealth(r).lastUpdateDateTime) },
];

/** The Security posture tab's columns: the device, its user and OS, encryption and TPM, then the security fields. */
export const POSTURE_FIELDS = HARDWARE_FIELDS.filter((f) => ["name", "user", "os", "encrypted", "tpm"].includes(f.key) || f.group === "security");

/** One managedDevice record as a flat row of the report's values (empty string where Graph gave none). */
export function hardwareRow(record) {
  const row = { id: record.id };
  for (const f of HARDWARE_FIELDS) row[f.key] = f.get(record);
  return row;
}

/** The columns at least one device has a value for, in field order: the Hardware table's by default (no security
 * fields); Device explorer and Security posture pass their own field lists. */
export function hardwareColumns(rows, fields = HARDWARE_FIELDS.filter((f) => !f.group)) {
  return fields.filter((f) => f.key === "name" || rows.some((r) => r[f.key] !== "" && r[f.key] !== undefined));
}

// Graph appears to leave some managedDevice properties empty unless named in $select: on a live tenant (2.82.0) every
// device's TPM version and Secure Boot came back blank from a plain read while Intune showed them. So the record reads
// name every field the Hardware report and quick facts use.
const HW_SELECT = ["id", "deviceName", "userDisplayName", "userPrincipalName", "manufacturer", "model", "chassisType", "serialNumber",
  "operatingSystem", "osVersion", "processorArchitecture", "physicalMemoryInBytes", "totalStorageSpaceInBytes", "freeStorageSpaceInBytes",
  "isEncrypted", "wiFiMacAddress", "ethernetMacAddress", "joinType", "deviceEnrollmentType", "managedDeviceOwnerType", "managementAgent",
  "enrolledDateTime", "lastSyncDateTime", "hardwareInformation", "deviceHealthAttestationState"].join(",");

/** One device's full record, for quick facts' More details: the named fields, or a plain read if Graph refuses the list. */
export async function readDeviceRecord(graph, id) {
  try {
    return await graph.get(`/beta/deviceManagement/managedDevices/${id}?$select=${HW_SELECT}`);
  } catch (e) {
    if (e?.code === "HTTP" && e.status === 400) return graph.get(`/beta/deviceManagement/managedDevices/${id}`);
    throw e;
  }
}

/**
 * Read the full record of each device, batched, naming the fields (devices whose read Graph refuses with 400 are read
 * again plainly). A device Graph can't answer for (deleted since the list was built, no permission) is counted, not
 * guessed at.
 * @param encryption readEncryptionStates() output, or null: each device's entry is joined by id, else by name
 * @returns { rows, failed }
 */
export async function readHardware(graph, ids, encryption = null) {
  const answers = await graph.batch(ids.map((id) => ({ id, url: `/deviceManagement/managedDevices/${id}?$select=${HW_SELECT}` })));
  const refused = ids.filter((id) => answers.get(String(id))?.status === 400);
  if (refused.length) for (const [id, a] of await graph.batch(refused.map((id) => ({ id, url: `/deviceManagement/managedDevices/${id}` })))) answers.set(id, a);
  const byId = new Map((encryption || []).map((e) => [String(e.id).toLowerCase(), e]));
  const byName = new Map((encryption || []).filter((e) => e.deviceName).map((e) => [e.deviceName.toLowerCase(), e]));
  const rows = [];
  let failed = 0;
  for (const id of ids) {
    const a = answers.get(String(id));
    if (a?.status === 200 && a.body) {
      const enc = byId.get(String(id).toLowerCase()) || byName.get(String(a.body.deviceName || "").toLowerCase());
      rows.push(hardwareRow(enc ? { ...a.body, _encryption: enc } : a.body));
    } else failed++;
  }
  return { rows, failed };
}

/** Every device's encryption state from Intune's encryption report source: state, readiness and the reasons it isn't
 * protected. Only those fields are kept (the worker caches the answer for 30 minutes). */
export async function readEncryptionStates(graph) {
  const items = await graph.all("/beta/deviceManagement/managedDeviceEncryptionStates");
  return items.map((e) => ({ id: e.id, deviceName: e.deviceName || "", encryptionState: e.encryptionState || "", encryptionReadinessState: e.encryptionReadinessState || "",
    advancedBitLockerStates: e.advancedBitLockerStates || "", fileVaultStates: e.fileVaultStates || "" }));
}
