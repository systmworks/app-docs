// Baseline gap report: how the settings Intune applies to one device compare with a Microsoft security baseline.
// The extension cannot read a device's registry, so this is judged from policy, never from the device: a baseline
// recommendation counts as "met" when a policy that reaches the device sets that setting to the recommended value.
// Settings the device gets some other way (local or domain Group Policy, the built-in security baseline profiles, scripts)
// are not seen. Pure; the baseline data comes from data/baselines.js (built by tools/build-baselines.py).
//
// Matching: a baseline row names the setting by CSP path (when Windows has one) and by ADMX policy name and title.
// Settings catalog and custom OMA-URI settings are matched by CSP path, or by the last part of the path (the ADMX policy
// name); Administrative templates by title and category. The value is compared when the recommendation can be read as
// a state (Enabled/Disabled) or as the option of a drop-down; anything else is "check value" with both values shown.

const bgNorm = (s) => String(s ?? "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
const bgCspKey = (p) => String(p ?? "").trim().toLowerCase().replace(/^\.\/(device|user)\//, "");
const bgLast = (p) => String(p ?? "").split("/").filter(Boolean).pop()?.toLowerCase() || "";
const bgIsOma = (s) => String(s?.p ?? "").startsWith("./");
const bgScopeOk = (path, cls) => (/^\.\/user\//i.test(path) ? cls === "User" : /^\.\/device\//i.test(path) ? cls === "Machine" : true);

export const BASELINE_STATUS = {
  differs: { label: "Different", order: 0 },
  conflict: { label: "Conflict", order: 1 },
  review: { label: "Check value", order: 2 },
  missing: { label: "Not configured", order: 3 },
  match: { label: "Matches", order: 4 },
};

/**
 * The policies that reach a device, with their settings: [{ id, name, typeKey, typeLabel, link, certainty, why, filters,
 * settings, hasSettings, partial }]. Excluded ones are left out. why and filters are the Device 360 row's reasons.
 */
export function appliedPolicies(report, policyIndex) {
  const byId = new Map((policyIndex?.policies || []).map((p) => [p.id, p]));
  return (report?.rows || []).filter((r) => r.state !== "excluded").map((r) => {
    const p = byId.get(r.id);
    return { id: r.id, name: r.name, typeKey: p?.type || "", typeLabel: r.typeLabel || "", link: r.link || "", certainty: r.state,
      why: r.why || [], filters: r.filters || [], settings: p?.settings || [], hasSettings: Array.isArray(p?.settings), partial: Boolean(p?.settingsPartial) };
  });
}

/**
 * Settings catalog policies list a setting's own drop-downs and boxes as separate entries whose definition id continues the
 * parent's ("..._policyname_elementid"). Those children share the parent's path, so they must not be matched on their own: a
 * child's "Enable" read as the setting's value made the report say "Enabled | Disable" and mix states.
 */
function childChecker(settings) {
  const ids = new Set((settings || []).map((s) => String(s.d ?? "").toLowerCase()).filter((d) => d && !d.startsWith("oma:")));
  return (s) => {
    const d = String(s.d ?? "").toLowerCase();
    if (!d || d.startsWith("oma:")) return false;
    for (let i = d.lastIndexOf("_"); i > 0; i = d.lastIndexOf("_", i - 1)) if (ids.has(d.slice(0, i))) return true;
    return false;
  };
}

/** Look-ups over the applied settings: by CSP path, by last path part, by title. Child entries are left out (see childChecker). */
export function indexApplied(applied) {
  const byCsp = new Map(), byName = new Map(), byTitle = new Map();
  const add = (map, key, hit) => { if (!key) return; if (!map.has(key)) map.set(key, []); map.get(key).push(hit); };
  for (const policy of applied) {
    const isChild = childChecker(policy.settings);
    for (const s of policy.settings || []) {
      if (isChild(s)) continue;
      const hit = { policy, s };
      if (bgIsOma(s)) { add(byCsp, bgCspKey(s.p), hit); add(byName, bgLast(s.p), hit); }
      else if (policy.typeKey === "adminTemplate") add(byTitle, bgNorm(s.n), hit);
    }
  }
  return { byCsp, byName, byTitle };
}

// Template profiles that stack by design: each one installs its own certificate, VPN, Wi-Fi or email profile, so two of
// them with different values are two profiles, not a conflict (2.83.0 live: three trusted certificates were flagged).
const bgStacks = (policy, s) => policy.typeKey === "deviceConfig" && /certificate|pfx|vpn|wifi|emailprofile/i.test(String(s.d ?? "").split(".")[0]);

/**
 * Every setting the policies reaching a device configure: one row per setting per policy, with a conflict flag when
 * two policies set the same setting to different values. Each policy's values for a setting are compared as a set, so
 * the items of one list (Hardened UNC paths, Defender exclusions) are never a conflict with each other, and two
 * policies with the same list are not either. Compliance policies (a device must pass every one) and stacking profiles
 * (bgStacks) are never conflicts. The same setting is found by CSP path for "./" paths (so a settings catalog entry and a
 * custom OMA-URI line for one path meet), otherwise by its definition id. Settings catalog child entries share their
 * parent's path, so they are told apart by their own id instead. Values compare by the raw choice when there is one,
 * else the shown value, ignoring case.
 * @param applied appliedPolicies() output
 * @returns { rows, settings, conflicts, policies, noSettings, partial }
 */
export function settingsReaching(applied) {
  const rows = [], byKey = new Map(), partial = [];
  let policies = 0, noSettings = 0;
  for (const policy of applied || []) {
    if (!policy.hasSettings && !(policy.settings || []).length) { noSettings++; continue; }
    policies++;
    if (policy.partial) partial.push(policy.name);
    const isChild = childChecker(policy.settings);
    for (const s of policy.settings || []) {
      const key = !isChild(s) && bgIsOma(s) ? `csp:${bgCspKey(s.p)}` : `id:${String(s.d ?? s.n ?? "").toLowerCase()}`;
      const row = { key, name: s.n || s.d || "", path: s.p || "", value: s.v ?? "", raw: String(s.r ?? s.v ?? "").toLowerCase(), conflict: false, same: false,
        policy: { id: policy.id, name: policy.name, typeLabel: policy.typeLabel, link: policy.link },
        certainty: policy.certainty, why: policy.why || [], filters: policy.filters || [] };
      rows.push(row);
      if (!byKey.has(key)) byKey.set(key, []); // every setting is counted; compliance and stacking rows are never compared
      if (policy.typeKey !== "compliance" && !bgStacks(policy, s)) byKey.get(key).push(row);
    }
  }
  let conflicts = 0, same = 0;
  for (const list of byKey.values()) {
    const valuesBy = new Map(); // policy id -> its values for this setting
    for (const r of list) {
      if (!valuesBy.has(r.policy.id)) valuesBy.set(r.policy.id, new Set());
      valuesBy.get(r.policy.id).add(r.raw);
    }
    if (valuesBy.size < 2) continue;
    // Two or more policies set it: to different values (a conflict), or to the same ones (harmless, worth tidying).
    const differ = new Set([...valuesBy.values()].map((v) => [...v].sort().join("\u0000"))).size > 1;
    if (differ) conflicts++; else same++;
    list.forEach((r) => { if (differ) r.conflict = true; else r.same = true; });
  }
  rows.sort((a, b) => Number(b.conflict) - Number(a.conflict) || Number(b.same) - Number(a.same) || a.name.localeCompare(b.name) || a.policy.name.localeCompare(b.policy.name));
  return { rows, settings: byKey.size, conflicts, same, policies, noSettings, partial };
}

/** The product part of a policy CSP path: "excel16v2~Policy~L_MicrosoftOfficeExcel~..." for an Office policy. */
const bgArea = (p) => String(p ?? "").toLowerCase().replace(/^\.\/(device|user)\/vendor\/msft\/policy\/config\//, "").split("/")[0];

/** Whether a path's product part can belong to a baseline row's ADMX file: Office files (excel16, ppt16, ...) start it; Edge's contains "edge". */
function productOk(file, area) {
  if (/^(access|excel|ppt|word|outlk|onent|proj|pub|visio|lync|office|teams|infopath|groove)\d*/.test(file)) return area.startsWith(file);
  if (file.startsWith("msedge")) return area.includes("edge");
  return true;
}

/**
 * The settings that carry a policy name. Products share policy names (every Office app has an "Allow Trusted Locations on the
 * network", Edge and Chrome both have "SSLErrorOverrideAllowed"), so a hit must be for the baseline row's product. When several
 * products remain and none is the row's own, none is taken: better "not configured" than another product's value.
 */
function namedHits(id, pname, cls, idx) {
  const file = String(id).split(":")[1]?.toLowerCase() || "";
  const named = (idx.byName.get(pname.toLowerCase()) || []).filter((h) => bgScopeOk(h.s.p, cls) && productOk(file, bgArea(h.s.p)));
  if (named.length < 2) return named;
  const ofFile = file ? named.filter((h) => bgArea(h.s.p).startsWith(file)) : [];
  if (ofFile.length) return ofFile;
  return new Set(named.map((h) => bgArea(h.s.p))).size > 1 ? [] : named;
}

/** Baseline row -> the applied settings that configure it. */
function hitsFor(row, idx) {
  const [id, title, category, , , , pname, cls, csp] = row;
  let hits = csp ? (idx.byCsp.get(csp) || []).filter((h) => bgScopeOk(h.s.p, cls)) : [];
  if (!hits.length && pname) hits = namedHits(id, pname, cls, idx);
  if (!hits.length) {
    let t = (idx.byTitle.get(bgNorm(title)) || []).filter((h) => (cls === "User" ? /^user/i.test(h.s.p) : /^computer/i.test(h.s.p) || !/^user/i.test(h.s.p)));
    if (t.length > 1) {
      const last = bgNorm(category.split(" > ").pop());
      const narrowed = t.filter((h) => bgNorm(String(h.s.p).split(": ").pop().split("\\").pop()) === last);
      if (narrowed.length) t = narrowed;
    }
    hits = t;
  }
  return hits;
}

/** Child settings of a catalog setting (its drop-downs and boxes): definition ids that continue the parent's. */
const childrenOf = (hit) => (hit.policy.settings || []).filter((x) => x !== hit.s && x.d && hit.s.d && String(x.d).toLowerCase().startsWith(`${String(hit.s.d).toLowerCase()}_`));

const appliedText = (hit) => {
  const kids = childrenOf(hit).map((k) => `${k.n}: ${k.v}`);
  return [String(hit.s.v ?? ""), ...kids].filter(Boolean).join("; ").slice(0, 300);
};

/** "Name: value" parts of an applied text; a "(User)" or "(Device)" tail on a name is dropped. */
function appliedParts(text) {
  return String(text).split(/;\s+/).map((p) => {
    const i = p.indexOf(":");
    return i < 1 ? null : { name: bgNorm(p.slice(0, i).replace(/\s*\((user|device)\)\s*$/i, "")), value: p.slice(i + 1).replace(/^:\s*/, "").trim() };
  }).filter(Boolean);
}

/**
 * A recommended detail against the text of the applied setting (its value and its child settings). The detail is the baseline's
 * own wording, one entry per "|": a drop-down option ("Disable all with notification"), a "Name:value" pair ("Excel:69632"),
 * a list entry or check box ("excel.exe", "Label - Enabled"; the policy shows those as "name (Device): True"). Each is checked
 * where the applied text allows. A wrong value for something the policy shows is Different; anything that cannot be found is
 * Check value. -> "match" | "differs" | "review"
 */
function detailVerdict(detail, text) {
  const hay = bgNorm(text);
  const parts = appliedParts(text);
  const isBool = (x) => /^(true|false)$/i.test(x);
  const segs = String(detail).split(/\s*\|\s*/).map((x) => x.trim()).filter(Boolean);
  let ok = 0, bad = 0, unknown = 0;
  segs.forEach((seg, i) => {
    const box = /^(.*\S)\s+(?:-\s+)?(enabled|disabled)$/i.exec(seg);
    if (box) {
      const part = parts.find((p) => p.name === bgNorm(box[1]));
      if (!part || !isBool(part.value)) { unknown++; return; }
      (/^true$/i.test(part.value) === /^enabled$/i.test(box[2]) ? ok++ : bad++);
      return;
    }
    const nv = /^([^:]*\S):\s*(\S.*)$/.exec(seg);
    if (nv) {
      const part = parts.find((p) => p.name === bgNorm(nv[1]));
      const want = bgNorm(nv[2]);
      if (part) (bgNorm(part.value).includes(want) ? ok++ : bad++);
      else if (want && hay.includes(bgNorm(nv[1])) && hay.includes(want)) ok++;
      else unknown++;
      return;
    }
    const w = bgNorm(seg);
    if (!w) { unknown++; return; } // a wildcard or symbols only
    const named = parts.find((p) => p.name === w);
    if (named) { isBool(named.value) ? (/^true$/i.test(named.value) ? ok++ : bad++) : unknown++; return; }
    if (hay.includes(w)) { ok++; return; }
    // A missing option label is a clear difference when the policy shows a value of its own and either this is the only entry or
    // the shown value is another option of the same drop-down (it starts with the same word).
    const others = parts.filter((p) => !isBool(p.value) && bgNorm(p.value));
    const sameDropDown = i === 0 && others.some((p) => bgNorm(p.value).split(" ")[0] === w.split(" ")[0]);
    if (others.length && (segs.length === 1 || sameDropDown)) bad++; else unknown++;
  });
  if (bad) return "differs";
  if (unknown || !ok) return "review";
  return "match";
}

/** One applied setting against one baseline row -> "match" | "differs" | "review". */
export function compareValue(row, hit) {
  const [, , , , state, detail, , , , exp] = row;
  if (!state) return "review";
  const v = String(hit.s.v ?? "");
  const disp = bgNorm(v);
  const raw = hit.s.r === undefined ? "" : String(hit.s.r);
  const want = state.toLowerCase();
  // Enabled with an option named "Disable" writes what Disabled writes (the Internet Explorer zone policies): the same.
  const disabledByOption = () => { const kids = childrenOf(hit); return kids.length > 0 && kids.every((k) => /^disabled?$/.test(bgNorm(k.v))); };

  if (bgIsOma(hit.s)) {
    if (disp === "enabled" || disp === "disabled") {
      if (disp !== want) return want === "disabled" && disp === "enabled" && disabledByOption() ? "match" : "differs";
      if (!detail && !(exp || []).length) return "match";
      if (!(exp || []).length) return want === "enabled" ? detailVerdict(detail, appliedText(hit)) : "review";
      const kids = childrenOf(hit);
      let ok = true;
      for (const e of exp) {
        const kid = kids.find((k) => String(k.d).toLowerCase().includes(String(e.e).toLowerCase()));
        if (!kid) return detailVerdict(detail, appliedText(hit));
        if (!(String(kid.r ?? "") === e.v || bgNorm(kid.v) === bgNorm(e.l))) ok = false;
      }
      return ok ? "match" : "differs";
    }
    // A classic CSP node (a number or a named option), not an Enabled/Disabled choice.
    if ((exp || []).length === 1) {
      if (raw === exp[0].v || disp === bgNorm(exp[0].l) || bgNorm(v) === bgNorm(exp[0].v)) return "match";
      return /^\d+$/.test(raw || v) ? "differs" : "review";
    }
    return "review";
  }

  // Administrative template: "Enabled; Label: value; ..." or "Disabled".
  const st = /^enabled/i.test(v) ? "enabled" : /^disabled/i.test(v) ? "disabled" : "";
  if (!st) return "review";
  if (st !== want) return want === "disabled" && st === "enabled" && /disabled?\s*$/i.test(v.split(";").pop().split(":").pop().trim()) ? "match" : "differs";
  if (want === "disabled" || !detail) return "match";
  if ((exp || []).length) {
    const wants = exp.map((e) => bgNorm(e.l));
    return wants.every((w) => w && bgNorm(v).includes(w)) ? "match" : detailVerdict(detail, v);
  }
  return detailVerdict(detail, v);
}

/**
 * The report for one baseline: one row per recommendation.
 * @param baseline  { id, label, name, version, rows } from data/baselines.js
 * @param applied   from appliedPolicies()
 */
export function baselineGap(baseline, applied) {
  const idx = indexApplied(applied);
  const rows = baseline.rows.map((row) => {
    const [id, title, category, recommended] = row;
    const hits = hitsFor(row, idx);
    const out = { id, title, category, recommended, status: "missing", applied: "", sources: [], note: "" };
    if (!hits.length) return out;
    const verdicts = hits.map((h) => ({ h, status: compareValue(row, h) }));
    out.sources = verdicts.map(({ h }) => ({ policyId: h.policy.id, name: h.policy.name, typeKey: h.policy.typeKey, certainty: h.policy.certainty }));
    out.applied = [...new Set(hits.map(appliedText))].join(" | ");
    const kinds = new Set(verdicts.map((v) => v.status));
    out.status = kinds.size === 1 ? [...kinds][0] : kinds.has("differs") && kinds.has("match") ? "conflict" : kinds.has("differs") ? "differs" : "review";
    if (out.status === "conflict") out.note = "Policies that reach this device set it differently.";
    if (verdicts.some(({ h }) => h.policy.certainty !== "applies")) out.note = `${out.note} ${hits.every((h) => h.policy.certainty !== "applies") ? "Only policies that may not apply set this (assignment filter or mixed targeting)." : "Some of the policies that set this may not apply (assignment filter or mixed targeting)."}`.trim();
    return out;
  });
  rows.sort((a, b) => BASELINE_STATUS[a.status].order - BASELINE_STATUS[b.status].order || a.category.localeCompare(b.category) || a.title.localeCompare(b.title));
  const counts = { match: 0, differs: 0, conflict: 0, review: 0, missing: 0 };
  for (const r of rows) counts[r.status]++;
  const notes = [];
  const profiles = applied.filter((p) => p.typeKey === "endpointSecurityLegacy");
  if (profiles.length) notes.push(`These Intune security profiles reach the device, but their settings are not read, so what they set shows as "Not configured" here: ${profiles.map((p) => p.name).join(", ")}.`);
  const partial = applied.filter((p) => p.partial);
  if (partial.length) notes.push(`Only part of these policies' settings could be read, so a setting they set may show as "Not configured" here: ${partial.map((p) => p.name).join(", ")}. Rebuild the policy list to try again.`);
  return { baseline: { id: baseline.id, label: baseline.label, name: baseline.name, version: baseline.version }, rows, counts, total: rows.length, appliedPolicies: applied.length, notes };
}
