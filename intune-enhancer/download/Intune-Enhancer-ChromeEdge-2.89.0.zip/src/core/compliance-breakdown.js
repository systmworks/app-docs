// Compliance breakdown: which compliance setting fails on the most devices, and which devices. Intune
// keeps a result per setting across all compliance policies (deviceCompliancePolicySettingStateSummaries)
// and, for each setting, a state per device. A device counts as failing a setting when its state is
// nonCompliant, error or conflict. Pure apart from the two reads, so it is tested offline.

import { deviceUrl } from "./portal-links.js";
import { words } from "./format.js";

const SUMMARIES = "/beta/deviceManagement/deviceCompliancePolicySettingStateSummaries";
const FAILING = new Set(["noncompliant", "error", "conflict"]);

const compWords = (text) => words(String(text || "").replace(/^[A-Za-z0-9]+CompliancePolicy\./, ""));

/**
 * One row per setting that fails somewhere, most failing devices first; settings that fail nowhere are counted.
 * `all` keeps every setting's counts, passing ones too, with its raw name (Environment overview's firewall check).
 * @param summaries  deviceCompliancePolicySettingStateSummary items from Graph
 * @returns { rows, passing, all }
 */
export function rankSettings(summaries) {
  const all = (summaries || []).map((s) => {
    const nonCompliant = Number(s.nonCompliantDeviceCount) || 0;
    const error = Number(s.errorDeviceCount) || 0;
    const conflict = Number(s.conflictDeviceCount) || 0;
    const compliant = (Number(s.compliantDeviceCount) || 0) + (Number(s.remediatedDeviceCount) || 0);
    const failing = nonCompliant + error + conflict;
    return { id: s.id, name: String(s.settingName || s.setting || ""), setting: compWords(s.settingName || s.setting),
      platform: String(s.platformType || "").replace(/^./, (c) => c.toUpperCase()), failing, nonCompliant, error, conflict, compliant, total: failing + compliant };
  });
  const rows = all.filter((r) => r.failing).map(({ name, ...r }) => r);
  rows.sort((a, b) => b.failing - a.failing || a.setting.localeCompare(b.setting));
  return { rows, passing: all.length - rows.length, all };
}

/**
 * The devices failing one setting, joined to the device list where the id matches.
 * @param states   deviceComplianceSettingState items from Graph
 * @param devices  the device index rows ({ managedId, name, upn, os, osVersion, lastSync })
 */
export function failingDevices(states, devices) {
  const byId = new Map((devices || []).map((d) => [String(d.managedId || "").toLowerCase(), d]));
  return (states || [])
    .filter((s) => FAILING.has(String(s.state || "").toLowerCase()))
    .map((s) => {
      const d = byId.get(String(s.deviceId || "").toLowerCase());
      return {
        // The user's name on screen (shorter than the UPN); the UPN goes to the CSV.
        name: s.deviceName || d?.name || "(unknown device)", user: s.userName || d?.displayName || s.userPrincipalName || d?.upn || "",
        upn: s.userPrincipalName || d?.upn || "",
        state: String(s.state), os: d ? [d.os, d.osVersion].filter(Boolean).join(" ") : "", lastSync: d?.lastSync || "",
        link: d ? deviceUrl(d.managedId) : "", inList: Boolean(d), managedId: d?.managedId || "",
      };
    })
    .sort((a, b) => a.name.localeCompare(b.name));
}

/** Every setting's summary. A tenant without compliance policies answers with an empty list. */
export const readComplianceSummaries = (graph) => graph.all(SUMMARIES);

/** The per-device states of one setting. */
export const readSettingStates = (graph, settingId) => graph.all(`${SUMMARIES}/${encodeURIComponent(settingId)}/deviceComplianceSettingStates`);
