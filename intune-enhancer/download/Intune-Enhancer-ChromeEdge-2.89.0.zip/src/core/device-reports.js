// Device reports for the workspace: OS build spread, stale devices and duplicate device records.
// Pure functions over the device list (see resolve.js toDevice), so they run the same on real and
// sample data and are tested offline.

// Importing it sets globalThis.IEActivity; the in-portal scripts load the same file.
import "../shared/activity.js";
import { gb } from "./format.js";

/** Days since an ISO time (null for never / unparseable), and the activity traffic light for it: see shared/activity.js. */
export const { ageDays, activityLevel, ageText } = globalThis.IEActivity;

/** Numeric sort key from a version string ("10.0.26100.4349" -> [10, 0, 26100, 4349]). */
const versionKey = (v) => String(v || "").split(/[.\s]/).map((n) => Number(n) || 0);
export const compareVersions = (a, b) => {
  const x = versionKey(a);
  const y = versionKey(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) !== (y[i] || 0)) return (y[i] || 0) - (x[i] || 0); // newest first
  }
  return 0;
};

/**
 * The release a device is on, for grouping: Windows by named release ("Win11 24H2"), other
 * platforms by major version ("iOS 18"). friendly is IEWindowsBuilds.friendly.
 */
export function releaseOf(device, friendly = () => null) {
  const os = device.os || "Unknown OS";
  const v = device.osVersion || "";
  if (/^windows/i.test(os)) {
    const named = friendly(v);
    if (named) return { label: named.replace(/\s*\(.*\)$/, ""), sort: v };
    const build = v.match(/^10\.0\.(\d{5})/)?.[1];
    return { label: build ? `Windows build ${build}` : "Windows (version unknown)", sort: v };
  }
  const major = v.split(".")[0];
  return { label: major ? `${os} ${major}` : `${os} (version unknown)`, sort: v };
}

/**
 * Devices grouped by platform, then release, newest release first.
 * -> { total, platforms: [{ os, count, releases: [{ label, count, devices }] }] }
 */
export function osSpread(devices, friendly) {
  const byOs = new Map();
  for (const d of devices) {
    const os = d.os || "Unknown OS";
    const r = releaseOf(d, friendly);
    if (!byOs.has(os)) byOs.set(os, new Map());
    const releases = byOs.get(os);
    if (!releases.has(r.label)) releases.set(r.label, { label: r.label, sort: r.sort, devices: [] });
    const rel = releases.get(r.label);
    rel.devices.push(d);
    if (compareVersions(r.sort, rel.sort) < 0) rel.sort = r.sort; // keep the newest version as the key
  }
  const total = devices.length;
  const platforms = [...byOs.entries()].map(([os, releases]) => {
    const list = [...releases.values()]
      .map((r) => ({ label: r.label, count: r.devices.length, sort: r.sort, devices: r.devices }))
      .sort((a, b) => compareVersions(a.sort, b.sort));
    return { os, count: list.reduce((n, r) => n + r.count, 0), releases: list };
  }).sort((a, b) => b.count - a.count);
  return { total, platforms };
}

/**
 * Update check (OS builds tab): per Windows release, which devices are on a build and which are behind it. Each release is
 * checked against the newest build any of your devices on it reports, or, when `target` is a build ("26100.9711" or
 * "10.0.26100.9711"), only that build's release is checked against it. Every monthly Windows update raises the build, so
 * a device below the build is missing that update or a later one. Devices with no build revision are counted as unknown.
 * -> { error } for a target that isn't a build, else { target, releases: [{ label, build, devices, have, behind, unknown }],
 *    others: [{ label, count }] (Windows releases left out because a target was typed) }; behind is oldest first.
 */
export function updateCheck(devices, friendly, target = "") {
  const typed = String(target || "").trim();
  const want = typed.match(/^(?:10\.0\.)?(\d{5})\.(\d{1,5})$/);
  if (typed && !want) return { error: `"${typed}" isn't a Windows build. Type one like 26100.9711.` };
  const byBuild = new Map();
  for (const d of devices) {
    if (!/^windows/i.test(d.os || "")) continue;
    const m = String(d.osVersion || "").match(/^10\.0\.(\d{5})(?:\.(\d+))?/);
    if (!m) continue;
    if (!byBuild.has(m[1])) byBuild.set(m[1], { label: releaseOf(d, friendly).label, major: m[1], devices: [], unknown: 0 });
    const group = byBuild.get(m[1]);
    if (m[2]) group.devices.push(d); else group.unknown++;
  }
  const groups = [...byBuild.values()].sort((a, b) => Number(b.major) - Number(a.major));
  const checked = want ? groups.filter((g) => g.major === want[1]) : groups;
  const releases = checked.map((g) => {
    const newest = [...g.devices].sort((a, b) => compareVersions(a.osVersion, b.osVersion))[0];
    const full = want ? `10.0.${want[1]}.${Number(want[2])}` : newest?.osVersion.match(/^10\.0\.\d{5}\.\d+/)[0] || "";
    const behind = g.devices.filter((d) => compareVersions(d.osVersion, full) > 0).sort((a, b) => compareVersions(b.osVersion, a.osVersion));
    return { label: g.label, build: full.replace(/^10\.0\./, ""), devices: g.devices, have: g.devices.length - behind.length, behind, unknown: g.unknown };
  });
  const others = want ? groups.filter((g) => g.major !== want[1]).map((g) => ({ label: g.label, count: g.devices.length + g.unknown })) : [];
  return { target: want ? `${want[1]}.${Number(want[2])}` : "", releases, others };
}

/** Devices not checked in for more than `days` (or never), oldest first. */
export function staleDevices(devices, days = 30, now = Date.now()) {
  return devices
    .map((d) => ({ ...d, age: ageDays(d.lastSync, now) }))
    .filter((d) => d.age === null || d.age > days)
    .sort((a, b) => (b.age ?? Infinity) - (a.age ?? Infinity) || a.name.localeCompare(b.name));
}

/**
 * Devices with less than `limitGb` free, least free first. Devices Intune reports no storage for
 * (total 0) are left out and counted in `unknown`. -> { list: [{ ...device, freeGb, totalGb }], unknown }
 */
export function lowStorageDevices(devices, limitGb = 10) {
  const list = [];
  let unknown = 0;
  for (const d of devices) {
    if (!(d.totalBytes > 0)) { unknown++; continue; }
    const freeGb = gb(d.freeBytes);
    if (freeGb < limitGb) list.push({ ...d, freeGb, totalGb: gb(d.totalBytes) });
  }
  list.sort((a, b) => a.freeGb - b.freeGb || a.name.localeCompare(b.name));
  return { list, unknown };
}

/**
 * Device names with more than one Intune record (re-imaged or re-enrolled devices leave old
 * records behind). Each group is newest check-in first; the first is marked current.
 * -> [{ name, count, records: [{ ...device, age, current }] }]
 */
export function duplicateDevices(devices, now = Date.now()) {
  const byName = new Map();
  for (const d of devices) {
    const key = String(d.name || "").trim().toLowerCase();
    if (!key) continue;
    if (!byName.has(key)) byName.set(key, []);
    byName.get(key).push(d);
  }
  return [...byName.values()]
    .filter((list) => list.length > 1)
    .map((list) => {
      const records = list
        .map((d) => ({ ...d, age: ageDays(d.lastSync, now) }))
        .sort((a, b) => String(b.lastSync || "").localeCompare(String(a.lastSync || "")))
        .map((d, i) => ({ ...d, current: i === 0 }));
      return { name: records[0].name, count: records.length, records };
    })
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}
