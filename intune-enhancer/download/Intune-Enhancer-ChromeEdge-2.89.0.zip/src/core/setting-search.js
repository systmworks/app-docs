// Reads of the policy index for the workspace. Pure, tested offline.
//
// Setting check and the deprecated finder group results by setting (same definition id), each
// listing the policies that configure it and the value each sets, flagged when values disagree.

import { TYPE_BY_KEY } from "./policy-types.js";
import { policyRef } from "./portal-links.js";
import { norm } from "./resolve.js";
import { searchWords, hasAllWords } from "./format.js";

/**
 * Group the configured settings that match(s) by setting (same definition id). score(s) ranks a
 * setting's group, higher first.
 * @returns {{ settings: object[], total: number, policyCount: number, settingCount: number, truncated: boolean }}
 */
function collect(index, match, score, limit) {
  let settingCount = 0;
  let policyCount = 0;
  const groups = new Map();

  for (const policy of index?.policies || []) {
    if (!policy.settings) continue;
    policyCount++;
    for (const s of policy.settings) {
      settingCount++;
      if (!match(s)) continue;
      const key = s.d || `${s.n}|${s.p}`;
      let g = groups.get(key);
      if (!g) {
        g = { id: key, name: s.n, path: s.p, hits: [], score: score(s) };
        groups.set(key, g);
      }
      g.hits.push({
        policyId: policy.id,
        policyName: policy.name,
        ...policyRef(policy),
        value: s.v,
        assignments: policy.assignments || [],
      });
    }
  }

  const settings = [...groups.values()]
    .map((g) => ({ ...g, differs: new Set(g.hits.map((h) => norm(h.value))).size > 1 }))
    .sort((a, b) => b.score - a.score || b.hits.length - a.hits.length || a.name.localeCompare(b.name));

  return { settings: settings.slice(0, limit), total: settings.length, policyCount, settingCount, truncated: settings.length > limit };
}

// The lowercased text a search looks in, built once per setting: every search reads every configured
// setting (tens of thousands). Keyed by the setting object, so it goes when the index is rebuilt.
const searchText = new WeakMap();
function searchTextOf(s) {
  let text = searchText.get(s);
  if (text === undefined) {
    text = `${norm(s.n)} ${norm(s.p)} ${norm(s.k)} ${norm(s.d)}`;
    searchText.set(s, text);
  }
  return text;
}

/**
 * The product or area part of a setting's CSP path, to tell apart settings that share a name (every Office app has an
 * "Allow Trusted Locations on the network"): "excel16v2" from ".../Config/excel16v2~Policy~...". "" when the path has none.
 */
export function settingArea(path) {
  const m = /\/Config\/([^/~]+)/i.exec(String(path || ""));
  return m ? m[1] : "";
}

/** Setting check: configured settings matching every word of the query. */
export function searchSettings(index, query, { limit = 100 } = {}) {
  const words = searchWords(query);
  const phrase = words.join(" ");
  return collect(index,
    (s) => words.length > 0 && hasAllWords(searchTextOf(s), words),
    // Name matches rank above path-only matches; an exact name match ranks first.
    (s) => {
      const name = norm(s.n);
      return name === phrase ? 3 : hasAllWords(name, words) ? 2 : 1;
    },
    limit);
}

// Microsoft marks retired settings in their name, e.g. "Allow Cortana (Deprecated)" or
// "[Deprecated] ..."; settings-extract.js also flags catalog definitions whose description says so.
const DEPRECATED_RE = /\b(deprecated|obsolete)\b/i;
const isDeprecated = (s) => Boolean(s.x) || DEPRECATED_RE.test(s.n || "");

/** Deprecated settings that are still configured, most widely used first. */
export function deprecatedSettings(index, { limit = 200 } = {}) {
  return collect(index, isDeprecated, () => 0, limit);
}

/**
 * Policy export's and App details' search: indexed policies (not apps), or with apps: true only apps, whose name has
 * every word of the query, by name, the first `max` of them. Returns { total, policies: [{ id, name, typeLabel }] }; an empty query finds nothing.
 */
export function findPolicies(index, query, max = 50, { apps = false } = {}) {
  const words = searchWords(query);
  const hits = words.length ? (index?.policies || []).filter((p) => (p.type === "app") === apps && hasAllWords(p.name, words))
    .sort((x, y) => x.name.localeCompare(y.name)) : [];
  return { total: hits.length, policies: hits.slice(0, max).map((p) => ({ id: p.id, name: p.name, typeLabel: policyRef(p).typeLabel })) };
}

/**
 * Recent changes: every indexed policy, profile, script and app with its created and modified
 * dates, most recently modified first (undated last).
 */
export function changedPolicies(index) {
  return (index?.policies || []).map((p) => ({
    id: p.id,
    name: p.name,
    ...policyRef(p),
    created: p.created || "",
    modified: p.modified || p.created || "",
    assignments: p.assignments || [],
  })).sort((a, b) => b.modified.localeCompare(a.modified) || a.name.localeCompare(b.name));
}

/**
 * The two built-in assignment targets that are not groups. Intune's "All users" is really "all
 * licensed users". Keyed by a virtual id the Group assignments buttons send.
 */
/**
 * How many policies, profiles and scripts the index holds, and how many are assigned (an include, All devices or All
 * users; exclude-only targets nobody), for Environment overview. Apps are counted apart: the index keeps assigned
 * ones only, so the worker reads the app catalogue's assigned flags (apps: { total, assigned } or null).
 */
export function assignmentCounts(index, apps = null) {
  const items = (index?.policies || []).filter((p) => p.type !== "app");
  const unknown = items.filter((p) => p.assignmentsUnknown).length;
  const assigned = items.filter((p) => !p.assignmentsUnknown && (p.assignments || []).some((a) => a.kind !== "exclude")).length;
  return { policies: { total: items.length, assigned, notAssigned: items.length - assigned - unknown, unknown }, apps };
}

export const BROAD_TARGETS = {
  "all-devices": { kind: "allDevices", name: "All devices" },
  "all-users": { kind: "allUsers", name: "All users (licensed)" },
};

/** Every policy that references a group (or a built-in broad target), for Group assignments. */
export function policiesForGroup(index, groupId) {
  const id = norm(groupId);
  const broad = BROAD_TARGETS[id];
  const out = [];
  for (const policy of index?.policies || []) {
    for (const a of policy.assignments || []) {
      if (broad ? a.kind !== broad.kind : norm(a.groupId) !== id) continue;
      out.push({
        policyId: policy.id,
        policyName: policy.name,
        ...policyRef(policy),
        area: TYPE_BY_KEY[policy.type]?.area || "home",
        kind: a.kind,
        intent: a.intent || "",
        filterId: a.filterId || "",
        filterType: a.filterType || "",
      });
    }
  }
  return out.sort((a, b) => a.typeLabel.localeCompare(b.typeLabel) || a.policyName.localeCompare(b.policyName));
}

// Setting name -> { settings, policies }, built once per index (a picker asks about dozens of names at a time).
const usageByName = new WeakMap();
function usageMap(index) {
  let map = usageByName.get(index);
  if (map) return map;
  map = new Map();
  for (const policy of index.policies || []) {
    for (const s of policy.settings || []) {
      const name = norm(s.n);
      let u = map.get(name);
      if (!u) { u = { settings: new Set(), policies: new Map() }; map.set(name, u); }
      u.settings.add(s.d || `${s.n}|${s.p}`);
      u.policies.set(policy.id, policy.name);
    }
  }
  usageByName.set(index, map);
  return map;
}

/**
 * Where each setting name is already configured, for the "Set in N policies" text in Intune's settings picker.
 * The picker shows only a setting's friendly name, so this matches on the name; shared is true when more than
 * one setting in the index has that name, so the count may include a different setting.
 * @param items  [{ key, name }]
 * @returns { [key]: { count, policies: string[], more, shared } } with an entry for every key (count 0 if unused)
 */
export function settingUsage(index, items, { listMax = 10 } = {}) {
  const map = usageMap(index);
  const out = {};
  for (const { key, name } of items) {
    const u = map.get(norm(name));
    out[key] = u
      ? { count: u.policies.size, policies: [...u.policies.values()].sort((a, b) => a.localeCompare(b)).slice(0, listMax), more: Math.max(0, u.policies.size - listMax), shared: u.settings.size > 1 }
      : { count: 0, policies: [], more: 0, shared: false };
  }
  return out;
}
