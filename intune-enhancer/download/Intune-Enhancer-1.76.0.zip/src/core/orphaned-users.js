// Orphaned primary users: devices whose primary user is disabled or no longer exists, so the device
// has no one to answer for it. Looked up by user id (managedDevice.userId), which survives renames.

const USER_ID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Ask Graph about each distinct user id. options: { onProgress(done, total), shouldStop() }, passed to the batch. -> Map(id -> "ok" | "disabled" | "deleted" | "unknown") */
export async function userStates(graph, ids, options = {}) {
  const list = [...new Set(ids)].filter((id) => USER_ID_RE.test(id));
  const res = await graph.batch(list.map((id) => ({ id, url: `/users/${id}?$select=id,accountEnabled` })), options);
  const out = new Map();
  for (const id of list) {
    const r = res.get(id);
    if (r?.status === 200) out.set(id, r.body?.accountEnabled === false ? "disabled" : "ok");
    else out.set(id, r?.status === 404 ? "deleted" : "unknown"); // 403, throttled out, no answer
  }
  return out;
}

/**
 * Devices whose primary user is disabled or deleted, most recently checked in first (those are still
 * in use). Users Graph wouldn't answer for are counted in `unknown`, not listed.
 * -> { list: [{ ...device, userState }], unknown }
 */
export function orphanedDevices(devices, states) {
  const list = [];
  let unknown = 0;
  for (const d of devices) {
    const state = d.userId && states.get(d.userId);
    if (state === "disabled" || state === "deleted") list.push({ ...d, userState: state });
    else if (state === "unknown") unknown++;
  }
  list.sort((a, b) => String(b.lastSync || "").localeCompare(String(a.lastSync || "")) || a.name.localeCompare(b.name));
  return { list, unknown };
}
