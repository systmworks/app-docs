// Remediations list (Devices > Scripts and remediations): the created and modified dates under each
// script package's name, and a "Sort by" dropdown above the list (Created or Modified, newest first),
// because the list has neither column. Dates come from the service worker, one read of all packages.
//
// Display only. Rows are matched by the package id the list keeps in a hidden element in each row.
// Sorting reorders the rows the list has drawn, with CSS only (the list's own markup is never moved).

(function () {
  if (window.__ieScriptDates) return;
  window.__ieScriptDates = true;

  const { feature, styleOnce, onPass, send, grid: G, rules, GUID, ADDED } = globalThis.IEKit;
  const DATES = "ie-script-dates";
  const BAR = "ie-script-sort";
  const NOTE = "ie-script-note";
  const GUID_RE = new RegExp(`^${GUID}$`, "i");
  const MODES = [["", "Default (as Intune sorts it)"], ["modified", "Modified, newest first"], ["created", "Created, newest first"]];

  let dates = null; // id (lowercase) -> { created, modified }
  let loading = false;
  let note = ""; // why the dates aren't showing, drawn beside the Sort by dropdown
  let mode = "";
  let unwatch = null;

  const day = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "unknown");

  /** The package id of a row: the id on the hidden element the list keeps in each row, or "". */
  const idOf = (row) => {
    const id = row.querySelector("[hidden][id]")?.id || "";
    return GUID_RE.test(id) ? id.toLowerCase() : "";
  };

  /** Rows (as { id }) in sort order: newest first by the chosen date; ids with no date come last. Pure. */
  function ranked(ids, byId, by) {
    const time = (id) => Date.parse(byId[id]?.[by] || "") || 0;
    return [...ids].sort((a, b) => time(b) - time(a));
  }

  function load() {
    if (dates || loading) return;
    loading = true;
    send({ type: "scripts/dates" })
      .then((res) => { if (!res?.ok) throw new Error(res?.error || "no answer from the extension"); dates = res.dates || {}; note = ""; loading = false; pass(); })
      .catch((e) => {
        note = `Dates couldn't be read: ${e?.message || e}`;
        showNote();
        setTimeout(() => { loading = false; if (unwatch) pass(); }, 15000); // no session yet, or Graph said no: ask again later
      });
  }

  /** Show `note` (or clear it) beside every Sort by dropdown. */
  function showNote() {
    for (const bar of document.querySelectorAll(`.${BAR}`)) {
      let el = bar.querySelector(`.${NOTE}`);
      if (!note) { el?.remove(); continue; }
      if (!el) { el = document.createElement("span"); el.className = NOTE; bar.append(el); }
      if (el.textContent !== note) el.textContent = note;
    }
  }

  function bar(listEl) {
    const host = listEl.closest('[data-automationid="DetailsList"]') || listEl;
    let el = host.previousElementSibling?.classList.contains(BAR) ? host.previousElementSibling : null;
    if (el) return;
    el = document.createElement("div");
    el.className = BAR;
    const label = Object.assign(document.createElement("label"), { textContent: "Sort by " });
    const select = document.createElement("select");
    select.setAttribute("aria-label", "Sort the Remediations list by date");
    select.title = `Sorts the packages shown below by the date they were created or last modified.${ADDED}`;
    for (const [value, text] of MODES) select.append(Object.assign(document.createElement("option"), { value, textContent: text }));
    select.value = mode;
    select.addEventListener("change", () => { mode = select.value; pass(); });
    label.append(select);
    el.append(label);
    host.before(el);
  }

  /** Put the drawn rows in `order` (a list of ids), or back as Intune has them when mode is "". */
  function reorder(cells, order) {
    const first = cells[0];
    if (!first) return;
    let root = first.parentElement;
    while (root && !cells.every((c) => root.contains(c))) root = root.parentElement;
    if (!root) return;
    const active = Boolean(mode);
    root.toggleAttribute("data-ie-sortroot", active);
    for (const cell of cells) {
      cell.style.order = active ? String(Math.max(0, order.indexOf(cell.dataset.ieId))) : "";
      for (let p = cell.parentElement; p && p !== root; p = p.parentElement) p.toggleAttribute("data-ie-sortpage", active);
    }
  }

  function pass(grids = G.scan()) {
    for (const { el, cols } of grids) {
      const col = rules.listName(cols, "script");
      if (!col) continue;
      bar(el);
      if (!dates) { load(); continue; }
      const cells = [];
      for (const row of G.rowsOf(el)) {
        const id = idOf(row);
        const cell = G.cellFor(G.cellsOf(row), col, cols);
        const item = row.closest('[data-automationid="ListCell"]');
        if (!id || !cell || !item) continue;
        item.dataset.ieId = id;
        cells.push(item);
        const d = dates[id];
        const host = cell.querySelector("button")?.parentElement || cell;
        let line = cell.querySelector(`.${DATES}`);
        if (!d) { line?.remove(); continue; }
        const text = `Created ${day(d.created)} · Modified ${day(d.modified)}`;
        if (!line) { line = document.createElement("div"); line.className = DATES; host.append(line); }
        if (line.textContent !== text) line.textContent = text;
      }
      // Rows are drawn but none could be matched to a package: say so instead of silently doing nothing.
      if (!cells.length && G.rowsOf(el).length && !note) { note = "Couldn't match the list's rows to script packages."; }
      else if (cells.length && note.startsWith("Couldn't match")) note = "";
      showNote();
      reorder(cells, ranked(cells.map((c) => c.dataset.ieId), dates, mode || "modified"));
    }
  }

  const CSS = `
    .${DATES} { font-size: 11px; opacity: 0.7; line-height: 1.2; white-space: nowrap; }
    .${BAR} { padding: 6px 0; font-size: 12px; }
    .${BAR} select { font: inherit; color: inherit; background: transparent; border: 1px solid rgba(128, 128, 128, 0.5); border-radius: 4px; padding: 2px 6px; margin-left: 4px; }
    .${NOTE} { margin-left: 10px; color: #c76a00; }
    :root[data-ie-dark] .${NOTE} { color: #f0a030; }
    .${BAR} option { color: CanvasText; background: Canvas; }
    [data-ie-sortroot] { display: flex !important; flex-direction: column; }
    [data-ie-sortpage] { display: contents !important; }`;

  const ensureStyles = styleOnce(CSS);
  feature("remediationDates", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      mode = "";
      document.querySelectorAll(`.${DATES}, .${BAR}, .${NOTE}`).forEach((el) => el.remove());
      document.querySelectorAll("[data-ie-sortroot], [data-ie-sortpage]").forEach((el) => { el.removeAttribute("data-ie-sortroot"); el.removeAttribute("data-ie-sortpage"); });
      document.querySelectorAll("[data-ie-id]").forEach((el) => { el.style.order = ""; el.removeAttribute("data-ie-id"); });
    },
  });

  if (globalThis.__IE_TEST__) Object.assign(globalThis.__IE_TEST__, { scriptDates: { ranked, idOf, day } });
})();
