// Shared helpers for the in-portal content scripts. Listed before them in manifest.json; content
// scripts in the same frame share one isolated world, so they all see globalThis.IEKit.
//
// Every in-portal feature goes through IEKit.feature(), which only starts it once the user has
// accepted the disclosure AND one of the feature's prefs is on (all prefs default to on), and
// stops it (removing everything it added) the moment that changes.

(function () {
  if (globalThis.IEKit) return;

  const CONSENT_KEY = "ie.consent";
  const CONSENT_VERSION = 1;
  const PREFS_KEY = "ie.prefs";
  const consented = (v) => (v?.version || 0) >= CONSENT_VERSION;

  let state = null; // { agreed, prefs }
  const listeners = new Set();

  const ready = chrome.storage.local.get([CONSENT_KEY, PREFS_KEY]).then((v) => {
    state = { agreed: consented(v[CONSENT_KEY]), prefs: v[PREFS_KEY] || {} };
  }).catch(() => { state = { agreed: false, prefs: {} }; });

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !state) return;
      if (changes[CONSENT_KEY]) state.agreed = consented(changes[CONSENT_KEY].newValue);
      if (changes[PREFS_KEY]) state.prefs = changes[PREFS_KEY].newValue || {};
      for (const fn of listeners) fn(changes);
    });
  } catch { /* extension context gone */ }

  /**
   * Run a feature while consent is given and any of its pref keys is on.
   * onChange(changes) is called for every later storage change while it runs (a pref edited, the
   * device index rebuilt), so it can redraw.
   * @param {string|string[]} keys
   * @param {{ start: () => void, stop: () => void, onChange?: (changes: object) => void }} spec
   */
  function feature(keys, { start, stop, onChange }) {
    const list = [].concat(keys);
    let running = false;
    const sync = (changes) => {
      const on = state.agreed && list.some(isOn);
      if (on && !running) { running = true; start(); }
      else if (!on && running) { running = false; stop(); }
      else if (on && changes) onChange?.(changes);
    };
    ready.then(() => { sync(); listeners.add(sync); });
  }

  /** Call fn(agreed) with the consent state now, and again whenever it changes. */
  function watchConsent(fn) {
    ready.then(() => {
      let last = state.agreed;
      fn(last);
      listeners.add(() => { if (state.agreed !== last) fn((last = state.agreed)); });
    });
  }

  /** Run fn once, as soon as the disclosure has been accepted (straight away if it already has). */
  function whenConsented(fn) {
    let done = false;
    watchConsent((agreed) => { if (agreed && !done) { done = true; fn(); } });
  }

  /** Current prefs (empty until storage has loaded). */
  const prefs = () => state?.prefs || {};
  /** Is a setting on? Every one is on unless saved as false (a switch) or "off" (a dropdown). */
  const isOn = (key) => prefs()[key] !== false && prefs()[key] !== "off";
  /** A dropdown's value: "off", the saved value if it's one of `values`, else values[0] (its default). */
  const choice = (key, values) => (!isOn(key) ? "off" : values.includes(prefs()[key]) ? prefs()[key] : values[0]);

  /** Save one setting (e.g. a column width the admin dragged). */
  function savePref(key, value) {
    try {
      chrome.storage.local.get(PREFS_KEY)
        .then((v) => chrome.storage.local.set({ [PREFS_KEY]: { ...(v[PREFS_KEY] || {}), [key]: value } }))
        .catch(() => {});
    } catch { /* extension context gone */ }
  }

  // Shared by the content scripts.
  const BRAND = "Intune Enhancer";
  const ADDED = `\nAdded by ${BRAND}`; // ends every tooltip we add
  const GUID = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
  const OPEN_ICON = '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2.5h4.5V7"/><path d="M13.5 2.5 7.5 8.5"/><path d="M12 9.5v3a1 1 0 0 1-1 1H3.5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h3"/></svg>';

  /** Rules for one of our small icon buttons (class cls), readable on the portal's light and dark themes (data-ie-dark). */
  const iconButtonCss = (cls) => `
    .${cls} { display: inline-flex; align-items: center; margin-left: 6px; padding: 1px 3px; border-radius: 4px; vertical-align: middle; cursor: pointer; color: #1f5fbf; }
    .${cls}:hover, .${cls}:focus-visible { background: rgba(31, 95, 191, 0.14); outline: none; }
    :root[data-ie-dark] .${cls} { color: #8ab4ff; }`;

  /**
   * Rules for one of our pills (class cls): a thin neon sky blue border marks it as ours, and it is
   * transparent so it takes the row's own hover and selection tint, with dark text on the portal's
   * light theme and white on its dark theme (data-ie-dark). `warn` is the selector suffix of its
   * pale red state (failed, empty); `action` the suffix of its clickable state. The caller adds any
   * rules of its own (`display`, inner colours, the default cursor).
   */
  const pillCss = (cls, { warn, action }) => `
    .${cls} { margin-left: 8px; padding: 0 7px; border: 1px solid #008aff; border-radius: 9px; box-shadow: 0 0 4px rgba(0, 138, 255, 0.45); font-size: 0.9em; color: #1b1b1b; background: transparent; white-space: nowrap; }
    .${cls}${warn} { background: #ffe1e3; font-weight: 600; }
    .${cls}${action} { cursor: pointer; }
    .${cls}${action}:hover, .${cls}${action}:focus-visible { background: rgba(128, 128, 128, 0.18); outline: none; }
    .${cls}${warn}${action}:hover, .${cls}${warn}${action}:focus-visible { background: #ffc9cd; }
    :root[data-ie-dark] {
      .${cls} { color: #fff; }
      .${cls}${warn} { background: #4a0d14; }
      .${cls}${action}:hover, .${cls}${action}:focus-visible { background: rgba(255, 255, 255, 0.12); }
      .${cls}${warn}${action}:hover, .${cls}${warn}${action}:focus-visible { background: #65121c; }
    }`;

  /** Add a stylesheet. Portal frames run a strict CSP that refuses <style>, so use a constructed sheet. */
  function adoptStyles(css, root = document) {
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(css);
      root.adoptedStyleSheets = [...root.adoptedStyleSheets, sheet];
      return true;
    } catch {
      return false;
    }
  }

  /** A function that adds `css` to the page the first time it is called and does nothing after that. */
  const styleOnce = (css) => {
    let done = false;
    return () => { if (!done) done = adoptStyles(css); };
  };

  // Anything we add to the page: an "ie-" class or a data-ie attribute.
  const OURS = "[class^='ie-'], [class*=' ie-'], [data-ie]";
  // Persona coins and avatars show initials ("GP") before a name, and can load after it.
  const AVATAR = "[class*='initials' i], [class*='coin' i], [class*='avatar' i]";
  const isInitials = (el) => Boolean(el?.closest(AVATAR)) && el.textContent.trim().length <= 3;

  /**
   * MutationObserver over the whole document that ignores changes made by our own elements, so
   * drawing never triggers another pass. Calls back once straight away, then once the page has been
   * still for `delay` ms (at most `maxWait` after the first change, so a long scroll still gets
   * drawn), when the browser is idle. Scrolling a long list changes the page constantly; running
   * every few hundred ms through it made scrolling sluggish.
   */
  function watch(callback, delay = 250, maxWait = 1000) {
    let timer = null;
    let idle = null;
    let first = 0; // when the oldest change not yet handled happened
    const run = () => {
      timer = null;
      first = 0;
      idle = requestIdleCallback(() => { idle = null; callback(); }, { timeout: 500 });
    };
    const isOurs = (n) => n?.nodeType === 1 && n.matches(OURS);
    const inOurs = (n) => Boolean((n?.nodeType === 1 ? n : n?.parentElement)?.closest(OURS));
    const observer = new MutationObserver((records) => {
      for (const rec of records) {
        if (inOurs(rec.target)) continue;
        const nodes = [...rec.addedNodes, ...rec.removedNodes];
        if (rec.type === "childList" && nodes.length && nodes.every(isOurs)) continue;
        first ||= Date.now();
        clearTimeout(timer);
        timer = setTimeout(run, Math.max(0, Math.min(delay, first + maxWait - Date.now())));
        return;
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    callback();
    return () => { observer.disconnect(); clearTimeout(timer); if (idle) cancelIdleCallback(idle); };
  }

  /**
   * Make one of our elements a button, keeping its clicks away from the portal's own row
   * navigation. handler(event) runs on click, Enter or Space.
   */
  function clickable(el, label, handler) {
    el.setAttribute("role", "button");
    el.setAttribute("aria-label", label);
    el.tabIndex = 0;
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup"]) el.addEventListener(type, (e) => e.stopPropagation());
    el.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); handler(e); });
    el.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " ") return;
      e.preventDefault(); e.stopPropagation(); handler(e);
    });
    return el;
  }

  /** Message the service worker; resolves with the response, rejects on failure. */
  function send(message) {
    return new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (res) => {
          const err = chrome.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(res);
        });
      } catch (e) {
        reject(e);
      }
    });
  }

  /** One pending retry of fn after ms; scheduling again while one is pending does nothing. */
  function retrier(ms, fn) {
    let timer = null;
    return {
      schedule() { if (!timer) timer = setTimeout(() => { timer = null; fn(); }, ms); },
      cancel() { clearTimeout(timer); timer = null; },
    };
  }

  /**
   * Batched lookups through the service worker. request(items) sends [{ key, ... }] as message
   * `type`, keeps the answers (res[field], by item key) in results, then calls redraw(). A key in
   * flight isn't asked for twice; after a failed request (no session yet, Graph refused) redraw()
   * runs again after retryMs, which asks again.
   */
  function lookups({ type, field, retryMs, redraw }) {
    const results = new Map();
    const inFlight = new Set();
    const retry = retrier(retryMs, redraw);
    return {
      results,
      wanted: (key) => !results.has(key) && !inFlight.has(key),
      request(items) {
        items.forEach((i) => inFlight.add(i.key));
        const done = () => items.forEach((i) => inFlight.delete(i.key));
        send({ type, items }).then((res) => {
          done();
          if (!res?.ok) { retry.schedule(); return; }
          let again = false;
          for (const [key, value] of Object.entries(res[field] || {})) {
            if (value?.retry) again = true; // Graph was busy: ask again shortly instead of remembering a non-answer
            else results.set(key, value);
          }
          if (again) retry.schedule();
          redraw();
        }, done);
      },
      cancel: retry.cancel,
    };
  }

  // ---------------------------------------------------------------------------------------
  // Reading the portal's lists. Works from column headers, so one set of rules covers Fluent
  // DetailsList, Fluent DataGrid and plain tables. Proven against the live portal by the primary
  // user labels (group members, device lists, Discovered apps).

  const textOf = (el) => String(el?.innerText ?? el?.textContent ?? "").replace(/\s+/g, " ").trim();

  /** Text of a cell without anything we added to it. */
  function cellText(cell) {
    if (!cell) return "";
    if (!cell.querySelector(OURS)) return textOf(cell);
    const clone = cell.cloneNode(true);
    clone.querySelectorAll(OURS).forEach((n) => n.remove());
    return textOf(clone);
  }

  /** First line of a cell's text (names), minus icon-font glyphs, avatar initials and our own additions. */
  function nameText(cell) {
    const clone = cell.cloneNode(true);
    clone.querySelectorAll(OURS).forEach((n) => n.remove());
    clone.querySelectorAll(AVATAR).forEach((n) => { if (isInitials(n)) n.remove(); });
    const raw = String(clone.innerText ?? clone.textContent ?? "");
    const first = raw.split("\n").map((s) => s.replace(/[\u{E000}-\u{F8FF}]/gu, "").trim()).find(Boolean) || "";
    return first.replace(/\s+/g, " ");
  }

  /** A cell's first non-blank text node that isn't ours or avatar initials (the name, in a name cell), or null. */
  function firstText(cell) {
    const walker = document.createTreeWalker(cell, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.nodeValue.trim() && !n.parentElement.closest(OURS) && !isInitials(n.parentElement)
        ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
    });
    return walker.nextNode();
  }

  const headerCellsOf = (grid) => [...grid.querySelectorAll('[role="columnheader"], thead th')];
  const rowsOf = (grid) => [...grid.querySelectorAll('[role="row"], tbody tr')]
    .filter((row) => !row.querySelector('[role="columnheader"], th'));
  const cellsOf = (row) => [...row.querySelectorAll(':scope [role="gridcell"], :scope [role="rowheader"], :scope > td')]
    // Nested grids would otherwise contribute their cells to the outer row.
    .filter((cell) => cell.closest('[role="row"], tr') === row);

  function colIndexOf(el, fallback) {
    const v = Number(el.getAttribute("aria-colindex"));
    return Number.isFinite(v) && v > 0 ? v : fallback;
  }

  // Header text can include sort arrows, "Press to sort" hints or icon-font glyphs.
  function headerLabel(th) {
    const named = th.getAttribute("aria-label") || th.getAttribute("title") || "";
    const raw = textOf(th) || named;
    return raw.replace(/[\u{E000}-\u{F8FF}]/gu, "").replace(/\b(sorted (ascending|descending)|press to sort.*)$/i, "").trim().toLowerCase();
  }

  /** A grid's columns: { cols, find(re), usesAria, headerCount }, or null if it has no headers. */
  function columns(grid) {
    const headers = headerCellsOf(grid);
    if (!headers.length) return null;
    const cols = headers.map((th, i) => ({ label: headerLabel(th), index: colIndexOf(th, i + 1), key: th.getAttribute("data-item-key") || "", el: th }));
    return {
      cols,
      find: (re) => cols.find((c) => re.test(c.label)) || null,
      usesAria: headers.some((th) => th.hasAttribute("aria-colindex")),
      headerCount: headers.length,
    };
  }

  /** The cell in `cells` (one row's cells) for column `col` of a grid laid out as `layout`. */
  function cellFor(cells, col, layout) {
    if (!col) return null;
    if (layout.usesAria) {
      const hit = cells.find((c) => colIndexOf(c, 0) === col.index);
      if (hit) return hit;
    }
    if (col.key) {
      const hit = cells.find((c) => c.getAttribute("data-automation-key") === col.key);
      if (hit) return hit;
    }
    // Positional fallback. A row with more cells than there are headers usually has a
    // selection checkbox cell in front that has no header of its own.
    const offset = Math.max(0, cells.length - layout.headerCount);
    return cells[col.index - 1 + offset] || null;
  }

  /** Attribute text of a row and its links: where portal deep links carry object ids. Bounded. */
  function attrText(row) {
    const parts = [];
    for (const el of [row, ...row.querySelectorAll("a, [href], [data-href], [data-url]")].slice(0, 60)) {
      for (const attr of el.attributes || []) {
        if (attr.name === "class" || attr.name === "style") continue;
        if (attr.value && attr.value.length < 2000) parts.push(attr.value);
      }
    }
    return parts.join(" ");
  }

  function findGrids(root) {
    const grids = new Set();
    for (const el of root.querySelectorAll('[role="grid"], [role="treegrid"], table')) grids.add(el);
    // Some Fluent lists put role="grid" on an inner element; rows outside a grid fall back to
    // the nearest ancestor that also holds the headers.
    for (const row of root.querySelectorAll('[role="row"]')) {
      if (row.closest('[role="grid"], [role="treegrid"], table')) continue;
      let el = row.parentElement;
      while (el && el !== document.body && !el.querySelector('[role="columnheader"]')) el = el.parentElement;
      if (el && el !== document.body) grids.add(el);
    }
    return [...grids];
  }

  /** Every list on the page that has column headers: [{ el, cols }], cols as columns() returns. */
  const scan = () => findGrids(document).map((el) => ({ el, cols: columns(el) })).filter((g) => g.cols);

  const grid = { cellText, nameText, firstText, rowsOf, cellsOf, columns, cellFor, attrText, findGrids, scan };

  // Which lists and columns we recognise by their headers, in one place so every script agrees.
  const LIST_NAMES = {
    // A Name column is an app, policy or group list's when its marker column sits beside it.
    app: { marker: /^(version|publisher|app type)$/, name: /^(name|app name|display name)$/ },
    policy: { marker: /^(policy type|profile type)$/, name: /^(name|policy name|profile name)$/ },
    group: { marker: /^(group type|membership type)$/, name: /^(name|display name)$/ },
    script: { marker: /^script package name$/, name: /^script package name$/ }, // the Remediations list
    member: { marker: /^details$/, name: /^name$/ }, // the Add members / Add owners picker (Name, Type, Details)
  };
  const rules = {
    /** A device list's name column. */
    deviceName: /^(device|device name|devicename|managed device|managed device name|computer name|hostname)$/,
    /** The group column of an assignment table. */
    groupColumn: /^(group|groups|group name|included groups?|excluded groups?|assigned groups?|target groups?|assignment groups?)$/,
    /** The Name column of an app, policy or group list (kind "app", "policy", "group" or "script") in columns(grid), or null. */
    listName: (cols, kind) => (cols.find(LIST_NAMES[kind].marker) ? cols.find(LIST_NAMES[kind].name) : null),
  };

  /**
   * Mark the portal's dark theme on <html> as data-ie-dark, for our stylesheets. Judged by the page's
   * text colour: the portal has its own light/dark setting, which needn't match the computer's.
   */
  function markTheme() {
    // A list cell's text colour is the real text; some frames leave the body's at a default that misleads.
    const probe = document.querySelector('[role="gridcell"], td') || document.body || document.documentElement;
    const m = getComputedStyle(probe).color.match(/[\d.]+/g);
    const dark = Boolean(m) && 0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2] > 140;
    if (document.documentElement.hasAttribute("data-ie-dark") !== dark) document.documentElement.toggleAttribute("data-ie-dark", dark);
  }

  // One observer and one grid scan per frame, shared by every feature, instead of one of each per feature.
  const passes = new Set();
  let unwatchAll = null;

  /** Call fn(grids) now and after every page change (debounced), until the returned stop function runs. */
  function onPass(fn) {
    passes.add(fn);
    markTheme();
    if (unwatchAll) fn(scan());
    else {
      unwatchAll = watch(() => {
        markTheme(); // a theme switch redraws the page, so this pass sees it
        const grids = scan();
        for (const f of passes) {
          try { f(grids); } catch { /* one feature failing mustn't stop the others */ }
        }
      });
    }
    return () => {
      passes.delete(fn);
      if (!passes.size) { unwatchAll(); unwatchAll = null; }
    };
  }

  /**
   * An outlined pill for a command we add to a portal toolbar, so it reads as ours: the same accent border and
   * glow as the pills we add to lists. `button` selects the button itself. Every value is a custom property.
   */
  const commandPillCss = (button) => `
    ${button} { --pill-border: #008aff; --pill-radius: 9px; --pill-glow: 0 0 4px rgba(0, 138, 255, 0.45); --pill-pad: 0 10px; --pill-margin: 0 6px; --pill-height: 26px;
      border: 1px solid var(--pill-border) !important; border-radius: var(--pill-radius) !important; box-shadow: var(--pill-glow);
      padding: var(--pill-pad) !important; margin: var(--pill-margin); height: var(--pill-height) !important; min-height: 0 !important; align-self: center; }`;

  /** Text made safe to put inside innerHTML. */
  const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  globalThis.IEKit = {
    feature, watchConsent, whenConsented, prefs, isOn, choice, savePref, adoptStyles, styleOnce, pillCss, commandPillCss, onPass, send, clickable, retrier, lookups, grid, rules, escapeHtml,
    BRAND, ADDED, GUID, OURS, OPEN_ICON, iconButtonCss,
  };
})();
