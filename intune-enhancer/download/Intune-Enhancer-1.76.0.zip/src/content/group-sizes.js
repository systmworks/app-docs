// Group size hints: wherever the portal lists groups (assignment tables, the Entra groups list, a
// device's group membership), show how many devices, users and nested groups each one holds,
// including nested members. "empty" stands out, which helps spot assignments that reach nobody.
// Clicking the pill opens the group (assignment tables show group names as plain text).
//
// In assignment tables the pill goes in a slim column of our own just past the table's right edge,
// lined up with each row (column-widths.js widens the Group column). Elsewhere (or with no room
// past the table) it goes on the group name's line.
//
// Display only. Counts and ids come from the service worker (cached for 30 minutes there) and are
// looked up in batches, never one Graph call per row.

(function () {
  if (window.__ieGroupSizes) return;
  window.__ieGroupSizes = true;

  const { feature, choice, styleOnce, onPass, send, clickable, lookups, grid: G, rules, pillCss, ADDED, GUID } = globalThis.IEKit;
  const CLASS = "ie-group-size";
  const SIDE = "ie-group-side";
  const SIDE_MIN = 160; // px needed past the table for the side column

  // A column of group names: assignment tables ("Group", "Included groups"...), or the Entra
  // groups list, recognised by a group/membership type column next to "Name".
  const OBJECT_ID_RE = /^(object id|group id)$/;
  // Virtual targets that aren't groups.
  const VIRTUAL = new Set(["all devices", "all users", "all licensed users", "none", ""]);
  const GUID_ONLY_RE = new RegExp(`^${GUID}$`, "i");
  const GROUP_ID_RE = new RegExp(`groupId(?:/|=|%2f|%3d)(${GUID})`, "i");

  let unwatch = null;
  // Member counts (and ids) by group key, retried while there's no session yet.
  const lookup = lookups({ type: "groups/sizes", field: "sizes", retryMs: 15000, redraw: () => passIfRunning() });
  const sizes = lookup.results;

  // ---------------------------------------------------------------------------------------
  // Reading rows

  /** Column layout for a grid listing groups, or null. */
  function describe(gridEl, c = G.columns(gridEl)) {
    if (!c) return null;
    const assignCol = c.find(rules.groupColumn);
    const col = assignCol || rules.listName(c, "group");
    if (!col) return null;
    // Assignment tables get the side column.
    return { col, assignment: Boolean(assignCol), idCol: c.find(OBJECT_ID_RE), usesAria: c.usesAria, headerCount: c.headerCount };
  }

  /** The group a row refers to: { key, id, name, cell }, or null. */
  function readRow(row, layout) {
    const cells = G.cellsOf(row);
    const cell = G.cellFor(cells, layout.col, layout);
    if (!cell) return null;
    // Assignment tables can prefix the mode ("Include: Sales"); keep just the name.
    const name = G.nameText(cell).replace(/^(include|exclude|included|excluded)\s*:\s*/i, "").trim();
    if (VIRTUAL.has(name.toLowerCase())) return null;
    const idText = layout.idCol ? G.cellText(G.cellFor(cells, layout.idCol, layout)) : "";
    const id = (GUID_ONLY_RE.test(idText) ? idText : G.attrText(row).match(GROUP_ID_RE)?.[1] || "").toLowerCase();
    if (!id && !name) return null;
    return { key: id ? `i:${id}` : `n:${name.toLowerCase()}`, id, name, cell };
  }

  // ---------------------------------------------------------------------------------------
  // Drawing the pill into a place: a side column item, or the group cell itself

  /** Text and tooltip for a size result. Pure; tested offline. */
  function format(s) {
    if (!s || s.notFound) return null;
    if (s.ambiguous) {
      return { text: `${s.ambiguous} groups share this name`, kind: "warn", title: "Several groups have this exact name, so the size can't be shown." };
    }
    const n = (v) => (v === null || v === undefined ? "?" : v.toLocaleString());
    const parts = [];
    if (s.devices) parts.push(`${n(s.devices)} device${s.devices === 1 ? "" : "s"}`);
    if (s.users) parts.push(`${n(s.users)} user${s.users === 1 ? "" : "s"}`);
    if (s.groups) parts.push(`${n(s.groups)} group${s.groups === 1 ? "" : "s"}`);
    const unknown = [s.devices, s.users, s.groups].some((v) => v === null);
    if (!parts.length && unknown) return { text: "size unknown", kind: "muted", title: "Couldn't read this group's members." };
    if (!parts.length) return { text: "empty", kind: "warn", title: "This group has no members, so anything assigned to it reaches nobody." };
    return { text: parts.join(" · "), kind: "", title: "Members including nested groups." };
  }

  // Inside the element holding the name, so they share its line.
  const hostOf = (place) => G.firstText(place)?.parentElement || place;

  /** Show, update or remove the size pill. With the group's id, clicking it opens the group. */
  function draw(place, key, s, id = "") {
    let f = format(s);
    if (f && choice("groupSizeHints", ["all", "empty"]) === "empty" && f.text !== "empty") f = null; // "Empty groups only"
    let span = place.querySelector(`.${CLASS}`);
    if (!f) { span?.remove(); return; }
    if (!span) {
      span = clickable(document.createElement("span"), "", (e) => {
        const gid = e.currentTarget.dataset.id;
        if (gid) send({ type: "portal/open", kind: "group", id: gid, newTab: e.ctrlKey || e.metaKey }).catch(() => {});
      });
      span.className = CLASS;
    }
    const host = hostOf(place);
    if (span.parentElement !== host) host.appendChild(span); // new, or the portal redrew the name
    if (span.dataset.key === key && span.textContent === f.text && (span.dataset.id || "") === id) return;
    span.dataset.key = key;
    span.dataset.kind = f.kind;
    span.textContent = f.text;
    span.title = `${f.title}${id ? "\nClick to open the group (Ctrl+click: new tab)" : ""}${ADDED}`;
    // A button only when there's a group to open.
    if (id) span.dataset.id = id; else delete span.dataset.id;
    span.tabIndex = id ? 0 : -1;
    if (id) span.setAttribute("role", "button"); else span.removeAttribute("role");
    span.setAttribute("aria-label", id ? `${f.text}: open the group` : f.text);
  }

  // ---------------------------------------------------------------------------------------
  // Side column past an assignment table. One fixed layer at the top of the page, positioned from
  // each row's place on screen: inside the page it would be clipped by the portal's containers,
  // which are only as wide as the table.

  let layer = null;
  const sideItems = new WeakMap(); // row -> its item in the side column
  const placed = new Map(); // side item in use -> { row, box }, refilled by each pass

  /** What the list shows on screen: the nearest horizontally scrolling container, or the grid. */
  function boxOf(gridEl, row) {
    for (let p = row.parentElement; p && p !== document.body; p = p.parentElement) {
      if (/auto|scroll/.test(getComputedStyle(p).overflowX)) return p;
      if (p === gridEl.parentElement) break;
    }
    return gridEl;
  }

  /** Room in the frame past the table for the side column? */
  const hasRoom = (box) => (window.innerWidth || Infinity) - box.getBoundingClientRect().right >= SIDE_MIN;

  /** The row's item in the side column, in the row's own text colour and font. place() positions it. */
  function sideItem(box, row) {
    if (!layer?.isConnected) {
      layer = document.createElement("div");
      layer.className = SIDE;
      Object.assign(layer.style, { position: "fixed", left: "0", top: "0", width: "0", height: "0", zIndex: "10" });
      document.documentElement.appendChild(layer);
    }
    let item = sideItems.get(row);
    if (item?.parentElement !== layer) {
      item = document.createElement("div");
      item.className = `${SIDE}-row`;
      const look = getComputedStyle(row);
      Object.assign(item.style, {
        position: "absolute", display: "flex", alignItems: "center", gap: "6px", whiteSpace: "nowrap",
        color: look.color, fontFamily: look.fontFamily, fontSize: look.fontSize,
      });
      layer.appendChild(item);
      sideItems.set(row, item);
    }
    placed.set(item, { row, box });
    return item;
  }

  /**
   * Line each side item up with its row, just right of the table's box, hidden while the row is
   * scrolled out of the box. All reads first, then all writes, so the page lays out only once.
   */
  function place() {
    const spots = [...placed].map(([item, { row, box }]) => [item, row.getBoundingClientRect(), box.getBoundingClientRect()]);
    for (const [item, r, b] of spots) {
      Object.assign(item.style, {
        left: `${Math.round(b.right + 12)}px`, top: `${Math.round(r.top)}px`, height: `${Math.round(r.height)}px`,
        visibility: r.bottom <= b.top || r.top >= b.bottom ? "hidden" : "",
      });
    }
  }

  // ---------------------------------------------------------------------------------------
  // Passes

  function pass(grids = G.scan()) {
    const pending = new Map();
    placed.clear(); // sideItem refills it with the side items still in use
    for (const { el: gridEl, cols } of grids) {
      const layout = describe(gridEl, cols);
      if (!layout) continue;
      const rows = G.rowsOf(gridEl);
      const box = layout.assignment && rows.length ? boxOf(gridEl, rows[0]) : null;
      const side = Boolean(box) && hasRoom(box);
      for (const row of rows) {
        const hit = readRow(row, layout);
        if (!hit) { row.querySelectorAll(`.${CLASS}`).forEach((el) => el.remove()); continue; }
        let place = hit.cell;
        if (side) {
          place = sideItem(box, row);
          hit.cell.querySelectorAll(`.${CLASS}`).forEach((el) => el.remove());
        }
        const s = sizes.get(hit.key);
        if (s) draw(place, hit.key, s, hit.id || s.id || "");
        else {
          const old = place.querySelector(`.${CLASS}`);
          if (old && old.dataset.key !== hit.key) old.remove();
          if (lookup.wanted(hit.key)) pending.set(hit.key, { key: hit.key, id: hit.id, name: hit.name });
        }
      }
    }
    if (layer) {
      [...layer.children].forEach((item) => { if (!placed.has(item)) item.remove(); });
      if (!layer.children.length) layer.remove();
    }
    place();
    if (pending.size) lookup.request([...pending.values()].slice(0, 40));
  }

  // Only redraw while running: a lookup can finish after the feature was switched off.
  const passIfRunning = () => { if (unwatch) pass(); };
  // Scrolling anywhere (captured) or resizing moves the tables: move the side items with them, once
  // per frame, without a full pass.
  let frameQueued = false;
  const follow = () => {
    if (frameQueued || !layer) return;
    frameQueued = true;
    requestAnimationFrame(() => { frameQueued = false; if (unwatch) place(); });
  };

  const LISTENERS = [
    [window, "resize", follow, false],
    [document, "scroll", follow, true],
  ];

  // Transparent, so it takes the row's own hover and selection tint, with dark text on the portal's
  // light theme and white on its dark theme (data-ie-dark, from the page itself); pale red / dark red
  // when the group is empty. Its own text colour, not the link blue around it. A thin border in the icon's neon sky blue marks it as ours.
  const CSS = `
    .${SIDE}-row > * { margin-left: 0 !important; }
    ${pillCss(CLASS, { warn: '[data-kind="warn"]', action: "[data-id]" })}
    .${CLASS} { cursor: help; } /* until it has a group to open */
    html .${SIDE}-row .${CLASS}, :root[data-ie-dark] .${SIDE}-row .${CLASS} { color: inherit; } /* the row's own text colour, on any theme */
    .${CLASS}[data-kind="muted"] { font-style: italic; }`;

  const ensureStyles = styleOnce(CSS);
  feature("groupSizeHints", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
      for (const [target, type, fn, capture] of LISTENERS) target.addEventListener(type, fn, capture);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      lookup.cancel();
      for (const [target, type, fn, capture] of LISTENERS) target.removeEventListener(type, fn, capture);
      placed.clear();
      document.querySelectorAll(`.${CLASS}, .${SIDE}`).forEach((el) => el.remove());
    },
    onChange(changes) {
      if (changes["ie.prefs"]) passIfRunning();
    },
  });

  if (globalThis.__IE_TEST__) {
    globalThis.__IE_TEST__.groupSizes = {
      describe, readRow, format, draw, boxOf, hasRoom, sideItem, place,
    };
  }
})();
