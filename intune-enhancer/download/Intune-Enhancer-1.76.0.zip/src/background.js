// Service worker. Holds the Graph token pool, owns the device and policy indexes, and answers the
// in-portal content scripts and the workspace page. All Graph traffic goes from here;
// content scripts never see a token apart from capture.js handing one in.

import { createGraphClient, odataQuote } from "./core/graph.js";
import { createTokenPool } from "./core/tokens.js";
import { createDeviceIndex } from "./core/device-index.js";
import { createPolicyIndex } from "./core/policy-index.js";
import { searchSettings, deprecatedSettings, changedPolicies } from "./core/setting-search.js";
import { searchGroups, groupImpact, groupRoster, groupSizes, groupNames, listFilters, searchUsers, compareGroups } from "./core/group-tools.js";
import { decodeIds } from "./core/id-decoder.js";
import { buildCleanup, referencedGroupIds } from "./core/cleanup.js";
import { CONSENT_KEY, isConsented, readConsent } from "./shared/consent.js";
import { deviceUrl, groupUrl, userUrl, appUrl, policyRef } from "./core/portal-links.js";
import { appStatus } from "./core/app-status.js";
import { policyNames, policyStatus } from "./core/policy-status.js";
import { scriptDates } from "./core/script-dates.js";
import { detailRows } from "./core/device-details.js";
import { rollupApps } from "./core/app-versions.js";
import { userStates, orphanedDevices } from "./core/orphaned-users.js";
import { tenantHealth } from "./core/tenant-health.js";
import { buildDevice360, device360Context, memberGroups, readDeviceGroups } from "./core/device-360.js";
import { shapeRelated } from "./core/device-related.js";
import { settingUsage } from "./core/setting-search.js";
import { duplicatePolicies } from "./core/duplicate-policies.js";
import { readHardware, HARDWARE_KEY, hardwareKey } from "./core/hardware.js";
import { compareDevices } from "./core/device-compare.js";
import { rankSettings, failingDevices, readComplianceSummaries, readSettingStates } from "./core/compliance-breakdown.js";
import { getItem, setItem, removePrefix } from "./core/store.js";
import { createHintCache } from "./core/hint-cache.js";

// The toolbar icon opens the workspace, where everything lives, including Settings and the
// disclosure. Nothing runs until the disclosure is accepted: until then the icon says OFF, and a
// new install opens Settings so nobody wonders why nothing happens.
const WORKSPACE_URL = chrome.runtime.getURL("src/workspace/workspace.html");

/** Show the workspace (on a tab, e.g. "settings"), reusing an open workspace tab. */
async function openWorkspace(tab = "") {
  const url = tab ? `${WORKSPACE_URL}#${tab}` : WORKSPACE_URL;
  const contexts = await chrome.runtime.getContexts({ contextTypes: ["TAB"] }).catch(() => []);
  const open = contexts.find((c) => c.documentUrl?.startsWith(WORKSPACE_URL));
  if (!open) return chrome.tabs.create({ url });
  await chrome.tabs.update(open.tabId, { active: true, ...(tab ? { url } : {}) });
  await chrome.windows.update(open.windowId, { focused: true });
}

function showConsentBadge() {
  chrome.action.setBadgeText({ text: consented ? "" : "OFF" }).catch(() => {});
  chrome.action.setBadgeBackgroundColor({ color: "#b42318" }).catch(() => {});
}

// Cached for the badge and the toolbar icon only. Requests read storage afresh, so the first
// request straight after the user agrees isn't refused by a cache that hasn't caught up.
let consented = false;
readConsent().then((ok) => { consented = ok; showConsentBadge(); });
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes[CONSENT_KEY]) return;
  consented = isConsented(changes[CONSENT_KEY].newValue);
  showConsentBadge();
  if (!consented) { tokens.clear(); index.clearAll(); policies.clearAll(); hints.clear(); removePrefix(HARDWARE_KEY); }
});
chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === "install") openWorkspace("settings");
});
chrome.action.onClicked.addListener(() => { openWorkspace(consented ? "" : "settings"); });

const tokens = createTokenPool({
  onIdentityChange: (id) => { index.load(id.tid).catch(() => {}); policies.load(id.tid).catch(() => {}); },
});
const graph = createGraphClient(() => tokens.candidates(), (token) => tokens.markGood(token));
const index = createDeviceIndex(graph, { onProgress: (p) => broadcast({ type: "index/progress", ...p }) });
const policies = createPolicyIndex(graph, { onProgress: (p) => broadcast({ type: "policies/progress", ...p }) });

function broadcast(message) {
  try { chrome.runtime.sendMessage(message).catch(() => {}); } catch { /* no listeners */ }
}

/** Consent + session check. Returns the tenant id or throws (the caller gets { ok: false }). */
async function requireSession() {
  await tokens.ready;
  if (!(await readConsent())) {
    throw Object.assign(new Error("Intune Enhancer is turned off. Turn it on in the workspace's Settings tab."), { code: "NO_CONSENT" });
  }
  const tid = tokens.identity?.tid;
  if (!tid || tokens.size === 0) {
    throw Object.assign(new Error("No Intune session. Open the Intune admin center in another tab and sign in."), { code: "NO_TOKEN" });
  }
  return tid;
}

async function status() {
  await tokens.ready;
  const consented = await readConsent();
  const id = tokens.identity;
  if (id?.tid) await Promise.all([index.load(id.tid), policies.load(id.tid)]).catch(() => {});
  return { ok: true, consented, signedIn: tokens.size > 0, upn: id?.upn || "", tid: id?.tid || "", index: index.status(), policies: policies.status() };
}

// Short-lived answers for the in-portal hints, in core/hint-cache.js. The worker sleeps after about 30 s
// idle, so they are also saved in IndexedDB.
const HINTS_KEY = "ie.hints";
const hints = createHintCache({ store: { get: () => getItem(HINTS_KEY), set: (entries) => setItem(HINTS_KEY, entries) } });

/** Group member counts: items [{ key, id?, name? }] -> { [key]: size }. */
const cachedSizes = (tid, items) => hints.cachedItems(tid, "size", items, (todo) => groupSizes(graph, todo));

// A discovered app's id is a hash string, not a GUID.
const isAppId = (s) => /^[\w-]{1,128}$/.test(String(s || ""));
const isGuid = (s) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(s || ""));

/** Content script items [{ key, id?, name? }], checked and capped. */
const hintItems = (msg) => (Array.isArray(msg.items) ? msg.items : []).slice(0, 40)
  .map((i) => ({ key: String(i.key), id: isGuid(i.id) ? i.id : "", name: String(i.name || "").slice(0, 256) }));

// Handlers any part of the extension may call, including content scripts running in the portal.
// Kept to what those scripts need.
const contentHandlers = {
  // The admin center's "turned off" note: open Settings, where the disclosure is.
  async "settings/open"() {
    await openWorkspace("settings");
    return { ok: true };
  },

  // The "Used by" button on a group page: open the workspace on Group impact for that group.
  async "workspace/open"(msg) {
    if (msg.tab !== "impact" || !isGuid(msg.group)) return { ok: false, error: "Bad request." };
    await openWorkspace(`impact/${msg.group.toLowerCase()}`);
    return { ok: true };
  },

  // The Related button on a device's page: the primary user's other devices and the device's groups.
  async "device/related"(msg) {
    const tid = await requireSession();
    const serial = String(msg.serial || "").slice(0, 128);
    const [res] = serial ? await index.lookup(tid, [{ serial }]) : [{ devices: [] }];
    const device = res.devices?.[0];
    if (!device) return { ok: true, found: false };
    const others = device.upn ? (await index.byUpns(tid, [device.upn]))[device.upn] || [] : [];
    const { groups, note, error } = await readDeviceGroups(graph, device);
    const why = note || (error ? `Couldn't read this device's groups (${error.message}).` : "");
    return { ok: true, found: true, related: shapeRelated(device, others, groups, why, res.devices.length - 1) };
  },

  // The settings picker's "Set in N policies" text: names asked about -> where each is configured. Reads only
  // the saved policy index; it never starts a build (that is the Setting check tab's explicit action).
  async "settings/usage"(msg) {
    const tid = await requireSession();
    await policies.load(tid);
    const index = policies.peek();
    if (!index) return { ok: false, error: "The policy index isn't built yet." };
    const items = (Array.isArray(msg.items) ? msg.items : []).slice(0, 100).map((i) => ({ key: String(i.key).slice(0, 256), name: String(i.name || "").slice(0, 256) }));
    return { ok: true, usage: settingUsage(index, items) };
  },

  async "token/seen"(msg) {
    await tokens.ready;
    if (await readConsent()) tokens.add(msg.token);
    return { ok: true };
  },

  // Primary user labels: [{ key, ref }] -> { [key]: result }
  async "lookup"(msg) {
    const tid = await requireSession();
    const items = Array.isArray(msg.items) ? msg.items.slice(0, 500) : [];
    const results = await index.lookup(tid, items.map((i) => i.ref));
    return { ok: true, results: Object.fromEntries(items.map((item, i) => [item.key, results[i]])) };
  },

  // Jump to Intune, quick facts, group and app pills: open a device, group or app in the portal's tab, or a
  // new tab beside it. Needs no "tabs" permission.
  async "portal/open"(msg, sender) {
    const urlFor = { device: deviceUrl, group: groupUrl, app: appUrl }[msg.kind];
    if (!urlFor || !isGuid(msg.id)) return { ok: false, error: "Bad link." };
    const url = urlFor(msg.id);
    const tab = sender.tab;
    if (msg.newTab || !tab?.id) await chrome.tabs.create({ url, index: tab ? tab.index + 1 : undefined, openerTabId: tab?.id });
    else await chrome.tabs.update(tab.id, { url });
    return { ok: true };
  },

  // Group size hints: member counts per group.
  async "groups/sizes"(msg) {
    const tid = await requireSession();
    return { ok: true, sizes: await cachedSizes(tid, hintItems(msg)) };
  },

  // App install status pills: installed and failed device counts per app.
  async "apps/status"(msg) {
    const tid = await requireSession();
    return { ok: true, status: await hints.cachedItems(tid, "app", hintItems(msg), (todo) => appStatus(graph, todo)) };
  },

  // Device quick facts, "More details": the rest of one managed device's record, read when asked for.
  async "device/details"(msg) {
    const tid = await requireSession();
    if (!isGuid(msg.id)) return { ok: false, error: "Bad device id." };
    const rows = await hints.cached(`${tid}|device|${msg.id.toLowerCase()}`, async () => detailRows(await graph.get(`/beta/deviceManagement/managedDevices/${msg.id}`)));
    return { ok: true, rows };
  },

  // Remediations list: when each script package was created and last modified.
  async "scripts/dates"() {
    const tid = await requireSession();
    return { ok: true, dates: await hints.cached(`${tid}|scriptDates`, () => scriptDates(graph)) };
  },

  // Policy status pills: succeeded and failed device counts per configuration policy.
  async "policies/status"(msg) {
    const tid = await requireSession();
    const names = () => hints.cached(`${tid}|policyNames`, () => policyNames(graph));
    return { ok: true, status: await hints.cachedItems(tid, "policy", hintItems(msg), (todo) => policyStatus(graph, todo, names)) };
  },

  // Filter rule hints: all assignment filters with their rules.
  async "filters/list"() {
    const tid = await requireSession();
    return { ok: true, filters: await hints.cached(`${tid}|filters`, () => listFilters(graph)) };
  },
};

// Handlers for the extension's own page (the workspace) only, never content scripts.
let orphansStop = false;

const pageHandlers = {
  "status": status,

  // The workspace's Stop button: ends whichever long read is running. A stopped build saves nothing.
  async "job/stop"() {
    index.cancel();
    policies.cancel();
    orphansStop = true;
    return { ok: true };
  },

  async "index/rebuild"() {
    const tid = await requireSession();
    await index.load(tid);
    await index.build();
    return status();
  },

  // Clears the stored device and policy lists, the saved Hardware report and the saved hint answers. Session tokens stay, so
  // the next lookup rebuilds.
  async "data/clear"() {
    await index.clearAll();
    await policies.clearAll();
    await hints.clear();
    await removePrefix(HARDWARE_KEY); // the saved Hardware report: serial numbers, IP and MAC addresses
    return status();
  },

  // OS builds and Stale & duplicates: every managed device, from the device index.
  async "devices/list"() {
    const tid = await requireSession();
    const { devices, builtAt } = await index.all(tid);
    devices.forEach((d) => { d.link = deviceUrl(d.managedId); });
    return { ok: true, devices, builtAt };
  },

  // Orphaned users: devices whose primary user is disabled or deleted (one Graph lookup per user).
  async "devices/orphaned"() {
    const tid = await requireSession();
    const { devices, builtAt } = await index.all(tid);
    orphansStop = false;
    let states;
    try {
      states = await userStates(graph, devices.map((d) => d.userId).filter(Boolean), {
        onProgress: (done, total) => broadcast({ type: "job/progress", key: "orphans", label: "Checking primary users", done, total }),
        shouldStop: () => orphansStop,
      });
    } finally {
      broadcast({ type: "job/done", key: "orphans" });
    }
    const { list, unknown } = orphanedDevices(devices, states);
    list.forEach((d) => { d.link = deviceUrl(d.managedId); });
    return { ok: true, devices: list, unknown, checked: states.size, builtAt };
  },

  // Device 360: what reaches one device and why. The first use builds the policy index.
  async "device/360"(msg) {
    const tid = await requireSession();
    const { devices } = await index.all(tid);
    const device = devices.find((d) => d.managedId === msg.managedId);
    if (!device) throw new Error("That device is no longer in the device list. Refresh the list and try again.");
    const [policyIndex, ctx] = await Promise.all([policies.get(tid), device360Context(graph, device, listFilters)]);
    return { ok: true, report: buildDevice360(device, policyIndex, ctx) };
  },

  // Tenant health: expiring tokens, certificates and connectors, one lookup per source.
  async "tenant/health"() {
    await requireSession();
    return { ok: true, rows: await tenantHealth(graph), at: Date.now() };
  },

  // App versions: discovered apps whose name contains the query, rolled up by app.
  async "apps/versions"(msg) {
    await requireSession();
    const query = String(msg.query || "").trim().slice(0, 100);
    if (!query) return { ok: true, apps: [] };
    const filter = encodeURIComponent(`contains(displayName,'${odataQuote(query)}')`);
    const detected = await graph.all(`/beta/deviceManagement/detectedApps?$filter=${filter}&$select=id,displayName,version,publisher,deviceCount,platform&$top=500`);
    return { ok: true, apps: rollupApps(detected) };
  },

  // App versions: the devices running the given discovered app versions, items [{ id, version }].
  async "apps/devices"(msg) {
    await requireSession();
    const items = (Array.isArray(msg.items) ? msg.items : []).filter((i) => isAppId(i?.id)).slice(0, 40);
    const select = "id,deviceName,userPrincipalName,userDisplayName,operatingSystem,osVersion,lastSyncDateTime,complianceState";
    const res = await graph.batch(items.map((i, n) => ({ id: String(n), url: `/deviceManagement/detectedApps/${encodeURIComponent(i.id)}/managedDevices?$select=${select}` })));
    const devices = [];
    let failed = 0;
    items.forEach((i, n) => {
      const r = res.get(String(n));
      if (r?.status !== 200) { failed++; return; }
      for (const d of r.body?.value || []) {
        devices.push({ managedId: d.id, name: d.deviceName || "", upn: d.userPrincipalName || "", displayName: d.userDisplayName || "", os: d.operatingSystem || "",
          osVersion: d.osVersion || "", lastSync: d.lastSyncDateTime || "", compliance: d.complianceState || "", appVersion: String(i.version || "").slice(0, 64), link: deviceUrl(d.id) });
      }
    });
    return { ok: true, devices, failed };
  },

  // Cleanup: the policy index, plus which referenced groups still exist and how big they are.
  async "cleanup/report"() {
    const tid = await requireSession();
    const idx = await policies.get(tid);
    const names = await groupNames(graph, referencedGroupIds(idx));
    const existing = Object.keys(names);
    const bySize = await cachedSizes(tid, existing.map((id) => ({ key: `i:${id}`, id })));
    const report = buildCleanup(idx, names, Object.fromEntries(existing.map((id) => [id, bySize[`i:${id}`]])));
    report.emptyGroup.forEach((f) => { f.groupLink = groupUrl(f.groupId); });
    return { ok: true, report, policies: policies.status() };
  },

  async "policies/build"() {
    const tid = await requireSession();
    await policies.get(tid, { rebuild: true });
    return { ok: true, policies: policies.status() };
  },

  async "settings/search"(msg) {
    const tid = await requireSession();
    const idx = await policies.get(tid);
    return { ok: true, ...searchSettings(idx, msg.query), policies: policies.status() };
  },

  async "settings/deprecated"() {
    const tid = await requireSession();
    return { ok: true, ...deprecatedSettings(await policies.get(tid)), policies: policies.status() };
  },

  // Recent changes: every indexed object with its created / modified dates.
  async "policies/changes"() {
    const tid = await requireSession();
    return { ok: true, items: changedPolicies(await policies.get(tid)), policies: policies.status() };
  },

  async "groups/search"(msg) {
    await requireSession();
    return { ok: true, groups: await searchGroups(graph, msg.query) };
  },

  // Compliance breakdown: how many devices fail each compliance setting, then the devices failing one.
  async "compliance/summary"() {
    await requireSession();
    return { ok: true, ...rankSettings(await readComplianceSummaries(graph)) };
  },
  async "compliance/devices"(msg) {
    const tid = await requireSession();
    if (!/^[\w.-]{1,200}$/.test(String(msg.id || ""))) return { ok: false, error: "Bad setting id." };
    const [states, { devices }] = await Promise.all([readSettingStates(graph, msg.id), index.all(tid)]);
    return { ok: true, devices: failingDevices(states, devices) };
  },

  // Compare devices: find a device by name or primary user, then compare two (the first use builds the policy index).
  async "devices/search"(msg) {
    const tid = await requireSession();
    const q = String(msg.query || "").trim().toLowerCase();
    const { devices } = await index.all(tid);
    const hits = q ? devices.filter((d) => [d.name, d.upn, d.displayName].some((s) => String(s || "").toLowerCase().includes(q))).sort((x, y) => x.name.localeCompare(y.name)) : [];
    return { ok: true, devices: hits.slice(0, 25).map((d) => ({ id: d.managedId, displayName: d.name, userPrincipalName: [d.displayName || d.upn || "No primary user", d.os].filter(Boolean).join(", ") })) };
  },

  async "devices/compare"(msg) {
    const tid = await requireSession();
    const { devices } = await index.all(tid);
    const a = devices.find((d) => d.managedId === msg.a);
    const b = devices.find((d) => d.managedId === msg.b);
    if (!a || !b) throw new Error("A device is no longer in the device list. Refresh the list and try again.");
    const policyIndex = await policies.get(tid);
    const [ctxA, ctxB] = await Promise.all([device360Context(graph, a, listFilters), device360Context(graph, b, listFilters)]);
    return { ok: true, ...compareDevices(buildDevice360(a, policyIndex, ctxA), buildDevice360(b, policyIndex, ctxB)) };
  },

  // Hardware report: full records for a batch of devices, and the saved result of the last run.
  async "hardware/read"(msg) {
    await requireSession();
    const ids = [...new Set((msg.ids || []).filter(isGuid))].slice(0, 200);
    return { ok: true, ...(await readHardware(graph, ids)) };
  },
  async "hardware/load"() {
    const tid = await requireSession();
    return { ok: true, saved: (await getItem(hardwareKey(tid))) || null };
  },
  async "hardware/save"(msg) {
    const tid = await requireSession();
    await setItem(hardwareKey(tid), { at: Date.now(), rows: Array.isArray(msg.rows) ? msg.rows : [] });
    return { ok: true };
  },

  // Duplicate policies: pairs setting the same things to the same values. The first use builds the policy index.
  async "policies/duplicates"() {
    const tid = await requireSession();
    const index = await policies.get(tid);
    return { ok: true, ...duplicatePolicies(index), builtAt: index.builtAt };
  },

  // Policy export: find an indexed policy by name, then read the one picked.
  async "policy/find"(msg) {
    const tid = await requireSession();
    const q = String(msg.query || "").trim().toLowerCase();
    const index = await policies.get(tid);
    const hits = q ? index.policies.filter((p) => p.type !== "app" && p.name.toLowerCase().includes(q)).sort((x, y) => x.name.localeCompare(y.name)) : [];
    return { ok: true, total: hits.length, policies: hits.slice(0, 50).map((p) => ({ id: p.id, name: p.name, typeLabel: policyRef(p).typeLabel })) };
  },

  async "policy/get"(msg) {
    const tid = await requireSession();
    const index = await policies.get(tid);
    const policy = index.policies.find((p) => p.id === msg.id);
    if (!policy) throw new Error("That policy is no longer in the index. Search again.");
    // Names are a nicety: if either read fails the document shows the ids instead.
    const ids = (policy.assignments || []).map((a) => a.groupId).filter(Boolean);
    const [names, filterList] = await Promise.all([
      ids.length ? groupNames(graph, ids).catch(() => ({})) : {},
      (policy.assignments || []).some((a) => a.filterId) ? listFilters(graph).catch(() => []) : [],
    ]);
    const filters = Object.fromEntries(filterList.map((f) => [String(f.id).toLowerCase(), { name: f.name }]));
    return { ok: true, policy: { ...policy, ...policyRef(policy) }, names, filters };
  },

  async "users/search"(msg) {
    await requireSession();
    return { ok: true, users: await searchUsers(graph, msg.query) };
  },

  // Compare two users: the groups both are in, and the ones only one is in.
  async "users/compare"(msg) {
    await requireSession();
    const read = async (id) => { try { return await memberGroups(graph, `/users/${id}`); } catch { return null; } };
    const [a, b] = await Promise.all([read(msg.a), read(msg.b)]);
    const result = compareGroups(a, b);
    const withLinks = (list) => list.map((g) => ({ ...g, link: groupUrl(g.id) }));
    return { ok: true, ...result, both: withLinks(result.both), onlyA: withLinks(result.onlyA), onlyB: withLinks(result.onlyB), unreadable: { a: !a, b: !b } };
  },

  async "group/impact"(msg) {
    const tid = await requireSession();
    const report = await groupImpact(graph, await policies.get(tid), msg.groupId);
    return { ok: true, report: { ...report, link: groupUrl(report.group.id) }, policies: policies.status() };
  },

  async "group/roster"(msg) {
    const tid = await requireSession();
    const roster = await groupRoster(graph, (refs) => index.lookup(tid, refs), msg.groupId, (upns) => index.byUpns(tid, upns));
    for (const r of roster.rows) {
      if (r.managedId) r.link = deviceUrl(r.managedId);
      if (r.type === "User") r.link = userUrl(r.objectId);
      (r.devices || []).forEach((d) => { d.link = deviceUrl(d.managedId); });
    }
    return { ok: true, roster };
  },

  // Group ids -> names, for showing who a policy is assigned to.
  async "groups/names"(msg) {
    await requireSession();
    return { ok: true, names: await groupNames(graph, (msg.ids || []).slice(0, 1000)) };
  },

  async "ids/decode"(msg) {
    const tid = await requireSession();
    // Assignments come from the policy index only if it's already built; decoding shouldn't
    // wait for a full policy read.
    await policies.load(tid).catch(() => {});
    return { ok: true, ...(await decodeIds(graph, msg.text, policies.peek())) };
  },
};

const isExtensionPage = (sender) => String(sender.url || "").startsWith(chrome.runtime.getURL(""));

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Only this extension's own pages and content scripts can reach this listener (no
  // externally_connectable), but check the sender anyway.
  if (sender.id !== chrome.runtime.id) return;
  const handler = contentHandlers[msg?.type] || (isExtensionPage(sender) ? pageHandlers[msg?.type] : null);
  if (!handler) return;
  handler(msg, sender).then(sendResponse, (e) => sendResponse({ ok: false, error: e?.message || String(e), code: e?.code || "" }));
  return true; // async response
});
