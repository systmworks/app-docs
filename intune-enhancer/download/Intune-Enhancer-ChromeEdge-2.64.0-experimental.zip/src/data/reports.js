// The All Reports list: Intune's own reports with the address of each, as seen in the live portal on 2026-11-05
// (owner-verified; see docs/reports-catalogue-checklist.md, private). Nothing here is read from a tenant.
// Row: [name, area, platform, description, path]. path is the part after the admin center host, so a US
// Government cloud gets its own host (core/portal-links.js reportUrl).
// area is one of REPORT_AREAS.

const DS = "#view/Microsoft_Intune_DeviceSettings/";
const EN = "#view/Microsoft_Intune_Enrollment/";
const RM = `${EN}ReportingMenu/~/`;
const UX = `${EN}UXAnalyticsMenu/~/`;

export const REPORT_AREAS = ["Compliance", "Updates", "Enrollment", "Apps", "Security", "Configuration", "Other"];

export const REPORTS = [
  // Compliance
  ["Noncompliant devices", "Compliance", "All", "Identify noncompliant devices and investigate their compliance details.", `${DS}NoncompliantDevicesReport.ReactView`],
  ["Policies with noncompliant and error devices", "Compliance", "All", "View policies with one or more noncompliant devices or devices with errors.", `${DS}PolicyNoncompliance.ReactView`],
  ["Device compliance", "Compliance", "All", "Compliance status of your devices: how many are compliant and how many need attention.", `${EN}DeviceComplianceOrgReport.ReactView`],
  ["Noncompliant devices and settings", "Compliance", "All", "Each device that is not compliant with policy, with the settings it fails.", `${EN}NonCompliantDSOrgReport.ReactView`],
  ["Devices without compliance policy", "Compliance", "All", "Each device that has no compliance policy assigned.", `${EN}DevicesWithoutCompliancePolicy.ReactView`],
  ["Setting compliance", "Compliance", "All", "Number of devices in various compliance states for settings.", `${EN}SettingCompliance.ReactView`],
  ["Policy compliance", "Compliance", "All", "Number of devices in various compliance states for policies.", `${EN}PolicyCompliance.ReactView`],
  ["Windows hardware attestation report", "Compliance", "Windows", "Status of hardware-attested compliance settings on Windows devices.", `${EN}WHAReport.ReactView`],

  // Updates
  ["Apple software update failures", "Updates", "iOS, macOS", "View software update installation failures on Apple devices.", `${DS}AppleSoftwareUpdateFailuresReport.ReactView`],
  ["Apple software updates (declarative)", "Updates", "iOS, macOS", "Update status for Apple devices on declarative device management.", `${EN}AppleDDMUpdatesOrgReport.ReactView`],
  ["Deployment status per Windows update ring", "Updates", "Windows", "The number of devices with successful or failed updates for each update ring.", `${DS}DeploymentStatuses.ReactView`],
  ["Feature update policies with alerts", "Updates", "Windows", "Policies with one or more Windows devices with feature update alerts.", `${DS}WindowsUpdateAlertSummaryReport.ReactView`],
  ["Expedited quality update policies with alerts", "Updates", "Windows", "Policies with one or more Windows devices with expedited quality update alerts.", `${DS}WindowsQualityUpdateAlertsSummaryReport.ReactView`],
  ["Driver update policies with alerts", "Updates", "Windows", "Policies with one or more Windows devices with driver update alerts.", `${DS}WindowsDriverUpdateAlertsSummaryReport.ReactView`],
  ["Windows Feature Update Report", "Updates", "Windows", "Generate a report for Windows feature update status.", `${EN}WindowsUpdateOrgReport.ReactView`],
  ["Windows Expedited Update Report", "Updates", "Windows", "Generate a report for Windows quality update status.", `${EN}WindowsQualityUpdateOrgReport.ReactView`],
  ["Windows Update Distribution Report", "Updates", "Windows", "Shows the number of devices in each quality update version and those that need updates.", `${EN}WindowsQualityUpdates.ReactView`],
  ["Windows Feature Update Device Readiness Report", "Updates", "Windows", "Select a target version of Windows and generate a report of device update readiness.", `${EN}UpgradeReadinessDeviceOrgReport.ReactView`],
  ["Windows Feature Update Compatibility Risks Report", "Updates", "Windows", "Select a target version of Windows and generate a report of app and driver compatibility risks.", `${EN}UpgradeReadinessAssetOrgReportBlade`],
  ["Windows Driver Update Report", "Updates", "Windows", "Generate a report for Windows driver update status.", `${EN}WindowsDriverUpdateOrgReport.ReactView`],
  ["Autopatch management status", "Updates", "Windows", "View the management status for your devices in Windows Autopatch.", "#view/Microsoft_EMM_ModernWorkplace/AutopatchDevicesReport.ReactView"],
  ["Autopatch overview", "Updates", "Windows", "Windows Autopatch overview report.", `${RM}windowsAutopatchOverviewReactView`],
  ["Autopatch quality updates", "Updates", "Windows", "Windows Autopatch quality update report.", `${RM}windowsQualityUpdatesReactView`],
  ["Autopatch feature updates", "Updates", "Windows", "Windows Autopatch feature update report.", `${RM}windowsFeatureUpdatesReactView`],

  // Enrollment
  ["Enrollment failures", "Enrollment", "All", "View details about failed user enrollment attempts.", `${EN}EnrollmentFailuresList`],
  ["Enrollment time grouping failures", "Enrollment", "All", "Failures when adding devices to security groups within the Device Group tab in enrollment.", `${EN}EnrollmentTimeGroupingFailuresList.ReactView`],
  ["Windows Autopilot deployment status", "Enrollment", "Windows", "Summary of deployment details for Windows Autopilot enrolled devices for the last 30 days.", `${EN}AutopilotDeploymentsList.ReactView`],
  ["Windows Autopilot device preparation deployment status", "Enrollment", "Windows", "Monitor the status of your Autopilot deployments for devices that have enrolled to Intune.", `${DS}AutopilotReportingV2.ReactView`],

  // Apps
  ["App install status", "Apps", "All", "A list of apps and their installation details, including version, publisher, platform and failures.", "#view/Microsoft_Intune_AppLifecycle/AppsInstallStatus.ReactView"],
  ["App configuration status", "Apps", "All", "Details about the configuration state of each app based on the user.", "#view/Microsoft_Intune/AppConfigurationStatusReports.ReactView"],
  ["App protection status", "Apps", "iOS, Android", "Monitor the compliance status of app protection policies and the issues users might have.", "#view/Microsoft_Intune/AppProtectionStatusReports.ReactView"],
  ["Discovered apps", "Apps", "All", "A list of all managed apps and unmanaged apps discovered on corporate devices.", "#view/Microsoft_Intune_Devices/DiscoveredAppsAggregate.ReactView"],

  // Security
  ["Device encryption status", "Security", "Windows", "Encryption details, including encryption readiness, encryption status and TPM version.", `${DS}EncryptionReport.ReactView`],
  ["Security update status", "Security", "Windows", "Update status across Windows client, Windows Server and Microsoft 365 Apps.", "#view/Microsoft_Intune_ManagedDevices/SecurityUpdateStatus.ReactView"],
  ["Antivirus agent status", "Security", "Windows", "The agent status of your devices: which have real-time or network protection, and their state.", `${EN}AgentStatusReport.ReactView`],
  ["Detected malware", "Security", "Windows", "The malware state of your devices, with the number detected and the details.", `${EN}DefenderReport.ReactView`],
  ["Firewall status", "Security", "Windows", "MDM firewall status for Windows 10 and later.", `${RM}firewall`],

  // Configuration
  ["Configuration policy assignment failures", "Configuration", "All", "Configuration policies with one or more failed device assignments.", `${DS}AssignmentFailuresReportSummary.ReactView`],
  ["Profile configuration status", "Configuration", "All", "The state of your device configuration profiles.", `${EN}DeviceConfigOrgReport.ReactView`],
  ["Certificates", "Configuration", "All", "Review info on certificates, including thumbprints, issuance info and status.", `${DS}AllDeviceCertificatesReportV2.ReactView`],
  ["Devices with restricted apps", "Configuration", "All", "A list of devices on which users have installed one or more restricted apps.", `${DS}RestrictedAppsDevices.ReactView`],
  ["Personal devices on Android Management API", "Configuration", "Android", "Android personally owned work profile devices using Android Management API.", `${DS}AndroidWorkProfileMigrationPolicyReport.ReactView`],

  // Other
  ["Device actions", "Other", "All", "A list of requested device actions and their statuses.", "#view/Microsoft_Intune_Devices/DeviceActionList.ReactView"],
  ["Device attestation status", "Other", "All", "Attestation status of your devices.", `${RM}tpmAttestationStatusReact`],
  ["Co-management eligibility", "Other", "Windows", "Co-management eligibility status for cloud attached devices.", `${EN}ComgmtEligibilityOrgReport.ReactView`],
  ["Co-managed workloads", "Other", "Windows", "Device workloads managed by Intune and Configuration Manager.", `${EN}ComgdWorkloadsOrgReport.ReactView`],
  ["Cloud PC actions", "Other", "Windows", "View actions for Cloud PCs over the last 90 days.", "#view/Microsoft_Azure_CloudPC/CloudPcActionStatusReport.ReactView"],
  ["Cloud PC overview", "Other", "Windows", "Windows 365 Cloud PC overview report.", `${RM}windows365Report`],
  ["Audit logs", "Other", "All", "Who changed what in Intune, and when.", "#view/Microsoft_Intune_DeviceSettings/TenantAdminMenu/~/auditing"],
  ["Endpoint analytics overview", "Other", "Windows", "Endpoint analytics scores, with Anomalies, Model scores and Device scores on its tabs.", `${UX}overview`],
  ["Startup performance", "Other", "Windows", "How long devices take to start up.", `${UX}bootPerformance`],
  ["Application reliability", "Other", "Windows", "How reliably apps run on devices.", `${UX}applicationReliability`],
  ["Resource performance", "Other", "Windows", "CPU and memory performance across devices.", `${UX}resourcePerformance`],
  ["Work from anywhere", "Other", "Windows", "How ready devices are to work from anywhere.", `${UX}workFromAnywhere`],
  ["Battery health", "Other", "Windows", "Battery health across devices.", `${UX}batteryHealth`],
];
