// Column widths: Intune remembers which columns you show but not how wide they are. The Device name,
// Policy name, App name and Group name columns open at a saved percentage of the portal's width
// (Settings sliders, 100 to 300%), and dragging such a column's right edge saves the new percentage.
//
// Works as a minimum width on the header and on every row's cell, so rows stay lined up and the
// portal's own sizing is never overridden (forcing a width broke both in 1.4.0). 100% adds nothing.

(function () {
  if (window.__ieColumnWidths) return;
  window.__ieColumnWidths = true;

  const { feature, prefs, savePref, onPass, grid: G, rules } = globalThis.IEKit;
  const BASE = "data-iebase"; // on a header: its own width in px when first seen
  const WIDE = "data-iewide"; // on a header or cell: the minimum width we set
  const COL = "data-iecol"; // on a header: the pref holding its width
  const DRAG_MIN_PX = 3; // the pointer must move further than this from the press for a drag; less is a click

  // The columns we size: their pref, default percentage, and how to find them in a list.
  const COLUMNS = [
    { key: "widthDeviceName", fallback: 150, find: (c) => c.find(rules.deviceName) },
    // The name column of the Configuration list, recognised by its Policy type (or Profile type) column.
    { key: "widthPolicyName", fallback: 150, find: (c) => rules.listName(c, "policy") },
    // Group columns of assignment tables, or the Name column of a list of groups.
    { key: "widthGroupName", fallback: 150, find: (c) => c.find(rules.groupColumn) || rules.listName(c, "group") },
    // The Name column of an app list, recognised by an app column beside it (Version, Publisher, App type).
    { key: "widthAppName", fallback: 200, find: (c) => rules.listName(c, "app") },
    // The Name column of the Add members and Add owners pickers (Name, Type, Details), where our label and light crowd it.
    { key: "widthMemberName", fallback: 250, find: (c) => rules.listName(c, "member") },
    // The Script package name column of the Remediations list.
    { key: "widthScriptName", fallback: 200, find: (c) => rules.listName(c, "script") },
  ];

  /** The saved percentage for a column, 100 to 300. */
  function percent(col) {
    const v = Number(prefs()[col.key]);
    return v >= 100 && v <= 300 ? v : col.fallback;
  }

  /** The minimum width for a header at `pct`, from its own width when first seen ("" at 100%). */
  function minFor(th, pct) {
    if (!th.hasAttribute(BASE)) {
      const w = th.getBoundingClientRect().width;
      if (!w) return "";
      th.setAttribute(BASE, String(Math.round(w)));
    }
    return pct > 100 ? `${Math.round(Number(th.getAttribute(BASE)) * pct / 100)}px` : "";
  }

  /** Set (or with "" clear) our minimum width on a header or cell. */
  function setMin(el, min) {
    if (el.style.minWidth === min && el.hasAttribute(WIDE) === Boolean(min)) return;
    el.style.minWidth = min;
    el.toggleAttribute(WIDE, Boolean(min));
  }

  function pass(grids = G.scan()) {
    for (const { el: gridEl, cols } of grids) {
      for (const col of COLUMNS) {
        const header = col.find(cols);
        if (!header) continue;
        header.el.setAttribute(COL, col.key);
        // While a column is dragged, every copy of it (an app list's sticky header too) follows the drag.
        const min = drag?.th.getAttribute(COL) === col.key ? drag.th.style.minWidth : minFor(header.el, percent(col));
        setMin(header.el, min);
        // Every row's cell in that column, even rows we add nothing to, so the rows line up.
        for (const row of G.rowsOf(gridEl)) {
          const cell = G.cellFor(G.cellsOf(row), header, cols);
          if (cell) setMin(cell, min);
        }
      }
    }
  }

  // ---------------------------------------------------------------------------------------
  // Dragging a sized column's right edge: the minimum follows the pointer, narrower or wider, and
  // the width is saved as a percentage on release.

  let drag = null; // { th, cells, startX, startWidth }

  /**
   * Everything a drag moves with a header: the same column in every list on the page, found by name as
   * pass() does, with its header and every row's cell. App lists draw their sticky header as a separate
   * copy with no rows, so following only the dragged header's own grid left the rows behind until release.
   */
  function cellsUnder(th) {
    const col = COLUMNS.find((c) => c.key === th.getAttribute(COL));
    const out = [];
    for (const { el, cols } of col ? G.scan() : []) {
      const header = col.find(cols);
      if (!header) continue;
      if (header.el !== th) out.push(header.el); // another copy of the header
      for (const row of G.rowsOf(el)) {
        const cell = G.cellFor(G.cellsOf(row), header, cols);
        if (cell) out.push(cell);
      }
    }
    return out;
  }

  function onPointerDown(e) {
    if (e.button !== 0) return;
    for (const th of document.querySelectorAll(`[${COL}]`)) {
      const r = th.getBoundingClientRect();
      if (Math.abs(e.clientX - r.right) <= 6 && e.clientY >= r.top && e.clientY <= r.bottom) {
        drag = { th, cells: cellsUnder(th), startX: e.clientX, startWidth: r.width, moved: false };
        return;
      }
    }
  }

  function onPointerMove(e) {
    if (!drag) return;
    if (!(e.buttons & 1)) { onPointerUp(); return; }
    if (Math.abs(e.clientX - drag.startX) <= DRAG_MIN_PX && !drag.moved) return; // a click, not a drag (yet)
    drag.moved = true;
    const min = `${Math.max(40, Math.round(drag.startWidth + e.clientX - drag.startX))}px`;
    for (const el of [drag.th, ...drag.cells]) setMin(el, min);
  }

  /** End a drag and save the width as a percentage of the header's own width. Returns it (tests). */
  function onPointerUp() {
    if (!drag) return null;
    const { th, moved } = drag;
    drag = null;
    if (!moved) return null; // a click on the edge (a sort click, say): nothing to save
    const base = Number(th.getAttribute(BASE)) || 0;
    if (!base) return null;
    const pct = Math.min(300, Math.max(100, Math.round(th.getBoundingClientRect().width / base * 10) * 10));
    savePref(th.getAttribute(COL), pct);
    return pct;
  }

  const LISTENERS = [["pointerdown", onPointerDown], ["pointermove", onPointerMove], ["pointerup", onPointerUp]];
  let unwatch = null;

  feature(COLUMNS.map((c) => c.key), {
    start() {
      unwatch = onPass(pass);
      for (const [type, fn] of LISTENERS) document.addEventListener(type, fn, true);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      drag = null;
      for (const [type, fn] of LISTENERS) document.removeEventListener(type, fn, true);
      document.querySelectorAll(`[${WIDE}]`).forEach((el) => setMin(el, ""));
      document.querySelectorAll(`[${COL}]`).forEach((el) => { el.removeAttribute(COL); el.removeAttribute(BASE); });
    },
    onChange(changes) {
      if (changes["ie.prefs"]) pass();
    },
  });

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.columnWidths = { COLUMNS, percent, minFor, setMin, pass, cellsUnder, onPointerDown, onPointerMove, onPointerUp };
})();
