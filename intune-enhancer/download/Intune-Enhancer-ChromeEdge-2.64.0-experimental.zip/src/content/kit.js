// Shared helpers for the in-portal content scripts. Listed before them in manifest.json; content
// scripts in the same frame share one isolated world, so they all see globalThis.IEKit.
//
// Every in-portal feature goes through IEKit.feature(), which only starts it once the user has
// accepted the disclosure AND one of the feature's prefs is on (all prefs default to on), and
// stops it (removing everything it added) the moment that changes.

(function () {
  if (globalThis.IEKit) return;

  const CONSENT_KEY = "ie.consent";
  const CONSENT_VERSION = 1;
  const PREFS_KEY = "ie.prefs";
  const consented = (v) => (v?.version || 0) >= CONSENT_VERSION;

  let state = null; // { agreed, prefs }
  const listeners = new Set();

  const ready = chrome.storage.local.get([CONSENT_KEY, PREFS_KEY]).then((v) => {
    state = { agreed: consented(v[CONSENT_KEY]), prefs: v[PREFS_KEY] || {} };
  }).catch(() => { state = { agreed: false, prefs: {} }; });

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local" || !state) return;
      if (changes[CONSENT_KEY]) state.agreed = consented(changes[CONSENT_KEY].newValue);
      if (changes[PREFS_KEY]) state.prefs = changes[PREFS_KEY].newValue || {};
      for (const fn of listeners) fn(changes);
    });
  } catch { /* extension context gone */ }

  /**
   * Run a feature while consent is given and any of its pref keys is on.
   * onChange(changes) is called for every later storage change while it runs (a pref edited, the
   * device index rebuilt), so it can redraw.
   * @param {string|string[]} keys
   * @param {{ start: () => void, stop: () => void, onChange?: (changes: object) => void }} spec
   */
  function feature(keys, { start, stop, onChange }) {
    const list = [].concat(keys);
    let running = false;
    const sync = (changes) => {
      const on = state.agreed && list.some(isOn);
      if (on && !running) { running = true; start(); }
      else if (!on && running) { running = false; stop(); }
      else if (on && changes) onChange?.(changes);
    };
    ready.then(() => { sync(); listeners.add(sync); });
  }

  /** Call fn(agreed) with the consent state now, and again whenever it changes. */
  function watchConsent(fn) {
    ready.then(() => {
      let last = state.agreed;
      fn(last);
      listeners.add(() => { if (state.agreed !== last) fn((last = state.agreed)); });
    });
  }

  /** Run fn once, as soon as the disclosure has been accepted (straight away if it already has). */
  function whenConsented(fn) {
    let done = false;
    watchConsent((agreed) => { if (agreed && !done) { done = true; fn(); } });
  }

  /** Current prefs (empty until storage has loaded). */
  const prefs = () => state?.prefs || {};
  /** Switches that are off until the admin turns them on (the same keys are false in workspace.js DEFAULT_PREFS). */
  const DEFAULT_OFF = new Set(["remediationDates"]);
  /** Is a setting on? Every one is on unless saved as false (a switch) or "off" (a dropdown), or never saved and in DEFAULT_OFF. */
  const isOn = (key) => (prefs()[key] === undefined ? !DEFAULT_OFF.has(key) : prefs()[key] !== false && prefs()[key] !== "off");
  /** A dropdown's value: "off", the saved value if it's one of `values`, else values[0] (its default). */
  const choice = (key, values) => (!isOn(key) ? "off" : values.includes(prefs()[key]) ? prefs()[key] : values[0]);

  /** Save one setting (e.g. a column width the admin dragged), through the worker, the one writer of ie.prefs. */
  function savePref(key, value) {
    send({ type: "prefs/set", patch: { [key]: value } }).catch(() => {});
  }

  // Shared by the content scripts.
  const BRAND = "Intune Enhancer";
  const ADDED = `\nAdded by ${BRAND}`; // ends every tooltip we add
  const GUID = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";
  const GUID_EXACT = new RegExp(`^${GUID}$`, "i"); // no "g" flag, so .test() keeps no state between calls
  const OPEN_ICON = '<svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2.5h4.5V7"/><path d="M13.5 2.5 7.5 8.5"/><path d="M12 9.5v3a1 1 0 0 1-1 1H3.5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h3"/></svg>';

  /**
   * Every colour our in-portal additions use: the one place to change one. Light is the base; dark lists only what
   * differs on the portal's dark theme (data-ie-dark on <html>, or data-dark on a card's host). Each key becomes a
   * custom property --ie-<key>; the content scripts' CSS uses only var(--ie-...). tests/build-test.py refuses a colour
   * written anywhere else in src/content.
   */
  const PALETTE = {
    light: {
      accent: "#008aff", "accent-glow": "rgba(0, 138, 255, 0.45)", // our border and glow: pills, busy chip, cards
      fg: "#1b1b1b", // pill and busy chip text
      link: "#1f5fbf", "link-hover": "rgba(31, 95, 191, 0.14)", // icon buttons, filter icons, primary user labels
      "pill-hover": "rgba(128, 128, 128, 0.18)", "pill-warn-bg": "#ffe1e3", "pill-warn-hover": "#ffc9cd",
      "busy-bg": "rgba(255, 255, 255, 0.92)",
      // Activity lights (and the red and orange warning text that shares them).
      "light-green": "#1a7f37", "light-yellow": "#d4a72c", "light-orange": "#e8890c", "light-red": "#cf222e",
      "halo-green": "rgba(26, 127, 55, 0.18)", "halo-yellow": "rgba(212, 167, 44, 0.2)", "halo-orange": "rgba(232, 137, 12, 0.2)", "halo-red": "rgba(207, 34, 46, 0.18)",
      "warn-text": "#c76a00", // low storage, remediation date notes
      // Primary user labels and their compliance shield.
      "label-bg": "rgba(31, 95, 191, 0.12)", "label-hover-bg": "rgba(31, 95, 191, 0.22)",
      "label-multi": "#8a5300", "label-multi-bg": "rgba(196, 120, 0, 0.14)", "label-muted": "#6b6b6b", "label-muted-bg": "rgba(128, 128, 128, 0.12)",
      "label-last": "#b06d00",
      "shield-unknown": "#8c959f", "shield-ok": "#1a7f37", "shield-bad": "#cf222e", "shield-warn": "#d4a72c",
      "app-ok": "#0b7a3b", "app-bad": "#c4141f", "app-dim": "0.6", // app install counts
      "usage-fg": "#605e5c", // settings picker usage
      "select-line": "rgba(128, 128, 128, 0.5)",
      // The Related and quick facts cards.
      "card-bg": "#fff", "card-fg": "#1f2328", "card-soft": "#e5e8ec", "card-muted": "#57606a", "card-accent": "#0070d1",
      "card-btn": "#0070d1", "card-btn-fg": "#fff", "card-shadow": "rgba(0, 0, 0, 0.16)", "card-pill": "#eef1f4",
      "ok-bg": "#dafbe1", "ok-fg": "#116329", "bad-bg": "#ffebe9", "bad-fg": "#a40e26", "warn-bg": "#fff8c5", "warn-fg": "#7d4e00",
      // The "turned off" note: always the workspace's dark look.
      "note-bg": "#081420", "note-fg": "#d8ecff", "note-btn-fg": "#00101f", "note-x": "#6fa8c0", "note-shadow": "rgba(0, 0, 0, 0.25)",
    },
    dark: {
      fg: "#fff", link: "#8ab4ff",
      "pill-hover": "rgba(255, 255, 255, 0.12)", "pill-warn-bg": "#4a0d14", "pill-warn-hover": "#65121c",
      "busy-bg": "rgba(32, 32, 32, 0.92)",
      "light-green": "#3fb950", "light-yellow": "#e3b341", "light-orange": "#f0a030", "light-red": "#f85149",
      "warn-text": "#f0a030",
      "label-bg": "rgba(138, 180, 255, 0.16)", "label-multi": "#ffc46b", "label-multi-bg": "rgba(255, 196, 107, 0.14)",
      "label-muted": "#a8a8a8", "label-last": "#ffc46b",
      "app-ok": "#3ddc84", "app-bad": "#ff6b6b", "app-dim": "1",
      "usage-fg": "#a8a8a8",
      "card-bg": "#252423", "card-fg": "#f3f2f1", "card-soft": "#323130", "card-muted": "#a19f9d", "card-accent": "#3da3ff",
      "card-btn": "#008aff", "card-shadow": "rgba(0, 0, 0, 0.55)", "card-pill": "#323130",
      "ok-bg": "#12361f", "ok-fg": "#6fdd8b", "bad-bg": "#3d1418", "bad-fg": "#ff9492", "warn-bg": "#3b2e05", "warn-fg": "#e3b341",
    },
  };
  const themeVars = (vars) => Object.entries(vars).map(([k, v]) => `--ie-${k}: ${v};`).join(" ");
  /** The palette as custom properties for a page (pageTheme) or inside a shadow root (hostTheme). */
  const pageTheme = `:root { ${themeVars(PALETTE.light)} } :root[data-ie-dark] { ${themeVars(PALETTE.dark)} }`;
  const hostTheme = `:host { ${themeVars(PALETTE.light)} } :host([data-dark]) { ${themeVars(PALETTE.dark)} }`;

  /** Rules for one of our small icon buttons (class cls), readable on the portal's light and dark themes (data-ie-dark). */
  const iconButtonCss = (cls) => `
    .${cls} { display: inline-flex; align-items: center; margin-left: 6px; padding: 1px 3px; border-radius: 4px; vertical-align: middle; cursor: pointer; color: var(--ie-link); }
    .${cls}:hover, .${cls}:focus-visible { background: var(--ie-link-hover); outline: none; }`;

  /**
   * Rules for one of our pills (class cls): a thin neon sky blue border marks it as ours, and it is
   * transparent so it takes the row's own hover and selection tint, with dark text on the portal's
   * light theme and white on its dark theme (data-ie-dark). `warn` is the selector suffix of its
   * pale red state (failed, empty); `action` the suffix of its clickable state. The caller adds any
   * rules of its own (`display`, inner colours, the default cursor).
   */
  const pillCss = (cls, { warn, action }) => `
    .${cls} { margin-left: 8px; padding: 0 7px; border: 1px solid var(--ie-accent); border-radius: 9px; box-shadow: 0 0 4px var(--ie-accent-glow); font-size: 0.9em; color: var(--ie-fg); background: transparent; white-space: nowrap; }
    .${cls}${warn} { background: var(--ie-pill-warn-bg); font-weight: 600; }
    .${cls}${action} { cursor: pointer; }
    .${cls}${action}:hover, .${cls}${action}:focus-visible { background: var(--ie-pill-hover); outline: none; }
    .${cls}${warn}${action}:hover, .${cls}${warn}${action}:focus-visible { background: var(--ie-pill-warn-hover); }`;

  /**
   * Add a stylesheet. Portal frames run a strict CSP that refuses <style>, so use a constructed sheet. The page's first
   * sheet carries the palette (pageTheme); a shadow root's CSS brings its own (hostTheme).
   */
  let pageThemed = false;
  function adoptStyles(css, root = document) {
    try {
      const sheet = new CSSStyleSheet();
      sheet.replaceSync(root === document && !pageThemed ? pageTheme + css : css);
      root.adoptedStyleSheets = [...root.adoptedStyleSheets, sheet];
      if (root === document) pageThemed = true;
      return true;
    } catch {
      return false;
    }
  }

  /** A function that adds `css` to the page the first time it is called and does nothing after that. */
  const styleOnce = (css) => {
    let done = false;
    return () => { if (!done) done = adoptStyles(css); };
  };

  // Anything we add to the page: an "ie-" class or a data-ie attribute.
  const OURS = "[class^='ie-'], [class*=' ie-'], [data-ie]";
  // Persona coins and avatars show initials ("GP") before a name, and can load after it.
  const AVATAR = "[class*='initials' i], [class*='coin' i], [class*='avatar' i]";
  const isInitials = (el) => Boolean(el?.closest(AVATAR)) && el.textContent.trim().length <= 3;

  /**
   * MutationObserver over the whole document that ignores changes made by our own elements, so
   * drawing never triggers another pass. Calls back once straight away, then once the page has been
   * still for `delay` ms (at most `maxWait` after the first change, so a long scroll still gets
   * drawn), when the browser is idle. Scrolling a long list changes the page constantly; running
   * every few hundred ms through it made scrolling sluggish.
   */
  function watch(callback, delay = 250, maxWait = 1000) {
    let timer = null;
    let idle = null;
    let first = 0; // when the oldest change not yet handled happened
    const run = () => {
      timer = null;
      first = 0;
      if (idle) cancelIdleCallback(idle); // one pass per quiet spell, not one per change that arrived meanwhile
      idle = requestIdleCallback(() => { idle = null; callback(); }, { timeout: 500 });
    };
    const isOurs = (n) => n?.nodeType === 1 && n.matches(OURS);
    const inOurs = (n) => Boolean((n?.nodeType === 1 ? n : n?.parentElement)?.closest(OURS));
    const stop = () => { observer.disconnect(); clearTimeout(timer); if (idle) cancelIdleCallback(idle); };
    const observer = new MutationObserver((records) => {
      // The extension was updated or reloaded: this copy of the script is orphaned (the new one runs after a page
      // reload), so it stops watching instead of scanning and asking a worker that is no longer there.
      if (!globalThis.chrome?.runtime?.id) { stop(); return; }
      for (const rec of records) {
        if (inOurs(rec.target)) continue;
        const nodes = [...rec.addedNodes, ...rec.removedNodes];
        if (rec.type === "childList" && nodes.length && nodes.every(isOurs)) continue;
        first ||= Date.now();
        clearTimeout(timer);
        timer = setTimeout(run, Math.max(0, Math.min(delay, first + maxWait - Date.now())));
        return;
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    callback();
    return stop;
  }

  /**
   * Make one of our elements a button, keeping its clicks away from the portal's own row
   * navigation. handler(event) runs on click, Enter or Space.
   */
  function clickable(el, label, handler) {
    el.setAttribute("role", "button");
    el.setAttribute("aria-label", label);
    el.tabIndex = 0;
    for (const type of ["pointerdown", "mousedown", "pointerup", "mouseup"]) el.addEventListener(type, (e) => e.stopPropagation());
    el.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); handler(e); });
    el.addEventListener("keydown", (e) => {
      if (e.key !== "Enter" && e.key !== " ") return;
      e.preventDefault(); e.stopPropagation(); handler(e);
    });
    return el;
  }

  // A small "fetching" chip at the bottom of the page while a request to the service worker is still pending.
  // It waits showAfterMs so fast answers never show it, and lingers hideAfterMs so back-to-back requests
  // don't flicker it.
  const BUSY = { showAfterMs: 1000, hideAfterMs: 400, text: `${BRAND}: fetching stats...` };
  const busyCss = `
    .ie-busy { position: fixed; right: 14px; bottom: 14px; z-index: 2147483000; pointer-events: none;
      padding: 4px 10px; border: 2px solid var(--ie-accent); border-radius: 9px; box-shadow: 0 0 4px var(--ie-accent-glow);
      font: 13px "Segoe UI", system-ui, sans-serif; color: var(--ie-fg); background: var(--ie-busy-bg); opacity: 0.95; }`;
  const busyStyle = styleOnce(busyCss);
  let pending = 0;
  let showTimer = null;
  let hideTimer = null;
  let chip = null;

  function busyBegin() {
    pending++;
    clearTimeout(hideTimer);
    hideTimer = null;
    if (!chip && !showTimer) {
      showTimer = setTimeout(() => {
        showTimer = null;
        if (!pending || !document.body) return;
        busyStyle();
        chip = document.createElement("div");
        chip.className = "ie-busy";
        chip.setAttribute("role", "status");
        chip.textContent = BUSY.text;
        document.body.appendChild(chip);
      }, BUSY.showAfterMs);
    }
  }

  function busyEnd() {
    pending = Math.max(0, pending - 1);
    if (pending) return;
    clearTimeout(showTimer);
    showTimer = null;
    if (chip && !hideTimer) hideTimer = setTimeout(() => { hideTimer = null; chip?.remove(); chip = null; }, BUSY.hideAfterMs);
  }

  /** Message the service worker; resolves with the response, rejects on failure. */
  function send(message) {
    busyBegin();
    const reply = new Promise((resolve, reject) => {
      try {
        chrome.runtime.sendMessage(message, (res) => {
          const err = chrome.runtime.lastError;
          if (err) reject(new Error(err.message));
          else resolve(res);
        });
      } catch (e) {
        reject(e);
      }
    });
    reply.then(busyEnd, busyEnd);
    return reply;
  }

  /** One pending retry of fn after ms (a number, or a function giving it); scheduling again while one is pending does nothing. */
  function retrier(ms, fn) {
    let timer = null;
    return {
      schedule() { if (!timer) timer = setTimeout(() => { timer = null; fn(); }, typeof ms === "function" ? ms() : ms); },
      cancel() { clearTimeout(timer); timer = null; },
    };
  }

  /**
   * Batched lookups through the service worker. request(items) sends [{ key, ... }] as message
   * `type`, keeps the answers (res[field], by item key) in results, then calls redraw(). A key in
   * flight isn't asked for twice; after a failed request (no session yet, Graph refused, or no answer
   * from the worker at all) redraw() runs again after retryMs, which asks again. With maxRetryMs, each failure
   * in a row doubles the wait, up to maxRetryMs (a feature that may wait a long time for an answer). Until that
   * retry runs nothing is asked for, so a page change (scrolling) can't skip the wait. With ttlMs, an answer older
   * than that is asked for again (the old one keeps showing until the new one arrives).
   */
  function lookups({ type, field, retryMs, maxRetryMs = retryMs, ttlMs = 0, redraw }) {
    const results = new Map();
    const answeredAt = new Map();
    const inFlight = new Set();
    let failures = 0;
    let pausedUntil = 0;
    const wait = () => Math.min(maxRetryMs, retryMs * 2 ** Math.max(0, failures - 1));
    const retry = retrier(wait, () => { pausedUntil = 0; redraw(); });
    const later = () => { pausedUntil = Date.now() + wait(); retry.schedule(); };
    const failed = () => { failures++; later(); };
    const fresh = (key) => results.has(key) && (!ttlMs || Date.now() - answeredAt.get(key) < ttlMs);
    return {
      results,
      wanted: (key) => Date.now() >= pausedUntil && !fresh(key) && !inFlight.has(key),
      request(items) {
        items.forEach((i) => inFlight.add(i.key));
        const done = () => items.forEach((i) => inFlight.delete(i.key));
        send({ type, items }).then((res) => {
          done();
          if (!res?.ok) { failed(); return; }
          failures = 0;
          let again = false;
          for (const [key, value] of Object.entries(res[field] || {})) {
            if (value?.retry) again = true; // Graph was busy: ask again shortly instead of remembering a non-answer
            else { results.set(key, value); answeredAt.set(key, Date.now()); }
          }
          if (again) later();
          redraw();
        }, () => {
          done();
          // No answer (the worker restarted): ask again, unless this script outlived a reload of the extension.
          if (globalThis.chrome?.runtime?.id) failed();
        });
      },
      cancel: retry.cancel,
    };
  }

  // ---------------------------------------------------------------------------------------
  // Reading the portal's lists. Works from column headers, so one set of rules covers Fluent
  // DetailsList, Fluent DataGrid and plain tables. Proven against the live portal by the primary
  // user labels (group members, device lists, Discovered apps).

  const textOf = (el) => String(el?.innerText ?? el?.textContent ?? "").replace(/\s+/g, " ").trim();

  /** Text of a cell without anything we added to it. */
  function cellText(cell) {
    if (!cell) return "";
    // Our text-less additions (icons) don't change the text, so only a cell where ours carry text needs the copy.
    if (![...cell.querySelectorAll(OURS)].some((n) => n.textContent.trim())) return textOf(cell);
    const clone = cell.cloneNode(true);
    clone.querySelectorAll(OURS).forEach((n) => n.remove());
    return textOf(clone);
  }

  /**
   * A cell's name: its first text, minus icon-font glyphs, avatar initials and our own additions. Read from
   * the text nodes, not innerText: Firefox's innerText of a detached copy has no line breaks, so a name cell
   * that also holds the portal's Copilot button ran everything together ("V-DEV100V-DEV100Summarize...").
   */
  function nameText(cell) {
    const first = firstText(cell);
    if (!first) return "";
    let raw = "";
    // React often splits one name over several text nodes under the same element.
    for (let n = first; n && n.nodeType === 3; n = n.nextSibling) raw += n.nodeValue;
    return raw.replace(/[\u{E000}-\u{F8FF}]/gu, "").replace(/\s+/g, " ").trim();
  }

  /** A cell's first non-blank text node that isn't ours or avatar initials (the name, in a name cell), or null. */
  function firstText(cell) {
    const walker = document.createTreeWalker(cell, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (n.nodeValue.replace(/[\s\u{E000}-\u{F8FF}]/gu, "") && !n.parentElement.closest(OURS) && !isInitials(n.parentElement)
        ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
    });
    return walker.nextNode();
  }

  const headerCellsOf = (grid) => [...grid.querySelectorAll('[role="columnheader"], thead th')];
  const rowsOf = (grid) => [...grid.querySelectorAll('[role="row"], tbody tr')]
    .filter((row) => !row.querySelector('[role="columnheader"], th'));
  const cellsOf = (row) => [...row.querySelectorAll(':scope [role="gridcell"], :scope [role="rowheader"], :scope > td')]
    // Nested grids would otherwise contribute their cells to the outer row.
    .filter((cell) => cell.closest('[role="row"], tr') === row);

  function colIndexOf(el, fallback) {
    const v = Number(el.getAttribute("aria-colindex"));
    return Number.isFinite(v) && v > 0 ? v : fallback;
  }

  // Header text can include sort arrows, "Press to sort" hints or icon-font glyphs.
  function headerLabel(th) {
    const named = th.getAttribute("aria-label") || th.getAttribute("title") || "";
    const raw = textOf(th) || named;
    return raw.replace(/[\u{E000}-\u{F8FF}]/gu, "").replace(/\b(sorted (ascending|descending)|press to sort.*)$/i, "").trim().toLowerCase();
  }

  /** A grid's columns: { cols, find(re), usesAria, headerCount }, or null if it has no headers. */
  function columns(grid) {
    const headers = headerCellsOf(grid);
    if (!headers.length) return null;
    const cols = headers.map((th, i) => ({ label: headerLabel(th), index: colIndexOf(th, i + 1), key: th.getAttribute("data-item-key") || "", el: th }));
    return {
      cols,
      find: (re) => cols.find((c) => re.test(c.label)) || null,
      usesAria: headers.some((th) => th.hasAttribute("aria-colindex")),
      headerCount: headers.length,
    };
  }

  /** The cell in `cells` (one row's cells) for column `col` of a grid laid out as `layout`. */
  function cellFor(cells, col, layout) {
    if (!col) return null;
    if (layout.usesAria) {
      const hit = cells.find((c) => colIndexOf(c, 0) === col.index);
      if (hit) return hit;
    }
    if (col.key) {
      const hit = cells.find((c) => c.getAttribute("data-automation-key") === col.key);
      if (hit) return hit;
    }
    // Positional fallback. A row with more cells than there are headers usually has a
    // selection checkbox cell in front that has no header of its own.
    const offset = Math.max(0, cells.length - layout.headerCount);
    return cells[col.index - 1 + offset] || null;
  }

  /** Attribute text of a row and its links: where portal deep links carry object ids. Bounded. */
  function attrText(row) {
    const parts = [];
    for (const el of [row, ...row.querySelectorAll("a, [href], [data-href], [data-url]")].slice(0, 60)) {
      for (const attr of el.attributes || []) {
        if (attr.name === "class" || attr.name === "style") continue;
        if (attr.value && attr.value.length < 2000) parts.push(attr.value);
      }
    }
    return parts.join(" ");
  }

  function findGrids(root) {
    const grids = new Set();
    for (const el of root.querySelectorAll('[role="grid"], [role="treegrid"], table')) grids.add(el);
    // Some Fluent lists put role="grid" on an inner element; rows outside a grid fall back to
    // the nearest ancestor that also holds the headers.
    for (const row of root.querySelectorAll('[role="row"]')) {
      if (row.closest('[role="grid"], [role="treegrid"], table')) continue;
      let el = row.parentElement;
      while (el && el !== document.body && !el.querySelector('[role="columnheader"]')) el = el.parentElement;
      if (el && el !== document.body) grids.add(el);
    }
    return [...grids];
  }

  /** Every list on the page that has column headers: [{ el, cols }], cols as columns() returns. */
  const scan = () => findGrids(document).map((el) => ({ el, cols: columns(el) })).filter((g) => g.cols);

  const grid = { cellText, nameText, firstText, rowsOf, cellsOf, columns, cellFor, attrText, findGrids, scan };

  /**
   * Text nodes on the page whose text contains `needle` (lower-case letters match either case). The browser
   * does the search (XPath), which is far cheaper than visiting every text node in script on each pass.
   */
  function textNodesContaining(needle, root = document.body || document.documentElement) {
    const lower = needle.toLowerCase();
    const upper = needle.toUpperCase();
    const literal = (s) => (s.includes("'") ? `"${s}"` : `'${s}'`);
    const test = lower === upper ? `contains(., ${literal(needle)})` : `contains(translate(., ${literal(upper)}, ${literal(lower)}), ${literal(lower)})`;
    try {
      const hits = document.evaluate(`.//text()[${test}]`, root, null, XPathResult.ORDERED_NODE_SNAPSHOT_TYPE, null);
      return Array.from({ length: hits.snapshotLength }, (_, i) => hits.snapshotItem(i));
    } catch {
      return [];
    }
  }

  // Which lists and columns we recognise by their headers, in one place so every script agrees.
  const LIST_NAMES = {
    // A Name column is an app, policy or group list's when its marker column sits beside it.
    app: { marker: /^(version|publisher|app type)$/, name: /^(name|app name|display name)$/ },
    policy: { marker: /^(policy type|profile type)$/, name: /^(name|policy name|profile name)$/ },
    group: { marker: /^(group type|membership type)$/, name: /^(name|display name)$/ },
    script: { marker: /^script package name$/, name: /^script package name$/ }, // the Remediations list
    member: { marker: /^details$/, name: /^name$/ }, // the Add members / Add owners picker (Name, Type, Details)
  };
  const rules = {
    /** A device list's name column. */
    deviceName: /^(device|device name|devicename|managed device|managed device name|computer name|hostname)$/,
    /** The group column of an assignment table. */
    groupColumn: /^(group|groups|group name|included groups?|excluded groups?|assigned groups?|target groups?|assignment groups?)$/,
    /** The Name column of an app, policy or group list (kind "app", "policy", "group" or "script") in columns(grid), or null. */
    listName: (cols, kind) => (cols.find(LIST_NAMES[kind].marker) ? cols.find(LIST_NAMES[kind].name) : null),
  };

  /**
   * Mark the portal's dark theme on <html> as data-ie-dark, for our stylesheets. Judged by the page's
   * text colour: the portal has its own light/dark setting, which needn't match the computer's.
   */
  function markTheme() {
    // A list cell's text colour is the real text; some frames leave the body's at a default that misleads.
    const probe = document.querySelector('[role="gridcell"], td') || document.body || document.documentElement;
    const m = getComputedStyle(probe).color.match(/[\d.]+/g);
    const dark = Boolean(m) && 0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2] > 140;
    if (document.documentElement.hasAttribute("data-ie-dark") !== dark) document.documentElement.toggleAttribute("data-ie-dark", dark);
  }

  // One observer and one grid scan per frame, shared by every feature, instead of one of each per feature.
  const passes = new Set();
  let unwatchAll = null;

  /** Call fn(grids) now and after every page change (debounced), until the returned stop function runs. */
  function onPass(fn) {
    passes.add(fn);
    markTheme();
    if (unwatchAll) fn(scan());
    else {
      unwatchAll = watch(() => {
        markTheme(); // a theme switch redraws the page, so this pass sees it
        const grids = scan();
        for (const f of passes) {
          try { f(grids); } catch { /* one feature failing mustn't stop the others */ }
        }
      });
    }
    return () => {
      passes.delete(fn);
      if (!passes.size) {
        unwatchAll();
        unwatchAll = null;
        document.documentElement.removeAttribute("data-ie-dark"); // the last feature stopped: leave nothing behind
      }
    };
  }

  /**
   * An outlined pill for a command we add to a portal toolbar, so it reads as ours: the same accent border and
   * glow as the pills we add to lists. `button` selects the button itself. Every value is a custom property.
   */
  const commandPillCss = (button) => `
    ${button} { --pill-border-width: 2px; --pill-border: var(--ie-accent); --pill-radius: 9px; --pill-glow: 0 0 4px var(--ie-accent-glow); --pill-pad: 0 10px; --pill-margin: 0 6px; --pill-height: 26px;
      border: var(--pill-border-width) solid var(--pill-border) !important; border-radius: var(--pill-radius) !important; box-shadow: var(--pill-glow);
      padding: var(--pill-pad) !important; margin: var(--pill-margin); height: var(--pill-height) !important; min-height: 0 !important; align-self: center; }`;

  /** Text made safe to put inside innerHTML. */
  const ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
  const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESCAPES[c]);

  /**
   * The one small card our features open beside something on the page (Device quick facts, the Related card). It lives
   * in a closed shadow root, so the portal's CSS can't reach it. `html` holds one `.card` element, styled by `css`; the
   * host carries `data-dark` on the portal's dark theme and any `attrs`. The card sits below the anchor, or above it
   * when there is no room below, inside the window. It closes on its `.x` button, Escape, or a press outside it that
   * `keepOpen(target)` doesn't claim; `onClick(event, root)` gets every other click in it. Opening one closes any other.
   * Returns { root, close }; `onClose` runs however it closes.
   */
  /**
   * The one look for every popupCard (Device quick facts, the Related card): the portal's greys with our accent
   * (PALETTE card-* keys), and the same 2px border, glow and radius as our command pills. Card markup: .card > header (title, .x),
   * section (h4 headings, dl rows or ul lists, .sub and .muted text, .pill, .light, button.link, button.btn and
   * button.btn.primary), footer. The host's data-dark (set by popupCard) switches to the dark values.
   */
  const cardCss = `${hostTheme}
    :host { all: initial; --card-width: 340px; --card-border: var(--ie-accent); --card-glow: 0 0 4px var(--ie-accent-glow);
      --card-bg: var(--ie-card-bg); --card-fg: var(--ie-card-fg); --card-soft: var(--ie-card-soft); --card-muted: var(--ie-card-muted);
      --card-accent: var(--ie-card-accent); --card-btn: var(--ie-card-btn); --card-btn-fg: var(--ie-card-btn-fg);
      --card-drop: 0 8px 24px var(--ie-card-shadow); --pill-bg: var(--ie-card-pill); }
    .card { position: fixed; width: var(--card-width); max-height: 70vh; overflow: auto; box-sizing: border-box;
      background: var(--card-bg); color: var(--card-fg); border: 2px solid var(--card-border); border-radius: 9px;
      box-shadow: var(--card-glow), var(--card-drop); font: 12.5px/1.4 "Segoe UI", system-ui, sans-serif; }
    header { display: flex; justify-content: space-between; align-items: center; padding: 8px 12px; font-weight: 600; border-bottom: 1px solid var(--card-soft); }
    section { padding: 6px 12px 8px; border-bottom: 1px solid var(--card-soft); }
    h4 { margin: 6px 0 3px; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em; color: var(--card-accent); overflow-wrap: anywhere; }
    p { margin: 2px 0; }
    dl { display: grid; grid-template-columns: auto 1fr; gap: 2px 10px; margin: 0 0 8px; }
    dt { color: var(--card-muted); } dd { margin: 0; overflow-wrap: anywhere; }
    ul { margin: 0; padding: 0; list-style: none; } li { padding: 2px 0; }
    .sub { display: block; color: var(--card-muted); font-size: 11.5px; }
    .muted { color: var(--card-muted); font-style: italic; }
    .pill { padding: 0 6px; border-radius: 8px; background: var(--pill-bg); }
    .c-compliant { background: var(--ie-ok-bg); color: var(--ie-ok-fg); } .c-noncompliant { background: var(--ie-bad-bg); color: var(--ie-bad-fg); }
    .c-inGracePeriod { background: var(--ie-warn-bg); color: var(--ie-warn-fg); }
    .light { display: inline-block; width: 8px; height: 8px; border-radius: 50%; margin-right: 6px; }
    .green { background: var(--ie-light-green); } .yellow { background: var(--ie-light-yellow); } .orange { background: var(--ie-light-orange); } .red { background: var(--ie-light-red); }
    button { font: inherit; cursor: pointer; }
    button.x { all: unset; cursor: pointer; font-size: 18px; line-height: 1; padding: 0 4px; color: var(--card-muted); }
    button.link { color: var(--card-accent); background: transparent; border: 0; padding: 0; text-align: left; }
    button.btn { padding: 3px 10px; margin: 0 6px 0 0; border-radius: 6px; border: 1px solid var(--card-btn); background: transparent; color: var(--card-btn); }
    button.btn.primary { background: var(--card-btn); color: var(--card-btn-fg); }
    footer { padding: 6px 12px; color: var(--card-muted); font-size: 11px; }`;

  const CARD_GAP = 6; // px between the anchor and the card
  const CARD_EDGE = 8; // px the card keeps from the window's edges
  let shownCard = null;
  function popupCard({ anchor, css, html, attrs = {}, onClick = () => {}, keepOpen = () => false, onClose = () => {} }) {
    shownCard?.close();
    const host = document.createElement("div");
    for (const [name, value] of Object.entries(attrs)) host.setAttribute(name, value);
    host.toggleAttribute("data-dark", document.documentElement.hasAttribute("data-ie-dark"));
    Object.assign(host.style, { position: "fixed", top: "0", left: "0", width: "0", height: "0", zIndex: "2147483646" });
    const root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `${adoptStyles(css, root) ? "" : `<style>${css}</style>`}${html}`;
    document.documentElement.appendChild(host);

    const box = root.querySelector(".card");
    const r = anchor.getBoundingClientRect();
    const b = box.getBoundingClientRect();
    const vw = document.documentElement.clientWidth;
    const vh = document.documentElement.clientHeight;
    const below = r.bottom + CARD_GAP;
    box.style.top = `${below + b.height > vh - CARD_EDGE ? Math.max(CARD_EDGE, r.top - b.height - CARD_GAP) : below}px`;
    box.style.left = `${Math.max(CARD_EDGE, Math.min(r.left, vw - b.width - CARD_EDGE))}px`;

    const onKey = (e) => { if (e.key === "Escape") card.close(); };
    const onOutside = (e) => { if (!e.composedPath().includes(host) && !keepOpen(e.target)) card.close(); };
    const card = {
      root,
      close() {
        if (shownCard !== card) return;
        shownCard = null;
        window.removeEventListener("keydown", onKey, true);
        window.removeEventListener("pointerdown", onOutside, true);
        host.remove();
        onClose();
      },
    };
    root.addEventListener("click", (e) => {
      if (e.target.closest(".x")) { card.close(); return; }
      onClick(e, root);
    });
    window.addEventListener("keydown", onKey, true);
    window.addEventListener("pointerdown", onOutside, true);
    shownCard = card;
    return card;
  }

  globalThis.IEKit = {
    feature, watchConsent, whenConsented, prefs, isOn, choice, savePref, adoptStyles, styleOnce, pillCss, commandPillCss, hostTheme, onPass, send, clickable, retrier, lookups, grid, rules, escapeHtml, popupCard, cardCss, textNodesContaining,
    BRAND, ADDED, GUID, GUID_EXACT, OURS, OPEN_ICON, iconButtonCss,
    busy: { begin: busyBegin, end: busyEnd, pending: () => pending, config: BUSY },
  };
})();
