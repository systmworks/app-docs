// Friendly OS versions: shows Windows build numbers such as "10.0.26100.4349" as
// "Win11 24H2 (26100.4349)" in the portal.
//
// Display only. The text is changed in place, in the portal's own text node: React keeps a reference
// to that node and updates it directly, so swapping it for an element of ours (as before 1.22.0)
// could leave React updating a node no longer on the page. The build numbers go in the element's
// tooltip, and turning the feature off puts every original back. Unknown builds are left alone.
// Runs in every portal frame because device lists render inside reactblade iframes.

(function () {
  if (window.__ieOsVersions) return;
  window.__ieOsVersions = true;

  const { feature, choice, onPass, BRAND, OURS } = globalThis.IEKit;
  const { PATTERN, friendly } = globalThis.IEWindowsBuilds;
  const BUILD_RE = new RegExp(PATTERN, "g"); // replace() restarts a global regex each time, so one is enough
  const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "INPUT", "SELECT", "OPTION", "NOSCRIPT"]);

  let unwatch = null;
  // Text nodes we changed: node -> { original, shown, titled } (titled: we set the parent's tooltip).
  const changed = new Map();
  const OWN_TITLE = "data-ie-titled"; // on an element whose tooltip we set

  function skip(node) {
    const parent = node.parentElement;
    return !parent || SKIP.has(parent.tagName) || parent.isContentEditable || parent.closest(OURS);
  }

  function rewrite(node) {
    const text = node.nodeValue;
    if (!text || text.length > 300 || !text.includes("10.0.")) return;
    const nameOnly = choice("friendlyOsVersions", ["full", "name"]) === "name";
    const builds = [];
    const shown = text.replace(BUILD_RE, (m) => {
      const label = friendly(m);
      if (!label) return m;
      builds.push(m);
      return nameOnly ? label.replace(/\s*\(.*\)$/, "") : label; // "Win11 24H2"
    });
    if (shown === text) return;
    const parent = node.parentElement;
    // A tooltip we set earlier is ours to refresh (a recycled row now shows another device's build);
    // one the portal set is left alone.
    const titled = parent.hasAttribute(OWN_TITLE) || !parent.hasAttribute("title");
    if (titled) {
      parent.title = `${builds.join(", ")}\nRelease name added by ${BRAND}`;
      parent.setAttribute(OWN_TITLE, "");
    }
    changed.set(node, { original: text, shown, titled });
    node.nodeValue = shown;
  }

  function pass() {
    for (const node of changed.keys()) if (!node.isConnected) changed.delete(node); // gone from the page
    // The browser finds the text nodes holding "10.0." itself (XPath), so a long list isn't walked node by node
    // in script on every pass.
    globalThis.IEKit.textNodesContaining("10.0.").filter((n) => !skip(n)).forEach(rewrite);
  }

  /** Put every original back, unless the portal has since changed the text itself. */
  function restoreAll() {
    for (const [node, c] of changed) {
      if (c.titled) {
        node.parentElement?.removeAttribute("title");
        node.parentElement?.removeAttribute(OWN_TITLE);
      }
      if (node.nodeValue === c.shown) node.nodeValue = c.original;
    }
    changed.clear();
  }

  feature("friendlyOsVersions", {
    start() {
      unwatch = onPass(pass);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      restoreAll();
    },
    onChange(changes) {
      // Only its own setting (name only <-> name and build) redraws; a width or a star changed elsewhere doesn't.
      const c = changes["ie.prefs"];
      if (c && c.oldValue?.friendlyOsVersions !== c.newValue?.friendlyOsVersions) { restoreAll(); pass(); }
    },
  });

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.osVersions = { rewrite, restoreAll, pass };
})();
