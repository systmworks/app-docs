// Device additions in portal lists, all from one row scan and one device lookup per row:
//   - Primary user label: the device's Intune primary user, in lists that don't show one.
//     Clicking it opens Device quick facts (compliance, OS, check-in, enrolment, ownership).
//   - Activity light: green = checked in within 8 hours, yellow = within 7 days, orange = within 30, red = longer or never.
//     In the list's own "Last check-in" column when it has one, otherwise before the device name.
//   - Compliance shield: green / amber / red, in lists without a compliance column.
//   - Last logged-on user: a small person icon when someone other than the primary user signed in
//     last (Windows), including on shared devices. Hover says who and when; click opens quick facts.
//   - Jump to Intune: an icon on rows whose own link goes to Entra (e.g. group members), opening
//     the device's Intune record instead.
//   - Full device names: long names wrap instead of being cut off (only the name text wraps, so
//     the portal's hover badges, e.g. Copilot, stay on the line).
//
// Runs in every portal frame, because most lists render inside *.reactblade.portal.azure.net
// iframes. It works from column headers (see kit.js), so one set of rules covers every list.
// Display only: it adds elements to the name cell and never changes the portal's own content.

(function () {
  if (window.__iePrimaryUserLabels) return;
  window.__iePrimaryUserLabels = true;

  const { feature, isOn, choice, styleOnce, popupCard, cardCss, onPass, send, clickable, lookups, grid: G, BRAND, ADDED, GUID, GUID_EXACT, OPEN_ICON, iconButtonCss } = globalThis.IEKit;

  const LABEL = "ie-primary-user";
  const LIGHT = "ie-activity";
  const SHIELD = "ie-compliance";
  const LAST = "ie-last-user";
  const JUMP = "ie-jump";
  // Set on the element holding a device name so it wraps. Not an "ie-" class or data-ie: the
  // element is the portal's, and those mark elements as ours.
  const FULL = "data-iefull";
  // Status icons go before the device name, the label and jump icon after it (the portal's own
  // hover badges, e.g. Copilot, sit at the cell's right edge). Order within each side is fixed.
  const BEFORE = [LIGHT, SHIELD];
  const AFTER = [LABEL, LAST, JUMP];
  const OUR_PIECES = [...BEFORE, ...AFTER].map((c) => `.${c}`).join(", ");
  const FEATURE_KEYS = ["primaryUserLabels", "activityLights", "complianceDots", "jumpToIntune", "lastLoggedOnUser", "fullDeviceNames"];
  // Everything we draw follows these. Any other pref (a column width, another feature's switch) needs no redraw.
  const DRAW_PREFS = [...FEATURE_KEYS, "deviceQuickFacts"];
  const drawPrefsChanged = (change) => DRAW_PREFS.some((key) => change?.oldValue?.[key] !== change?.newValue?.[key]);
  const MAX_BATCH = 400;

  // Ids embedded in portal deep links (href, data-* attributes).
  const MANAGED_ID_RE = new RegExp(`(?:mdmDeviceId|managedDeviceId)(?:/|=|%2f|%3d)(${GUID})`, "i");
  const AAD_ID_RE = new RegExp(`(?:\\b|/)deviceId(?:/|=|%2f|%3d)(${GUID})`, "i");
  const OBJECT_ID_RE = new RegExp(`objectId(?:/|=|%2f|%3d)(${GUID})`, "i");

  // Column headers (lower-cased). A plain "Email" column in Entra member lists is the member's
  // own address (empty for devices), so it only counts as a user column in Intune's own device
  // lists, where it's the primary user's (e.g. Discovered apps > devices).
  const USER_HEADER_RE = /^(primary user|primary user upn|primary user display name|primary user email address|user|user name|username|user principal name|upn|enrolled by|enrolled by user|last logged on user|assigned user)$/;
  const DEVICE_LIST_USER_HEADER_RE = /^(email|email address|e-mail|user email|user email address)$/;
  const DEVICE_HEADER_RE = globalThis.IEKit.rules.deviceName;
  const NAME_HEADER_RE = /^(name|display name|member|member name)$/;
  const TYPE_HEADER_RE = /^(type|object type|member type)$/;
  const COMPLIANCE_HEADER_RE = /^(compliance|compliance state|compliant)$/;
  const CHECK_IN_HEADER_RE = /^(last check-?in|last check-?in time|last checked in|last sync|last synced|last sync time|last contact)$/;
  const MANAGED_ID_HEADER_RE = /^(device id|intune device id|managed device id|mdm device id)$/;
  const AAD_ID_HEADER_RE = /^(azure ad device id|entra device id|microsoft entra device id|aad device id)$/;
  const OBJECT_ID_HEADER_RE = /^(object id)$/;
  const NOT_DEVICE_TYPES = new Set(["user", "group", "service principal", "contact", "organizational contact", "guest", "application"]);

  let unwatch = null;
  // Device lookups by ref key (see refKey), retried while there's no session yet.
  const lookup = lookups({ type: "lookup", field: "results", retryMs: 10000, redraw: () => { if (unwatch) scan(); } });
  const results = lookup.results;

  // ---------------------------------------------------------------------------------------
  // Reading rows

  /** Column layout for a grid of devices, or null when it isn't one. */
  function describeGrid(grid, c = G.columns(grid)) {
    if (!c) return null;
    const device = c.find(DEVICE_HEADER_RE);
    const nameCol = device || c.find(NAME_HEADER_RE);
    if (!nameCol) return null;
    return {
      nameCol,
      allDevices: Boolean(device), // a "Device" column means every row is a device
      hasUserColumn: Boolean(c.find(USER_HEADER_RE) || (device && c.find(DEVICE_LIST_USER_HEADER_RE))),
      hasComplianceColumn: Boolean(c.find(COMPLIANCE_HEADER_RE)),
      checkInCol: c.find(CHECK_IN_HEADER_RE),
      typeCol: c.find(TYPE_HEADER_RE),
      managedIdCol: c.find(MANAGED_ID_HEADER_RE),
      aadIdCol: c.find(AAD_ID_HEADER_RE),
      objectIdCol: c.find(OBJECT_ID_HEADER_RE),
      usesAria: c.usesAria,
      headerCount: c.headerCount,
    };
  }

  /** { nameCell, checkInCell, ref, intuneLinked } for a device row, or null if the row isn't a device. */
  function readRow(row, layout) {
    const cells = G.cellsOf(row);
    const nameCell = G.cellFor(cells, layout.nameCol, layout);
    if (!nameCell) return null;
    const attrs = G.attrText(row);
    const text = (col) => (col ? G.cellText(G.cellFor(cells, col, layout)) : "");

    if (!layout.allDevices) {
      const type = text(layout.typeCol).toLowerCase();
      if (NOT_DEVICE_TYPES.has(type)) return null;
      if (type !== "device" && !/Microsoft_AAD_Devices|DeviceDetailsMenuBlade|Microsoft_Intune_(Managed)?Devices/i.test(attrs)) return null;
    }

    const guid = (col) => { const t = text(col); return GUID_EXACT.test(t) ? t : ""; };
    const ref = {
      managedId: guid(layout.managedIdCol) || attrs.match(MANAGED_ID_RE)?.[1] || "",
      deviceId: guid(layout.aadIdCol) || attrs.match(AAD_ID_RE)?.[1] || "",
      objectId: guid(layout.objectIdCol) || attrs.match(OBJECT_ID_RE)?.[1] || "",
      name: G.nameText(nameCell),
    };
    if (!ref.managedId && !ref.deviceId && !ref.objectId && !ref.name) return null;
    // Rows that already open the Intune device need no jump icon: links to the Intune device
    // blade, and rows in Intune's own device lists, whose names open the record via click
    // handlers. Only rows pointing at Entra get the icon.
    const intuneLinked = /Microsoft_Intune_(Managed)?Devices/i.test(attrs) ||
      (layout.allDevices && !/Microsoft_AAD_Devices|DeviceDetailsMenuBlade/i.test(attrs));
    return { nameCell, checkInCell: layout.checkInCol ? G.cellFor(cells, layout.checkInCol, layout) : null, ref, intuneLinked };
  }

  const n = (s) => String(s || "").trim().toLowerCase();

  // Cache key for a row's device: the strongest id the row offers, else its name.
  function refKey(ref) {
    if (ref.managedId) return `m:${n(ref.managedId)}`;
    if (ref.deviceId) return `d:${n(ref.deviceId)}`;
    if (ref.objectId) return `o:${n(ref.objectId)}`;
    return `n:${n(ref.name)}`;
  }

  // ---------------------------------------------------------------------------------------
  // Drawing

  const COMPLIANCE_TEXT = {
    compliant: "Compliant", noncompliant: "Not compliant", inGracePeriod: "In grace period", conflict: "Conflict",
    error: "Error", unknown: "Unknown", configManager: "Config Manager",
  };
  const complianceText = (c) => COMPLIANCE_TEXT[c] || c || "Unknown";
  const ownerText = (o) => ({ company: "Corporate", personal: "Personal" }[o] || o || "Unknown");

  const { activityLevel, ageText } = globalThis.IEActivity; // shared/activity.js: the rule, its thresholds and its words

  /** The activity light's level and a sentence for its tooltip. */
  function activity(iso) {
    const age = ageText(iso);
    return { level: activityLevel(iso), when: age ? `Last check-in ${age}` : "Never checked in" };
  }

  // Labels show the display name or the UPN.
  const labelMode = () => choice("primaryUserLabels", ["name", "upn"]);
  const who = (u) => (labelMode() === "upn" ? u.upn || u.displayName : u.displayName || u.upn);
  /** The last logged-on user, when it isn't the primary user (or there's no primary user). */
  const otherLastUser = (d) => (d?.lastUser && n(d.lastUser.upn || d.lastUser.displayName) !== n(d.upn || d.displayName) ? d.lastUser : null);
  const sinceText = (iso) => ageText(iso) || "";

  function labelFor(result) {
    if (!result) return null;
    switch (result.status) {
      case "user": {
        const u = result.users[0];
        return { text: who(u), kind: "user", title: `Primary user: ${u.displayName || ""}${u.upn ? ` <${u.upn}>` : ""}` };
      }
      case "multiple":
        return {
          text: `${who(result.users[0])} +${result.users.length - 1}`,
          kind: "multiple",
          title: `${result.devices.length} Intune devices share this name:\n` +
            result.devices.map((d) => `${d.name}: ${d.displayName || d.upn || "no primary user"}`).join("\n"),
        };
      case "noUser":
        return { text: "no primary user", kind: "muted", title: "Intune has no primary user for this device (shared or userless)." };
      case "notFound":
        return { text: "not in Intune", kind: "muted", title: "No Intune managed device matches this device." };
      default:
        return null;
    }
  }

  // Inside the cell, beside its main content, so the portal's own link or click target is untouched.
  const hostOf = (nameCell) => nameCell.querySelector(".ms-DetailsRow-cellContent, [data-automationid='DetailsRowCell'] > *") || nameCell;

  /**
   * Find our piece `cls` in the cell, or create it in its fixed position: inside the element
   * holding the name text, right before it (BEFORE) or right after it (AFTER). The portal can make
   * that element a block or stretch it across the cell, so anything placed outside it would land
   * on another line or at the cell's far edge.
   */
  function piece(nameCell, cls, create) {
    let el = nameCell.querySelector(`.${cls}`);
    if (el) return el;
    el = create ? create() : document.createElement("span");
    el.classList.add(cls);
    const text = G.firstText(nameCell);
    const parent = text?.parentNode || hostOf(nameCell);
    const side = BEFORE.includes(cls) ? BEFORE : AFTER;
    const mine = (c) => parent.querySelector(`:scope > .${c}`);
    const later = side.slice(side.indexOf(cls) + 1).map(mine).find(Boolean);
    if (side === BEFORE) parent.insertBefore(el, later || text || parent.firstChild);
    else {
      const anchor = side.slice(0, side.indexOf(cls)).map(mine).filter(Boolean).pop() || text;
      parent.insertBefore(el, later || anchor?.nextSibling || null);
    }
    // These can sit inside the name link: a click on them shouldn't follow it.
    el.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); });
    return el;
  }

  const PERSON_ICON = '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true" fill="currentColor"><circle cx="8" cy="5" r="3"/><path d="M2.5 14c.4-3 2.7-5 5.5-5s5.1 2 5.5 5z"/></svg>';
  const SHIELD_ICON = '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path fill="currentColor" d="M8 1 2.5 3v4.2c0 3.4 2.3 6.4 5.5 7.8 3.2-1.4 5.5-4.4 5.5-7.8V3L8 1z"/></svg>';

  /** Show or remove one piece. */
  function toggle(nameCell, cls, want, draw) {
    if (want) draw(piece(nameCell, cls, draw.create));
    else nameCell.querySelector(`.${cls}`)?.remove();
  }

  /**
   * Draw one row's additions. opts: showLight, showShield, showLabel, showLastUser, showJump (each
   * follows its switch and what the list already shows), intuneLinked, and lightCell (the row's
   * Last check-in cell, where the light goes instead of before the name). With several Intune
   * records under one name, the light and shield describe the newest (resolve.js sorts newest
   * first).
   */
  function applyLabel(nameCell, key, result, opts = { showLabel: true }) {
    const devices = result?.devices || [];
    const d = devices[0];
    const many = devices.length > 1 ? `\n(newest of ${devices.length} records with this name)` : "";

    if (opts.lightCell) nameCell.querySelector(`.${LIGHT}`)?.remove();
    toggle(opts.lightCell || nameCell, LIGHT, opts.showLight && d, (el) => {
      const a = activity(d.lastSync);
      el.dataset.level = a.level;
      el.title = `${a.when}${many}${ADDED}`;
      el.setAttribute("aria-label", a.when);
    });

    toggle(nameCell, SHIELD, opts.showShield && d, (el) => {
      if (!el.firstChild) el.innerHTML = SHIELD_ICON;
      el.dataset.state = d.compliance || "unknown";
      el.title = `${complianceText(d.compliance)}${many}${ADDED}`;
      el.setAttribute("aria-label", complianceText(d.compliance));
    });

    const label = opts.showLabel ? labelFor(result) : null;
    const drawLabel = (el) => {
      el.dataset.key = key;
      el.dataset.kind = label.kind;
      // Only when it changed: a rewrite on every pass replaces the text node, so the next row's innerText read lays out the page again.
      if (el.textContent !== label.text) el.textContent = label.text;
      el.title = `${label.title}${isOn("deviceQuickFacts") ? "\nClick for quick facts" : ""}${ADDED}`;
    };
    drawLabel.create = () => clickable(document.createElement("span"), "Primary user", (e) => {
      const r = results.get(e.currentTarget.dataset.key);
      if (r && isOn("deviceQuickFacts")) showCard(e.currentTarget, r);
    });
    toggle(nameCell, LABEL, label, drawLabel);

    const last = opts.showLastUser ? otherLastUser(d) : null;
    const drawLast = (el) => {
      const said = `Last logged on: ${last.displayName || last.upn}${last.upn && last.displayName ? ` <${last.upn}>` : ""}, ${sinceText(last.at)}`;
      el.dataset.key = key;
      el.setAttribute("aria-label", said);
      el.title = `${said}\n${d.upn || d.displayName ? `Primary user: ${d.displayName || d.upn}` : "No primary user"}${many}` +
        `${isOn("deviceQuickFacts") ? "\nClick for quick facts" : ""}${ADDED}`;
      const text = `last: ${who(last)}`;
      if (el.dataset.mode === "name" && el.textContent !== text) el.textContent = text;
    };
    // An icon by default, so the Device name column stays narrow, or "last: name" (Full name).
    drawLast.create = () => {
      const el = clickable(document.createElement("span"), "Last logged-on user", (e) => {
        const r = results.get(e.currentTarget.dataset.key);
        if (r && isOn("deviceQuickFacts")) showCard(e.currentTarget, r);
      });
      el.dataset.mode = choice("lastLoggedOnUser", ["icon", "name"]);
      if (el.dataset.mode === "icon") el.innerHTML = PERSON_ICON;
      return el;
    };
    toggle(nameCell, LAST, last, drawLast);

    const drawJump = (el) => {
      el.dataset.key = key;
      el.title = devices.length === 1
        ? `Open this device in Intune (Ctrl+click: new tab)${ADDED}`
        : `${devices.length} Intune devices share this name: click to choose${ADDED}`;
    };
    drawJump.create = () => {
      const el = clickable(document.createElement("span"), "Open in Intune", (e) => {
        const list = results.get(el.dataset.key)?.devices || [];
        if (list.length === 1) openDevice(list[0].managedId, e.ctrlKey || e.metaKey);
        else if (list.length > 1) showCard(el, results.get(el.dataset.key));
      });
      el.innerHTML = OPEN_ICON;
      return el;
    };
    toggle(nameCell, JUMP, opts.showJump && !opts.intuneLinked && d, drawJump);
  }

  function openDevice(managedId, newTab) {
    if (managedId) send({ type: "portal/open", kind: "device", id: managedId, newTab }).catch(() => {});
  }

  // ---------------------------------------------------------------------------------------
  // Device quick facts card. Lives in a closed shadow root so the portal's CSS can't reach it.

  let card = null; // the open card, from IEKit.popupCard
  const esc = globalThis.IEKit.escapeHtml;
  const dateText = (iso) => (iso ? new Date(iso).toLocaleDateString() : "");

  function cardHtml(result) {
    const devices = result.devices.slice(0, 6);
    const muted = (t) => `<span class="muted">${t}</span>`;
    const rows = devices.map((d) => {
      const a = activity(d.lastSync);
      return `
      <section>
        <h4>${esc(d.name)}</h4>
        <dl>
          <dt>Primary user</dt><dd>${d.displayName || d.upn ? `${esc(d.displayName)}${d.upn ? `<span class="sub">${esc(d.upn)}</span>` : ""}` : muted("None (shared or userless)")}</dd>
          ${d.lastUser ? `<dt>Last logged on</dt><dd>${esc(d.lastUser.displayName || d.lastUser.upn)}<span class="sub">${esc(sinceText(d.lastUser.at))}${otherLastUser(d) ? ", not the primary user" : ""}</span></dd>` : ""}
          <dt>Compliance</dt><dd><span class="pill c-${esc(d.compliance || "unknown")}">${esc(complianceText(d.compliance))}</span></dd>
          <dt>OS</dt><dd>${esc(globalThis.IEWindowsBuilds.friendlyOs(d.os, d.osVersion)) || muted("Unknown")}</dd>
          <dt>Last check-in</dt><dd><span class="light ${a.level}"></span>${esc(a.when.replace(/^Last check-in /, ""))}</dd>
          <dt>Enrolled</dt><dd>${esc(dateText(d.enrolled)) || muted("Unknown")}</dd>
          <dt>Ownership</dt><dd>${esc(ownerText(d.owner))}</dd>
          ${d.model ? `<dt>Model</dt><dd>${esc(d.model)}</dd>` : ""}
        </dl>
        <div class="more" data-for="${esc(d.managedId)}"></div>
        <button class="btn" data-more="${esc(d.managedId)}">More details</button>
        <button class="btn primary" data-open="${esc(d.managedId)}">Open in Intune</button>
      </section>`;
    }).join("");
    const more = result.devices.length > devices.length ? `<section><p class="muted">${result.devices.length - devices.length} more not shown.</p></section>` : "";
    const head = result.devices.length > 1 ? `${result.devices.length} Intune devices share this name` : "Device quick facts";
    return `<div class="card" role="dialog" aria-label="Device quick facts">
      <header><span>${esc(head)}</span><button class="x" aria-label="Close">&times;</button></header>
      ${rows || '<section><p class="muted">No Intune managed device matches.</p></section>'}${more}
      <footer>${esc(BRAND)}</footer>
    </div>`;
  }

  function hideCard() {
    card?.close();
  }

  /** "More details": read the device's full record (when asked, not before) and add its rows to the card. */
  function loadMore(root, button) {
    const id = button.dataset.more;
    const box = [...root.querySelectorAll(".more")].find((el) => el.dataset.for === id);
    button.disabled = true;
    button.textContent = "Loading...";
    send({ type: "device/details", id }).then((res) => {
      if (!res?.ok) throw new Error(res?.error || "Graph refused");
      box.innerHTML = res.rows.length
        ? `<dl>${res.rows.map(([label, value]) => `<dt>${esc(label)}</dt><dd>${esc(value)}</dd>`).join("")}</dl>`
        : '<p class="muted">Nothing more to show.</p>';
      button.remove();
    }).catch((e) => {
      box.innerHTML = `<p class="muted">Couldn't load more details: ${esc(e.message)}</p>`;
      button.disabled = false;
      button.textContent = "More details";
    });
  }

  function showCard(anchor, result) {
    card = popupCard({
      anchor, css: cardCss, html: cardHtml(result), attrs: { "data-ie": "quick-facts" },
      onClose: () => { card = null; },
      onClick: (e, root) => {
        const moreButton = e.target.closest("button[data-more]");
        if (moreButton) { loadMore(root, moreButton); return; }
        const btn = e.target.closest("button[data-open]");
        if (!btn) return;
        openDevice(btn.dataset.open, e.ctrlKey || e.metaKey);
        hideCard();
      },
    });
  }

  // ---------------------------------------------------------------------------------------
  // Passes

  /** What to draw in a list, given the switches and what the list already shows. */
  function drawOptions(layout) {
    return {
      showLabel: isOn("primaryUserLabels") && !layout.hasUserColumn,
      showLight: isOn("activityLights"),
      showShield: isOn("complianceDots") && !layout.hasComplianceColumn,
      showLastUser: isOn("lastLoggedOnUser"),
      showJump: isOn("jumpToIntune"),
    };
  }

  // The device overview page: the activity light in front of "Last check-in <date>". The page's own address
  // carries no device id (the portal passes it into the frame separately), and the page shows none, so the
  // device is found by the Serial number shown in the same panel.
  const OVERVIEW = "data-ie-overview";

  /** The overview panel's serial number and its "Last check-in" labels, or null when this isn't a device overview. */
  function overviewPage() {
    const panel = document.querySelector("[class*='EssentialsPanel']");
    if (!panel) return null;
    let serial = "";
    const targets = [];
    for (const label of panel.querySelectorAll("label")) {
      const text = label.textContent.trim();
      if (/^serial number$/i.test(text)) {
        const row = label.parentElement?.parentElement;
        serial = (row?.innerText || "").replace(/^\s*serial number\s*/i, "").trim() || (label.parentElement?.nextElementSibling?.textContent || "").trim();
      } else if (/^last check-?in\b/i.test(text) && /\d/.test(text)) {
        targets.push(label);
      }
    }
    return { serial, targets };
  }

  globalThis.IEKit.overviewPage = overviewPage; // shared with device-related.js
  globalThis.IEKit.checkInText = (iso) => activity(iso).when; // so the Related card words check-ins the same way

  function overviewLight(page = overviewPage()) {
    const key = page?.serial ? `s:${n(page.serial)}` : "";
    const d = key ? results.get(key)?.devices?.[0] : null;
    const targets = isOn("activityLights") && page ? page.targets : [];
    if (targets.length && key && !d && lookup.wanted(key)) lookup.request([{ key, ref: { serial: page.serial } }]);
    document.querySelectorAll(`.${LIGHT}[${OVERVIEW}]`).forEach((el) => { if (!d || !targets.includes(el.parentElement)) el.remove(); });
    if (!d) return;
    const a = activity(d.lastSync);
    for (const label of targets) {
      let el = label.querySelector(`:scope > .${LIGHT}[${OVERVIEW}]`);
      if (!el) {
        el = document.createElement("span");
        el.className = LIGHT;
        el.setAttribute(OVERVIEW, "");
        label.prepend(el);
      }
      el.dataset.level = a.level;
      el.title = `${a.when}${ADDED}`;
      el.setAttribute("aria-label", a.when);
    }
  }

  function scan(grids = G.scan()) {
    overviewLight();
    const pending = new Map(); // a device can appear in more than one list
    for (const { el: grid, cols } of grids) {
      const layout = describeGrid(grid, cols);
      if (!layout) continue;
      const opts = drawOptions(layout);
      const wrapNames = isOn("fullDeviceNames");
      const drawsAnything = opts.showLabel || opts.showLight || opts.showShield || opts.showLastUser;
      for (const row of G.rowsOf(grid)) {
        const hit = readRow(row, layout);
        if (!hit) {
          row.querySelectorAll(OUR_PIECES).forEach((el) => el.remove()); // recycled row, no longer a device
          row.querySelectorAll(`[${FULL}]`).forEach((el) => el.removeAttribute(FULL));
          continue;
        }
        G.firstText(hit.nameCell)?.parentElement.toggleAttribute(FULL, wrapNames);
        const rowOpts = { ...opts, intuneLinked: hit.intuneLinked, lightCell: hit.checkInCell };
        if (!drawsAnything && !(opts.showJump && !hit.intuneLinked)) {
          row.querySelectorAll(OUR_PIECES).forEach((el) => el.remove()); // nothing to add here
          continue;
        }
        const key = refKey(hit.ref);
        if (results.has(key)) {
          applyLabel(hit.nameCell, key, results.get(key), rowOpts);
        } else {
          // Clear pieces a recycled (virtualised) row left behind while this one is looked up.
          row.querySelectorAll(OUR_PIECES).forEach((el) => el.remove());
          if (lookup.wanted(key)) pending.set(key, { key, ref: hit.ref });
        }
      }
    }
    if (pending.size) lookup.request([...pending.values()].slice(0, MAX_BATCH));
  }

  function removeAll() {
    document.querySelectorAll(OUR_PIECES).forEach((el) => el.remove());
    document.querySelectorAll(`[${FULL}]`).forEach((el) => el.removeAttribute(FULL));
    hideCard();
  }

  // ---------------------------------------------------------------------------------------
  // Styling. The portal has its own light and dark themes, so the colours read on both.

  const CSS = `
    .${LABEL} {
      display: inline-block; margin-left: 8px; padding: 0 6px; border-radius: 8px; font-size: 0.92em;
      line-height: 1.5; white-space: nowrap; vertical-align: baseline; cursor: pointer;
      color: var(--ie-link); background: var(--ie-label-bg);
    }
    .${LABEL}:hover, .${LABEL}:focus-visible { background: var(--ie-label-hover-bg); outline: none; }
    .${LABEL}[data-kind="multiple"] { color: var(--ie-label-multi); background: var(--ie-label-multi-bg); }
    .${LABEL}[data-kind="muted"] { color: var(--ie-label-muted); background: var(--ie-label-muted-bg); font-style: italic; }
    .${LIGHT} { display: inline-block; width: 9px; height: 9px; margin: 0 6px 0 2px; border-radius: 50%; vertical-align: middle; cursor: help; }
    .${LIGHT}[data-level="green"] { background: var(--ie-light-green); box-shadow: 0 0 0 2px var(--ie-halo-green); }
    .${LIGHT}[data-level="yellow"] { background: var(--ie-light-yellow); box-shadow: 0 0 0 2px var(--ie-halo-yellow); }
    .${LIGHT}[data-level="orange"] { background: var(--ie-light-orange); box-shadow: 0 0 0 2px var(--ie-halo-orange); }
    .${LIGHT}[data-level="red"] { background: var(--ie-light-red); box-shadow: 0 0 0 2px var(--ie-halo-red); }
    .${SHIELD} { display: inline-flex; margin-right: 6px; vertical-align: middle; cursor: help; color: var(--ie-shield-unknown); }
    .${SHIELD}[data-state="compliant"] { color: var(--ie-shield-ok); }
    .${SHIELD}[data-state="noncompliant"], .${SHIELD}[data-state="error"] { color: var(--ie-shield-bad); }
    .${SHIELD}[data-state="inGracePeriod"], .${SHIELD}[data-state="conflict"] { color: var(--ie-shield-warn); }
    ${iconButtonCss(LAST)}
    .${LAST} { color: var(--ie-label-last); }
    .${LAST}[data-mode="name"] { font-size: 0.88em; font-style: italic; white-space: nowrap; }
    /* Full device names: the name's own element wraps instead of ending in an ellipsis. */
    [${FULL}] { white-space: normal !important; text-overflow: clip !important; overflow-wrap: anywhere; }
    ${iconButtonCss(JUMP)}`;

  // Exposed for the offline test harness only.
  if (globalThis.__IE_TEST__) {
    globalThis.__IE_TEST__.labeler = { results, overviewLight, overviewPage, describeGrid, readRow, refKey, labelFor, applyLabel, activity, cardHtml, drawOptions, otherLastUser, scan, drawPrefsChanged };
  }

  const ensureStyles = styleOnce(CSS);
  feature(FEATURE_KEYS, {
    start() {
      ensureStyles();
      unwatch = onPass(scan);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      lookup.cancel();
      results.clear(); // onChange doesn't run while stopped, so an index rebuilt meanwhile would leave these stale
      removeAll();
    },
    onChange(changes) {
      // A rebuilt device index means fresher answers; changed prefs mean a redraw.
      if (changes["ie.indexStamp"]) results.clear(); // device-index.js INDEX_STAMP
      if (changes["ie.prefs"] && drawPrefsChanged(changes["ie.prefs"])) removeAll();
      scan();
    },
  });
})();
