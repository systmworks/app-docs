// "Set in N policies" beside each setting in Intune's settings picker (Add settings), so you can see what is
// already configured before adding it. Hover for the policy names. Nothing is shown for a setting no policy uses.
//
// The picker's rows carry only the setting's friendly name (no setting id), so this matches on the name against
// the policy index the Setting check tab builds; a name more than one setting uses is marked "name shared".
// Needs that index to exist: until it does, nothing is drawn and the worker is asked again, after 3 s at first
// and then less often, up to once a minute (it only reads what is saved). The text sits at the right edge of the setting's grid
// cell, in line with the portal's info icons, not tight against the name.
// Display only. Turning the switch off removes the text.

(function () {
  if (window.__ieSettingUsage) return;
  window.__ieSettingUsage = true;

  const { feature, onPass, lookups, styleOnce, ADDED } = globalThis.IEKit;
  const CLASS = "ie-setting-use";
  const CELL = ".fxc-gc-cell-content";
  const LABEL = `${CELL} label.azc-form-label`;
  const CELL_CLASS = "ie-use-cell"; // makes the cell the anchor the text is positioned against
  const BATCH = 100;
  const RESULT_TTL_MS = 60000; // how long answers are kept, so a Refresh in Setting check shows up without reloading the page
  let askedAt = Date.now();
  let unwatch = null;

  // Until the index exists the worker says no: ask after 3 s, then wait twice as long each time, up to a minute.
  const lookup = lookups({ type: "settings/usage", field: "usage", retryMs: 3000, maxRetryMs: 60000, redraw: () => { if (unwatch) pass(); } });
  const keyOf = (label) => label.textContent.trim().toLowerCase().replace(/\s+/g, " ");

  // Every look-and-feel value is a custom property on the badge, so it can be tweaked live in DevTools.
  const CSS = `
    .${CELL_CLASS} { position: relative; }
    .${CLASS} { --use-color: var(--ie-usage-fg); --use-right: 44px; --use-size: 0.9em; position: absolute; right: var(--use-right); top: 50%; transform: translateY(-50%); font-size: var(--use-size); color: var(--use-color); white-space: nowrap; cursor: default; }`;

  const text = (u) => `Set in ${u.count} ${u.count === 1 ? "policy" : "policies"}${u.shared ? ", name shared" : ""}`;
  const tip = (u) => [...u.policies, ...(u.more ? [`and ${u.more} more`] : []), ...(u.shared ? ["", "More than one setting has this name, so this may include policies that set a different one."] : [])].join("\n") + ADDED;

  function draw(label, u) {
    const cell = label.closest(CELL);
    if (!cell) return;
    let badge = cell.querySelector(`.${CLASS}`);
    if (!u.count) { badge?.remove(); return; }
    if (!badge) {
      badge = document.createElement("span");
      badge.className = CLASS;
      cell.classList.add(CELL_CLASS);
      cell.append(badge);
    }
    badge.textContent = text(u);
    badge.title = tip(u);
  }

  function remove() {
    document.querySelectorAll(`.${CLASS}`).forEach((el) => el.remove());
    document.querySelectorAll(`.${CELL_CLASS}`).forEach((el) => el.classList.remove(CELL_CLASS));
  }

  /** Forget the answers once they are a minute old; the next pass asks again. */
  function expireResults(now = Date.now()) {
    if (now - askedAt <= RESULT_TTL_MS) return;
    lookup.results.clear();
    askedAt = now;
  }

  function pass() {
    expireResults();
    const todo = new Map();
    for (const label of document.querySelectorAll(LABEL)) {
      const key = keyOf(label);
      if (!key) continue;
      const u = lookup.results.get(key);
      if (u) draw(label, u);
      else if (lookup.wanted(key)) todo.set(key, label.textContent.trim());
    }
    if (todo.size) lookup.request([...todo].slice(0, BATCH).map(([key, name]) => ({ key, name })));
  }

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.settingUse = { pass, remove, draw, text, tip, expireResults, results: lookup.results };

  const ensureStyles = styleOnce(CSS);
  feature("settingUsage", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() { unwatch?.(); unwatch = null; lookup.cancel(); remove(); },
    onChange() { pass(); },
  });
})();
