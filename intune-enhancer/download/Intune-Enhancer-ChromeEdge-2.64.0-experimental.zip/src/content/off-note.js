// While the disclosure hasn't been accepted, a small note in the corner of the Intune admin
// center (top frame only) says the extension is installed but off, with a button that opens
// Settings, where the disclosure is. It only shows text: nothing is read from the page. It goes
// away when the disclosure is accepted, or for this page when dismissed.

(function () {
  if (window.__ieOffNote) return;
  window.__ieOffNote = true;

  const { watchConsent, adoptStyles, send, BRAND, hostTheme } = globalThis.IEKit;

  const CSS = `${hostTheme}
    :host { all: initial; }
    .note { position: fixed; right: 20px; bottom: 20px; z-index: 2147483646; display: flex; align-items: center; gap: 12px;
      max-width: 420px; padding: 10px 12px 10px 14px; border-radius: 10px; box-shadow: 0 8px 24px var(--ie-note-shadow);
      background: var(--ie-note-bg); color: var(--ie-note-fg); border: 1px solid var(--ie-accent); font: 13px/1.4 "Segoe UI", system-ui, sans-serif; }
    button { font: inherit; border-radius: 6px; cursor: pointer; padding: 4px 10px; }
    .on { background: var(--ie-accent); color: var(--ie-note-btn-fg); border: 1px solid var(--ie-accent); font-weight: 600; white-space: nowrap; }
    .x { background: none; border: 0; color: var(--ie-note-x); font-size: 18px; line-height: 1; padding: 0 4px; }`;

  let host = null;
  let dismissed = false;

  function show() {
    if (host) return;
    host = document.createElement("div");
    host.setAttribute("data-ie", "off-note");
    const root = host.attachShadow({ mode: "closed" });
    if (!adoptStyles(CSS, root)) root.innerHTML = `<style>${CSS}</style>`;
    const note = document.createElement("div");
    note.className = "note";
    note.setAttribute("role", "status");
    note.innerHTML = `<span><strong></strong> is installed but turned off.</span>
      <button class="on">Turn it on</button><button class="x" aria-label="Dismiss">&times;</button>`;
    note.querySelector("strong").textContent = BRAND;
    note.querySelector(".on").addEventListener("click", () => send({ type: "settings/open" }).catch(() => {}));
    note.querySelector(".x").addEventListener("click", () => { dismissed = true; hide(); });
    root.appendChild(note);
    document.documentElement.appendChild(host);
  }

  function hide() {
    host?.remove();
    host = null;
  }

  watchConsent((agreed) => { if (agreed || dismissed) hide(); else show(); });
})();
