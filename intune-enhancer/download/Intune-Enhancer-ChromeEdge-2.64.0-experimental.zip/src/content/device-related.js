// "Related" button on a device's page: one more command in the toolbar that opens a small card with the
// primary user's other devices and the groups this device is in.
//
// The device isn't in the page's address (the portal passes it into the frame separately), so it is found by
// the Serial number shown on the Overview page (the same panel the activity light reads). The button is a copy
// of one of the toolbar's own plain buttons, with its icon, id and overflow handling removed, so it looks like
// the portal's. Display only; turning the switch off removes it.

(function () {
  if (window.__ieRelated) return;
  window.__ieRelated = true;

  const { feature, onPass, send, styleOnce, commandPillCss, escapeHtml: esc, popupCard, cardCss, BRAND, ADDED } = globalThis.IEKit;
  const BTN = "ie-related-btn";
  const HOST = "ie-related-card";
  let unwatch = null;
  let open = null; // the open card, from popupCard
  let asked = 0; // which request the open card is waiting for, so an old answer can't draw over a newer card
  const toolbar = () => document.querySelector("[role='toolbar'].intune-ResourceViewToolbar, #resourceViewToolbar");

  /** Close the card. */
  function hideCard() {
    open?.close();
  }

  function remove() {
    hideCard();
    document.querySelectorAll(`.${BTN}`).forEach((el) => el.remove());
  }

  /** A copy of one of the toolbar's plain buttons, made ours. */
  function makeButton(bar) {
    const source = [...bar.querySelectorAll("button")].filter((b) => !b.hasAttribute("aria-haspopup") && !b.classList.contains(BTN))
      .sort((a, b) => Number(a.disabled) - Number(b.disabled))[0];
    if (!source) return null;
    const btn = source.cloneNode(false);
    for (const attr of ["id", "disabled", "aria-disabled", "label", "data-overflow-item", "data-overflow-group", "data-tabster", "elementtiming"]) btn.removeAttribute(attr);
    btn.classList.add(BTN);
    btn.textContent = "Related";
    btn.setAttribute("aria-label", "Related");
    btn.title = `The primary user's other devices and this device's groups${ADDED}`;
    btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); toggleCard(btn); });
    return btn;
  }

  function pass() {
    const bar = toolbar();
    const page = globalThis.IEKit.overviewPage?.();
    if (!bar || !page?.serial) { remove(); return; }
    let btn = bar.querySelector(`.${BTN}`);
    if (btn) {
      if (btn.dataset.ieSerial !== page.serial) hideCard(); // the page moved to another device
      btn.dataset.ieSerial = page.serial;
      return;
    }
    btn = makeButton(bar);
    if (!btn) return;
    btn.dataset.ieSerial = page.serial;
    const more = [...bar.querySelectorAll("button")].find((b) => /^more items$/i.test(b.getAttribute("aria-label") || ""));
    if (more?.parentElement) more.parentElement.insertBefore(btn, more); else bar.append(btn);
  }

  // ---------------------------------------------------------------------------------------
  // The card. In a closed shadow root so the portal's CSS can't reach it.

  function cardHtml(data) {
    const user = data.user ? `${esc(data.user.name)}${data.user.upn && data.user.upn !== data.user.name ? `<span class="sub">${esc(data.user.upn)}</span>` : ""}` : '<span class="muted">None (shared or userless)</span>';
    const others = data.others.length
      ? `<ul>${data.others.map((d) => `<li><button class="link" data-device="${esc(d.managedId)}">${esc(d.name)}</button><span class="sub">${esc([d.os, d.compliance, globalThis.IEKit.checkInText?.(d.lastSync)].filter(Boolean).join(", "))}</span></li>`).join("")}</ul>${data.othersTotal > data.others.length ? `<p class="muted">${data.othersTotal - data.others.length} more not shown.</p>` : ""}`
      : '<p class="muted">None.</p>';
    const groups = data.groups === null ? `<p class="muted">${esc(data.groupsNote)}</p>`
      : data.groups.length ? `<ul>${data.groups.map((g) => `<li><button class="link" data-group="${esc(g.id)}">${esc(g.name)}</button>${g.direct ? "" : `<span class="sub">nested${g.via ? `, via ${esc(g.via)}` : ""}</span>`}</li>`).join("")}</ul>` : '<p class="muted">In no groups.</p>';
    return `<header><span>Related to ${esc(data.device.name)}</span><button class="x" aria-label="Close">&times;</button></header>
      <section>
      ${data.sameSerial ? `<p class="muted">${data.sameSerial} other record${data.sameSerial === 1 ? "" : "s"} in Intune share this serial number. Showing the most recently checked in.</p>` : ""}
      <h4>Primary user</h4><p>${user}</p>
      <h4>Their other devices (${data.othersTotal})</h4>${others}
      <h4>This device's groups${data.groups ? ` (${data.groups.length})` : ""}</h4>${groups}
      </section>
      <footer>${esc(BRAND)}</footer>`;
  }

  function showCard(anchor, data) {
    open = popupCard({
      anchor, css: cardCss, html: `<div class="card" role="dialog" aria-label="Related">${cardHtml(data)}</div>`, attrs: { class: HOST },
      // The Related button toggles the card itself, so a press on it is not "outside".
      keepOpen: (target) => Boolean(target.closest?.(`.${BTN}`)),
      onClose: () => { open = null; },
      onClick: (e) => {
        const link = e.target.closest("button[data-device], button[data-group]");
        if (!link) return;
        const kind = link.dataset.device ? "device" : "group";
        send({ type: "portal/open", kind, id: link.dataset[kind], newTab: e.ctrlKey || e.metaKey }).catch(() => {});
      },
    });
  }

  async function toggleCard(btn) {
    if (open) { hideCard(); return; }
    const mine = ++asked;
    const serial = btn.dataset.ieSerial;
    const say = (note) => showCard(btn, { device: { name: "this device" }, user: null, others: [], othersTotal: 0, groups: null, groupsNote: note });
    say("Reading...");
    try {
      const res = await send({ type: "device/related", serial });
      if (mine !== asked || !open) return; // closed, or closed and reopened, while we waited
      if (!res?.ok) throw new Error(res?.error || "no answer from the extension");
      if (!res.found) { say("This device isn't in the device list yet. Refresh the device list in Settings."); return; }
      showCard(btn, res.related);
    } catch (e) {
      if (mine === asked && open) say(`Couldn't read: ${e?.message || e}`);
    }
  }

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.related = { pass, remove, cardHtml, makeButton };

  const ensureStyles = styleOnce(commandPillCss(`.${BTN}`));
  feature("deviceRelated", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() { unwatch?.(); unwatch = null; remove(); },
    onChange() { pass(); },
  });
})();
