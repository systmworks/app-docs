// The progress bar along the bottom of the workspace: one line for the job that last reported, redrawn every
// redrawMs so it doesn't flicker. A job with a total shows a meter; with a stop it shows Stop (a function, or true
// for a worker job, which stopWorker() stops). Kept apart from workspace.js so tests/test.html can drive it.

/**
 * @param doc         the page (its #jobbar, #job-text, #job-meter, #job-fill, #job-detail and #job-stop)
 * @param stopWorker  called by Stop for a job whose stop is true (the worker's own reads)
 * @param redrawMs    how often a running job is redrawn
 * @param doneMs      how long a final message ("Stopped. Kept ...") stays
 */
export function createJobBar({ doc = document, stopWorker = () => {}, redrawMs = 2000, doneMs = 6000 } = {}) {
  const jobs = new Map(); // key -> { label, done, total, stop, startedAt, touched, final?, stopping? }
  const hideTimers = new Map(); // key -> the timer that removes that job's final message (one per job)
  let timer = 0;
  const el = (id) => doc.getElementById(id);
  /** The job that reported last, or null. */
  const latest = () => [...jobs.values()].reduce((a, b) => (!a || b.touched >= a.touched ? b : a), null);

  function draw() {
    const bar = el("jobbar");
    if (!bar) return;
    const job = latest();
    if (!job) { bar.hidden = true; doc.body.classList.remove("has-job"); return; }
    const seconds = Math.round((Date.now() - job.startedAt) / 1000);
    const count = job.total ? ` (${job.done.toLocaleString()} of ${job.total.toLocaleString()})` : job.done ? ` (${job.done.toLocaleString()} so far)` : "";
    el("job-text").textContent = job.final || `${job.label}${count}`;
    const pct = job.total ? Math.min(100, Math.round((job.done / job.total) * 100)) : 0;
    el("job-meter").hidden = !job.total || Boolean(job.final);
    el("job-fill").style.width = `${pct}%`;
    el("job-detail").textContent = job.final ? "" : `${job.total ? `${pct}%, ` : ""}${seconds} s`;
    el("job-stop").hidden = !job.stop || Boolean(job.final);
    el("job-stop").disabled = Boolean(job.stopping);
    bar.hidden = false;
    doc.body.classList.add("has-job");
  }
  const tick = () => { draw(); if (!jobs.size) { clearInterval(timer); timer = 0; } };
  const ensureTimer = () => { if (!timer) timer = setInterval(tick, redrawMs); };
  const cancelHide = (key) => { clearTimeout(hideTimers.get(key)); hideTimers.delete(key); };

  return {
    /** Start or update a job; the first report draws at once, later ones wait for the next redraw. */
    set(key, update) {
      const first = !jobs.has(key);
      const job = jobs.get(key) || { label: "", done: 0, total: 0, stop: null, startedAt: Date.now() };
      Object.assign(job, update, { touched: Date.now() });
      delete job.final;
      jobs.set(key, job);
      cancelHide(key);
      if (first) draw();
      ensureTimer();
    },

    /** End a job, optionally leaving a final message on the bar for doneMs. */
    done(key, message = "") {
      const job = jobs.get(key);
      if (!job) return;
      cancelHide(key);
      if (message) {
        job.final = message;
        job.touched = Date.now();
        hideTimers.set(key, setTimeout(() => { hideTimers.delete(key); jobs.delete(key); draw(); }, doneMs));
      } else {
        jobs.delete(key);
      }
      draw();
    },

    /** Stop the shown job: a function runs, true asks the worker. */
    stop() {
      const job = latest();
      if (!job?.stop) return;
      job.stopping = true;
      job.label = "Stopping...";
      draw();
      if (typeof job.stop === "function") job.stop();
      else stopWorker();
    },

    /** For tests: the jobs still held and whether the redraw timer runs. */
    state: () => ({ keys: [...jobs.keys()], ticking: Boolean(timer) }),
  };
}
