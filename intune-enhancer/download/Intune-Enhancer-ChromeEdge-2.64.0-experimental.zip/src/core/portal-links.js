// Deep links into the Intune and Entra admin centers, in one place so they're easy to fix when
// the portal changes. The portal has no documented deep-link scheme; these follow the
// #view/<extension>/<blade>/... form the portal itself puts in the address bar.
//
// VERIFIED marks a pattern confirmed against the live portal. Policy types whose own link
// isn't known yet open their list page instead (areaUrl).

import { TYPE_BY_KEY } from "./policy-types.js";

let PORTAL = "https://intune.microsoft.com/";

/** The admin center host for the signed-in cloud (core/clouds.js); links use it from then on. */
export const setPortalHost = (host) => { PORTAL = `https://${host}/`; };

const enc = encodeURIComponent;

/**
 * Intune managed device overview, in the new device view (the one the portal's own "Open in Intune"
 * opens; owner-supplied 2026-11-04). The old view was
 * #view/Microsoft_Intune_Devices/DeviceSettingsMenuBlade/~/overview/mdmDeviceId/<id>, which Microsoft
 * is expected to retire.
 */
let newDeviceView = true;

/** Set from the "New device view" switch (pref newDeviceView, on unless saved as false). */
export const setNewDeviceView = (on) => { newDeviceView = on !== false; };

export const deviceUrl = (managedId) => newDeviceView
  ? `${PORTAL}#view/Microsoft_Intune_ManagedDevices/ManagedDeviceMenu.MenuView/~/overview/managedDeviceId/${enc(managedId)}`
  : `${PORTAL}#view/Microsoft_Intune_Devices/DeviceSettingsMenuBlade/~/overview/mdmDeviceId/${enc(managedId)}`;

/**
 * A remediation's overview page. VERIFIED 2026-11-04 from the address bar (a custom script; the
 * portal also puts /isFirstParty~/false at the end, and true for Microsoft's built-in scripts, which
 * the index does not tell apart, so every link says false).
 */
export const remediationUrl = (id, name = "") =>
  `${PORTAL}#view/Microsoft_Intune_Enrollment/UXAnalyticsScriptMenu/~/overview/id/${enc(id)}/scriptName/${enc(name)}/isFirstParty~/false`;

/** Entra group overview. VERIFIED 2026-10-27 (opens the group's Overview). */
export const groupUrl = (groupId) =>
  `${PORTAL}#view/Microsoft_AAD_IAM/GroupDetailsMenuBlade/~/Overview/groupId/${enc(groupId)}`;

/** Entra user overview. VERIFIED 2026-11-04 (the portal adds /hidePreviewBanner~/true, not needed). */
export const userUrl = (userId) =>
  `${PORTAL}#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/${enc(userId)}`;

/** An Intune report page from data/reports.js. path is the part after the host, so the link follows setPortalHost. */
export const reportUrl = (path) => `${PORTAL}${path}`;

/** Intune app overview. VERIFIED 2026-10-26 (opens the app). */
export const appUrl = (appId) =>
  `${PORTAL}#view/Microsoft_Intune_Apps/SettingsMenu/~/0/appId/${enc(appId)}`;

// List pages, used where a direct link to the object isn't known yet. Paths only: the host is added when a link
// is made, so they follow setPortalHost (a US Government cloud) like every other link.
const LIST_PAGES = {
  configuration: "#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/configuration",
  compliance: "#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/compliance",
  scripts: "#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/scripts",
  remediations: "#view/Microsoft_Intune_Enrollment/UXAnalyticsMenu/~/proactiveRemediations",
  apps: "#view/Microsoft_Intune_DeviceSettings/AppsMenu/~/allApps",
  updates: "#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/windows10Update",
  enrollment: "#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/enrollment",
  endpointSecurity: "#view/Microsoft_Intune_Workflows/SecurityManagementMenu/~/overview",
  appProtection: "#view/Microsoft_Intune_DeviceSettings/AppsMenu/~/protection",
  tenantAdmin: "#view/Microsoft_Intune_DeviceSettings/TenantAdminMenu/~/roles",
  home: "",
};

/** Best available link for a policy-like object of the given kind (see policy-types.js `area`). */
export function areaUrl(area) {
  return `${PORTAL}${LIST_PAGES[area] ?? LIST_PAGES.home}`;
}

/**
 * A settings catalog policy's summary page (also used by endpoint security policies built on the
 * catalog). VERIFIED 2026-11-04 from a live tenant's address bar (the earlier 2026-10-26 form was
 * #blade/... with isAssigned/true; the portal now shows #view/... with isAssigned~/true):
 *   #view/Microsoft_Intune_Workflows/PolicySummaryBlade/policyId/<id>/isAssigned~/true
 *     /technology/mdm/templateId//platformName/windows10
 * meta: { platforms, technologies, templateId } as Graph returns them; isAssigned from assignments.
 */
export function catalogPolicyUrl(id, meta = {}, isAssigned = false) {
  const tech = String(meta.technologies || "mdm").split(",")[0].trim() || "mdm";
  const platform = String(meta.platforms || "windows10").split(",")[0].trim() || "windows10";
  return `${PORTAL}#view/Microsoft_Intune_Workflows/PolicySummaryBlade/policyId/${enc(id)}/isAssigned~/${isAssigned ? "true" : "false"}` +
    `/technology/${enc(tech)}/templateId/${enc(meta.templateId || "")}/platformName/${enc(platform)}`;
}

/**
 * Link for any indexed policy: the policy itself where its URL format is known (settings
 * catalog), otherwise the list page for its kind. typeInfo is its POLICY_TYPES entry.
 */
export function policyUrl(policy, typeInfo) {
  if (policy?.type === "settingsCatalog") {
    return catalogPolicyUrl(policy.id, policy.meta || {}, (policy.assignments || []).some((a) => a.kind !== "exclude"));
  }
  if (policy?.type === "app") return appUrl(policy.id);
  if (policy?.type === "remediation") return remediationUrl(policy.id, policy.name);
  return areaUrl(typeInfo?.area);
}

/** The type, its label and the link for an indexed policy, as every report row shows them. */
export function policyRef(policy) {
  const typeInfo = TYPE_BY_KEY[policy.type];
  return { type: policy.type, typeLabel: typeInfo?.label || policy.type, link: policyUrl(policy, typeInfo) };
}
