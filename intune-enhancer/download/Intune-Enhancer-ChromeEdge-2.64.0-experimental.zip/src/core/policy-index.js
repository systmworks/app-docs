// Per-tenant index of every assignable Intune object (see policy-types.js): its name, its
// assignments, and, for configuration types, the settings it configures. Built on demand from
// the workspace, kept in the worker's IndexedDB (store.js), and shared by Setting check and Group assignments.
//
// A type the admin's role can't read is recorded in `errors` and skipped, so a partial index is
// still useful and the UI can say exactly what wasn't checked.

import { POLICY_TYPES, stripVersion } from "./policy-types.js";
import { extractCatalog, extractAdmx, extractProperties, normaliseAssignment } from "./settings-extract.js";
import { getItem, setItem, removePrefix } from "./store.js";
import { stoppedError } from "./graph.js";

const POLICY_KEY_PREFIX = "ie.policies.";
const POLICY_SCHEMA = 6; // 6: raw choice values (`r`), for the Baseline gap report; 2: settings catalog `meta` for deep links; 3: created/modified dates; 4: `odataType`, for the platform; 5: ADMX values set inside each setting
const POLICY_STALE_MS = 12 * 60 * 60 * 1000;
/** Policies whose settings are read in one batched go (see readSettings): caps the raw answers held at once. */
const SETTINGS_SLICE = 150;

export function createPolicyIndex(graph, { onProgress = () => {}, store = { getItem, setItem, removePrefix } } = {}) {
  let tid = null;
  let index = null; // { schema, builtAt, policies, errors }
  let building = null;
  let cancelled = false; // set by cancel(), checked between steps of a build
  let cleared = 0; // bumped by clearAll(): a build that started before a clear is not saved
  const batch = (requests, options = {}) => graph.batch(requests, { ...options, shouldStop: () => cancelled });
  let lastError = "";

  async function load(forTid) {
    if (tid === forTid && index) return;
    tid = forTid;
    index = null;
    const saved = await store.getItem(POLICY_KEY_PREFIX + tid);
    if (saved?.schema === POLICY_SCHEMA) index = saved;
  }

  async function readType(type, policies, errors) {
    let items;
    let perItemAssignments = !type.expand;
    try {
      items = await graph.all(`${type.path}${type.expand ? "?$expand=assignments" : ""}`);
    } catch (e) {
      if (type.expand && e.code === "HTTP" && e.status === 400) {
        // Some tenants/endpoints reject $expand=assignments; read them per item instead.
        items = await graph.all(type.path);
        perItemAssignments = true;
      } else {
        throw e;
      }
    }
    if (type.filter) items = items.filter(type.filter);

    if (perItemAssignments && items.length) {
      const base = stripVersion(type.path);
      const res = await batch(items.map((it) => ({ id: it.id, url: `${base}/${it.id}/assignments` })));
      for (const it of items) {
        const r = res.get(String(it.id));
        if (r?.status === 200) it.assignments = r.body?.value || [];
        else {
          // Unknown, not empty: Cleanup mustn't call it "Not assigned".
          it.assignmentsUnknown = true;
          errors[`${type.key}:assignments`] = r?.body?.error?.message || `HTTP ${r?.status}`;
        }
      }
    }

    // Settings, for the types that have them: one batched read per item, then each answer extracted. An answer
    // with more pages (a big policy) has the rest read by following its next link, so no setting is left out.
    const settingsById = new Map();
    const unreadable = new Set(); // policies whose settings read failed, so "no settings" is not claimed for them
    const partial = new Set(); // policies whose later settings pages failed: what was read is kept, and marked
    // fallback: a plainer query for the items whose answer Graph refused (HTTP 400), so a richer read never costs
    // the settings themselves.
    const readSettings = async (suffix, extract, options = {}, fallback = "") => {
      const base = stripVersion(type.path);
      const ask = (list, s, opts) => batch(list.map((it) => ({ id: it.id, url: `${base}/${it.id}/${s}` })), opts);
      // In slices: a catalog answer carries every setting's definition, so a whole type's raw answers at once could
      // be hundreds of MB in the worker on a large tenant. Each slice's answers go before the next is read.
      for (let start = 0; start < items.length; start += SETTINGS_SLICE) {
        const slice = items.slice(start, start + SETTINGS_SLICE);
        const onProgress = options.onProgress && ((done) => options.onProgress(start + done, items.length));
        const res = await ask(slice, suffix, onProgress ? { ...options, onProgress } : options);
        const refused = fallback ? slice.filter((it) => res.get(String(it.id))?.status === 400) : [];
        if (refused.length) for (const [id, r] of await ask(refused, fallback)) res.set(id, r);
        for (const it of slice) {
          const r = res.get(String(it.id));
          if (r?.status !== 200) { errors[`${type.key}:settings`] = r?.body?.error?.message || `HTTP ${r?.status}`; unreadable.add(it.id); continue; }
          let value = r.body?.value || [];
          const next = r.body?.["@odata.nextLink"];
          if (next) {
            if (cancelled) throw stoppedError();
            try {
              value = value.concat(await graph.all(next));
            } catch (e) {
              errors[`${type.key}:settings`] = `Only part of a policy's settings could be read: ${e?.message || e}`;
              partial.add(it.id);
            }
          }
          settingsById.set(it.id, extract(value));
        }
      }
    };
    if (type.settings === "catalog" && items.length) {
      await readSettings("settings?$expand=settingDefinitions&$top=1000", extractCatalog,
        { onProgress: (done, total) => onProgress({ building: true, step: `${type.label} settings`, done, total }) });
    } else if (type.settings === "admx" && items.length) {
      // The values set inside each setting (text, numbers, lists) are its presentation values.
      const definition = "definition($select=id,displayName,categoryPath,classType)";
      await readSettings(`definitionValues?$expand=${definition},presentationValues($expand=presentation)`, extractAdmx, undefined,
        `definitionValues?$expand=${definition}`);
    } else if (type.settings === "properties") {
      for (const it of items) settingsById.set(it.id, extractProperties(it));
    }

    for (const it of items) {
      policies.push({
        id: it.id,
        type: type.key,
        name: it[type.nameField] || it.displayName || it.name || "(unnamed)",
        assignments: (it.assignments || []).map(normaliseAssignment),
        ...(it.assignmentsUnknown ? { assignmentsUnknown: true } : {}),
        created: it.createdDateTime || "",
        modified: it.lastModifiedDateTime || it.modifiedDateTime || "",
        odataType: it["@odata.type"] || "",
        ...(settingsById.has(it.id) ? { settings: settingsById.get(it.id) } : {}),
        ...(unreadable.has(it.id) ? { settingsUnknown: true } : {}),
        ...(partial.has(it.id) ? { settingsPartial: true } : {}),
        // What a settings catalog policy's deep link needs (portal-links.js catalogPolicyUrl).
        ...(type.key === "settingsCatalog"
          ? { meta: { platforms: it.platforms || "", technologies: it.technologies || "", templateId: it.templateReference?.templateId || "" } }
          : {}),
      });
    }
  }

  async function build() {
    if (building) return building;
    const forTid = tid;
    const clearedAt = cleared;
    cancelled = false;
    building = (async () => {
      const policies = [];
      const errors = {};
      let n = 0;
      for (const type of POLICY_TYPES) {
        if (cancelled) throw stoppedError();
        onProgress({ building: true, step: type.label, done: n++, total: POLICY_TYPES.length });
        try {
          await readType(type, policies, errors);
        } catch (e) {
          if (e?.code === "CANCELLED") throw e;
          errors[type.key] = e?.message || String(e);
          if (e?.code === "NO_TOKEN") throw e;
        }
      }
      if (forTid !== tid || clearedAt !== cleared) return; // tenant switched or data cleared mid-build; discard
      index = { schema: POLICY_SCHEMA, builtAt: Date.now(), policies, errors };
      lastError = "";
      await store.setItem(POLICY_KEY_PREFIX + tid, index);
    })().catch((e) => {
      if (e?.code !== "CANCELLED") lastError = e?.message || String(e);
      throw e;
    }).finally(() => {
      building = null;
      onProgress({ building: false, count: index?.policies.length || 0 });
    });
    return building;
  }

  return {
    load,
    build,

    /** Stop a build in progress; it throws and saves nothing. */
    cancel() { if (building) cancelled = true; },

    /** The index for this tenant, building it first if there isn't one. */
    async get(forTid, { rebuild = false } = {}) {
      await load(forTid);
      if (!index || rebuild) {
        await build();
        // A build already running was for the tenant we just left and drops its result; build for this one.
        if (!index) await build();
      }
      return index;
    },

    /** The loaded index, or null; never triggers a build. */
    peek() {
      return index;
    },

    status() {
      return {
        tid,
        count: index?.policies.length || 0,
        builtAt: index?.builtAt || 0,
        stale: Boolean(index && Date.now() - index.builtAt > POLICY_STALE_MS),
        building: Boolean(building),
        errors: index?.errors || {},
        error: lastError,
      };
    },

    async clearAll() {
      cleared++;
      await store.removePrefix(POLICY_KEY_PREFIX);
      index = null;
      tid = null;
    },
  };
}
