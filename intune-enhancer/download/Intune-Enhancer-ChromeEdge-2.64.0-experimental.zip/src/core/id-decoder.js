// ID decoder: paste any Intune/Entra ID or admin center link and find out what it is.
// parseIds() is pure (tested offline); decodeIds() probes Graph with batched GETs, where a 404
// simply means "not this kind of object".

import { POLICY_TYPES, stripVersion } from "./policy-types.js";
import { deviceUrl, groupUrl, userUrl, appUrl, areaUrl, catalogPolicyUrl } from "./portal-links.js";
import { groupNames } from "./group-tools.js";
import { GUID_PATTERN } from "../shared/guid.js";

const GUID_RE = new RegExp(GUID_PATTERN, "gi");
// Labels the portal puts in front of ids in its URLs, mapped to the kind of object they name.
const URL_HINTS = {
  mdmdeviceid: "managedDevice", manageddeviceid: "managedDevice", deviceid: "device", objectid: "directoryObject",
  groupid: "group", userid: "user", appid: "app", policyid: "policy", scriptid: "policy", configurationid: "policy",
};
const MAX_IDS = 5;

/** Pull GUIDs (and any label in front of them, e.g. "groupId/<guid>") out of pasted text. */
export function parseIds(text) {
  const s = String(text || "");
  const seen = new Map();
  let m;
  GUID_RE.lastIndex = 0;
  while ((m = GUID_RE.exec(s)) && seen.size < MAX_IDS) {
    const guid = m[0].toLowerCase();
    if (seen.has(guid)) continue;
    const before = s.slice(Math.max(0, m.index - 30), m.index);
    const label = before.match(/([A-Za-z]+)(?:\/|=|%2F|%3D|~\/)$/i)?.[1]?.toLowerCase() || "";
    seen.set(guid, { guid, hint: URL_HINTS[label] || "" });
  }
  GUID_RE.lastIndex = 0;
  return [...seen.values()];
}

/** The probes for one id: [{ key, url, kind, label, link(body) }]. */
function probes(guid) {
  const q = (s) => encodeURIComponent(s);
  const list = [
    { key: "managedDevice", kind: "Intune managed device", url: `/deviceManagement/managedDevices/${guid}?$select=id,deviceName,userPrincipalName,operatingSystem`,
      name: (b) => b.deviceName, extra: (b) => [b.operatingSystem, b.userPrincipalName].filter(Boolean).join(", "), link: (b) => deviceUrl(b.id) },
    { key: "managedDeviceByAad", kind: "Entra device id of an Intune device", url: `/deviceManagement/managedDevices?$filter=${q(`azureADDeviceId eq '${guid}'`)}&$select=id,deviceName,userPrincipalName`,
      list: true, name: (b) => b.deviceName, extra: (b) => b.userPrincipalName || "", link: (b) => deviceUrl(b.id) },
    { key: "group", kind: "Group", url: `/groups/${guid}?$select=id,displayName,groupTypes`, name: (b) => b.displayName, link: (b) => groupUrl(b.id) },
    { key: "user", kind: "User", url: `/users/${guid}?$select=id,displayName,userPrincipalName`, name: (b) => b.displayName, extra: (b) => b.userPrincipalName, link: (b) => userUrl(b.id) },
    { key: "device", kind: "Entra device (object id)", url: `/devices/${guid}?$select=id,displayName,deviceId,operatingSystem`, name: (b) => b.displayName, extra: (b) => `Entra device id ${b.deviceId}` },
    { key: "deviceById", kind: "Entra device (device id)", url: `/devices?$filter=${q(`deviceId eq '${guid}'`)}&$select=id,displayName,operatingSystem`, list: true, name: (b) => b.displayName, extra: (b) => b.operatingSystem || "" },
    { key: "servicePrincipal", kind: "Enterprise app (service principal)", url: `/servicePrincipals/${guid}?$select=id,displayName,appId`, name: (b) => b.displayName, extra: (b) => `App id ${b.appId}` },
    { key: "spByAppId", kind: "Application (client) id", url: `/servicePrincipals?$filter=${q(`appId eq '${guid}'`)}&$select=id,displayName`, list: true, name: (b) => b.displayName },
    { key: "autopilot", kind: "Autopilot device", url: `/deviceManagement/windowsAutopilotDeviceIdentities/${guid}`, name: (b) => b.displayName || b.serialNumber, extra: (b) => b.serialNumber ? `Serial ${b.serialNumber}` : "" },
    { key: "filter", kind: "Assignment filter", url: `/deviceManagement/assignmentFilters/${guid}?$select=id,displayName,platform`, name: (b) => b.displayName, extra: (b) => b.platform || "" },
  ];
  for (const t of POLICY_TYPES) {
    list.push({
      key: `policy:${t.key}`, kind: t.label, url: `${stripVersion(t.path)}/${guid}`, policy: true,
      name: (b) => b[t.nameField] || b.displayName || b.name,
      extra: policyDetails,
      link: (b) => {
        if (t.key === "app") return appUrl(b.id);
        if (t.key === "settingsCatalog") {
          return catalogPolicyUrl(b.id, { platforms: b.platforms, technologies: b.technologies, templateId: b.templateReference?.templateId }, b.isAssigned);
        }
        return areaUrl(t.area);
      },
    });
  }
  return list;
}

const PLATFORMS = { windows10: "Windows", macOS: "macOS", iOS: "iOS/iPadOS", android: "Android", androidEnterprise: "Android Enterprise", linux: "Linux" };

/** Platform, setting count, publisher/version (apps), last modified and description. Pure. */
export function policyDetails(b) {
  const platform = String(b.platforms || "").split(",").map((p) => PLATFORMS[p.trim()] || p.trim()).filter(Boolean).join(", ") ||
    // "windows10CustomConfiguration" -> "windows 10 Custom": a space before each capital and around each run of digits.
    String(b["@odata.type"] || "").replace("#microsoft.graph.", "").replace(/(Configuration|CompliancePolicy|Policy|Profile|App)$/, "")
      .replace(/([a-z])([0-9])/g, "$1 $2").replace(/([a-z0-9])([A-Z])/g, "$1 $2");
  const modified = b.lastModifiedDateTime ? `modified ${new Date(b.lastModifiedDateTime).toLocaleDateString()}` : "";
  return [
    platform,
    b.settingCount ? `${b.settingCount} setting${b.settingCount === 1 ? "" : "s"}` : "",
    b.publisher || "",
    b.displayVersion ? `v${b.displayVersion}` : "",
    modified,
    b.description ? String(b.description).slice(0, 160) : "",
  ].filter(Boolean).join(" · ");
}

/** "Assigned to A, B (filter); excludes C" from normalised assignments and group names. Pure. */
export function assignmentSummary(assignments, names = {}) {
  if (!assignments?.length) return "Not assigned";
  const label = (a) => {
    const filter = a.filterId ? ` (filter ${a.filterType || "on"})` : "";
    if (a.kind === "allDevices") return `All devices${filter}`;
    if (a.kind === "allUsers") return `All users${filter}`;
    return `${names[a.groupId] || a.groupId || "?"}${a.intent ? ` [${a.intent}]` : ""}${filter}`;
  };
  const inc = assignments.filter((a) => a.kind !== "exclude").map(label);
  const exc = assignments.filter((a) => a.kind === "exclude").map(label);
  return [inc.length ? `Assigned to ${inc.join(", ")}` : "", exc.length ? `excludes ${exc.join(", ")}` : ""].filter(Boolean).join("; ");
}

// Probe keys that match each URL_HINTS kind, tried before the full set of 30+ probes.
const HINT_PROBES = {
  managedDevice: ["managedDevice"],
  device: ["managedDeviceByAad", "device", "deviceById"],
  directoryObject: ["device", "user", "group", "servicePrincipal"],
  group: ["group"],
  user: ["user"],
  app: ["policy:app", "spByAppId"],
  policy: POLICY_TYPES.map((t) => `policy:${t.key}`),
};

/**
 * Decode up to MAX_IDS ids. Returns [{ guid, hint, matches: [{ kind, name, extra, assigned, link }] }].
 * policyIndex (optional, if already built) adds who each policy is assigned to.
 */
export async function decodeIds(graph, text, policyIndex = null) {
  const ids = parseIds(text);
  if (!ids.length) return { ids: [], message: "No IDs found. Paste an ID (a GUID) or an admin center link." };
  const all = [];
  for (const { guid } of ids) for (const p of probes(guid)) all.push({ ...p, guid, id: `${guid}|${p.key}` });
  const ask = (list) => graph.batch(list.map((p) => ({ id: p.id, url: p.url })));
  const hit = (p) => res.get(p.id)?.status === 200 && (!p.list || res.get(p.id).body?.value?.length > 0);

  // An id whose link names its kind is probed for that kind first; every other kind only if that misses.
  const hintOf = new Map(ids.map((x) => [x.guid, HINT_PROBES[x.hint]]));
  const first = new Set(all.filter((p) => !hintOf.get(p.guid) || hintOf.get(p.guid).includes(p.key)));
  const res = await ask([...first]);
  const found = new Set([...first].filter(hit).map((p) => p.guid));
  const rest = all.filter((p) => !first.has(p) && !found.has(p.guid));
  if (rest.length) for (const [id, r] of await ask(rest)) res.set(id, r);

  const decoded = ids.map(({ guid, hint }) => {
    const matches = [];
    for (const p of all.filter((x) => x.guid === guid)) {
      const r = res.get(p.id);
      if (r?.status !== 200 || !r.body) continue;
      const bodies = p.list ? r.body.value || [] : [r.body];
      for (const b of bodies) {
        const indexed = p.policy ? policyIndex?.policies.find((x) => x.id === b.id) : null;
        matches.push({
          kind: p.kind, name: p.name(b) || "(unnamed)", extra: p.extra?.(b) || "", link: p.link?.(b) || "", id: b.id || guid,
          ...(indexed ? { assignments: indexed.assignments } : {}),
        });
      }
    }
    return { guid, hint, matches };
  });

  // Group names for the assignment summaries.
  const groupIds = decoded.flatMap((d) => d.matches.flatMap((m) => (m.assignments || []).map((a) => a.groupId))).filter(Boolean);
  const names = groupIds.length ? await groupNames(graph, groupIds).catch(() => ({})) : {};
  for (const d of decoded) {
    for (const m of d.matches) {
      if (m.assignments) m.assigned = assignmentSummary(m.assignments, names);
      delete m.assignments;
    }
  }
  return { ids: decoded, policyIndexBuiltAt: policyIndex?.builtAt || 0 };
}
