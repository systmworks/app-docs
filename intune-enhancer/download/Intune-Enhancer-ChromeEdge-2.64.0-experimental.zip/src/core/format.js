// Small text and number formatters, and the one search rule, shared by the report modules, the worker and the
// workspace. Pure.

const BYTES_PER_GIB = 1024 ** 3;

/** Bytes as a number of GB (1024 ** 3 bytes). */
export const gb = (bytes) => Number(bytes) / BYTES_PER_GIB;

/** Bytes as "12.3 GB". */
export const gbText = (bytes) => `${gb(bytes).toFixed(1)} GB`;

/** The date part ("2025-01-31") of an ISO date-time, or "" when it is missing or the 1970 placeholder. */
export const day = (iso) => (Date.parse(iso) > 864e5 ? String(iso).slice(0, 10) : "");

/**
 * The one search rule for every search box: split a query into lower-case words; quoted phrases stay together.
 * A row matches when its text holds every word, in any order (hasAllWords).
 */
export function searchWords(query) {
  const out = [];
  const re = /"([^"]+)"|(\S+)/g;
  let m;
  while ((m = re.exec(String(query ?? "")))) out.push((m[1] || m[2]).trim().toLowerCase());
  return out.filter(Boolean);
}

/** True when `text` holds every one of `words` (from searchWords), any case. No words matches everything. */
export const hasAllWords = (text, words) => {
  const t = String(text ?? "").toLowerCase();
  return words.every((w) => t.includes(w));
};

/** "windowsAzureADJoin" -> "Windows Azure AD Join". */
export const words = (text) => String(text ?? "").replace(/([a-z])([A-Z])/g, "$1 $2").replace(/([A-Z])([A-Z][a-z])/g, "$1 $2").replace(/^./, (c) => c.toUpperCase());
