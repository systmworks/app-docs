// The Microsoft clouds the extension can work in. Commercial is built in. The two US Government clouds
// (GCC High and DoD) are optional: the admin grants their hosts from the workspace's Settings tab
// (optional host permissions), so existing users are not asked to accept anything new.
//
// Checked 2026-11-04: Microsoft Learn (Graph national clouds) gives graph.microsoft.us for GCC High,
// dod-graph.microsoft.us for DoD, portal.azure.us and login.microsoftonline.us for both; intune.microsoft.us
// answers (endpoint.microsoft.us redirects to it). Not confirmed by any document: that DoD uses
// intune.microsoft.us too, and the frame host. Still EXPERIMENTAL: never tried on a government tenant. All hosts are here,
// in one place, to fix if one turns out to differ.

export const DEFAULT_CLOUD = "commercial";

export const CLOUDS = {
  commercial: { graphHost: "graph.microsoft.com", portalHost: "intune.microsoft.com" },
  gcch: { graphHost: "graph.microsoft.us", portalHost: "intune.microsoft.us" },
  dod: { graphHost: "dod-graph.microsoft.us", portalHost: "intune.microsoft.us" },
};

/**
 * What the admin allows in Settings for both government clouds (one permission request): the two Graph
 * hosts, the admin center, and the Azure Government portal (which the Learn pages also name as the Intune
 * admin portal), whose list frames are on its subdomains.
 */
export const GOV = {
  topHosts: ["intune.microsoft.us", "portal.azure.us"],
  frameMatch: "https://*.portal.azure.us/*",
  origins: [
    "https://graph.microsoft.us/*",
    "https://dod-graph.microsoft.us/*",
    "https://intune.microsoft.us/*",
    "https://portal.azure.us/*",
    "https://*.portal.azure.us/*",
  ],
};

/** Every host a Graph request may go to. */
export const GRAPH_HOSTS = Object.values(CLOUDS).map((c) => c.graphHost);

/**
 * Cloud key for the portal host a token came from, refined by the token's audience when that names a Graph
 * host (the only way to tell DoD from GCC High, which share the admin center). Unknown hosts are commercial. Pure.
 */
export function cloudFor(host, aud = "") {
  const h = String(host || "").toLowerCase();
  const a = String(aud || "").toLowerCase();
  if (!GOV.topHosts.includes(h) && !h.endsWith(".portal.azure.us")) return DEFAULT_CLOUD;
  return a.includes("dod-graph.microsoft.us") ? "dod" : "gcch";
}

/** Cloud settings for a key, falling back to commercial. Pure. */
export const cloudOf = (key) => CLOUDS[key] || CLOUDS[DEFAULT_CLOUD];
