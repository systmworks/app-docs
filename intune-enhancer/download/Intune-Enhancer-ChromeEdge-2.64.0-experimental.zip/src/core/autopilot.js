// Autopilot failures report: the deployment events behind Intune's "Windows Autopilot deployments (preview)" list
// (Graph beta deviceManagement/autopilotEvents, kept by Intune for 30 days), each with the per-policy and per-app
// status of its enrollment status page (ESP) where Intune has it, and the device's Autopilot registration record.
// All reads. The report keeps every field Intune sends, so the format can be decided from real data: field names
// are matched loosely and nothing here is verified against a live tenant yet.

import { isTransient, sayOnce } from "./graph.js";
import { joinAutopilot, J_MAX } from "./autopilot-joins.js";

const EVENT_ID = /^[\w.-]{1,128}$/;

/** When the deployment happened (ISO text), or "". Pure. */
export const eventWhen = (e) => String(e?.enrollmentStartDateTime || e?.deploymentStartDateTime || e?.eventDateTime || e?.deviceRegisteredDateTime || "");

/** "failure", "success", "inprogress" or "unknown", from Intune's deployment state (or enrollment state). Pure. */
export function eventState(e) {
  const t = String(e?.deploymentState ?? "").toLowerCase();
  if (/fail/.test(t)) return "failure";
  if (/succe/.test(t)) return "success";
  if (/progress/.test(t)) return "inprogress";
  if (/fail/.test(String(e?.enrollmentState ?? "").toLowerCase())) return "failure";
  return "unknown";
}

/** The ESP items (apps and policies) that failed, from an event's policy status details. Pure. */
export function failedItems(details) {
  return (Array.isArray(details) ? details : []).filter((d) => {
    const status = String(d?.complianceStatus ?? d?.status ?? "").toLowerCase();
    const code = d?.errorCode;
    return /fail|error|noncompliant|conflict/.test(status) || (code !== undefined && code !== null && Number(code) !== 0 && code !== "");
  });
}

/**
 * The ways Graph might serve an event's enrollment status page items. A live tenant refused the sub-resource in a
 * batch ("Resource not found for the segment") and the plain single-event read (400), so the newest event is tried
 * with each way in turn, one request at a time (full refusal text kept), and the first that works is used for the rest.
 */
const espWays = (r) => {
  const id = encodeURIComponent(r.id);
  const dev = encodeURIComponent(String(r.event?.deviceId || r.id).replace(/^autopilot_/, ""));
  return [
    { name: "event sub-resource", url: (x) => `/deviceManagement/autopilotEvents/${x}/policyStatusDetails`, key: id, pick: (b) => b?.value },
    { name: "event with $expand", url: (x) => `/deviceManagement/autopilotEvents/${x}?$expand=policyStatusDetails`, key: id, pick: (b) => b?.policyStatusDetails },
    { name: "device id sub-resource", url: (x) => `/deviceManagement/autopilotEvents/${x}/policyStatusDetails`, key: dev, pick: (b) => b?.value },
    { name: "single event", url: (x) => `/deviceManagement/autopilotEvents/${x}`, key: id, pick: (b) => b?.policyStatusDetails },
  ];
};

async function readEspItems(graph, toRead) {
  const tried = [];
  let way = null, firstBody = null;
  for (const w of espWays(toRead[0])) {
    try {
      const body = await graph.get(`/beta${w.url(w.key)}`);
      const items = w.pick(body);
      if (Array.isArray(items)) { way = w.name; firstBody = { body, items }; break; }
      tried.push(`${w.name}: answered without items`);
    } catch (e) {
      tried.push(`${w.name}: ${String(e?.message || e).replace(/\s+/g, " ").slice(0, 260)}`);
    }
  }
  if (!way) {
    sayOnce("autopilot-details", "warn", "Autopilot ESP items unavailable:", tried.join(" | "));
    const text = `Graph gave no enrollment status page items by any of the ${tried.length} ways tried (the full refusals are in the service worker console).`;
    for (const r of toRead) r.detailsNote = text;
    return;
  }
  sayOnce("autopilot-esp-way", "info", "Autopilot ESP items read by:", way);
  const w = espWays(toRead[0]).find((x) => x.name === way);
  const apply = (r, body, items) => {
    r.details = items;
    if (body && typeof body === "object" && !Array.isArray(body)) {
      const { policyStatusDetails, value, ...whole } = body;
      for (const [k, v] of Object.entries(whole)) if (!k.startsWith("@odata") && !(k in r.event)) r.event = { ...r.event, [k]: v };
    }
    if (r.details[0]) sayOnce("autopilot-detail-fields", "info", "Autopilot ESP detail fields:", Object.keys(r.details[0]).join(", "));
    if (!r.details.length) r.detailsNote = "Intune sent no enrollment status page items for this event.";
  };
  apply(toRead[0], firstBody.body, firstBody.items);
  const rest = toRead.slice(1);
  if (!rest.length) return;
  const res = await graph.batch(rest.map((r, n) => {
    const ww = espWays(r).find((x) => x.name === way);
    return { id: String(n), url: ww.url(ww.key) };
  }));
  rest.forEach((r, n) => {
    const x = res.get(String(n));
    const items = x?.status === 200 ? w.pick(x.body) : null;
    if (Array.isArray(items)) apply(r, x.body, items);
    else if (isTransient(x)) r.detailsNote = "Intune was busy; read again to try once more.";
    else r.detailsNote = `Intune refused the event (${x?.status ?? "no answer"})${x?.body?.error?.message ? `: ${String(x.body.error.message).slice(0, 200)}` : ""}.`;
  });
}

/**
 * Autopilot deployment events from the last `days` days, newest first, each as
 * { id, when, state, event (every field Intune sent), details, detailsNote, identity }.
 * details: the event's ESP status items (null when Intune has none or refused; detailsNote says which).
 * identity: the matching Autopilot device record (by serial number), or null.
 */
export async function autopilotEvents(graph, days, now = Date.now()) {
  const cutoff = now - days * 864e5;
  const all = await graph.all("/beta/deviceManagement/autopilotEvents");
  const events = all
    .map((e) => ({ id: String(e.id ?? ""), when: eventWhen(e), state: eventState(e), event: e }))
    .filter((r) => !r.when || Date.parse(r.when) >= cutoff)
    .sort((a, b) => b.when.localeCompare(a.when));
  if (events[0]) sayOnce("autopilot-fields", "info", "Autopilot event fields:", Object.keys(events[0].event).join(", "));

  // ESP details, newest events first (successes too, so a refusal can be told from "no items"). Some tenants send them
  // inline, otherwise they are read per event.
  const need = events.filter((r) => EVENT_ID.test(r.id)).slice(0, J_MAX);
  for (const r of events) { r.details = Array.isArray(r.event.policyStatusDetails) ? r.event.policyStatusDetails : null; r.detailsNote = ""; }
  const toRead = need.filter((r) => !r.details);
  if (toRead.length) await readEspItems(graph, toRead);

  // The device's Autopilot registration record: model, group tag, profile assignment state, last contact.
  let identities = new Map();
  try {
    const list = await graph.all("/beta/deviceManagement/windowsAutopilotDeviceIdentities");
    identities = new Map(list.filter((i) => i.serialNumber).map((i) => [String(i.serialNumber).toLowerCase(), i]));
  } catch (e) {
    sayOnce("autopilot-identities", "warn", "Autopilot device records unavailable:", e?.message || e);
  }
  for (const r of events) r.identity = identities.get(String(r.event.deviceSerialNumber || "").toLowerCase()) || null;
  try { await joinAutopilot(graph, events); } catch (e) { sayOnce("autopilot-joins", "warn", "Autopilot joins unavailable:", e?.message || e); }
  return events;
}
