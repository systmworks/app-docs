// The extra rows of Device quick facts, from one managed device's full record (read when the admin asks
// for "More details"). Pure, so it is tested offline. Only values Graph returned are shown.

import { gbText, words } from "./format.js";
import { hardwareRow } from "./hardware.js";

/** [[label, value], ...] for the rows Graph filled in. */
export function detailRows(device) {
  const rows = [];
  const add = (label, value) => {
    if (value !== undefined && value !== null && String(value).trim() !== "") rows.push([label, String(value)]);
  };
  const known = (value) => (value && value !== "unknown" ? words(value) : "");
  const total = Number(device?.totalStorageSpaceInBytes) || 0;
  const free = Number(device?.freeStorageSpaceInBytes);
  // The plain text facts come from the Hardware report's field list, so each is defined once.
  const hw = hardwareRow(device || {});

  add("Serial number", hw.serial);
  add("Manufacturer", hw.manufacturer);
  add("Memory", Number(device?.physicalMemoryInBytes) > 0 ? gbText(device.physicalMemoryInBytes) : "");
  add("Storage", total > 0 && Number.isFinite(free) ? `${gbText(free)} free of ${gbText(total)}` : "");
  add("Encrypted", hw.encrypted);
  add("TPM version", hw.tpm);
  add("Windows edition", hw.edition);
  add("IP address", hw.ip);
  add("Wi-Fi MAC", hw.wifiMac);
  add("Ethernet MAC", hw.ethMac);
  add("Enrolment type", hw.enrolment);
  add("Join type", hw.join);
  add("Managed by", known(device?.managementAgent));
  return rows;
}
