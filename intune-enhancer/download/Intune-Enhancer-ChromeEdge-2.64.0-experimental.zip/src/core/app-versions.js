// Discovered apps rolled up by app name: every version found and how many devices run it, and the devices
// running chosen versions. The shaping is pure, so it is tested offline and runs on sample data; the two
// reads are GETs (one paged list, one $batch).

import { compareVersions } from "./device-reports.js";
import { odataQuote } from "./graph.js";
import { deviceUrl } from "./portal-links.js";

const MAX_APPS = 50;
const APP_DEVICE_FIELDS = "id,deviceName,userPrincipalName,userDisplayName,operatingSystem,osVersion,lastSyncDateTime,complianceState";

/** Discovered apps whose name contains the query, rolled up by app; [] for an empty query. */
export async function searchDetectedApps(graph, query) {
  const q = String(query || "").trim().slice(0, 100);
  if (!q) return [];
  const filter = encodeURIComponent(`contains(displayName,'${odataQuote(q)}')`);
  return rollupApps(await graph.all(`/beta/deviceManagement/detectedApps?$filter=${filter}&$select=id,displayName,version,publisher,deviceCount,platform&$top=500`));
}

/** One managed device as Graph lists it under a discovered app, in the workspace's device shape. Pure. */
const detectedAppDevice = (d, version) => ({
  managedId: d.id, name: d.deviceName || "", upn: d.userPrincipalName || "", displayName: d.userDisplayName || "", os: d.operatingSystem || "",
  osVersion: d.osVersion || "", lastSync: d.lastSyncDateTime || "", compliance: d.complianceState || "", appVersion: String(version || "").slice(0, 64), link: deviceUrl(d.id),
});

/**
 * The devices running the given discovered app versions, items [{ id, version }], in one $batch.
 * Returns { devices, failed }: failed counts the versions Graph would not list.
 */
export async function appDevices(graph, items) {
  const res = await graph.batch(items.map((i, n) => ({ id: String(n), url: `/deviceManagement/detectedApps/${encodeURIComponent(i.id)}/managedDevices?$select=${APP_DEVICE_FIELDS}` })));
  const devices = [];
  let failed = 0;
  items.forEach((i, n) => {
    const r = res.get(String(n));
    if (r?.status !== 200) { failed++; return; }
    for (const d of r.body?.value || []) devices.push(detectedAppDevice(d, i.version));
  });
  return { devices, failed };
}

/** True when `version` is older than `minimum`. (compareVersions sorts newest first, so older is positive.) */
export const isBelowVersion = (version, minimum) => compareVersions(version, minimum) > 0;

/**
 * @param detected Graph detectedApps: { id, displayName, version, publisher, deviceCount, platform }
 * @returns [{ name, publisher, platform, total, versions: [{ id, version, devices }] }], busiest app
 *   first, each app's versions newest first
 */
export function rollupApps(detected) {
  const apps = new Map();
  for (const item of detected || []) {
    const name = String(item.displayName || "").trim();
    if (!name) continue;
    const publisher = String(item.publisher || "").trim();
    const key = `${name.toLowerCase()}|${publisher.toLowerCase()}`;
    if (!apps.has(key)) apps.set(key, { name, publisher, platform: String(item.platform || ""), total: 0, versions: [] });
    const app = apps.get(key);
    const devices = Number(item.deviceCount) || 0;
    app.versions.push({ id: item.id, version: String(item.version || ""), devices });
    app.total += devices;
  }
  for (const app of apps.values()) app.versions.sort((a, b) => compareVersions(a.version, b.version));
  return [...apps.values()].sort((a, b) => b.total - a.total || a.name.localeCompare(b.name)).slice(0, MAX_APPS);
}
