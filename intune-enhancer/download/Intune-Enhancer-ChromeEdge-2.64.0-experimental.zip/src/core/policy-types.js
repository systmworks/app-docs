// Every Intune object type that can be assigned to groups, and how to read it from Graph.
// Used by the policy index (Setting check, Group assignments) and the ID decoder.
//
//   path      list endpoint (beta: most Intune assignment data is only complete there)
//   expand    true if the list supports $expand=assignments; otherwise /{id}/assignments is
//             read per item
//   settings  how to read configured settings, if the type has them (see settings-extract.js)
//   area      list page in the portal (portal-links.js areaUrl)
//   nameField property holding the display name

export const POLICY_TYPES = [
  { key: "settingsCatalog", label: "Settings catalog", path: "/beta/deviceManagement/configurationPolicies", nameField: "name", expand: true, settings: "catalog", area: "configuration" },
  { key: "deviceConfig", label: "Device configuration (template)", path: "/beta/deviceManagement/deviceConfigurations", nameField: "displayName", expand: true, settings: "properties", area: "configuration" },
  { key: "adminTemplate", label: "Administrative template", path: "/beta/deviceManagement/groupPolicyConfigurations", nameField: "displayName", expand: true, settings: "admx", area: "configuration" },
  { key: "compliance", label: "Compliance policy", path: "/beta/deviceManagement/deviceCompliancePolicies", nameField: "displayName", expand: true, settings: "properties", area: "compliance" },
  { key: "endpointSecurityLegacy", label: "Endpoint security (legacy)", path: "/beta/deviceManagement/intents", nameField: "displayName", expand: false, area: "endpointSecurity" },
  { key: "remediation", label: "Remediation", path: "/beta/deviceManagement/deviceHealthScripts", nameField: "displayName", expand: true, area: "remediations" },
  { key: "windowsScript", label: "Platform script (Windows)", path: "/beta/deviceManagement/deviceManagementScripts", nameField: "displayName", expand: true, area: "scripts" },
  { key: "macScript", label: "Shell script (macOS)", path: "/beta/deviceManagement/deviceShellScripts", nameField: "displayName", expand: true, area: "scripts" },
  { key: "macCustomAttribute", label: "Custom attribute (macOS)", path: "/beta/deviceManagement/deviceCustomAttributeShellScripts", nameField: "displayName", expand: true, area: "scripts" },
  { key: "app", label: "App", path: "/beta/deviceAppManagement/mobileApps", nameField: "displayName", expand: true, area: "apps",
    // Only apps that actually have assignments matter here, and the built-in store catalogue is large.
    filter: (item) => item.isAssigned !== false },
  { key: "appConfigDevice", label: "App configuration (managed devices)", path: "/beta/deviceAppManagement/mobileAppConfigurations", nameField: "displayName", expand: true, area: "apps" },
  { key: "appConfigApps", label: "App configuration (managed apps)", path: "/beta/deviceAppManagement/targetedManagedAppConfigurations", nameField: "displayName", expand: true, area: "apps" },
  { key: "appProtectionIos", label: "App protection (iOS)", path: "/beta/deviceAppManagement/iosManagedAppProtections", nameField: "displayName", expand: true, area: "appProtection" },
  { key: "appProtectionAndroid", label: "App protection (Android)", path: "/beta/deviceAppManagement/androidManagedAppProtections", nameField: "displayName", expand: true, area: "appProtection" },
  { key: "appProtectionWindows", label: "App protection (Windows)", path: "/beta/deviceAppManagement/windowsManagedAppProtections", nameField: "displayName", expand: true, area: "appProtection" },
  { key: "featureUpdate", label: "Windows feature update", path: "/beta/deviceManagement/windowsFeatureUpdateProfiles", nameField: "displayName", expand: true, area: "updates" },
  { key: "qualityUpdate", label: "Windows quality update", path: "/beta/deviceManagement/windowsQualityUpdateProfiles", nameField: "displayName", expand: true, area: "updates" },
  { key: "driverUpdate", label: "Windows driver update", path: "/beta/deviceManagement/windowsDriverUpdateProfiles", nameField: "displayName", expand: true, area: "updates" },
  { key: "enrollmentConfig", label: "Enrollment configuration", path: "/beta/deviceManagement/deviceEnrollmentConfigurations", nameField: "displayName", expand: true, area: "enrollment" },
  { key: "autopilotProfile", label: "Autopilot profile", path: "/beta/deviceManagement/windowsAutopilotDeploymentProfiles", nameField: "displayName", expand: true, area: "enrollment" },
  { key: "policySet", label: "Policy set", path: "/beta/deviceAppManagement/policySets", nameField: "displayName", expand: true, area: "home" },
  { key: "termsAndConditions", label: "Terms and conditions", path: "/beta/deviceManagement/termsAndConditions", nameField: "displayName", expand: true, area: "tenantAdmin" },
];

export const TYPE_BY_KEY = Object.fromEntries(POLICY_TYPES.map((t) => [t.key, t]));

/** "/beta/deviceManagement/x" -> "/deviceManagement/x", for $batch requests (relative to a version). */
export const stripVersion = (path) => path.replace(/^\/(beta|v1\.0)/, "");
