// One report, three files: a report document ({ title, subtitle, headline, sections }) written as Markdown, as a
// self-contained HTML page (opens anywhere, and the browser's Print saves it as a PDF), or as CSV rows. Each section
// is a small count table: { title, of, ofLabel, labelHeading, countHeading, note, rows: [{ label, count }] }, its
// percentages taken of `of` (countHeading: what is counted, "Devices" unless the section says otherwise). A section
// can instead be a plain table, { title, head: [labels], cells: [[text]], note }, drawn full width (a report page read as it is on screen).
// The HTML uses the workspace's light theme colours (copied from workspace.css, defined once in its :root) on a white
// page whatever theme the workspace is in, and asks the browser to keep the box fills when it prints. Pure.

import { escapeHtml } from "../shared/escape.js";
// Text from the tenant (a device, group or policy name) written into a Markdown line: line breaks flattened, and a backslash, backtick,
// [ ] < > escaped so a name such as ![](https://x/p.png) or <img src=x> cannot become an image, a link or HTML where the copy is pasted.
const rdLine = (s) => String(s ?? "").replace(/\s*[\r\n]\s*/g, " ").replace(/[\\`[\]<>]/g, "\\$&");
const rdCell = (s) => rdLine(s).replace(/\|/g, "\\|");

/** A count as a percentage of a base, "37%" (one decimal under 10%), "" without a base. */
export const docPercent = (count, of) => {
  if (!of) return "";
  const p = (count / of) * 100;
  return `${p > 0 && p < 10 ? p.toFixed(1) : Math.round(p)}%`;
};

/** The report as Markdown: title, headline facts, one table per section. */
export function docMarkdown(doc) {
  const md = [`# ${rdLine(doc.title)}`, "", ...(doc.subtitle ? [rdLine(doc.subtitle), ""] : []), ...(doc.headline || []).map((h) => `- ${rdLine(h.label)}: ${rdLine(h.value)}`)];
  for (const s of doc.sections) {
    md.push("", `## ${rdLine(s.title)}`, "");
    if (s.cells) {
      const n = Math.max(s.head?.length || 0, ...s.cells.map((r) => r.length));
      const pad = (r) => Array.from({ length: n }, (_, i) => rdCell(r[i]));
      if (s.cells.length) md.push(`| ${pad(s.head || []).join(" | ")} |`, `|${"---|".repeat(n)}`, ...s.cells.map((r) => `| ${pad(r).join(" | ")} |`));
    } else if (s.rows.length) md.push(`| ${rdCell(s.labelHeading || "Value")} | ${rdCell(s.countHeading || "Devices")} | % of ${rdCell(s.ofLabel || "devices")} |`, "|---|---:|---:|", ...s.rows.map((r) => `| ${rdCell(r.label)} | ${r.count} | ${docPercent(r.count, s.of)} |`));
    if (s.note) md.push("", rdLine(s.note));
  }
  return md.join("\n") + "\n";
}

/** The report as one HTML page with its own small stylesheet: two sections side by side, each kept on one page. */
export function docHtml(doc) {
  const head = (doc.headline || []).map((h) => `<div><strong>${escapeHtml(h.value)}</strong>${escapeHtml(h.label)}</div>`).join("");
  const plain = (s) => `<section class="wide"><h2>${escapeHtml(s.title)}</h2><table>${s.head?.length ? `<tr>${s.head.map((h) => `<th>${escapeHtml(h)}</th>`).join("")}</tr>` : ""}${s.cells.map((r) => `<tr>${r.map((c) => `<td>${escapeHtml(c)}</td>`).join("")}</tr>`).join("")}</table>${s.note ? `<p class="note">${escapeHtml(s.note)}</p>` : ""}</section>`;
  const sections = doc.sections.map((s) => s.cells ? plain(s) : `<section><h2>${escapeHtml(s.title)}</h2>${s.rows.length
    ? `<table><tr><th>${escapeHtml(s.labelHeading || "Value")}</th><th class="n">${escapeHtml(s.countHeading || "Devices")}</th><th class="n">%</th><th class="b"></th></tr>${s.rows.map((r) => {
      const p = s.of ? Math.round((r.count / s.of) * 100) : 0;
      return `<tr><td>${escapeHtml(r.label)}</td><td class="n">${r.count.toLocaleString()}</td><td class="n">${docPercent(r.count, s.of)}</td><td class="b"><span style="width:${p}%"></span></td></tr>`;
    }).join("")}</table>` : ""}${s.note ? `<p class="note">${escapeHtml(s.note)}</p>` : ""}</section>`).join("");
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><title>${escapeHtml(doc.title)}</title><style>
:root{--page:#ffffff;--fg:#10203c;--muted:#46628a;--line:#aec7ea;--fill:#e9f1fc;--accent:#175cd3;--bar:#008aff;color-scheme:light}
*{-webkit-print-color-adjust:exact;print-color-adjust:exact}
body{font:13px/1.4 system-ui,"Segoe UI",sans-serif;margin:24px auto;max-width:960px;padding:0 16px;background:var(--page);color:var(--fg)}
h1{font-size:22px;margin:0}h2{font-size:15px;margin:0 0 6px;color:var(--accent)}.sub,.note{color:var(--muted)}.note{font-size:12px;margin:6px 0 0}
.head{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:16px 0}
.head div{border:1px solid var(--line);border-radius:8px;padding:8px 12px;background:var(--fill);color:var(--muted)}.head strong{display:block;font-size:20px;color:var(--accent)}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.foot{margin:18px 0 0;font-size:12px;color:var(--muted);text-align:center}.wide{grid-column:1/-1}.wide td{vertical-align:top;white-space:pre-wrap}
section{border:1px solid var(--line);border-radius:8px;padding:10px 12px;break-inside:avoid;background:var(--fill)}
table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:2px 6px;border-bottom:1px solid var(--line)}th{font-weight:600;color:var(--muted)}
.n{text-align:right;white-space:nowrap}td.b{width:25%}td.b span{display:block;height:6px;border-radius:3px;background:var(--bar)}
@page{margin:12mm}@media print{body{margin:0}}
</style></head><body><h1>${escapeHtml(doc.title)}</h1>${doc.subtitle ? `<p class="sub">${escapeHtml(doc.subtitle)}</p>` : ""}<div class="head">${head}</div><div class="grid">${sections}</div><p class="foot">Created with Intune Enhancer. &copy; 2026 Systmworks. All rights reserved.</p></body></html>`;
}

/** The report as CSV rows: Section, Value, Count, %. */
export function docCsvRows(doc) {
  return [["Section", "Value", "Count", "%"],
    ...(doc.headline || []).map((h) => ["Summary", h.label, h.value, ""]),
    ...doc.sections.flatMap((s) => (s.rows || []).map((r) => [s.title, r.label, r.count, docPercent(r.count, s.of)]))];
}
