// Quick pill filters for a long report: a group is { key, label, value: (row) => text or [text], order?: [text] }, and the
// admin picks pills in one or more groups. A row matches when, in every group that has a pick, it has one of the picked
// values (AND across groups, OR within one). The pills show only values some row has, with how many rows have each. Pure,
// so any report can use it (chipBar in workspace/core.js draws them).

import { ageDays } from "./device-reports.js";

const values = (row, group) => [].concat(group.value(row) ?? []).map((v) => String(v).trim()).filter(Boolean);

/** The pills of one group: its values with a row count each, in the group's own `order` if it has one, else most rows first. */
export function chipOptions(rows, group, max = 10) {
  const counts = new Map();
  for (const row of rows) for (const v of new Set(values(row, group))) counts.set(v, (counts.get(v) || 0) + 1);
  const list = [...counts].map(([value, count]) => ({ value, count }));
  if (group.order) return list.sort((a, b) => group.order.indexOf(a.value) - group.order.indexOf(b.value));
  return list.sort((a, b) => b.count - a.count || a.value.localeCompare(b.value)).slice(0, max);
}

/** Whether a row passes the picks ({ groupKey: Set of values }): AND across groups, OR within a group, no pick = no limit. */
export const chipMatch = (row, groups, picked) => groups.every((g) => {
  const want = picked[g.key];
  return !want?.size || values(row, g).some((v) => want.has(v));
});

/**
 * Every group's pills with the count each would leave: the pills (and their order) come from all the rows, but a pill's count is
 * the rows that pass the OTHER groups' picks, so a pill that would leave nothing shows 0 (the page greys it out). `rows` are the
 * ones the report's own search and filters let through.
 */
export function chipFacets(rows, groups, picked, max = 10) {
  return groups.map((group) => {
    const others = groups.filter((g) => g !== group);
    const left = new Map(chipOptions(rows.filter((r) => chipMatch(r, others, picked)), group, Infinity).map((o) => [o.value, o.count]));
    return { group, options: chipOptions(rows, group, max).map((o) => ({ value: o.value, count: left.get(o.value) || 0 })) };
  });
}

export const AGE_BUCKETS = ["Last 7 days", "8 to 30 days", "31 to 90 days", "Over 90 days", "Never"];

/** How long ago a date (a day or a timestamp) was, as one of AGE_BUCKETS; "" is "Never". */
export function ageBucket(date, now = Date.now()) {
  const days = ageDays(date, now);
  if (days === null) return "Never";
  return days <= 7 ? AGE_BUCKETS[0] : days <= 30 ? AGE_BUCKETS[1] : days <= 90 ? AGE_BUCKETS[2] : AGE_BUCKETS[3];
}
