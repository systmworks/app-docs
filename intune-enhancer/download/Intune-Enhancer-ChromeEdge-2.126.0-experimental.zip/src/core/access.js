// "Check my access": which Microsoft Graph areas the signed-in admin's own sign-in can read, so an empty or partial report can be
// explained by a missing Intune role, scope tag or Entra role. One record is asked for from each area (the same paths the tools
// already read, so nothing new is read) and only the answer is kept: allowed or refused, with Graph's own message. Pure answer
// code here (the offline tests cover it); the one network function takes the Graph client.

/** The areas checked: a path (relative to Graph's beta root, as graph.batch sends it) and the tools that need it. */
export const ACCESS_AREAS = [
  { id: "devices", label: "Devices", url: "/deviceManagement/managedDevices?$top=1", usedBy: "Device 360, Device explorer, Hardware, OS builds, Stale devices, Low storage, Security posture" },
  { id: "encryption", label: "Device encryption states", url: "/deviceManagement/managedDeviceEncryptionStates?$top=1", usedBy: "Hardware, Security posture" },
  { id: "configs", label: "Configuration profiles", url: "/deviceManagement/deviceConfigurations?$top=1", usedBy: "Policy export, Cleanup, Setting check, Duplicate policies" },
  { id: "catalog", label: "Settings catalog policies", url: "/deviceManagement/configurationPolicies?$top=1", usedBy: "Policy export, Cleanup, Setting check, Duplicate policies" },
  { id: "compliance", label: "Compliance policies", url: "/deviceManagement/deviceCompliancePolicies?$top=1", usedBy: "Policy export, Cleanup" },
  { id: "complianceSummary", label: "Compliance setting results", url: "/deviceManagement/deviceCompliancePolicySettingStateSummaries?$top=1", usedBy: "Compliance" },
  { id: "scripts", label: "Scripts", url: "/deviceManagement/deviceManagementScripts?$top=1", usedBy: "Policy export, Cleanup" },
  { id: "remediations", label: "Remediations", url: "/deviceManagement/deviceHealthScripts?$top=1", usedBy: "Policy export, Cleanup" },
  { id: "apps", label: "Apps", url: "/deviceAppManagement/mobileApps?$top=1", usedBy: "App details, App versions, Failed apps, Cleanup" },
  { id: "detectedApps", label: "Discovered apps", url: "/deviceManagement/detectedApps?$top=1", usedBy: "App versions" },
  { id: "filters", label: "Assignment filters", url: "/deviceManagement/assignmentFilters?$top=1", usedBy: "Cleanup, Group assignments, Device 360" },
  { id: "autopilot", label: "Autopilot devices", url: "/deviceManagement/windowsAutopilotDeviceIdentities?$top=1", usedBy: "Autopilot failures" },
  { id: "autopilotEvents", label: "Autopilot deployment events", url: "/deviceManagement/autopilotEvents?$top=1", usedBy: "Autopilot failures" },
  { id: "roles", label: "Intune role assignments", url: "/deviceManagement/roleAssignments?$top=1", usedBy: "Group assignments" },
  { id: "groups", label: "Groups (Entra)", url: "/groups?$top=1", usedBy: "Group assignments, Group roster, Compare users, Cleanup" },
  { id: "users", label: "Users (Entra)", url: "/users?$top=1", usedBy: "User 360, Compare users, Orphaned users" },
  { id: "entraDevices", label: "Devices (Entra)", url: "/devices?$top=1", usedBy: "Device 360, Autopilot failures" },
  { id: "conditionalAccess", label: "Conditional Access policies", url: "/identity/conditionalAccess/policies?$top=1", usedBy: "Group assignments" },
];

const detailOf = (r) => String(r?.body?.error?.message || "").replace(/\s+/g, " ").slice(0, 200);

/**
 * One row per area from Graph's answers, Map(id -> { status, body }): can is "Yes" (200), "No" (401 or 403, with Graph's own
 * message, which names the missing role when Intune says) or "Unknown" (anything else, or no answer).
 */
export function accessRows(answers) {
  return ACCESS_AREAS.map((a) => {
    const r = answers.get(a.id);
    const can = r?.status === 200 ? "Yes" : r?.status === 401 || r?.status === 403 ? "No" : "Unknown";
    const detail = can === "Yes" ? "" : detailOf(r) || (r ? `Graph answered ${r.status}` : "No answer");
    return { id: a.id, area: a.label, usedBy: a.usedBy, can, detail };
  });
}

/**
 * Ask each area for one record. A refusal inside the batch only means the first token tried lacks the scope (the portal keeps
 * several), so each refused area is asked again on its own, which tries every token, before it counts as No.
 * @returns { rows, at }
 */
export async function checkAccess(graph) {
  const answers = await graph.batch(ACCESS_AREAS.map((a) => ({ id: a.id, url: a.url })));
  for (const a of ACCESS_AREAS) {
    const r = answers.get(a.id);
    if (r?.status !== 401 && r?.status !== 403) continue;
    try {
      await graph.get(`/beta${a.url}`);
      answers.set(a.id, { status: 200, body: null });
    } catch (e) {
      answers.set(a.id, { status: e?.status || r.status, body: { error: { message: String(e?.message || "").replace(/^Graph \d+:\s*/, "") } } });
    }
  }
  return { rows: accessRows(answers), at: Date.now() };
}
