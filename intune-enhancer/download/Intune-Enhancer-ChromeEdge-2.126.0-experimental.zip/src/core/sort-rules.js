// The rules every sortable report table follows (docs/sort-plan.md). Pure: no DOM, no Intune data.
//
// A column is { key, label, type?, num?, first? }. type is "text" (the default), "num" or "date"; num: true is the older spelling of
// type "num". first overrides the direction of the first click (1 ascending, -1 descending). A sort state is { key, dir }, with dir 1
// ascending and -1 descending, and key "" or null for the table's own order.
//
// First click: text A to Z; numbers and dates biggest or newest first. A second click reverses. Empty values always sort last, either way.

/** The type of a column: "text", "num" or "date". */
export const colType = (col) => col?.type || (col?.num ? "num" : "text");

/** The direction of the first click on a column: text 1 (A to Z), num and date -1 (biggest or newest first), unless the column says `first`. */
export const firstDir = (col) => (col?.first === 1 || col?.first === -1 ? col.first : colType(col) === "text" ? 1 : -1);

/**
 * What a cell value sorts as, or null when it is empty (empty sorts last either way). text: the string; num: a number, after taking out
 * "," and "%" and spaces; date: milliseconds from a timestamp or an ISO date ("2026-11-21"), where the 0001 and 1970 placeholders Graph
 * sends for "never" and anything that is not a date count as empty.
 */
export function sortKey(value, type = "text") {
  if (value === undefined || value === null || value === "") return null;
  if (type === "num") {
    const n = typeof value === "number" ? value : parseFloat(String(value).replace(/[,%\s]/g, ""));
    return Number.isNaN(n) ? null : n;
  }
  if (type === "date") {
    const ms = typeof value === "number" ? value : Date.parse(value);
    return ms > 864e5 ? ms : null;
  }
  return String(value);
}

/** Two sort keys in ascending order (text with numbers inside, such as versions, in numeric order: 1.2.9 before 1.2.10). */
export const compareKeys = (a, b, type = "text") => (type === "text" ? String(a).localeCompare(String(b), undefined, { numeric: true }) : a - b);

/**
 * The rows in the order of the sort state, as a new array. value(row, key) reads a cell's value (default row[key]). A state whose key
 * is not a column keeps the rows' own order. Empty values sort last whichever way the sort runs; ties keep their order.
 */
export function sortRows(rows, cols, state, value = (row, key) => row[key]) {
  const col = cols.find((c) => c.key === state?.key);
  if (!col) return [...rows];
  const type = colType(col);
  const dir = state.dir < 0 ? -1 : 1;
  return rows.map((row, i) => ({ row, i, k: sortKey(value(row, col.key), type) }))
    .sort((a, b) => (a.k === null ? (b.k === null ? 0 : 1) : b.k === null ? -1 : compareKeys(a.k, b.k, type) * dir) || a.i - b.i)
    .map((x) => x.row);
}

/** The sort state after a click on a column: the same column reverses, another column starts in its first direction. */
export const nextSort = (state, col) => ({ key: col.key, dir: state?.key === col.key ? -state.dir : firstDir(col) });
