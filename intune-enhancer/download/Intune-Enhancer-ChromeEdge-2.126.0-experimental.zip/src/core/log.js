// The Console tab's log: pure helpers. The worker keeps the list in chrome.storage.session (the browser session only, never
// written to disk) and the workspace page draws it. Nothing secret goes in: redact() strips anything that looks like a token.

import { serialQueue } from "./serial.js";

/** Most Console entries kept; older ones fall off the front. */
export const MAX_LOG = 200;
export const LEVELS = ["info", "warn", "error"];

/** Text safe to keep: JWTs and Bearer values replaced, and cut to a sensible length. */
export const redact = (text) => String(text ?? "")
  .replace(/eyJ[\w-]{8,}\.[\w-]{8,}(\.[\w-]*)?/g, "[token]")
  .replace(/Bearer\s+[\w.~+/=-]+/gi, "Bearer [token]")
  .slice(0, 600);

/** The list with one more entry, keeping only the newest `max`. */
export const addEntry = (list, entry, max = MAX_LOG) => [...list, entry].slice(-max);

/** One Console entry from its parts: time now, a known level, a short source, and redacted text. */
export const makeEntry = (level, source, message, detail = "", now = Date.now()) => ({
  t: now,
  level: LEVELS.includes(level) ? level : "error",
  source: String(source).slice(0, 40),
  message: redact(message),
  detail: redact(detail).slice(0, 200),
});

/**
 * The list kept in `storage` (chrome.storage.session) under `key`, with every add, read and clear run one after another:
 * two lines logged while the worker wakes can't both read the old list and overwrite each other, and a clear can't be
 * undone by a line that was already reading. add() rejects if storage does; the caller decides whether that matters.
 */
export function createLogStore(storage, key, now = Date.now) {
  const after = serialQueue();
  let cache = null;
  const load = async () => (cache ??= (await storage.get(key))[key] || []);
  return {
    add: (level, source, message, detail = "") => after(async () => {
      cache = addEntry(await load(), makeEntry(level, source, message, detail, now()));
      await storage.set({ [key]: cache });
    }),
    get: () => after(load),
    clear: () => after(async () => { cache = []; await storage.remove(key); }),
  };
}
