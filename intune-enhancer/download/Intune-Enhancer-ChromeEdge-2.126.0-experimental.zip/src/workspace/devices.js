// Device tools: the device list tabs (OS builds, Device explorer, Stale and duplicates, Low storage), Orphaned users,
// Compliance (with its failing devices), Hardware and Security posture. Moved out of workspace.js without changes to
// the code (see docs/workspace-split-plan.md).

import { osSpread, updateCheck, staleDevices, lowStorageDevices, duplicateDevices } from "../core/device-reports.js";
import { searchWords, hasAllWords } from "../core/format.js";
import { hardwareColumns, POSTURE_FIELDS } from "../core/hardware.js";
import { postureIssues, postureCounts } from "../core/security-posture.js";
import { EXPLORER_FIELDS, EXPLORER_DEFAULT, explorerRow } from "../core/device-explorer.js";
import { ageBucket, AGE_BUCKETS } from "../core/chip-filter.js";
import { createSorter, sortedTable } from "./sort.js";
import { $, $$, SAMPLE, ago, appState, badgeCounts, bindExport, capped, checkInCell, chipBar, complianceBadge, complianceRank, copyTsv, emptyBox, errorBox, esc, exportButtons, fillPlatforms, friendlyOs, jobBar, link, loadDevices, loading, newestOnly, onEnterOrClear, oneAtATime, ownerLabel, registerTab, runInto, saveCsv, savePrefs, scopeIds, scopeNote, scoped, send, showBanner, showExport, tableHtml, tableWrap, td, userOf } from "./core.js";

// ------------------------------------------------------------------------------------------
// Device list (shared by OS builds and Stale & duplicates), loaded once per visit

function renderDeviceIndexLine() {
  for (const el of $$(".device-index-line")) {
    el.innerHTML = appState.devicesCache
      ? `Device list: ${appState.devicesCache.devices.length.toLocaleString()}${appState.scope ? ` of ${appState.devicesCache.total.toLocaleString()}` : ""} devices${appState.scope ? ` (scope: ${esc(appState.scope.name)})` : ""}, updated ${esc(ago(appState.devicesCache.builtAt))}. <button class="link" data-refresh-devices>Refresh</button>`
      : "";
  }
}

document.addEventListener("click", async (e) => {
  if (!e.target.closest?.("[data-refresh-devices]")) return;
  for (const el of $$(".device-index-line")) el.innerHTML = '<span class="spinner"></span>Reading devices...';
  try {
    if (!SAMPLE) await send("index/rebuild");
    await loadDevices(true);
    showDeviceTab(appState.currentTab);
  } catch (err) {
    for (const el of $$(".device-index-line")) el.textContent = err.message;
  }
});

/** The tools drawn from the device list (devices/list), redrawn when it is refreshed or the scope changes. */
export const DEVICE_TABS = ["os", "hygiene", "storage", "explorer"];

// What each tool does when its tab opens (selectTab in core.js calls it); returning true skips focusing the first field.
registerTab(DEVICE_TABS, (name) => { showDeviceTab(name); return true; }); // the device report tabs load the device list the first time they're shown
registerTab("orphans", () => { if (!orphans) runOrphans(); return true; });
registerTab(["hardware", "posture"], (name) => { if (!appState.hwData) loadSavedHardware(); else if (name === "posture") renderPosture(); return true; });

export async function showDeviceTab(name) {
  const out = $(name === "os" ? "#os-results" : name === "storage" ? "#storage-results" : name === "explorer" ? "#explorer-results" : "#stale-results");
  if (!appState.devicesCache) {
    out.innerHTML = loading("Reading your devices...");
    if (name === "hygiene") $("#dupe-results").innerHTML = "";
  }
  try {
    await loadDevices();
  } catch (err) {
    out.innerHTML = errorBox(err);
    return;
  }
  renderDeviceIndexLine();
  if (name === "os") renderOs();
  else if (name === "storage") renderStorage();
  else if (name === "explorer") renderExplorer();
  else renderHygiene();
}

// Device explorer: every device in the device list, with the columns the admin picks (saved as explorerColumns).

const exSorter = createSorter("explorer", { key: "name", dir: 1 }, () => renderExplorer());
let exColumns = EXPLORER_DEFAULT;

/** Take the column choice from the saved prefs. */
export function applyExplorerColumns(prefs) {
  exColumns = Array.isArray(prefs.explorerColumns) && prefs.explorerColumns.length ? prefs.explorerColumns : EXPLORER_DEFAULT;
  if (appState.currentTab === "explorer" && appState.devicesCache) renderExplorer();
}

// Pills over the explorer's rows (explorerRow text), picked and counted by chipBar.
const exChips = chipBar([
  { key: "os", label: "Platform", value: (r) => r.os },
  { key: "compliance", label: "Compliance", value: (r) => r.compliance },
  { key: "owner", label: "Ownership", value: (r) => r.owner },
  { key: "seen", label: "Last check-in", value: (r) => ageBucket(r.lastSync), order: AGE_BUCKETS },
], () => renderExplorer());

/** Pills for a list of devices from the device list (Low storage, Stale devices): compliance, ownership and last check-in, read with the explorer's own field getters. */
const deviceChips = (onChange) => chipBar([
  { key: "compliance", label: "Compliance", value: EXPLORER_FIELDS.find((f) => f.key === "compliance").get },
  { key: "owner", label: "Ownership", value: EXPLORER_FIELDS.find((f) => f.key === "owner").get },
  { key: "seen", label: "Last check-in", value: (d) => ageBucket(d.lastSync), order: AGE_BUCKETS },
], onChange);

/** The explorer's columns (only fields some device has), its matching rows in sort order, and every row. */
function exView() {
  const all = appState.devicesCache.devices.map((d) => explorerRow(d, globalThis.IEWindowsBuilds?.friendly));
  const present = hardwareColumns(all, EXPLORER_FIELDS);
  const cols = present.filter((f) => f.key === "name" || exColumns.includes(f.key));
  const words = searchWords($("#ex-filter").value);
  const searched = all.filter((r) => hasAllWords(cols.map((c) => r[c.key]).join("\n"), words));
  const rows = exSorter.apply(searched.filter(exChips.test), cols, (r, key) => r[key]);
  return { all, searched, present, cols, rows };
}

function renderExplorer() {
  const { all, searched, present, cols, rows } = exView();
  $("#ex-cols").innerHTML = present.map((f) => `<label class="inline"><input type="checkbox" data-ex-col="${esc(f.key)}"${cols.includes(f) ? " checked" : ""}${f.key === "name" ? " disabled" : ""}> ${esc(f.label)}</label>`).join("");
  $("#ex-chips").innerHTML = exChips.html(searched);
  $("#ex-count").textContent = `${rows.length.toLocaleString()} of ${all.length.toLocaleString()} devices`;
  showExport("explorer", rows.length > 0);
  $("#explorer-results").innerHTML = rows.length
    ? capped(rows, (shown) => sortedTable(exSorter, cols, shown, (r) => cols.map((c) => td(c.key === "name" ? link(r.link, r.name) : esc(r[c.key] ?? ""),
      c.num ? "num" : c.nowrap ? "nowrap" : ""))), 2000)
    : emptyBox("No device matches the filter.");
}

onEnterOrClear($("#ex-filter"), renderExplorer);
$("#ex-chips").addEventListener("click", (e) => exChips.handle(e));
$("#ex-cols").addEventListener("change", () => {
  exColumns = $$("[data-ex-col]:checked", $("#ex-cols")).map((el) => el.dataset.exCol);
  savePrefs({ explorerColumns: exColumns }).catch((e) => showBanner(`Couldn't save the columns: ${e.message}`));
  renderExplorer();
});
bindExport("explorer", () => {
  const { cols, rows } = exView();
  return [cols.map((c) => c.label), ...rows.map((r) => cols.map((c) => r[c.key] ?? ""))];
}, () => "devices.csv");

// ------------------------------------------------------------------------------------------
// OS builds

let spread = null;
const osOpen = new Set(); // the OS builds release rows left open ("pi:ri"), so a sort keeps them open
const updOpen = new Set(); // the same for Update check ("i")

/** A table cell with a bar `value` / `max` long, and `title` on hover (OS builds, Update check). */
const barCell = (value, max, title) => td(`<div class="bar" title="${esc(title)}"><span style="width:${max ? (value / max * 100).toFixed(1) : 0}%"></span></div>`);

/** Opens or closes the hidden row under a Show button, filling it with fill() the first time it opens. labels: [closed, open]. `open` is the set that remembers it. */
function toggleSubRow(btn, row, fill, [closed, open], openSet, key) {
  row.hidden = !row.hidden;
  btn.textContent = row.hidden ? closed : open;
  if (row.hidden) openSet.delete(key); else openSet.add(key);
  if (!row.hidden && !row.firstElementChild.innerHTML) row.firstElementChild.innerHTML = fill();
}

/** A release row and the row under it that Show opens; drawn open (filled by fill()) when `open`, so a sort keeps a release open. */
const releaseRows = (cells, colspan, subAttr, open, fill) =>
  `<tr>${cells.join("")}</tr><tr class="sub"${open ? "" : " hidden"}><td colspan="${colspan}" ${subAttr}>${open ? fill() : ""}</td></tr>`;

// Each sorter below keeps its own state by id: one per platform table, one per opened device list.
const subSorters = new Map();
const subSorter = (id, redraw) => { if (!subSorters.has(id)) subSorters.set(id, createSorter(id, { key: "" }, redraw)); return subSorters.get(id); };

const REL_COLS = [{ key: "name", label: "Device" }, { key: "user", label: "Primary user" }, { key: "os", label: "OS version" },
  { key: "compliance", label: "Compliance", type: "num", first: 1 }, { key: "sync", label: "Last check-in", type: "date" }];
const relValue = (d, k) => ({ name: d.name, user: userOf(d), os: friendlyOs(d.os, d.osVersion), compliance: complianceRank(d.compliance), sync: d.lastSync }[k]);

/** The devices under an OS builds or Update check row, already in the sorter's order: the first 1,000, and a note when there are more. */
const releaseDeviceTable = (list, sorter) => sortedTable(sorter, REL_COLS, list.slice(0, 1000), (d) => [
  td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
  td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)),
]) + (list.length > 1000 ? `<p class="muted small" style="margin:6px 10px">Showing 1,000 of ${list.length}. Copy or save includes all.</p>` : "");

// OS builds: one table per platform, one row per release (Show devices opens its devices; the list is by name until a heading is clicked).
const OS_COLS = [{ key: "label", label: "Release" }, { key: "count", label: "Devices", num: true }, { key: "share", label: "Share", num: true }];
const osSorter = (pi) => subSorter(`os-${pi}`, drawOs);
const osDevSorter = (pi, ri) => subSorter(`os-${pi}-${ri}`, () => fillOsSub(pi, ri));
/** The devices of one release in screen order. */
const osList = (pi, ri) => osDevSorter(pi, ri).apply([...spread.platforms[pi].releases[ri].devices].sort((a, b) => a.name.localeCompare(b.name)), REL_COLS, relValue);

function osSub(pi, ri) {
  return `<div class="toolbar" style="margin:8px 10px">
      <strong>${esc(spread.platforms[pi].releases[ri].label)}</strong><span class="spacer"></span>
      <button class="export" data-os-copy="${pi}:${ri}">Copy table</button><button class="export" data-os-csv="${pi}:${ri}">Save CSV</button></div>` +
    releaseDeviceTable(osList(pi, ri), osDevSorter(pi, ri));
}
function fillOsSub(pi, ri) {
  const cell = $(`[data-os-sub="${pi}:${ri}"]`);
  if (cell) cell.innerHTML = osSub(pi, ri);
}

function renderOs() {
  spread = osSpread(appState.devicesCache.devices, globalThis.IEWindowsBuilds?.friendly);
  osOpen.clear();
  if (upd && upd.list !== appState.devicesCache) { upd = null; $("#upd-results").innerHTML = ""; } // a refreshed list or a new scope
  if (!spread.total) { $("#os-results").innerHTML = emptyBox("No managed devices."); return; }
  drawOs();
}

function drawOs() {
  $("#os-results").innerHTML = spread.platforms.map((p, pi) => {
    const top = Math.max(...p.releases.map((r) => r.count));
    const sorter = osSorter(pi);
    const rows = sorter.apply(p.releases.map((r, ri) => ({ r, ri })), OS_COLS, (x, k) => x.r[k === "share" ? "count" : k]).map(({ r, ri }) => {
      const open = osOpen.has(`${pi}:${ri}`);
      return releaseRows([
        td(esc(r.label)),
        td(r.count.toLocaleString(), "num"),
        td(`${(r.count / p.count * 100).toFixed(r.count / p.count < 0.1 ? 1 : 0)}%`, "num"),
        barCell(r.count, top, `${r.count} of ${p.count} ${p.os} devices`),
        td(`<button class="link" data-os="${pi}:${ri}">${open ? "Hide devices" : "Show devices"}</button>`),
      ], 5, `data-os-sub="${pi}:${ri}"`, open, () => osSub(pi, ri));
    });
    return `<article class="card">
      <h2>${esc(p.os)} <span class="muted">· ${p.count.toLocaleString()} device${p.count === 1 ? "" : "s"} (${(p.count / spread.total * 100).toFixed(0)}% of all)</span></h2>
      ${tableWrap(sorter.head(OS_COLS) + "<th></th><th></th>", rows.join(""))}
    </article>`;
  }).join("");
}

$("#os-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-os]");
  if (btn) {
    const [pi, ri] = btn.dataset.os.split(":").map(Number);
    toggleSubRow(btn, $(`[data-os-sub="${btn.dataset.os}"]`).parentElement, () => osSub(pi, ri), ["Show devices", "Hide devices"], osOpen, btn.dataset.os);
    return;
  }
  const exp = e.target.closest("button[data-os-copy], button[data-os-csv]");
  if (!exp) return;
  const [pi, ri] = (exp.dataset.osCopy || exp.dataset.osCsv).split(":").map(Number);
  const rel = spread.platforms[pi].releases[ri];
  const rows = [["Device", "Primary user", "UPN", "OS", "OS version", "Release", "Compliance", "Last check-in"],
    ...osList(pi, ri).map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, rel.label, d.compliance, d.lastSync])];
  if (exp.dataset.osCopy) copyTsv(exp, rows);
  else saveCsv(`os-build-${rel.label}.csv`, rows);
});

// Update check (OS builds): Windows devices behind the newest build on your devices, or a build typed. Runs on Enter or
// the button, from the device list the tab already reads (no Graph read of its own).
let upd = null; // { list: the devicesCache it was worked out from, result: updateCheck() }
const UPD_COLS = [{ key: "label", label: "Release" }, { key: "build", label: "Checked against" }, { key: "have", label: "Up to date", num: true }, { key: "behind", label: "Behind", num: true }];
const updSorter = createSorter("upd", { key: "" }, () => { if (upd) $("#upd-results").innerHTML = renderUpdateCheck(upd.result); });
const updDevSorter = (i) => subSorter(`upd-${i}`, () => { const cell = $(`[data-upd-sub="${i}"]`); if (cell) cell.innerHTML = releaseDeviceTable(updList(i), updDevSorter(i)); });
/** The releases of the last Update check in screen order, each with its index (the Show behind button and the list under it use it). */
const updReleases = (r) => updSorter.apply(r.releases.map((rel, i) => ({ rel, i })), UPD_COLS, (x, k) => (k === "behind" ? x.rel.behind.length : x.rel[k]));
/** The behind devices of one release in screen order. */
const updList = (i) => updDevSorter(i).apply(upd.result.releases[i].behind, REL_COLS, relValue);

$("#upd-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const out = $("#upd-results");
  try {
    if (!appState.devicesCache) out.innerHTML = loading("Reading your devices...");
    await loadDevices();
  } catch (err) { out.innerHTML = errorBox(err); return; }
  const result = updateCheck(appState.devicesCache.devices, globalThis.IEWindowsBuilds?.friendly, $("#upd-build").value);
  upd = result.error ? null : { list: appState.devicesCache, result };
  updOpen.clear(); // a new answer: the releases are new, so no sort or open row carries over
  updSorter.reset();
  for (const [id, s] of subSorters) if (id.startsWith("upd-")) s.reset();
  out.innerHTML = result.error ? emptyBox(result.error) : renderUpdateCheck(result);
});

/** The Update check card: one row per Windows release, with its behind devices under a Show behind row. */
function renderUpdateCheck(r) {
  if (!r.releases.length) {
    return emptyBox(r.target ? `No Windows device in the device list is on build ${r.target.split(".")[0]}.` : "No Windows device in the device list reports a build.");
  }
  const rows = updReleases(r).map(({ rel, i }) => {
    const total = rel.have + rel.behind.length;
    const open = updOpen.has(String(i));
    return releaseRows([
      td(esc(rel.label)), td(esc(rel.build)), td(rel.have.toLocaleString(), "num"),
      td(`<span class="badge ${rel.behind.length ? "bad" : "ok"}">${rel.behind.length.toLocaleString()}</span>`, "num"),
      barCell(rel.have, total, `${rel.have} of ${total} up to date`),
      td(rel.behind.length ? `<button class="link" data-upd="${i}">${open ? "Hide" : "Show behind"}</button>` : ""),
    ], 6, `data-upd-sub="${i}"`, open, () => releaseDeviceTable(updList(i), updDevSorter(i)));
  });
  const unknown = r.releases.reduce((n, rel) => n + rel.unknown, 0);
  const notes = [
    r.target ? "" : "Each release is checked against the newest build any of your devices on it reports, which may be an optional preview update. Type a build to check against a specific one (Microsoft's Windows release information page lists the build for each update).",
    r.others.length ? `Not checked against this build: ${r.others.map((o) => `${o.label} (${o.count})`).join(", ")}. Each release has its own build numbers.` : "",
    unknown ? `${unknown} device${unknown === 1 ? "" : "s"} reported no build revision and ${unknown === 1 ? "is" : "are"} left out.` : "",
    "Every monthly Windows update raises the build, so a device below it is missing that update or a later one. Other updates (.NET, Office) don't change the build.",
  ].filter(Boolean);
  return `<article class="card">
    <div class="toolbar tight"><h2 style="margin:0">Update check</h2>
      <span class="muted">${r.target ? `against build ${esc(r.target)}` : "against the newest build on your devices, per release"}</span>
      <span class="spacer"></span>${exportButtons("upd")}</div>
    ${tableWrap(updSorter.head(UPD_COLS) + "<th></th><th></th>", rows.join(""))}
    ${notes.map((n) => `<p class="muted small" style="margin:8px 0 0">${esc(n)}</p>`).join("")}
  </article>`;
}

$("#upd-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-upd]");
  if (!btn || !upd) return;
  const i = Number(btn.dataset.upd);
  toggleSubRow(btn, $(`[data-upd-sub="${i}"]`).parentElement, () => releaseDeviceTable(updList(i), updDevSorter(i)), ["Show behind", "Hide"], updOpen, String(i));
});

// Update check's Copy table and Save CSV: every Windows device checked, with whether it is up to date, the releases in screen order.
bindExport("upd", () => upd && [["Device", "Primary user", "UPN", "Release", "OS version", "Checked against", "Status", "Compliance", "Last check-in"],
  ...updReleases(upd.result).flatMap(({ rel }) => {
    const behind = new Set(rel.behind);
    return rel.devices.map((d) => [d.name, d.displayName, d.upn, rel.label, d.osVersion, rel.build, behind.has(d) ? "Behind" : "Up to date", d.compliance, d.lastSync]);
  })], () => `update-check${upd?.result.target ? `-${upd.result.target}` : ""}.csv`);

// ------------------------------------------------------------------------------------------
// Compliance breakdown

let compData = null;
const compRun = newestOnly();
const COMP_COLS = [{ key: "setting", label: "Setting" }, { key: "platform", label: "Platform" }, { key: "failing", label: "Failing", num: true },
  { key: "nonCompliant", label: "Not compliant", num: true }, { key: "error", label: "Error", num: true }, { key: "conflict", label: "Conflict", num: true }, { key: "compliant", label: "Compliant", num: true }];
const compSorter = createSorter("compliance", { key: "" }, () => { if (compData) $("#comp-results").innerHTML = renderCompliance(compData); });
const compSorted = (r) => compSorter.apply(r.rows, COMP_COLS, (x, k) => x[k]);

function renderCompliance(r) {
  if (!r.rows.length) return emptyBox(`No compliance setting is failing on any device${r.passing ? ` (${r.passing.toLocaleString()} settings checked)` : ""}.`);
  return `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${r.rows.length.toLocaleString()} failing setting${r.rows.length === 1 ? "" : "s"}; ${r.passing.toLocaleString()} with no failures</span>
      <span class="spacer"></span>
      ${exportButtons("comp")}
    </div>` +
    sortedTable(compSorter, COMP_COLS, compSorted(r), (x) => [td(esc(x.setting)), td(esc(x.platform)), td(`<strong>${x.failing.toLocaleString()}</strong>`, "num"), td(x.nonCompliant.toLocaleString(), "num"),
        td(x.error.toLocaleString(), "num"), td(x.conflict.toLocaleString(), "num"), td(x.compliant.toLocaleString(), "num"),
        td(`<button class="link" data-comp="${esc(x.id)}" data-name="${esc(x.setting)}">Devices</button>`)], { extra: "<th></th>" }) + "</article>";
}

function compRows() {
  return [["Setting", "Platform", "Failing", "Not compliant", "Error", "Conflict", "Compliant"],
    ...(compData ? compSorted(compData) : []).map((x) => [x.setting, x.platform, x.failing, x.nonCompliant, x.error, x.conflict, x.compliant])];
}

// Pills over the devices failing one compliance setting; a new setting starts with none picked.
const redrawCompDevices = () => { if (appState.compDevices) $("#comp-devices").innerHTML = renderCompDevices(appState.compDevices.name, appState.compDevices.list); };
const compChips = chipBar([
  { key: "state", label: "State", value: (d) => d.state },
  { key: "os", label: "Platform", value: (d) => d.os },
  { key: "seen", label: "Last check-in", value: (d) => ageBucket(d.lastSync), order: AGE_BUCKETS },
], redrawCompDevices);
const COMPDEV_COLS = [{ key: "name", label: "Device" }, { key: "user", label: "User" }, { key: "state", label: "State" }, { key: "os", label: "OS" }, { key: "sync", label: "Last check-in", type: "date" }];
const compDevSorter = createSorter("compdev", { key: "" }, redrawCompDevices);
/** The picked chips' devices in screen order (an empty last check-in, shown as unknown, sorts last). */
const compFiltered = (all) => compDevSorter.apply(all.filter(compChips.test), COMPDEV_COLS, (d, k) => ({ name: d.name, user: d.user, state: d.state, os: d.os, sync: d.lastSync }[k]));
const compShown = () => compFiltered(appState.compDevices?.list || []);

function compDeviceRows() {
  return [["Device", "User", "UPN", "State", "OS", "Last check-in"], ...compShown().map((d) => [d.name, d.user, d.upn || "", d.state, d.os, d.lastSync])];
}

function renderCompDevices(name, all) {
  const list = compFiltered(all);
  return `<article class="card">
    <div class="toolbar tight">
      <h2>${esc(name)}: ${list.length.toLocaleString()} failing device${list.length === 1 ? "" : "s"}${esc(scopeNote())}</h2>
      <span class="spacer"></span>
      ${exportButtons("compdev")}
    </div>${compChips.html(all)}` + (list.length
      ? capped(list, (rows) => sortedTable(compDevSorter, COMPDEV_COLS, rows, (d) => [td(d.inList ? link(d.link, d.name) : esc(d.name), "nowrap"), td(esc(d.user)), td(esc(d.state)), td(esc(d.os)), td(d.lastSync ? checkInCell(d.lastSync) : '<span class="muted">unknown</span>')]))
      : '<p class="muted">No device is failing this setting now.</p>') + "</article>";
}

$("#comp-run").addEventListener("click", () => {
  $("#comp-devices").innerHTML = "";
  runInto($("#comp-results"), compRun, "Reading compliance results...", async (current) => {
    const r = await send("compliance/summary");
    if (!current()) return;
    compData = r;
    compSorter.reset();
    return renderCompliance(r);
  });
});
$("#comp-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-comp]");
  if (!pick) return;
  const out = $("#comp-devices");
  runInto(out, compRun, "Reading the devices failing this setting...", async (current) => {
    const { devices: all } = await send("compliance/devices", { id: pick.dataset.comp });
    const devices = await scoped(all); // a device not in the device list has no Intune id, so a scope leaves it out
    if (!current()) return;
    compChips.reset();
    compDevSorter.reset();
    appState.compDevices = { name: pick.dataset.name, list: devices };
    out.innerHTML = renderCompDevices(appState.compDevices.name, devices);
    out.scrollIntoView({ behavior: "smooth", block: "nearest" });
  });
});
$("#comp-devices").addEventListener("click", (e) => compChips.handle(e));
bindExport("comp", () => compRows(), () => "compliance-breakdown.csv");
bindExport("compdev", () => compDeviceRows(), () => "compliance-failing-devices.csv");

// Hardware report

const HW_CHUNK = 100; // devices per request to the worker, so progress and Stop respond between chunks
const HW_SHOWN = 1000;
const hwSorter = createSorter("hardware", { key: "name", dir: 1 }, () => renderHardware());
let hwStop = false;

/** The Hardware rows inside the header's scope (a saved report may cover more devices). */
export const hwRows = () => (appState.hwData?.rows || []).filter((r) => !appState.scope?.ids || appState.scope.ids.has(r.id));
const hwChips = chipBar([
  { key: "os", label: "Platform", value: (r) => r.os },
  { key: "manufacturer", label: "Manufacturer", value: (r) => r.manufacturer },
  { key: "encrypted", label: "Encrypted", value: (r) => r.encrypted },
], () => renderHardware());
/** The Hardware rows the pills let through (what the table, Copy table and CSV hold). */
const hwShown = () => hwRows().filter(hwChips.test);
export function renderHardware() {
  const out = $("#hw-results");
  const all = hwRows();
  if (!all.length) { out.innerHTML = emptyBox(appState.hwData?.rows.length ? "No device in the scope group is in this report. Run it again." : "Nothing read yet."); return; }
  const rows = hwShown();
  const cols = hardwareColumns(all);
  const sorted = hwSorter.apply(rows, cols, (r, key) => r[key]);
  out.innerHTML = `<article class="card">
    <div class="toolbar tight">
      <span class="muted">${rows.length.toLocaleString()} of ${all.length.toLocaleString()} devices, read ${esc(ago(appState.hwData.at))}. Click a heading to sort.</span>
      <span class="spacer"></span>
      ${exportButtons("hw")}
    </div>
    ${hwChips.html(all)}
    ${rows.length ? capped(sorted, (rows) => sortedTable(hwSorter, cols, rows, (r) => cols.map((c) => td(esc(r[c.key] ?? ""), c.num ? "num" : c.nowrap ? "nowrap" : ""))), HW_SHOWN) : emptyBox("No device matches the filters.")}
  </article>`;
}

function hwTableRows() {
  const cols = hardwareColumns(hwRows());
  return [cols.map((c) => c.label), ...hwSorter.apply(hwShown(), cols, (r, key) => r[key]).map((r) => cols.map((c) => r[c.key] ?? ""))];
}

export const runHardware = oneAtATime([$("#hw-run"), $("#posture-run")], async () => {
  hwStop = false;
  const out = $("#hw-results");
  out.innerHTML = loading("Reading your devices...");
  $("#posture-results").innerHTML = loading("Reading every device's record. Stop keeps what is read so far.");
  const rows = [];
  let failed = 0;
  try {
    await loadDevices();
    const ids = [...new Set(appState.devicesCache.devices.map((d) => d.managedId).filter(Boolean))];
    for (let i = 0; i < ids.length && !hwStop; i += HW_CHUNK) {
      jobBar.set("hardware", { label: "Reading hardware", done: i, total: ids.length, stop: () => { hwStop = true; } });
      out.innerHTML = loading("Reading hardware for every device. Stop keeps what is read so far.");
      const res = await send("hardware/read", { ids: ids.slice(i, i + HW_CHUNK) });
      rows.push(...res.rows);
      failed += res.failed;
    }
    appState.hwData = { at: Date.now(), rows };
    // Only a finished run replaces the saved report: a stopped one is shown but not saved, so a long earlier run isn't lost.
    if (!hwStop) await send("hardware/save", { rows });
    jobBar.done("hardware", hwStop ? `Stopped. Showing ${rows.length.toLocaleString()} of ${ids.length.toLocaleString()} devices; the saved report is unchanged.` : "");
    renderHardware();
    renderPosture();
    if (failed) out.insertAdjacentHTML("afterbegin", `<p class="muted small">${failed.toLocaleString()} devices couldn't be read and are left out.</p>`);
    if (hwStop) out.insertAdjacentHTML("afterbegin", '<p class="muted small">Stopped early: this is a partial list.</p>');
  } catch (err) {
    out.innerHTML = errorBox(err);
    jobBar.done("hardware"); // on success the try ended the job, with its "Stopped. Kept ..." message when stopped
    $("#posture-results").innerHTML = errorBox(err);
  }
});

async function loadSavedHardware() {
  try {
    const { saved } = await send("hardware/load");
    if (saved && !runHardware.busy()) {
      appState.hwData = saved;
      if (appState.scope) await scopeIds().catch(() => {}); // filter the saved report to the scope
      renderHardware();
      renderPosture();
    }
  } catch { /* nothing saved, or no session yet: the button still works */ }
}

$("#hw-run").addEventListener("click", runHardware);
$("#posture-run").addEventListener("click", runHardware);
$("#job-stop").addEventListener("click", () => jobBar.stop());
$("#hw-results").addEventListener("click", (e) => { hwChips.handle(e); });
bindExport("hw", () => hwTableRows(), () => "hardware.csv");

// Security posture: the Hardware report's security columns (one read serves both tabs), what needs attention, counts.

const posSorter = createSorter("posture", { key: "issues", dir: -1 }, () => renderPosture());
const POSTURE_COUNT_BADGES = { pass: ["ok", "Pass"], fail: ["bad", "Fail"], unknown: ["", "Not reported"] };
// The summary of checks: its Devices column holds three counts, so it sorts by the Fail count (the most serious one).
const POSTURE_CHECK_COLS = [{ key: "label", label: "Check" }, { key: "fail", label: "Devices", type: "num" }];
const posChecksSorter = createSorter("posture-checks", { key: "" }, () => renderPosture());

/**
 * Windows and macOS rows of the Hardware report (in the scope), each with its issues. allCols: every posture column some
 * device has (Copy table, CSV); cols: those without the detail ones, with Needs attention after the user (the screen).
 */
const posChips = chipBar([
  { key: "os", label: "Platform", value: (r) => r.os },
  { key: "issue", label: "Needs attention for", value: (r) => r.issueList },
], () => renderPosture());
function posView() {
  const rows = hwRows().filter((r) => /windows|mac/i.test(r.os || "")).map((r) => { const issueList = postureIssues(r); return { ...r, issueList, issues: issueList.join("; ") }; });
  const present = hardwareColumns(rows, POSTURE_FIELDS);
  const issues = { key: "issues", label: "Needs attention" };
  const lead = present.filter((c) => c.key === "name" || c.key === "user");
  const cols = [...lead, issues, ...present.filter((c) => !c.detail && !lead.includes(c))];
  const allCols = [...lead, issues, ...present.filter((c) => !lead.includes(c))];
  const base = $("#posture-show")?.value === "all" ? rows : rows.filter((r) => r.issues);
  return { rows, base, cols, allCols, shown: posSorter.apply(base.filter(posChips.test), allCols, (r, key) => r[key]) };
}

function renderPosture() {
  const out = $("#posture-results");
  if (!appState.hwData) { out.innerHTML = emptyBox("Nothing read yet. Read every device, or run the Hardware report: both use the same read."); return; }
  const { rows, base, cols, shown } = posView();
  if (!rows.length) { out.innerHTML = emptyBox("No Windows or macOS device is in this report."); return; }
  const c = postureCounts(rows);
  const old = !rows.some((r) => "credGuard" in r);
  const keep = $("#posture-show")?.value || "attention";
  out.innerHTML = `<article class="card">
      <p><strong>${c.withIssues.toLocaleString()}</strong> of ${c.devices.toLocaleString()} Windows and macOS devices need attention. Read ${esc(ago(appState.hwData.at))}.</p>
      ${old ? '<p class="warn small">This saved report is from before Security posture: read again to add the security details.</p>' : ""}
      ${sortedTable(posChecksSorter, POSTURE_CHECK_COLS, posChecksSorter.apply(c.checks, POSTURE_CHECK_COLS, (k, key) => k[key]), (k) => [td(esc(k.label), "nowrap"), td(badgeCounts(POSTURE_COUNT_BADGES, k))])}
      <div class="toolbar">
        <label>Show <select id="posture-show"><option value="attention">Needs attention</option><option value="all">All</option></select></label>
        <span class="muted small">${shown.length.toLocaleString()} shown</span>
        <span class="spacer"></span>
        ${exportButtons("posture")}
      </div>
      ${posChips.html(base)}
      ${shown.length ? capped(shown, (list) => sortedTable(posSorter, cols, list, (r) => cols.map((col) => td(esc(r[col.key] ?? ""),
        col.nowrap ? "nowrap" : col.key === "issues" && r.issues ? "warn" : ""))), 1000) : emptyBox("Nothing needs attention.")}
      <p class="muted small">From each device's own record (Device Health Attestation, Device Guard) and Intune's encryption report. Blank means Intune didn't report it, which isn't counted as a problem.</p>
    </article>`;
  $("#posture-show").value = keep;
}

$("#posture-results").addEventListener("input", (e) => { if (e.target.id === "posture-show") renderPosture(); });
$("#posture-results").addEventListener("click", (e) => { posChips.handle(e); });
bindExport("posture", () => {
  const { allCols, shown } = posView();
  return [allCols.map((c) => c.label), ...shown.map((r) => allCols.map((c) => r[c.key] ?? ""))];
}, () => "security-posture.csv");

// ------------------------------------------------------------------------------------------
// Orphaned users

let orphans = null; // last answer: { devices, unknown, checked }
const ORPHAN_COLS = [{ key: "name", label: "Device" }, { key: "user", label: "Primary user" }, { key: "state", label: "User" }, { key: "os", label: "OS" },
  { key: "sync", label: "Last check-in", type: "date" }, { key: "owner", label: "Ownership" }];
const orphValue = (d, k) => ({ name: d.name, user: userOf(d), state: d.userState, os: friendlyOs(d.os, d.osVersion), sync: d.lastSync, owner: ownerLabel(d.owner) }[k]);
const orphSorter = createSorter("orphans", { key: "" }, () => renderOrphans());

// One scan at a time: it checks every primary user.
const runOrphans = oneAtATime($("#orphans-run"), async () => {
  $("#orphans-results").innerHTML = loading("Checking each primary user...");
  $("#orphans-count").textContent = "";
  showExport("orphans", false);
  try {
    orphans = await send("devices/orphaned");
    orphSorter.reset();
  } catch (err) {
    orphans = null;
    $("#orphans-results").innerHTML = errorBox(err);
    return;
  }
  renderOrphans();
});

/** Draws the Orphaned users answer, inside the header's scope when one is set (no new lookups when the scope changes). */
export async function renderOrphans() {
  if (!orphans) return;
  let devices;
  try {
    devices = orphans.shown = orphSorter.apply(await scoped(orphans.devices), ORPHAN_COLS, orphValue);
  } catch (err) {
    $("#orphans-results").innerHTML = errorBox(err);
    return;
  }
  const { unknown, checked } = orphans;
  showExport("orphans", devices.length > 0);
  $("#orphans-count").textContent = `${devices.length.toLocaleString()} devices${scopeNote()}, from ${checked.toLocaleString()} users checked`
    + (unknown ? `, ${unknown.toLocaleString()} devices couldn't be checked` : "");
  $("#orphans-results").innerHTML = devices.length
    ? capped(devices, (rows) => sortedTable(orphSorter, ORPHAN_COLS, rows, (d) => [
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))),
      td(d.userState === "deleted" ? '<span class="badge bad">Deleted</span>' : '<span class="badge warn">Disabled</span>'),
      td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ]))
    : emptyBox(scopeNote() ? `No device${scopeNote()} has a disabled or deleted primary user.` : "Every primary user is active.");
}

function orphanRows() {
  return [["Device", "Primary user", "UPN", "User", "OS", "OS version", "Last check-in", "Ownership", "Model"],
    ...(orphans?.shown || orphans?.devices || []).map((d) => [d.name, d.displayName, d.upn, d.userState, d.os, d.osVersion, d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#orphans-run").addEventListener("click", runOrphans);
bindExport("orphans", () => orphanRows(), () => "orphaned-users.csv");

// ------------------------------------------------------------------------------------------
// Low storage

let storageList = [];
const storageSorter = createSorter("storage", { key: "free", dir: 1 }, () => appState.devicesCache && renderStorage()); // least free space first
const STORAGE_COLS = [{ key: "name", label: "Device" }, { key: "user", label: "Primary user" }, { key: "os", label: "OS" },
  { key: "free", label: "Free", num: true, first: 1 }, { key: "total", label: "Total", num: true }, { key: "pct", label: "Free %", num: true, first: 1 }, { key: "sync", label: "Last check-in", type: "date" }];
const storageValue = (d, k) => ({ name: d.name, user: userOf(d), os: friendlyOs(d.os, d.osVersion), free: d.freeGb, total: d.totalGb, pct: d.freeGb / d.totalGb * 100, sync: d.lastSync }[k]);

const storageChips = deviceChips(() => appState.devicesCache && renderStorage());
function renderStorage() {
  const limit = Number($("#storage-gb").value) || 10;
  const sel = $("#storage-os");
  fillPlatforms(sel, appState.devicesCache.platforms);
  const { list, unknown } = lowStorageDevices(appState.devicesCache.devices, limit);
  const byPlatform = list.filter((d) => !sel.value || (d.os || "Unknown OS") === sel.value);
  $("#storage-chips").innerHTML = storageChips.html(byPlatform);
  storageList = storageSorter.apply(byPlatform.filter(storageChips.test), STORAGE_COLS, storageValue);
  showExport("storage", storageList.length > 0);
  $("#storage-count").textContent = `${storageList.length.toLocaleString()} low` + (unknown ? `, ${unknown.toLocaleString()} report no storage` : "");
  $("#storage-results").innerHTML = storageList.length
    ? capped(storageList, (rows) => sortedTable(storageSorter, STORAGE_COLS, rows, (d) => [
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(`${d.freeGb.toFixed(1)} GB`, "num"), td(`${d.totalGb.toFixed(0)} GB`, "num"), td(`${(d.freeGb / d.totalGb * 100).toFixed(0)}%`, "num"),
      td(checkInCell(d.lastSync)),
    ]))
    : emptyBox(`No device has less than ${limit} GB free.`);
}

function storageRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Free GB", "Total GB", "Free %", "Last check-in", "Ownership", "Model"],
    ...storageList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.freeGb.toFixed(1), d.totalGb.toFixed(0),
      (d.freeGb / d.totalGb * 100).toFixed(0), d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#storage-chips").addEventListener("click", (e) => storageChips.handle(e));
$("#storage-gb").addEventListener("input", () => appState.devicesCache && renderStorage());
$("#storage-os").addEventListener("input", () => appState.devicesCache && renderStorage());
bindExport("storage", () => storageRows(), () => "low-storage.csv");

// ------------------------------------------------------------------------------------------
// Stale & duplicates

let staleList = [];
let dupes = []; // found once per device list; the stale list reads it on every keystroke

function renderHygiene() {
  fillPlatforms($("#stale-os"), appState.devicesCache.platforms);
  dupes = duplicateDevices(appState.devicesCache.devices);
  renderStale();
  renderDupes();
}

const staleChips = deviceChips(() => appState.devicesCache && renderStale());
const STALE_COLS = [{ key: "name", label: "Device" }, { key: "user", label: "Primary user" }, { key: "os", label: "OS" },
  { key: "compliance", label: "Compliance", type: "num", first: 1 }, { key: "sync", label: "Last check-in", type: "date" }, { key: "owner", label: "Ownership" }];
const staleValue = (d, k) => ({ name: d.name, user: userOf(d), os: friendlyOs(d.os, d.osVersion), compliance: complianceRank(d.compliance), sync: d.lastSync, owner: ownerLabel(d.owner) }[k]);
const staleSorter = createSorter("stale", { key: "" }, () => appState.devicesCache && renderStale()); // oldest check-in first until a heading is clicked
function renderStale() {
  const days = Number($("#stale-days").value) || 30;
  const os = $("#stale-os").value;
  const byPlatform = staleDevices(appState.devicesCache.devices, days).filter((d) => !os || (d.os || "Unknown OS") === os);
  $("#stale-chips").innerHTML = staleChips.html(byPlatform);
  staleList = staleSorter.apply(byPlatform.filter(staleChips.test), STALE_COLS, staleValue);
  // A stale record that has a newer record under the same name is usually a re-imaged device's
  // leftover, not a missing device. Say so.
  const olderRecords = new Set(dupes.flatMap((g) => g.records.filter((r) => !r.current).map((r) => r.managedId)));
  staleList.forEach((d) => { d.olderDuplicate = olderRecords.has(d.managedId); });
  showExport("stale", staleList.length > 0);
  $("#stale-count").textContent = `${staleList.length.toLocaleString()} of ${appState.devicesCache.devices.length.toLocaleString()}`;
  $("#stale-results").innerHTML = staleList.length
    ? capped(staleList, (rows) => sortedTable(staleSorter, STALE_COLS, rows, (d) => [
      td(`${link(d.link, d.name)}${d.olderDuplicate ? ' <span class="badge" title="A newer Intune record has the same name">older duplicate</span>' : ""}`, "nowrap"),
      td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ]))
    : emptyBox(`Every device has checked in within ${days} days.`);
}

$("#stale-chips").addEventListener("click", (e) => staleChips.handle(e));
function staleRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Compliance", "Last check-in", "Days since", "Ownership", "Model", "Older duplicate"],
    ...staleList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.compliance, d.lastSync, d.age ?? "never",
      ownerLabel(d.owner), d.model, d.olderDuplicate ? "yes" : ""])];
}

function renderDupes() {
  const records = dupes.reduce((n, g) => n + g.count, 0);
  showExport("dupe", dupes.length > 0);
  $("#dupe-count").textContent = dupes.length ? `${dupes.length} names, ${records} records` : "";
  if (!dupes.length) { $("#dupe-results").innerHTML = emptyBox("No device name has more than one Intune record."); return; }
  const rows = [];
  const older = [];
  for (const g of dupes) {
    g.records.forEach((d, i) => {
      rows.push([
        td(i === 0 ? `<strong>${esc(g.name)}</strong> <span class="muted">×${g.count}</span>` : "", "nowrap"),
        td(link(d.link, "Open in Intune")),
        td(esc(userOf(d))),
        td(esc(d.enrolled ? new Date(d.enrolled).toLocaleDateString() : "")),
        td(checkInCell(d.lastSync)),
        td(d.current ? '<span class="badge ok">Current</span>' : '<span class="badge">Older record</span>'),
      ]);
      older.push(!d.current);
    });
  }
  $("#dupe-results").innerHTML = tableHtml(["Device name", "Record", "Primary user", "Enrolled", "Last check-in", ""], rows.slice(0, 3000), (i) => (older[i] ? 'class="older"' : ""));
}

function dupeRows() {
  return [["Device name", "Record", "Primary user", "UPN", "Enrolled", "Last check-in", "Days since", "Intune device ID"],
    ...dupes.flatMap((g) => g.records.map((d) => [g.name, d.current ? "Current" : "Older record", d.displayName, d.upn,
      d.enrolled, d.lastSync, d.age ?? "never", d.managedId]))];
}

$("#stale-days").addEventListener("input", () => appState.devicesCache && renderStale());
$("#stale-os").addEventListener("input", () => appState.devicesCache && renderStale());
bindExport("stale", () => staleRows(), () => "stale-devices.csv");
bindExport("dupe", () => dupeRows(), () => "duplicate-devices.csv");
