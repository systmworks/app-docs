// The workspace's six themes: the list, the saved-value check, the dropdown in the top bar and the static patterns behind
// dark green and dark red. The colours themselves live only in workspace.css; this file reads them with var(--...) and
// getComputedStyle, so it writes no colour of its own. Nothing here animates: a pattern is painted once per theme switch and
// once after a resize, never in a loop. A pattern is the same at a given window size; a different size draws a different one.
// Imports only popup.js (which imports nothing), so the offline tests can load it on its own.
import { dismissable } from "./popup.js";

/** Every theme: id (what is saved and what workspace.css selects), the menu name, and its group. Order is the menu order. */
export const THEMES = [
  { id: "light-blue", name: "Blue", group: "light" },
  { id: "light-grey", name: "Grey", group: "light" },
  { id: "light-pink", name: "Pink", group: "light" },
  { id: "dark-blue", name: "Blue", group: "dark" },
  { id: "dark-green", name: "Green", group: "dark" },
  { id: "dark-red", name: "Red", group: "dark" },
];
const THEME_GROUPS = [{ id: "light", label: "Light" }, { id: "dark", label: "Dark" }];
export const DEFAULT_THEME = "dark-blue";
const THEME_KEY = "ie.theme";

/** The theme to use for a saved value: a known id stays, the old "light" becomes light-blue, anything else is the default. */
export function normalizeTheme(saved) {
  if (saved === "light") return "light-blue";
  return THEMES.some((t) => t.id === saved) ? saved : DEFAULT_THEME;
}

// ---- static backgrounds ----

/** A small seeded random generator (mulberry32), so a pattern is the same each time it is painted at one window size. */
function seededRandom(seed) {
  let s = seed;
  return () => {
    s = (s + 0x6D2B79F5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function themeVar(name) { return getComputedStyle(document.documentElement).getPropertyValue(name).trim(); }

// Digits and half-width katakana (U+FF71 to U+FF9D), written as code points so the file stays plain.
const GLYPHS = "0123456789" + Array.from({ length: 45 }, (_, i) => String.fromCharCode(0xFF71 + i)).join("");

/** Dark green: a field of dim glyph columns, each ending in a brighter head, like code rain that has stopped. */
function paintGlyphs(ctx, w, h, rand) {
  const accent = themeVar("--accent"), fg = themeVar("--fg");
  const cell = 14;
  ctx.font = `${cell - 2}px "Cascadia Mono", Consolas, monospace`;
  ctx.textBaseline = "top";
  for (let x = 0; x < w; x += cell) {
    const run = 6 + Math.floor(rand() * 20);
    const head = Math.floor(rand() * (h / cell));
    for (let i = 0; i < run; i++) {
      const row = head - i;
      if (row < 0) break;
      ctx.globalAlpha = i === 0 ? 0.55 : 0.3 * (1 - i / run);
      ctx.fillStyle = i === 0 ? fg : accent;
      ctx.fillText(GLYPHS[Math.floor(rand() * GLYPHS.length)], x, row * cell);
    }
  }
}

/** Dark red: a red haze that is strongest at the edges and the bottom, with a scatter of frozen specks (spores). */
function paintSpores(ctx, w, h, rand) {
  const accent = themeVar("--accent"), fg = themeVar("--fg");
  const edge = ctx.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.2, w / 2, h / 2, Math.max(w, h) * 0.75);
  edge.addColorStop(0, "transparent");
  edge.addColorStop(1, accent);
  ctx.globalAlpha = 0.22;
  ctx.fillStyle = edge;
  ctx.fillRect(0, 0, w, h);
  const floor = ctx.createLinearGradient(0, h, 0, h * 0.5);
  floor.addColorStop(0, accent);
  floor.addColorStop(1, "transparent");
  ctx.globalAlpha = 0.12;
  ctx.fillStyle = floor;
  ctx.fillRect(0, h * 0.5, w, h * 0.5);
  const specks = Math.round((w * h) / 2600);
  for (let i = 0; i < specks; i++) {
    ctx.globalAlpha = 0.06 + rand() * 0.2;
    ctx.fillStyle = rand() < 0.25 ? fg : accent;
    ctx.beginPath();
    ctx.arc(rand() * w, rand() * h, 0.6 + rand() * 1.8, 0, Math.PI * 2);
    ctx.fill();
  }
}
const PAINTERS = { "dark-green": paintGlyphs, "dark-red": paintSpores };

/** Paints the current theme's pattern on #theme-canvas (and clears it under a theme with none). Called on a switch and a resize. */
export function paintThemeBackground() {
  const canvas = document.getElementById("theme-canvas");
  const ctx = canvas?.getContext?.("2d");
  if (!ctx) return;
  const id = document.documentElement.dataset.theme;
  const paint = PAINTERS[id];
  const w = window.innerWidth, h = window.innerHeight, dpr = window.devicePixelRatio || 1;
  // Sizing the canvas also clears it. A theme with no pattern keeps a 0 by 0 canvas, so nothing large is held while it is hidden.
  canvas.width = paint ? Math.round(w * dpr) : 0;
  canvas.height = paint ? Math.round(h * dpr) : 0;
  if (!paint) return;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  paint(ctx, w, h, seededRandom(id === "dark-green" ? 7 : 11));
  ctx.globalAlpha = 1;
}

// ---- the dropdown ----

/** Applies a theme: the page attribute, the button's words, the checked menu entry and the pattern; saves it when asked. */
export function applyTheme(id, save) {
  const theme = THEMES.find((t) => t.id === id) || THEMES.find((t) => t.id === DEFAULT_THEME);
  document.documentElement.dataset.theme = theme.id;
  const btn = document.getElementById("theme-toggle");
  const label = `Theme: ${theme.group === "dark" ? "Dark" : "Light"} ${theme.name}`;
  btn.setAttribute("aria-label", label);
  btn.title = label;
  for (const item of document.querySelectorAll("#theme-menu [data-theme-id]")) {
    item.setAttribute("aria-checked", String(item.dataset.themeId === theme.id));
  }
  paintThemeBackground();
  if (save) { try { localStorage.setItem(THEME_KEY, theme.id); } catch { /* storage unavailable: still switches for this visit */ } }
}

/** Builds the menu (a Light and a Dark heading, one button per theme), wires the keys and clicks, and paints the first pattern. */
export function setupThemePicker() {
  const btn = document.getElementById("theme-toggle");
  const menu = document.getElementById("theme-menu");
  for (const group of THEME_GROUPS) {
    const box = document.createElement("div");
    box.setAttribute("role", "group");
    box.setAttribute("aria-label", group.label);
    const head = document.createElement("div");
    head.className = "theme-head";
    head.setAttribute("aria-hidden", "true");
    head.textContent = group.label;
    box.append(head);
    for (const theme of THEMES.filter((t) => t.group === group.id)) {
      const item = document.createElement("button");
      item.type = "button";
      item.setAttribute("role", "menuitemradio");
      item.dataset.themeId = theme.id;
      item.tabIndex = -1;
      const dot = document.createElement("i");
      dot.className = "theme-dot";
      dot.dataset.theme = theme.id; // workspace.css gives an element with this attribute that theme's variables, so the dot shows its accent
      const name = document.createElement("span");
      name.textContent = theme.name;
      item.append(dot, name);
      box.append(item);
    }
    menu.append(box);
  }
  const items = () => [...menu.querySelectorAll("[data-theme-id]")];
  const setOpen = (open, focusItem) => {
    menu.hidden = !open;
    btn.setAttribute("aria-expanded", String(open));
    if (open) (focusItem || items().find((i) => i.getAttribute("aria-checked") === "true") || items()[0]).focus();
  };
  btn.addEventListener("click", () => setOpen(menu.hidden));
  btn.addEventListener("keydown", (e) => { if (e.key === "ArrowDown" && menu.hidden) { e.preventDefault(); setOpen(true); } });
  menu.addEventListener("click", (e) => {
    const item = e.target.closest("[data-theme-id]");
    if (!item) return;
    applyTheme(item.dataset.themeId, true);
    setOpen(false);
    btn.focus();
  });
  menu.addEventListener("keydown", (e) => {
    const all = items(), at = all.indexOf(document.activeElement);
    const go = { ArrowDown: (at + 1) % all.length, ArrowUp: (at - 1 + all.length) % all.length, Home: 0, End: all.length - 1 }[e.key];
    if (go !== undefined) { e.preventDefault(); all[go].focus(); }
    else if (e.key === "Tab") setOpen(false);
  });
  dismissable(document.getElementById("theme-picker"), () => !menu.hidden, () => setOpen(false), btn);
  let resizeTimer = null;
  window.addEventListener("resize", () => { clearTimeout(resizeTimer); resizeTimer = setTimeout(paintThemeBackground, 150); });
  applyTheme(normalizeTheme(document.documentElement.dataset.theme), false);
}
