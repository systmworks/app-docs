// Tenant tools: Tenant health, Autopilot failures, Console, Error code lookup, ID decoder, US Government clouds and Check
// my access. Moved out of workspace.js without changes to the code (see docs/workspace-split-plan.md).

import { failedItems } from "../core/autopilot.js";
import { lookupError, codesInText } from "../core/error-codes.js";
import { loadErrorCodes } from "./lazy-data.js";
import { searchWords, hasAllWords } from "../core/format.js";
import { GOV } from "../core/clouds.js";
import { sheetDate } from "./sheet.js";
import { createSorter, sortedTable } from "./sort.js";
import { $, $$, SAMPLE, apCell, badge, bindExport, capped, chipBar, emptyBox, errorBox, esc, headCells, kvTable, link, loading, newestOnly, onEnterOrClear, oneAtATime, runInto, send, showExport, tableHtml, tableWrap, td, registerTab } from "./core.js";

// ------------------------------------------------------------------------------------------
// Error code lookup: Microsoft's published error tables, shipped inside the extension (data/error-codes.js).

let ecData = null; // { index, sources, built } once loaded (lazy-data.js)
const ecSource = (i) => ecData?.sources[i] || { label: "Microsoft Learn", url: "" };

/** Loads the error tables the first time they are needed (Error code lookup, Autopilot details). Null if they fail to load. */
async function errorCodes() {
  if (ecData) return ecData;
  try {
    ecData = await loadErrorCodes();
  } catch {
    return null;
  }
  $("#errors-source").textContent = `Adapted from Microsoft Learn (CC BY 4.0), shortened. ${ecData.index.list.length.toLocaleString()} codes, built ${ecData.built}. Not every code is documented.`;
  return ecData;
}

/** A table of matches: code, name, meaning, fix, the page it came from. */
function errorTable(matches, showVia = true) {
  const fixes = matches.some((m) => m.fix); // the Windows system error tables have no fixes
  return tableHtml(["Code", "Name", "Meaning", ...(fixes ? ["Fix"] : []), "Source"], matches.map((m) => [
    td(`<span class="mono">${esc(m.code)}</span>${showVia && m.via ? `<div class="muted small">${esc(m.via)}</div>` : ""}`, "nowrap"),
    td(esc(m.name)), td(esc(m.desc)), ...(fixes ? [td(esc(m.fix))] : []), td(link(ecSource(m.source).url, ecSource(m.source).label)),
  ]));
}

export async function runErrorLookup() {
  const text = $("#errors-input").value;
  const out = $("#errors-results");
  const data = await errorCodes();
  if (!data) { out.innerHTML = emptyBox("The error tables could not be loaded. Reload the page and try again."); return; }
  const res = lookupError(text, data.index);
  if (res.kind === "empty") { out.innerHTML = emptyBox("Type an error code or a few words."); return; }
  if (!res.matches.length) {
    out.innerHTML = emptyBox(`${res.kind === "code" ? `No entry for ${res.interpretations.map((i) => i.label).join(" or ")} in Microsoft's published tables.` : "No error text contains all of those words."} The codes Microsoft does not document are not listed. Search the code on the web, or in the device's logs.`);
    return;
  }
  out.innerHTML = errorTable(res.matches, res.kind === "code")
    + (res.more ? `<p class="muted small">${res.more.toLocaleString()} more match. Add words to narrow it down.</p>` : "");
}
$("#errors-form").addEventListener("submit", (e) => { e.preventDefault(); runErrorLookup(); });

/** What the lookup knows about the error codes written in these texts, as a Details section. */
function apErrorCodes(texts) {
  const index = ecData?.index; // loaded when the Autopilot tab opens
  if (!index) return "";
  const rows = [];
  for (const code of [...new Set(texts.flatMap((t) => codesInText(t)))]) {
    const hit = lookupError(code, index).matches[0];
    rows.push(`<tr>${td(`<a href="#errors/${encodeURIComponent(code)}">${esc(code)}</a>`, "nowrap")}${td(esc(hit ? `${hit.name}: ${hit.desc}` : "Not in Microsoft's published tables"))}${td(esc(hit?.fix || ""))}</tr>`);
  }
  return rows.length ? `<h3>Error codes in this event</h3>${tableWrap(headCells(["Code", "Meaning", "Fix"]), rows.join(""))}` : "";
}

// ------------------------------------------------------------------------------------------
// ID decoder

const decodeRun = newestOnly(); // a second lookup started before the first answers wins
$("#decode-form").addEventListener("submit", (e) => {
  e.preventDefault();
  const text = $("#decode-input").value;
  runInto($("#decode-results"), decodeRun, "Looking these up...", async () => {
    const res = await send("ids/decode", { text });
    if (!res.ids.length) return emptyBox(res.message);
    return res.ids.map((x) => `
      <article class="card">
        <h2 class="mono">${esc(x.guid)}</h2>
        ${x.hint ? `<div class="muted">The link labels this as: ${esc(x.hint)}</div>` : ""}
        ${x.matches.length ? tableHtml(["What it is", "Name", "Details"], x.matches.map((m) => [
          td(esc(m.kind)), td(link(m.link, m.name)),
          td(`${esc(m.extra)}${m.assigned ? `<div class="small" style="margin-top:2px">${esc(m.assigned)}</div>` : ""}`),
        ]), undefined, ' style="margin-top:8px"') : '<p class="muted">Not found as any object type this tool checks, or your role can\'t read it.</p>'}
      </article>`).join("") + (!res.policyIndexBuiltAt && res.ids.some((x) => x.matches.some((m) => /polic|profile|script|app|update|configuration|remediation/i.test(m.kind)))
      ? '<p class="muted">Tip: run a Setting check once (it reads your policies) and the decoder will also show who each policy is assigned to.</p>' : "");
  });
});

// ------------------------------------------------------------------------------------------
// Tenant health

let health = null; // last answer: { rows }
const HEALTH_BADGE = {
  expired: ["bad", "Expired"], soon: ["warn", "Expires soon"], attention: ["warn", "Needs a look"],
  ok: ["ok", "OK"], none: ["", "Not set up"], error: ["bad", "Couldn't check"],
};

// Tenant health sorts Status most serious first, and Expires and Days left soonest first (like Days left, the owner's smallest-first rule).
const HEALTH_ORDER = ["expired", "soon", "attention", "error", "none", "ok"];
const HEALTH_COLS = [{ key: "area", label: "Area", get: (r) => r.area }, { key: "name", label: "Name", get: (r) => r.name }, { key: "status", label: "Status", type: "num", first: 1, get: (r) => HEALTH_ORDER.indexOf(r.status) + 1 || null },
  { key: "expires", label: "Expires", type: "date", first: 1, get: (r) => r.expires }, { key: "daysLeft", label: "Days left", num: true, first: 1, get: (r) => r.daysLeft }, { key: "detail", label: "Detail", get: (r) => r.detail }];
const healthSorter = createSorter("health", { key: "" }, () => drawHealth());
const healthSorted = () => healthSorter.apply(health?.rows || [], HEALTH_COLS);
function drawHealth() {
  $("#health-results").innerHTML = sortedTable(healthSorter, HEALTH_COLS, healthSorted(), (r) => [
    td(esc(r.area), "nowrap"), td(esc(r.name)), td(badge(HEALTH_BADGE, r.status)),
    td(r.expires ? esc(new Date(r.expires).toLocaleDateString()) : ""), td(r.daysLeft === null ? "" : String(r.daysLeft), "num"), td(esc(r.detail)),
  ]);
}

// One check at a time: coming back to the tab or clicking Check again doesn't start another.
const runHealth = oneAtATime($("#health-run"), async () => {
  $("#health-results").innerHTML = loading("Checking tokens, certificates and connectors...");
  $("#health-count").textContent = "";
  showExport("health", false);
  try {
    health = await send("tenant/health");
  } catch (err) {
    health = null;
    $("#health-results").innerHTML = errorBox(err);
    return;
  }
  const worried = health.rows.filter((r) => r.status === "expired" || r.status === "soon").length;
  showExport("health", health.rows.length > 0);
  $("#health-count").textContent = worried ? `${worried} need action` : "Nothing expiring soon";
  healthSorter.reset();
  drawHealth();
});

function healthRowsOut() {
  return [["Area", "Name", "Status", "Expires", "Days left", "Detail"],
    ...healthSorted().map((r) => [r.area, r.name, HEALTH_BADGE[r.status][1], r.expires, r.daysLeft ?? "", r.detail])];
}

$("#health-run").addEventListener("click", runHealth);
bindExport("health", () => healthRowsOut(), () => "tenant-health.csv");

// ------------------------------------------------------------------------------------------
// Autopilot failures: Intune's Autopilot deployment events for the last N days, with the enrollment status page
// (ESP) items and the device's Autopilot record. Every field Intune sends is kept (Details, CSV and JSON), so the
// layout can be decided from real data.

const AP_STATE = { failure: ["bad", "Failed"], success: ["ok", "Success"], inprogress: ["warn", "In progress"], unknown: ["", "Unknown"] };
const AP_COLS = [
  { key: "when", label: "Date", type: "date" }, { key: "name", label: "Device name" }, { key: "serial", label: "Serial number" }, { key: "user", label: "User" },
  { key: "stateLabel", label: "Status" }, { key: "method", label: "Method" }, { key: "profile", label: "Profile" },
  { key: "espCheck", label: "ESP check" }, { key: "attempts", label: "Attempts" }, { key: "entraText", label: "Entra" }, { key: "lastSync", label: "Last sync", type: "date" },
  { key: "secs", label: "Duration", num: true }, { key: "failedText", label: "Failed items" }, { key: "notes", label: "Notes" }, { key: "model", label: "Model" }, { key: "os", label: "OS version" },
];
let apRows = null; // as read: [{ id, when, state, event, details, detailsNote, identity }]
let apAll = []; // apRows as table rows (apBuild)
const apSorter = createSorter("autopilot", { key: "when", dir: -1 }, () => apRows && renderAutopilot()); // newest first
let apView = []; // rows as shown
// The event whose details show in the pane under the table (#ap-detail), or null.
let apSel = null;
// The table shows these columns; the rest of AP_COLS (which is also the Copy table and CSV) are in the details pane.
const AP_SHOWN = ["when", "name", "serial", "user", "stateLabel", "notes"];
const AP_TABLE_COLS = AP_COLS.filter((c) => AP_SHOWN.includes(c.key));
/** One event's text for a column (the Copy table, the CSV and the details pane all read it this way). */
const apCellText = (v, c) => (c.key === "secs" ? v.durText : v[c.key]);

/** "PT1H34M48S" as "1 hr 34 min 48 sec", and its seconds. Pure. */
function isoDuration(text) {
  const m = /^P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:([\d.]+)S)?$/i.exec(String(text || ""));
  if (!m) return { secs: NaN, text: String(text || "") };
  const [d, h, mi, s] = [m[1], m[2], m[3], m[4]].map((x) => Number(x) || 0);
  const secs = d * 86400 + h * 3600 + mi * 60 + s;
  const parts = [d && `${d} d`, h && `${h} hr`, mi && `${mi} min`, (s || !secs) && `${Math.round(s)} sec`].filter(Boolean);
  return { secs, text: parts.join(" ") };
}

/**
 * What the data says about an event that did not succeed, in plain words. Real tenant data showed hybrid-join
 * deployments that end after a second with state "unknown" (no result ever reported), often with the device still
 * named DESKTOP-xxxx or by its id, and a later success for the same serial; those are told apart from a real failure.
 * lastOk: lower-case serial -> ISO time of that device's latest successful deployment.
 */
function apNotes(r, v, lastOk) {
  if (v.state === "success") return "";
  const out = [];
  if (v.state === "unknown" && v.secs <= 2) out.push(`Ended after ${v.durText || "0 sec"} with no result reported`);
  const ok = lastOk.get(v.serial.toLowerCase());
  out.push(ok && ok >= v.when ? `Succeeded later (${new Date(ok).toLocaleDateString()})` : "No success since");
  if (!r.identity) out.push("No Autopilot record for this serial number");
  else if (/notcontacted/i.test(r.identity.enrollmentState || "") || /^0001/.test(r.identity.lastContactedDateTime || "")) out.push("Autopilot record has never contacted Intune");
  if (/^DESKTOP-/i.test(v.name) || /^[0-9a-f]{8}-[0-9a-f]{4}-/i.test(v.name)) out.push("Device name not set yet");
  if (/^default$/i.test(r.event?.windows10EnrollmentCompletionPageConfigurationDisplayName || "")) out.push("Used the Default enrollment status page, not an assigned one");
  if (r.esp?.agrees === false) out.push(`Expected enrollment status page "${r.esp.expectedName}", used "${r.esp.actualName || "none"}"${r.joinNotes?.entraNewer ? " (Entra record is newer than the event, so unproven)" : ""}`);
  if (/hybrid/i.test(r.profile?.kind || "") && /^azureadjoined$/i.test(r.device?.joinType || "")) out.push("Intune says Entra joined but the profile is hybrid: the domain join did not happen");
  else if (r.esp?.agrees === true && /^default$/i.test(r.esp.actualName || "")) out.push("Default is what the groups say should apply");
  if (r.entra && /offlinedomainjoined/i.test(v.method) && r.entra.trustType && r.entra.trustType !== "ServerAd") out.push("Not hybrid joined in Entra yet");
  if (!r.device && r.joinNotes?.device) out.push("No Intune managed device record");
  if (v.attemptCount > 1) out.push(`Attempt ${r.history.position} of ${v.attemptCount} for this serial`);
  const inProfile = r.profile?.assignedGroups?.filter((g) => !g.excluded);
  if (inProfile?.length && inProfile.every((g) => g.deviceIsMember === false)) out.push("Device is not in the profile's assigned group now");
  return out.join("; ");
}

function apRow(r, lastOk = new Map()) {
  const e = r.event || {};
  const dur = isoDuration(e.deploymentDuration);
  const failed = failedItems(r.details).map((d) => d.displayName || d.policyId || d.id || "(unnamed)");
  const v = {
    id: r.id, raw: r, when: r.when, name: e.managedDeviceName || "", serial: e.deviceSerialNumber || "", user: e.userPrincipalName || "",
    state: r.state, stateLabel: AP_STATE[r.state][1], method: e.enrollmentType || "", profile: e.windowsAutopilotDeploymentProfileDisplayName || "",
    secs: dur.secs, durText: dur.text, failedText: failed.join(", "), model: r.identity?.model || "", os: e.osVersion || "",
    espCheck: !r.esp ? "" : r.esp.agrees === true ? `OK: ${r.esp.actualName || "Default"}` : r.esp.agrees === false ? `Mismatch: expected ${r.esp.expectedName}` : "Unknown",
    attemptCount: r.history?.attempts || 0, attempts: r.history ? `${r.history.attempts}${r.history.laterSuccess ? ", later success" : r.history.attempts > 1 ? ", no success since" : ""}` : "",
    entraText: r.entra ? ({ ServerAd: "Hybrid joined", AzureAd: "Entra joined", Workplace: "Registered" }[r.entra.trustType] || r.entra.trustType || "Found") : r.joinNotes?.entra ? "No Entra record" : "",
    lastSync: r.device?.lastSyncDateTime || "",
  };
  v.notes = apNotes(r, v, lastOk);
  return v;
}

/** Details sections for the joined data: attempts, the ESP check, the profile, the device and Entra records, groups. */
function apJoined(r) {
  const out = [];
  const h = r.history;
  if (h) out.push(`<h3>Attempts for this serial number</h3><p class="small">${h.attempts} in this period (first ${esc(new Date(h.first).toLocaleString())}, last ${esc(new Date(h.last).toLocaleString())}); ${h.failedOrUnknown} not successful.`
    + ` ${h.laterSuccess ? `A later deployment succeeded (${esc(new Date(h.laterSuccess).toLocaleString())}).` : "No later success."}</p>`);
  if (r.esp) {
    const c = r.esp.candidates || [];
    out.push(`<h3>Enrollment status page check</h3><p class="small">Used: ${esc(r.esp.actualName || r.esp.actualId || "none")}. Expected from the groups now: ${esc(r.esp.expectedName || "cannot tell")}.${r.esp.note ? ` ${esc(r.esp.note)}` : ""}</p>`
      + (c.length ? tableWrap(headCells(["Assigned page", { label: "Priority", num: true }, "Targets this device or user", "Through"]), c.map((x) => `<tr>${td(esc(x.name))}${td(String(x.priority), "num")}${td(x.matches === null ? "unknown" : x.matches ? "yes" : "no")}${td(esc(x.via))}</tr>`).join("")) : ""));
  }
  if (r.profile) {
    const { assignedGroups, ...rest } = r.profile;
    out.push(`<h3>Autopilot profile${r.profile.kind ? ` (${esc(r.profile.kind)})` : ""}</h3>${kvTable(rest)}`
      + (assignedGroups?.length ? tableWrap(headCells(["Assigned group", "", "Device in it now", "Dynamic rule"]), assignedGroups.map((g) => `<tr>${td(esc(g.name))}${td(g.excluded ? "excluded" : "")}${td(g.deviceIsMember === null ? "unknown" : g.deviceIsMember ? "yes" : "no")}${td(esc(g.rule))}</tr>`).join("")) : ""));
  }
  if (r.device) out.push(`<h3>Intune managed device record</h3>${kvTable(r.device)}`);
  if (r.entra) out.push(`<h3>Entra device record</h3>${kvTable(r.entra)}`);
  const names = (list) => (list ? list.map((g) => g.name).sort((a, b) => a.localeCompare(b)).join(", ") || "(none)" : "could not be read");
  if (r.deviceGroups || r.userGroups) out.push(`<h3>Groups now</h3><p class="small">Device: ${esc(names(r.deviceGroups))}</p><p class="small">User: ${esc(names(r.userGroups))}</p>`);
  const notes = Object.values(r.joinNotes || {});
  if (notes.length) out.push(`<p class="muted small">${notes.map(esc).join("<br>")}</p>`);
  return out.join("");
}

function apDetail(v) {
  const r = v.raw;
  const esp = Array.isArray(r.details) && r.details.length
    ? `<h3>Enrollment status page items (${r.details.length})</h3>` + (() => {
      const keys = [...new Set(r.details.flatMap((d) => Object.keys(d)))];
      return tableWrap(headCells(keys), r.details.map((d) => `<tr>${keys.map((k) => td(esc(apCell(d[k])))).join("")}</tr>`).join(""));
    })()
    : `<p class="muted small">No enrollment status page items from Intune${r.detailsNote ? `: ${esc(r.detailsNote)}` : "."}</p>`;
  const codeTexts = [r.event?.enrollmentFailureDetails, ...(Array.isArray(r.details) ? r.details.map((d) => (d?.errorCode && Number(d.errorCode) !== 0 ? String(d.errorCode) : "")) : [])].filter(Boolean);
  return `${apJoined(r)}${apErrorCodes(codeTexts)}<h3>Deployment event</h3>${kvTable(r.event)}${esp}` +
    (r.identity ? `<h3>Autopilot device record</h3>${kvTable(r.identity)}` : '<p class="muted small">No Autopilot device record found for this serial number.</p>');
}

/** The table rows for the events just read, made once (not on every search or filter change). */
function apBuild(rows) {
  const lastOk = new Map();
  for (const r of rows) {
    const serial = String(r.event?.deviceSerialNumber || "").toLowerCase();
    if (r.state === "success" && serial && r.when > (lastOk.get(serial) || "")) lastOk.set(serial, r.when);
  }
  return rows.map((r) => apRow(r, lastOk));
}

function apFilter() {
  const words = searchWords($("#ap-search").value);
  const status = $("#ap-status").value;
  return apAll.filter((v) => (status === "all" || v.state === "failure" || (status === "unknown" && v.state === "unknown"))
    && hasAllWords(`${v.name}\n${v.serial}\n${v.user}`, words));
}

function renderAutopilot() {
  const out = $("#ap-results");
  if (!apRows) return;
  apView = apSorter.apply(apFilter(), AP_COLS, (v, k) => v[k]);
  showExport("ap", apView.length > 0);
  $("#ap-count").textContent = `${apView.length.toLocaleString()} of ${apRows.length.toLocaleString()} events`;
  if (!apView.length) {
    out.innerHTML = emptyBox(apRows.length ? "No event matches." : "Intune has no Autopilot events in this period.");
    return;
  }
  const draw = (rows) => sortedTable(apSorter, AP_TABLE_COLS, rows, (v) => [
    td(v.when ? `${esc(new Date(v.when).toLocaleString())}` : "", "nowrap"), td(esc(v.name), "nowrap"), td(esc(v.serial), "nowrap"), td(esc(v.user), "nowrap"),
    td(badge(AP_STATE, v.state)), td(esc(v.notes), "ap-notes"),
  ], { rowAttrs: (v) => `data-ap-id="${esc(v.id)}" tabindex="0" aria-selected="false" title="Click for this event's details"` });
  out.innerHTML = capped(apView, draw, 1000, "Copy, Save CSV and Save JSON include all. Click a row for its details.");
  apShowDetail();
}

/** Marks the selected row and fills the details pane under the table (hidden when that event isn't in the list now). */
function apShowDetail() {
  const pane = $("#ap-detail");
  const v = apSel && apView.find((x) => x.id === apSel);
  for (const tr of $$("#ap-results tr[data-ap-id]")) tr.setAttribute("aria-selected", String(tr.dataset.apId === apSel));
  pane.hidden = !v;
  if (!v) return;
  const more = AP_COLS.filter((c) => !AP_SHOWN.includes(c.key)).map((c) => [c.label, sheetDate(apCellText(v, c) || (c.key === "failedText" && v.state === "failure" ? "no ESP detail" : ""))])
    .filter(([, x]) => x !== "");
  pane.innerHTML = `<div class="toolbar flush"><h2>${esc(v.name || v.serial)} <span class="muted">${esc(v.when ? new Date(v.when).toLocaleString() : "")}</span></h2><span class="spacer"></span><button type="button" data-ap-close>Close</button></div>`
    + `${kvTable(more)}${apDetail(v)}`;
}

function apTableRows() {
  return [[...AP_COLS.map((c) => c.label)], ...apView.map((v) => AP_COLS.map((c) => apCellText(v, c)))];
}

/** Every field of every shown event: the table columns, then each event field, ESP items and Autopilot record field. */
function apFullRows() {
  const eventKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.event || {})))];
  const idKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.identity || {})))];
  const devKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.device || {})))];
  const entraKeys = [...new Set(apView.flatMap((v) => Object.keys(v.raw.entra || {})))];
  const json = (x) => (x ? JSON.stringify(x) : "");
  return [
    [...AP_COLS.map((c) => c.label), "ESP items (JSON)", "ESP check (JSON)", "Attempts (JSON)", "Profile (JSON)", "Device groups", "User groups", "Join notes",
      ...eventKeys.map((k) => `event.${k}`), ...idKeys.map((k) => `autopilot.${k}`), ...devKeys.map((k) => `device.${k}`), ...entraKeys.map((k) => `entra.${k}`)],
    ...apView.map((v) => [...AP_COLS.map((c) => apCellText(v, c)), json(v.raw.details), json(v.raw.esp), json(v.raw.history), json(v.raw.profile),
      (v.raw.deviceGroups || []).map((g) => g.name).join("; "), (v.raw.userGroups || []).map((g) => g.name).join("; "), Object.values(v.raw.joinNotes || {}).join(" "),
      ...eventKeys.map((k) => apCell(v.raw.event?.[k])), ...idKeys.map((k) => apCell(v.raw.identity?.[k])),
      ...devKeys.map((k) => apCell(v.raw.device?.[k])), ...entraKeys.map((k) => apCell(v.raw.entra?.[k]))]),
  ];
}

$("#ap-run").addEventListener("click", oneAtATime($("#ap-run"), async () => {
  const days = Math.min(30, Math.max(1, Math.floor(Number($("#ap-days").value)) || 7));
  $("#ap-days").value = days;
  $("#ap-results").innerHTML = loading("Reading Autopilot events...");
  try {
    const rows = (await send("autopilot/events", { days })).rows;
    apAll = apBuild(rows);
    apRows = rows;
    apSel = null;
    renderAutopilot();
  } catch (err) {
    $("#ap-results").innerHTML = errorBox(err);
  }
}));
onEnterOrClear($("#ap-search"), renderAutopilot); // on Enter or when cleared, like the other searches
$("#ap-status").addEventListener("input", renderAutopilot);
$("#ap-results").addEventListener("click", (e) => {
  const tr = e.target.closest("tr[data-ap-id]");
  if (tr) { apSel = apSel === tr.dataset.apId ? null : tr.dataset.apId; apShowDetail(); if (apSel) $("#ap-detail .toolbar").scrollIntoView({ block: "nearest" }); } // only the pane's heading is brought into view, and only if it is off screen
});
$("#ap-results").addEventListener("keydown", (e) => { // a row works like a button from the keyboard: Enter or Space
  const tr = e.target.closest("tr[data-ap-id]");
  if (tr && (e.key === "Enter" || e.key === " ")) { e.preventDefault(); tr.click(); }
});
$("#ap-detail").addEventListener("click", (e) => { if (e.target.closest("[data-ap-close]")) { apSel = null; apShowDetail(); } });
// Save JSON holds every event read (all statuses, whatever the filter) with every field Intune sent.
bindExport("ap", () => apTableRows(), () => "autopilot-failures.csv", () => apFullRows(), () => ({ file: "autopilot-events.json", data: { readAt: new Date().toISOString(), rows: apRows } }));

// ------------------------------------------------------------------------------------------
// Console: the worker's own log (core/log.js), newest first, with level and source pills and a filter box.

let logEntries = []; // newest first
const LOG_BADGE = { error: ["bad", "error"], warn: ["warn", "warn"], info: ["", "info"] };
const logChips = chipBar([
  { key: "level", label: "Level", value: (e) => e.level, order: ["error", "warn", "info"] },
  { key: "source", label: "Source", value: (e) => e.source },
], () => renderConsole());

async function loadConsole() {
  try {
    logEntries = [...(await send("log/get")).entries || []].reverse();
    renderConsole();
  } catch (err) {
    $("#log-results").innerHTML = errorBox(err);
  }
}

/** The entries the filter box lets through (the pills are counted from these), and those the pills let through too. */
const logSearched = () => {
  const words = searchWords($("#log-filter").value);
  return logEntries.filter((e) => hasAllWords(`${e.source} ${e.message} ${e.detail}`, words));
};
// Level sorts most serious first (error, warn, info); the newest-first order is kept until a heading is clicked.
const LOG_COLS = [{ key: "t", label: "Time", type: "date", get: (e) => e.t }, { key: "level", label: "Level", type: "num", first: 1, get: (e) => Object.keys(LOG_BADGE).indexOf(e.level) + 1 || null },
  { key: "source", label: "Source", get: (e) => e.source }, { key: "message", label: "Message", get: (e) => e.message }];
const logSorter = createSorter("console", { key: "" }, () => renderConsole());
const logShown = () => logSorter.apply(logSearched().filter(logChips.test), LOG_COLS);

function renderConsole() {
  const rows = logShown();
  $("#log-chips").innerHTML = logChips.html(logSearched());
  $("#log-count").textContent = `${rows.length.toLocaleString()} of ${logEntries.length.toLocaleString()}`;
  showExport("log", rows.length > 0);
  $("#log-results").innerHTML = rows.length
    ? sortedTable(logSorter, LOG_COLS, rows, (e) => [td(esc(sheetDate(new Date(e.t).toISOString())), "nowrap"),
      td(badge(LOG_BADGE, e.level)), td(esc(e.source)),
      td(`${esc(e.message)}${e.detail ? ` <span class="muted">(${esc(e.detail)})</span>` : ""}`)])
    : emptyBox(logEntries.length ? "No entry matches the filter." : "Nothing logged yet this browser session.");
}

onEnterOrClear($("#log-filter"), renderConsole);
$("#log-chips").addEventListener("click", (e) => logChips.handle(e));
$("#log-refresh").addEventListener("click", loadConsole);
$("#log-clear").addEventListener("click", async () => { await send("log/clear"); loadConsole(); });
bindExport("log", () => [["Time", "Level", "Source", "Message", "Detail"], ...logShown().map((e) => [new Date(e.t).toISOString(), e.level, e.source, e.message, e.detail])], () => "console-log.csv");
// This page's own script errors go to the Console too (a failed send is dropped, so a broken worker cannot loop here).
const logPageError = (message, detail = "") => { Promise.resolve(send("log/add", { level: "error", message, detail })).catch(() => {}); };
window.addEventListener("error", (e) => logPageError(e.message || "Script error", `${(e.filename || "").split("/").pop()}:${e.lineno || ""}`));
window.addEventListener("unhandledrejection", (e) => logPageError(`Unhandled: ${e.reason?.message || e.reason}`));

// ------------------------------------------------------------------------------------------
// US Government clouds: optional host permissions the admin grants here (core/clouds.js). The worker then
// registers the portal scripts for them (background.js, syncGovScripts).

export async function renderGov() {
  // Only the US Government row needs the permissions API; the card's other switches always show.
  const row = $("#gov-row");
  row.hidden = SAMPLE || !chrome.permissions?.contains;
  if (row.hidden) return;
  const on = await chrome.permissions.contains({ origins: GOV.origins }).catch(() => false);
  $("#gov-control").innerHTML = `<span class="muted small">${on ? "allowed" : "not allowed"}</span> ` +
    `<button data-gov data-on="${on ? 1 : 0}">${on ? "Remove access" : "Allow access"}</button>`;
}

$("#gov-list").addEventListener("click", async (e) => {
  const b = e.target.closest("button[data-gov]");
  if (!b) return;
  $("#gov-error").hidden = true;
  try {
    // Must be called straight from the click (a browser rule), so nothing is awaited before it.
    const ok = b.dataset.on === "1" ? await chrome.permissions.remove({ origins: GOV.origins }) : await chrome.permissions.request({ origins: GOV.origins });
    if (!ok && b.dataset.on !== "1") { $("#gov-error").textContent = "Access was not granted."; $("#gov-error").hidden = false; }
  } catch (err) {
    $("#gov-error").textContent = `Could not change access: ${err.message}`; $("#gov-error").hidden = false;
  }
  renderGov();
});

// Check my access (Settings): which Graph areas this sign-in may read (core/access.js). Runs on a click only.
let access = null; // last answer: { rows, at }
const ACCESS_BADGE = { Yes: ["ok", "Yes"], No: ["bad", "No"], Unknown: ["warn", "Unknown"] };
// Can read sorts No first (a refusal is what to look at), then Unknown, then Yes.
const ACCESS_COLS = [{ key: "area", label: "Area", get: (r) => r.area }, { key: "can", label: "Can read", type: "num", first: 1, get: (r) => ["No", "Unknown", "Yes"].indexOf(r.can) + 1 || null },
  { key: "usedBy", label: "Used by", get: (r) => r.usedBy }, { key: "detail", label: "Detail", get: (r) => r.detail }];
const accessSorter = createSorter("access", { key: "" }, () => drawAccess());
const accessSorted = () => accessSorter.apply(access?.rows || [], ACCESS_COLS);
const drawAccess = () => {
  $("#access-results").innerHTML = sortedTable(accessSorter, ACCESS_COLS, accessSorted(), (r) => [td(esc(r.area), "nowrap"),
    td(badge(ACCESS_BADGE, r.can)), td(esc(r.usedBy)), td(esc(r.detail))])
    + '<p class="muted small">A refusal here means Microsoft refused this sign-in, not that the extension failed. The policy list reads more kinds (updates, app protection, scripts of every type) than the areas above, and Tenant health shows its own unreadable sources.</p>';
};
const runAccess = oneAtATime($("#access-run"), async () => {
  $("#access-results").innerHTML = loading("Asking Microsoft about each area...");
  $("#access-count").textContent = "";
  showExport("access", false);
  try {
    access = await send("access/check");
  } catch (err) {
    access = null;
    $("#access-results").innerHTML = errorBox(err);
    return;
  }
  const count = (can) => access.rows.filter((r) => r.can === can).length;
  $("#access-count").textContent = `${count("Yes")} of ${access.rows.length} readable${count("No") ? `, ${count("No")} refused` : ""}${count("Unknown") ? `, ${count("Unknown")} unknown` : ""}`;
  showExport("access", true);
  accessSorter.reset();
  drawAccess();
});
$("#access-run").addEventListener("click", runAccess);
bindExport("access", () => access && [["Area", "Can read", "Used by", "Detail"], ...accessSorted().map((r) => [r.area, r.can, r.usedBy, r.detail])], () => "access-check.csv");

// What each of these tabs does when it opens (selectTab in core.js calls it).
registerTab("health", () => { if (!health) runHealth(); return true; });
registerTab("console", () => { loadConsole(); });
registerTab(["errors", "autopilot"], () => { errorCodes(); });
