// Lookup tools: Group picker, Group assignments, Group roster, Compare devices, Compare users, Device 360 and User 360.
// Moved out of workspace.js without changes to the code (see docs/workspace-split-plan.md).

import { ageDays } from "../core/device-reports.js";
import { groupKind } from "../core/group-tools.js";
import { deviceSearchText, pickerDevice } from "../core/resolve.js";
import { searchWords, hasAllWords } from "../core/format.js";
import { dismissable } from "./popup.js";
import { createSorter, sortedTable } from "./sort.js";
import { $, ago, appState, badge, bindExport, capped, checkInCell, checkInText, complianceBadge, complianceRank, emptyBox, esc, exportButtons, friendlyOs, link, loadDevices, newestOnly, onEnterOrClear, recordsBadge, runInto, scopeNote, send, tableHtml, td, userOf, valueCell } from "./core.js";

// ------------------------------------------------------------------------------------------
// Group picker (shared by Group assignments and Group roster)

export function setupPicker(name, onPick, search) {
  const root = $(`[data-picker="${name}"]`);
  // A picker written as an empty form gets its box here: data-ph and data-label, or the group search wording.
  if (!root.firstElementChild) root.innerHTML = `<input type="search" placeholder="${esc(root.dataset.ph ?? "Search groups by name, then press Enter")}" autocomplete="off" aria-label="${esc(root.dataset.label ?? "Group")}"><button class="primary" type="submit">Search</button>${root.dataset.refresh ? `<button type="button" class="refresh" title="${esc(root.dataset.refresh)}" aria-label="${esc(root.dataset.refresh)}" hidden>↻</button>` : ""}<ul class="picker-list" hidden></ul>`;
  const input = $("input", root);
  const button = $("button[type=submit]", root);
  const list = $(".picker-list", root);
  // A picker with data-refresh has a refresh button, hidden until the report calls again(fn) after a check: a click runs fn.
  const refresh = $(".refresh", root);
  let rerun = null;
  refresh?.addEventListener("click", () => rerun?.());
  let items = [];
  let active = -1;
  let empty = "No groups found";

  const close = () => { list.hidden = true; active = -1; };
  const draw = () => {
    list.innerHTML = items.length
      ? items.map((g, i) => `<li role="option" data-i="${i}" aria-selected="${i === active}">${esc(g.displayName)}<span class="sub">${esc(g.userPrincipalName ?? kindOf(g))}</span></li>`).join("")
      : `<li class="muted">${esc(empty)}</li>`;
    list.hidden = false;
  };
  // A user shows with their sign-in name, since the same person can exist under more than one domain.
  const pick = (g) => { input.value = root.dataset.key === "users" && g.userPrincipalName ? `${g.displayName} (${g.userPrincipalName})` : g.displayName; close(); onPick(g); };

  // Searches on Enter or the Search button only, one at a time, so answers can't arrive out of order.
  root.addEventListener("submit", async (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q || button.disabled) return;
    button.disabled = true;
    try {
      const key = root.dataset.key || "groups";
      items = search ? await search(q) : (await send(root.dataset.search || "groups/search", { query: q }))[key] || [];
      empty = `No ${key} found${search ? scopeNote() : ""}`;
    } catch (err) {
      items = [];
      empty = err.message;
    } finally {
      button.disabled = false;
    }
    active = -1;
    draw();
  });
  input.addEventListener("keydown", (e) => {
    if (list.hidden) return;
    if (e.key === "ArrowDown") { active = Math.min(items.length - 1, active + 1); draw(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { active = Math.max(0, active - 1); draw(); e.preventDefault(); }
    else if (e.key === "Enter" && items[active]) { pick(items[active]); e.preventDefault(); }
  });
  list.addEventListener("click", (e) => {
    const li = e.target.closest("li[data-i]");
    if (li) pick(items[Number(li.dataset.i)]);
  });
  dismissable(root, () => !list.hidden, close);
  return { again(fn) { rerun = fn; if (refresh) refresh.hidden = false; } };
}

const kindOf = (g) => `${groupKind(g, { short: true })}${g.description ? `: ${g.description}` : ""}`;

// ------------------------------------------------------------------------------------------
// Group assignments

const impactRun = newestOnly();
let impactExport = null; // the report on screen and its file name; Copy table / Save CSV read its rows (impactRows) when clicked, so they follow the sorted tables
bindExport("impact", () => impactExport && impactRows(impactExport.report), () => impactExport.file);

// Three tables, one sorter each: the built-in target's list, the group's own assignments, and those inherited through parent groups.
const IMP_COLS = { name: { key: "name", label: "Name" }, type: { key: "type", label: "Type" }, target: { key: "target", label: "Target" },
  through: { key: "through", label: "Through" }, intent: { key: "intent", label: "Intent" }, filter: { key: "filter", label: "Filter" } };
const impCols = (...keys) => keys.map((k) => IMP_COLS[k]);
const BROAD_COLS = impCols("name", "type", "intent", "filter");
const INTUNE_COLS = impCols("name", "type", "target", "intent", "filter");
const INHERITED_COLS = impCols("name", "type", "target", "through", "intent", "filter");
const impValue = (i, k) => ({ name: i.policyName, type: i.typeLabel, target: i.kind, through: i.viaGroup, intent: i.intent || "", filter: i.filterId ? i.filterType || "yes" : "" }[k]);
const redrawImpact = () => { if (impactExport) $("#impact-results").innerHTML = impactExport.report.target ? renderBroad(impactExport.report) : renderImpact(impactExport.report); };
const broadSorter = createSorter("impact-broad", { key: "" }, redrawImpact);
const intuneSorter = createSorter("impact-intune", { key: "" }, redrawImpact);
const inheritedSorter = createSorter("impact-inherited", { key: "" }, redrawImpact);
/** The report's assignment lists in screen order: the table of a built-in target (it has a `target`) or of a group, and the inherited one. */
const impIntune = (r) => (r.target ? broadSorter : intuneSorter).apply(r.intune, r.target ? BROAD_COLS : INTUNE_COLS, impValue);
const impInherited = (r) => inheritedSorter.apply(r.inherited || [], INHERITED_COLS, impValue);
const newImpact = (report, file) => { impactExport = { report, file }; for (const x of [broadSorter, intuneSorter, inheritedSorter]) x.reset(); };

// The refresh button beside Search checks again whatever is on screen, a group or a built-in target, without searching and picking again.
const impactPicker = setupPicker("impact", (g) => runImpact(g));

export function runImpact(g) {
  impactPicker.again(() => runImpact(g));
  return runInto($("#impact-results"), impactRun, "Checking everything that references this group...", async (current) => {
    const { report } = await send("group/impact", { groupId: g.id });
    if (!current()) return;
    newImpact(report, `group-assignments-${report.group.name}.csv`);
    return renderImpact(report);
  });
}

// "All devices" / "All users" buttons: Intune assignments only (they are not groups).
function runBroad(target) {
  impactPicker.again(() => runBroad(target));
  return runInto($("#impact-results"), impactRun, "Checking what is assigned to this target...", async (current) => {
    const { report } = await send("group/broad", { target });
    if (!current()) return;
    newImpact(report, `assigned-to-${report.target.name}.csv`);
    return renderBroad(report);
  });
}
$("#impact-broad").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-broad]");
  if (b) runBroad(b.dataset.broad);
});

function renderBroad(r) {
  return `
    <article class="card">
      <div class="toolbar flush"><h2>${esc(r.target.name)}: Intune assignments</h2><span class="spacer"></span>${r.intune.length ? exportButtons("impact") : ""}</div>
      <p class="muted">${r.intune.length} assigned. Exclusions of groups are not shown here; open the policy to see them. Policy index from ${esc(ago(r.policyIndexBuiltAt))}.</p>
      ${r.policyErrors.length ? `<p class="muted">Some policy types couldn't be read, so this list may be incomplete: ${esc(r.policyErrors.join(", "))}</p>` : ""}
      ${r.intune.length ? sortedTable(broadSorter, BROAD_COLS, impIntune(r), (i) => [
        td(link(i.link, i.policyName)), td(esc(i.typeLabel)), td(esc(i.intent || "")), td(i.filterId ? esc(i.filterType || "yes") : ""),
      ], { attrs: ' style="margin-top:8px"' }) : '<p class="muted">Nothing is assigned to this target.</p>'}
    </article>`;
}

const ICON = { clear: "✅", "in-use": "⚠️", unknown: "❔" };

function renderImpact(r) {
  const verdictText = {
    clear: ["Looks safe to retire", "Nothing found that references this group."],
    unknown: ["Couldn't check everything", "Nothing found so far, but some checks couldn't run. See below."],
    "in-use": ["In use", "Retiring this group would change what the items below apply to."],
  }[r.verdict];
  const members = (n) => (n === null || n === undefined ? "?" : n.toLocaleString());
  const section = (title, rows) => (rows ? `<h3>${esc(title)}</h3>${rows}` : "");
  const simpleList = (arr, fmt) => (arr?.length ? `<ul>${arr.map((x) => `<li>${fmt(x)}</li>`).join("")}</ul>` : "");

  return `
    <article class="card">
      <h2>${link(r.link, r.group.name)}</h2>
      <div class="muted">${esc(r.group.kind)}${r.group.synced ? ", synced from on-premises" : ""}</div>
      ${r.group.description ? `<div>${esc(r.group.description)}</div>` : ""}
      ${r.group.rule ? `<div class="path">Rule: ${esc(r.group.rule)}</div>` : ""}
      <div class="facts">
        <div><span>Devices (incl. nested)</span>${members(r.members.devices)}</div>
        <div><span>Users (incl. nested)</span>${members(r.members.users)}</div>
        <div><span>Owners</span>${r.owners ? esc(r.owners.join(", ") || "None") : "?"}</div>
        <div><span>Created</span>${r.group.created ? esc(new Date(r.group.created).toLocaleDateString()) : "?"}</div>
      </div>
    </article>

    <div class="verdict ${esc(r.verdict)}"><div>${ICON[r.verdict]}</div><div><strong>${esc(verdictText[0])}</strong>${esc(verdictText[1])}</div></div>

    <article class="card">
      <h2>Retirement checklist</h2>
      <ul class="checklist">${r.checklist.map((c) => `
        <li><span>${ICON[c.status]}</span><span>${esc(c.label)}</span><span>${c.count === null ? "?" : c.count}</span>
        ${c.detail && c.status !== "clear" ? `<span class="detail">${esc(c.detail)}</span>` : ""}</li>`).join("")}
      </ul>
      <p class="muted">Policy index from ${esc(ago(r.policyIndexBuiltAt))}. Refresh it on the Setting check tab if policies changed since.</p>
    </article>

    <article class="card">
      <div class="toolbar flush"><h2>Intune assignments</h2><span class="spacer"></span>${r.intune.length || r.inherited?.length ? exportButtons("impact") : ""}</div>
      ${r.intune.length ? sortedTable(intuneSorter, INTUNE_COLS, impIntune(r), (i) => [
        td(link(i.link, i.policyName)), td(esc(i.typeLabel)),
        td(i.kind === "exclude" ? '<span class="badge warn">Exclude</span>' : '<span class="badge">Include</span>'),
        td(esc(i.intent || "")), td(i.filterId ? esc(i.filterType || "yes") : ""),
      ], { attrs: ' style="margin-top:8px"' }) : `<p class="muted">No Intune policy, app, script or profile is assigned to this group${r.inherited?.length ? " itself" : ""}.</p>`}
      ${r.inherited?.length ? section("Through parent groups", '<p class="muted small">This group is a member of these groups, so its members get what they are assigned too.</p>'
        + sortedTable(inheritedSorter, INHERITED_COLS, impInherited(r), (i) => [
          td(link(i.link, i.policyName)), td(esc(i.typeLabel)),
          td(i.kind === "exclude" ? '<span class="badge warn">Exclude</span>' : '<span class="badge">Include</span>'),
          td(esc(i.viaGroup) + (i.viaPath ? `<div class="muted small">nested, via ${esc(i.viaPath)}</div>` : "")),
          td(esc(i.intent || "")), td(i.filterId ? esc(i.filterType || "yes") : ""),
        ])) : ""}
      ${section("Conditional Access", simpleList(r.conditionalAccess, (p) => `${esc(p.name)} <span class="muted">(${esc(p.mode)}, ${esc(p.state)})</span>`))}
      ${section("Enterprise apps", simpleList(r.appAssignments, esc))}
      ${section("Licences", simpleList(r.licenses, esc))}
      ${section("Intune role assignments", simpleList(r.roleAssignments, (x) => `${esc(x.name)} <span class="muted">(as ${esc(x.as)})</span>`))}
      ${section("Member of", simpleList(r.parents, (x) => esc(x.displayName)))}
      ${section("Contains groups", simpleList(r.children, (x) => esc(x.displayName)))}
    </article>`;
}

function impactRows(r) {
  return [
    ["Name", "Type", "Target", "Intent", "Filter type", "Through group"],
    ...impIntune(r).map((i) => [i.policyName, i.typeLabel, i.kind, i.intent, i.filterType, ""]),
    ...impInherited(r).map((i) => [i.policyName, i.typeLabel, i.kind, i.intent, i.filterType, i.viaPath ? `${i.viaGroup} (via ${i.viaPath})` : i.viaGroup]),
  ];
}

// ------------------------------------------------------------------------------------------
// Group roster

let roster = null;
// Every column the roster can show (the Devices column only when a user is listed); the sort reads these.
const ROSTER_SORT_COLS = [{ key: "type", label: "Type" }, { key: "name", label: "Name" }, { key: "upn", label: "Primary user / UPN" }, { key: "devices", label: "Devices", type: "num" },
  { key: "compliance", label: "Compliance", type: "num", first: 1 }, { key: "os", label: "OS" }, { key: "seen", label: "Last check-in", type: "date" }];
const rosterSorter = createSorter("roster", { key: "" }, () => drawRoster());

const rosterRun = newestOnly();

setupPicker("roster", (g) => {
  $("#roster-tools").hidden = true;
  return runInto($("#roster-results"), rosterRun, "Reading members...", async (current) => {
    const answer = (await send("group/roster", { groupId: g.id })).roster;
    if (!current()) return;
    roster = answer;
    rosterSorter.reset();
    $("#roster-tools").hidden = false;
    drawRoster();
  });
});

function rosterView() {
  if (!roster) return [];
  const words = searchWords($("#roster-filter").value);
  const type = $("#roster-type").value;
  const stale = $("#roster-stale").checked ? Number($("#roster-days").value) || 30 : null;
  return rosterSorter.apply(roster.rows.filter((r) => {
    if (type && r.type !== type) return false;
    if (stale !== null) {
      // Devices by their own check-in; users by their most recent device. Users with no devices
      // and groups have nothing to be stale.
      if (r.type === "Group" || (r.type === "User" && !r.deviceCount)) return false;
      const d = ageDays(r.lastCheckIn);
      if (d !== null && d <= stale) return false;
    }
    if (!hasAllWords(rosterHaystack(r), words)) return false;
    return true;
  }), ROSTER_SORT_COLS, rosterValue);
}

// The lowercased text the filter looks in, built once per row (not on every filter run).
const rosterTexts = new WeakMap();
function rosterHaystack(r) {
  let text = rosterTexts.get(r);
  if (text === undefined) {
    text = [r.type, r.name, r.upn, r.primaryUser, r.department, r.jobTitle, r.compliance, r.os, r.osVersion,
      ...(r.devices || []).map((d) => d.name)].filter(Boolean).join(" ").toLowerCase();
    rosterTexts.set(r, text);
  }
  return text;
}

// Rows with a check-in to show: Intune devices, and users by their most recent device.
const hasCheckIn = (r) => (r.type === "Device" && r.intune) || (r.type === "User" && r.deviceCount > 0);

// One definition per column, used by the table, Copy table and Save CSV.
const ROSTER_COLUMNS = [
  ["Type", (r) => r.type],
  ["Name", (r) => r.name],
  ["Primary user / UPN", (r) => (r.type === "Device" ? r.primaryUser : r.upn || "")],
  ["Devices", (r) => (r.type === "User" ? (r.devices || []).map((d) => d.name).join("; ") : "")],
  ["Compliance", (r) => (hasCheckIn(r) ? r.compliance || "" : "")],
  ["OS", (r) => (hasCheckIn(r) ? friendlyOs(r.os?.split(" ")[0], r.osVersion) : "")],
  ["Last check-in", (r) => (hasCheckIn(r) ? checkInText(r.lastCheckIn) : r.type === "Device" ? "not in Intune" : "")],
  ["Department", (r) => r.department || ""],
  ["Job title", (r) => r.jobTitle || ""],
];
const COL = Object.fromEntries(ROSTER_COLUMNS.map(([h, f]) => [h, f]));

// Group by count for Devices (users only), by severity for Compliance, by the timestamp for Last check-in; a row with nothing to show is empty, so it sorts last.
const rosterValue = (r, k) => ({ type: r.type, name: r.name, upn: COL["Primary user / UPN"](r), devices: r.type === "User" ? r.deviceCount : null,
  compliance: hasCheckIn(r) ? complianceRank(r.compliance) : null, os: COL.OS(r), seen: hasCheckIn(r) ? r.lastCheckIn : null }[k]);

function userDevicesCell(r) {
  if (r.type !== "User") return "";
  if (!r.deviceCount) return '<span class="muted">None</span>';
  const shown = r.devices.slice(0, 3).map((d) => `<span class="nowrap">${link(d.link, d.name)}</span>`).join(", ");
  return r.deviceCount > 3 ? `${shown} <span class="muted">+${r.deviceCount - 3} more</span>` : shown;
}

function drawRoster() {
  const rows = rosterView();
  $("#roster-count").textContent = `${rows.length} of ${roster.rows.length}`;
  if (!rows.length) { $("#roster-results").innerHTML = emptyBox("No members match."); return; }
  const hasUsers = rows.some((r) => r.type === "User");
  const cols = ROSTER_SORT_COLS.filter((c) => hasUsers || c.key !== "devices");
  $("#roster-results").innerHTML = capped(rows, (shownRows) => sortedTable(rosterSorter, cols, shownRows, (r) => {
    const sub = r.type === "User" ? [r.jobTitle, r.department].filter(Boolean).join(", ") : "";
    return [
      td(esc(r.type)),
      td(`${r.link ? link(r.link, r.name) : esc(r.name)}${recordsBadge(r.duplicates)}${sub ? `<div class="muted small">${esc(sub)}</div>` : ""}`),
      td(`${esc(COL["Primary user / UPN"](r))}${r.type === "User" && r.enabled === false ? ' <span class="badge">Disabled</span>' : ""}`),
      ...(hasUsers ? [td(userDevicesCell(r))] : []),
      td(hasCheckIn(r) ? complianceBadge(r.compliance) : ""),
      td(esc(COL.OS(r))),
      td(hasCheckIn(r) ? checkInCell(r.lastCheckIn) : esc(COL["Last check-in"](r))),
    ];
  }));
}

// The text filter runs on Enter or when cleared, like the other searches; the dropdown, checkbox and day count
// apply at once.
onEnterOrClear($("#roster-filter"), drawRoster);
["#roster-type", "#roster-stale", "#roster-days"].forEach((sel) => $(sel).addEventListener("input", drawRoster));

function rosterTable() {
  return [ROSTER_COLUMNS.map(([h]) => h).concat("Object ID"), ...rosterView().map((r) => ROSTER_COLUMNS.map(([, f]) => f(r)).concat(r.objectId))];
}
bindExport("roster", () => rosterTable(), () => `group-roster-${roster?.group?.name || "group"}.csv`);

// Compare devices

const cmpDevPicked = {};
let cmpDevReport = null;
const cmpDevRun = newestOnly();
const CMP_DEV_STATE = { applies: "Applies", filter: "Depends on filter", uncertain: "Uncertain", excluded: "Excluded" };

for (const side of ["cmpda", "cmpdb"]) {
  setupPicker(side, (d) => { cmpDevPicked[side] = d; $("#cmpdevices-run").disabled = !(cmpDevPicked.cmpda && cmpDevPicked.cmpdb); },
    async (q) => { await loadDevices(); return matchDevices(q).slice(0, 25).map(pickerDevice); }); // the Workspace scope applies
  // Typing in the box drops the earlier pick, so Run never compares a device the box no longer shows.
  $(`[data-picker="${side}"] input`).addEventListener("input", () => { cmpDevPicked[side] = null; $("#cmpdevices-run").disabled = true; });
}

// The three policy tables, one sorter each. The report is kept (cmpDevReport) so a sort draws the result again; a state sorts by severity (CMP_DEV_STATE is in that order).
const redrawCompareDevices = () => { if (cmpDevReport) $("#cmpdevices-results").innerHTML = renderCompareDevices(cmpDevReport); };
const cmpSorters = { both: createSorter("cmpdev-both", { key: "" }, redrawCompareDevices), onlyA: createSorter("cmpdev-onlyA", { key: "" }, redrawCompareDevices), onlyB: createSorter("cmpdev-onlyB", { key: "" }, redrawCompareDevices) };
/** Headings: Name, Type and two state columns, the first two labelled (a, b, or State and On x) and reading the fields k1 and k2. */
const cmpCols = (l1, l2, k1, k2) => [{ key: "name", label: "Name" }, { key: "type", label: "Type" }, { key: k1, label: l1, type: "num", first: 1 }, { key: k2, label: l2, type: "num", first: 1 }];
const cmpRank = (s) => Object.keys(CMP_DEV_STATE).indexOf(s) + 1 || null;
const cmpValue = (x, k) => (k === "name" ? x.name : k === "type" ? x.typeLabel : cmpRank(x[k]));
/** The report's three policy lists in screen order. */
const cmpPolicies = (r) => ({ both: cmpSorters.both.apply(r.policies.both, cmpCols("", "", "stateA", "stateB"), cmpValue),
  onlyA: cmpSorters.onlyA.apply(r.policies.onlyA, cmpCols("", "", "state", "otherState"), cmpValue), onlyB: cmpSorters.onlyB.apply(r.policies.onlyB, cmpCols("", "", "state", "otherState"), cmpValue) });

function renderCompareDevices(r) {
  const a = r.a.name;
  const b = r.b.name;
  const how = (g) => (g.direct ? "direct" : `nested${g.via ? `, via ${g.via}` : ""}`);
  const groupCards = (title, g) => {
    if (g.unreadable) return `<article class="card"><h2>${esc(title)}</h2><p class="muted">Couldn't be read for one of the devices, so nothing is compared.</p></article>`;
    const list = (groups, none, text) => (groups.length ? `<ul>${groups.map((x) => `<li>${link(x.link, x.name)} <span class="muted">${esc(text(x))}</span></li>`).join("")}</ul>` : `<p class="muted">${esc(none)}</p>`);
    return `<article class="card"><h2>${esc(title)}</h2>
      <h3>In both (${g.both.length})</h3>${list(g.both, "None in common.", (x) => `${a}: ${how(x)}; ${b}: ${how(x.other)}`)}
      <h3>Only ${esc(a)} (${g.onlyA.length})</h3>${list(g.onlyA, "None.", how)}
      <h3>Only ${esc(b)} (${g.onlyB.length})</h3>${list(g.onlyB, "None.", how)}</article>`;
  };
  const p = cmpPolicies(r);
  const state = (s) => esc(CMP_DEV_STATE[s] || "");
  const notAssigned = '<span class="muted">not assigned</span>';
  const polTable = (title, list, sorter, headCols, cols) => `<h3>${esc(title)} (${list.length})</h3>` + (list.length
    ? sortedTable(sorter, headCols, list, (x) => [td(link(x.link, x.name)), td(esc(x.typeLabel)), ...cols(x)]) : '<p class="muted">None.</p>');
  const notes = r.notes.length ? `<article class="card"><h2>Not everything could be checked</h2><ul>${r.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul></article>` : "";
  const unknown = '<span class="muted">unknown</span>';
  return `${notes}
    <article class="card"><h2>Details</h2>${tableHtml(["", a, b], r.facts.map((f) => [td(esc(f.label)), td(esc(f.a) || unknown, f.differs ? "differs" : ""), td(esc(f.b) || unknown, f.differs ? "differs" : "")]))}</article>
    ${groupCards("Device groups", r.deviceGroups)}
    ${groupCards("Primary users' groups", r.userGroups)}
    <article class="card">
      <div class="toolbar tight"><h2>Policies, apps and scripts</h2><span class="spacer"></span>
        ${exportButtons("cmpdevices")}</div>
      ${polTable("Reach both", p.both, cmpSorters.both, cmpCols(a, b, "stateA", "stateB"), (x) => [td(state(x.stateA)), td(state(x.stateB))])}
      ${polTable(`Only ${a}`, p.onlyA, cmpSorters.onlyA, cmpCols("State", `On ${b}`, "state", "otherState"), (x) => [td(state(x.state)), td(x.otherState ? state(x.otherState) : notAssigned)])}
      ${polTable(`Only ${b}`, p.onlyB, cmpSorters.onlyB, cmpCols("State", `On ${a}`, "state", "otherState"), (x) => [td(state(x.state)), td(x.otherState ? state(x.otherState) : notAssigned)])}
      ${r.otherPlatform.a || r.otherPlatform.b ? `<p class="muted small">Policies for other platforms are left out: ${r.otherPlatform.a} for ${esc(a)}, ${r.otherPlatform.b} for ${esc(b)}.</p>` : ""}
    </article>`;
}

function cmpDevRows() {
  const r = cmpDevReport;
  if (!r) return [];
  const g = (title, s) => (s.unreadable ? [[title, "Couldn't be read", "", ""]]
    : [...s.both.map((x) => [title, x.name, "Both", ""]), ...s.onlyA.map((x) => [title, x.name, `Only ${r.a.name}`, ""]), ...s.onlyB.map((x) => [title, x.name, `Only ${r.b.name}`, ""])]);
  const pol = cmpPolicies(r);
  return [["Section", "Item", r.a.name, r.b.name],
    ...r.facts.map((f) => ["Details", f.label, f.a, f.b]),
    ...g("Device group", r.deviceGroups), ...g("User group", r.userGroups),
    ...pol.both.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.stateA], CMP_DEV_STATE[x.stateB]]),
    ...pol.onlyA.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.state], CMP_DEV_STATE[x.otherState] || "Not assigned"]),
    ...pol.onlyB.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.otherState] || "Not assigned", CMP_DEV_STATE[x.state]])];
}

$("#cmpdevices-run").addEventListener("click", () => {
  const out = $("#cmpdevices-results");
  if (cmpDevPicked.cmpda.id === cmpDevPicked.cmpdb.id) {
    cmpDevRun(); // an earlier compare still running must not replace this note
    out.innerHTML = emptyBox("Both sides are the same device. Pick two different devices to compare.");
    return;
  }
  runInto(out, cmpDevRun, "Reading both devices' groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const r = await send("devices/compare", { a: cmpDevPicked.cmpda.id, b: cmpDevPicked.cmpdb.id });
    if (!current()) return;
    cmpDevReport = r;
    for (const x of Object.values(cmpSorters)) x.reset();
    return renderCompareDevices(r);
  });
});
bindExport("cmpdevices", () => cmpDevRows(), () => `compare-${cmpDevReport?.a.name}-${cmpDevReport?.b.name}.csv`);

// Compare users

const cmpPicked = {};
let cmpReport = null;
const cmpRun = newestOnly();

for (const side of ["cmpa", "cmpb"]) {
  setupPicker(side, (u) => { cmpPicked[side] = u; $("#cmpusers-run").disabled = !(cmpPicked.cmpa && cmpPicked.cmpb); });
  // Typing in the box drops the earlier pick, so Run never compares a user the box no longer shows.
  $(`[data-picker="${side}"] input`).addEventListener("input", () => { cmpPicked[side] = null; $("#cmpusers-run").disabled = true; });
}

const userLabel = (u) => (u?.userPrincipalName ? `${u.displayName} (${u.userPrincipalName})` : u?.displayName || "");

// r.users is { a, b }: the two users compared, kept with the answer so picking again doesn't relabel it.
function renderCompare(r) {
  const { a: ua, b: ub } = r.users;
  const a = userLabel(ua);
  const b = userLabel(ub);
  // Short names inside the lists, unless the two share a name (the same person under two domains).
  const sameName = ua.displayName === ub.displayName;
  const shortA = sameName ? ua.userPrincipalName : ua.displayName;
  const shortB = sameName ? ub.userPrincipalName : ub.displayName;
  const warnings = [r.unreadable.a && a, r.unreadable.b && b].filter(Boolean).map((n) => `${n}'s groups couldn't be read.`);
  if (r.unreadable.a || r.unreadable.b) return emptyBox(`${warnings.join(" ")} Nothing is compared, so it isn't guessed.`);
  const how = (g) => (g.direct ? "direct" : `nested${g.via ? `, via ${g.via}` : ""}`);
  const card = (title, groups, none, extra = () => "") => `<article class="card"><h2>${esc(title)} (${groups.length})</h2>${groups.length
    ? `<ul>${groups.map((g) => `<li>${link(g.link, g.name)} <span class="muted">${esc(extra(g) || how(g))}</span></li>`).join("")}</ul>`
    : `<p class="muted">${esc(none)}</p>`}</article>`;
  return card("In both", r.both, "No group in common.", (g) => `${shortA}: ${how(g)}; ${shortB}: ${how(g.other)}`) +
    card(`Only ${a}`, r.onlyA, `Everything ${a} is in, ${b} is in too.`) +
    card(`Only ${b}`, r.onlyB, `Everything ${b} is in, ${a} is in too.`) +
    `<div class="toolbar">${exportButtons("cmpusers")}</div>`;
}

function cmpRows() {
  const r = cmpReport;
  const a = userLabel(r?.users.a) || "A";
  const b = userLabel(r?.users.b) || "B";
  return [["Group", "Result"], ...(r ? [
    ...r.both.map((g) => [g.name, "Both"]), ...r.onlyA.map((g) => [g.name, `Only ${a}`]), ...r.onlyB.map((g) => [g.name, `Only ${b}`])] : [])];
}

$("#cmpusers-run").addEventListener("click", () => {
  const out = $("#cmpusers-results");
  if (cmpPicked.cmpa.id === cmpPicked.cmpb.id) {
    cmpRun(); // an earlier compare still running must not replace this note
    out.innerHTML = emptyBox("Both sides are the same user. Pick two different users to compare.");
    return;
  }
  const users = { a: cmpPicked.cmpa, b: cmpPicked.cmpb };
  runInto(out, cmpRun, "Reading both users' groups...", async (current) => {
    const r = await send("users/compare", { a: users.a.id, b: users.b.id });
    if (!current()) return;
    cmpReport = { ...r, users };
    return renderCompare(cmpReport);
  });
});
bindExport("cmpusers", () => cmpRows(), () => `compare-${cmpReport?.users.a.displayName}-${cmpReport?.users.b.displayName}.csv`);

// Device 360

let d360Report = null;
const d360Run = newestOnly(); // only the latest search may draw
const D360_BADGE = {
  applies: ["ok", "Applies"], filter: ["warn", "Depends on filter"],
  uncertain: ["warn", "Uncertain"], excluded: ["", "Excluded"],
};
// The "what reaches" table of Device 360 and of User 360: one sorter each, drawing only the table (the Settings card beside it keeps its filter).
const REACH_COLS = [{ key: "name", label: "Name" }, { key: "type", label: "Type" }, { key: "state", label: "Result", type: "num", first: 1 }, { key: "why", label: "Why" }, { key: "intent", label: "Intent" }];
const reachReport = (prefix) => (prefix === "d360" ? d360Report : u360Report);
const redrawReach = (prefix) => { const el = $(`#${prefix}-reach`), r = reachReport(prefix); if (el && r) el.innerHTML = reachTable(r, prefix); };
const reachSorters = { d360: createSorter("d360reach", { key: "" }, () => redrawReach("d360")), u360: createSorter("u360reach", { key: "" }, () => redrawReach("u360")) };
const reachValue = (row, k) => ({ name: row.name, type: row.typeLabel, state: Object.keys(D360_BADGE).indexOf(row.state) + 1 || null, why: row.why.join(" "), intent: row.intents.join(", ") }[k]);
const reachSorted = (report, prefix) => reachSorters[prefix].apply(report?.rows || [], REACH_COLS, reachValue);
const reachTable = (r, prefix) => sortedTable(reachSorters[prefix], REACH_COLS, reachSorted(r, prefix), (row) => [
  td(link(row.link, row.name)), td(esc(row.typeLabel)), td(badge(D360_BADGE, row.state)), td(d360WhyCell(row)), td(esc(row.intents.join(", "))),
]);
const d360SetSorter = createSorter("d360set", { key: "", dir: 1 }, () => drawD360Settings()); // "" keeps the report's order: conflicts first, then by setting

/** Why a policy reaches the device: its groups, the filter that decides, and an unknown platform. Device 360 and its Settings card. */
const d360FilterText = (f) => `${f.mode === "exclude" ? "Unless" : "Only if"} filter "${f.name}" matches`;
const d360WhyCell = (row) => [...row.why.map((w) => esc(w)),
  ...row.filters.map((f) => `<span title="${esc(f.rule)}">${esc(d360FilterText(f))}</span>`),
  ...(row.platformUnknown ? ['<span class="muted">Platform not known, may not apply to this device</span>'] : [])].join("<br>");

/**
 * Shared by the Device 360 and Baseline gap searches: load the devices, match the name or primary user, and either
 * open the one hit or list up to 50 to pick from. The pick buttons carry `attr` (data-d360 / data-bl).
 * newRun() starts a run and returns a function that says whether it is still the newest.
 */
/** Devices in the loaded (scoped) device list whose name or primary user holds every word of q, A to Z. */
function matchDevices(q, windowsOnly = false) {
  const words = searchWords(q);
  return appState.devicesCache.devices
    .filter((d) => (!windowsOnly || /windows/i.test(d.os || "")) && hasAllWords(deviceSearchText(d), words))
    .sort((x, y) => x.name.localeCompare(y.name));
}

export function findDevice({ q, out, newRun, windowsOnly, attr, open }) {
  return runInto(out, newRun, "Reading your devices...", async (current) => {
    await loadDevices();
    if (!current()) return;
    const kind = windowsOnly ? "Windows device" : "device";
    const hits = matchDevices(q, windowsOnly);
    if (hits.length === 1) { open(hits[0].managedId); return; }
    return hits.length
      ? `<article class="card"><p class="muted">${hits.length.toLocaleString()} ${kind}s match. Pick one.</p>` +
        tableHtml(["Device", "Primary user", "OS", "Last check-in"], hits.slice(0, 50).map((d) => [
          td(`<button class="link" ${attr}="${esc(d.managedId)}">${esc(d.name)}</button>`, "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)),
        ])) + (hits.length > 50 ? '<p class="muted small">Showing the first 50. Search for more of the name.</p>' : "") + "</article>"
      : emptyBox(`No ${kind} matches that name or primary user.`);
  });
}

function findD360() {
  const q = $("#d360-query").value.trim().toLowerCase();
  if (!q) return;
  return findDevice({ q, out: $("#d360-results"), newRun: d360Run, attr: "data-d360", open: runD360 });
}

async function runD360(managedId) {
  await runInto($("#d360-results"), d360Run, "Reading groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const { report } = await send("device/360", { managedId });
    if (!current()) return;
    d360Report = report;
    d360SetSorter.reset();
    reachSorters.d360.reset();
    return renderD360(report);
  });
  const filter = $("#d360set-filter");
  if (filter) { onEnterOrClear(filter, drawD360Settings); drawD360Settings(); }
}

/** The Settings card: every setting the policies reaching this device configure, which policy sets it, and conflicts. */
function d360SettingsCard(s) {
  const notes = [
    ...(s.noSettings ? [`${s.noSettings} other item${s.noSettings === 1 ? "" : "s"} (apps, scripts and similar) reach the device but have no settings in the index.`] : []),
    ...(s.partial.length ? [`Only part of the settings of ${s.partial.join(", ")} could be read, so a conflict with them may be missed.`] : []),
  ];
  return `<article class="card">
      <div class="toolbar tight">
        <h2>Settings that reach this device</h2>
        <span class="muted">${s.settings.toLocaleString()} settings from ${s.policies.toLocaleString()} policies${s.conflicts ? `, <strong>${s.conflicts.toLocaleString()} in conflict</strong>` : ", no conflicts"}${s.same ? `, ${s.same.toLocaleString()} set the same by several` : ""}</span>
        <span class="spacer"></span>
        ${exportButtons("d360set")}
      </div>
      <div class="toolbar">
        <label>Show <select id="d360set-show"><option value="conflict"${s.conflicts ? " selected" : ""}>Conflicts (different values)</option><option value="same">Same value, several policies</option><option value="all"${s.conflicts ? "" : " selected"}>All</option></select></label>
        <input id="d360set-filter" type="search" placeholder="Filter settings, then press Enter" aria-label="Filter settings">
        <span class="muted small" id="d360set-count"></span>
      </div>
      <div id="d360set-table"></div>
      ${notes.map((n) => `<p class="muted small">${esc(n)}</p>`).join("")}
      <p class="muted small">A conflict is the same setting set to different values by two policies that reach this device; Intune reports it as a conflict on the device. Group Policy and scripts are not seen.</p>
    </article>`;
}

const D360SET_COLS = [{ key: "name", label: "Setting" }, { key: "value", label: "Value" }, { key: "policy", label: "Policy" }, { key: "certainty", label: "Result", type: "num", first: 1 }, { key: "why", label: "Reached through" }];
const d360SetValue = (r, key) => (key === "policy" ? r.policy.name : key === "certainty" ? (Object.keys(D360_BADGE).indexOf(r.certainty) + 1 || null) : key === "why" ? r.why.join(" ") : r[key]);

/** The Settings card's rows after its Show choice and filter, in the chosen sort order. */
function d360SetShown() {
  const s = d360Report?.settings;
  if (!s) return [];
  const words = searchWords($("#d360set-filter")?.value || "");
  const show = $("#d360set-show")?.value; // conflict, same or all
  return d360SetSorter.apply(s.rows.filter((r) => (show === "conflict" ? r.conflict : show === "same" ? r.same : true) && hasAllWords(`${r.name}\n${r.path}\n${r.value}\n${r.policy.name}`, words)),
    D360SET_COLS, d360SetValue);
}

function drawD360Settings() {
  const out = $("#d360set-table");
  if (!out) return;
  const rows = d360SetShown();
  $("#d360set-count").textContent = `${rows.length.toLocaleString()} of ${d360Report.settings.rows.length.toLocaleString()} shown`;
  out.innerHTML = rows.length
    ? capped(rows, (shown) => sortedTable(d360SetSorter, D360SET_COLS, shown, (r) => [
      td(`${r.conflict ? '<span class="badge bad">Conflict</span> ' : r.same ? '<span class="badge">Same value</span> ' : ""}${esc(r.name)}${r.path && r.path !== r.name ? `<div class="muted small path">${esc(r.path)}</div>` : ""}`),
      valueCell(r.value), td(link(r.policy.link, r.policy.name) + `<div class="muted small">${esc(r.policy.typeLabel)}</div>`),
      td(badge(D360_BADGE, r.certainty), "nowrap"), td(d360WhyCell(r)),
    ]), 1000)
    : emptyBox("Nothing to show with this choice and filter.");
}

function d360SetRows() {
  return [["Setting", "Path", "Value", "Policy", "Type", "Result", "Reached through", "Overlap"],
    ...d360SetShown().map((r) => [r.name, r.path, r.value, r.policy.name, r.policy.typeLabel, D360_BADGE[r.certainty]?.[1] || "", r.why.join("; "), r.conflict ? "Conflict" : r.same ? "Same value" : ""])];
}

/** A list of groups (direct, or nested with the group they come through), "Couldn't be read" for null. Device 360, User 360. */
const groupsCard = (title, groups, none) => `<article class="card"><h2>${esc(title)}</h2>${groups === null ? '<p class="muted">Couldn\'t be read.</p>'
  : groups.length ? `<ul>${groups.map((g) => `<li>${link(g.link, g.name)}${g.direct ? "" : ` <span class="muted">nested${g.via ? `, via ${esc(g.via)}` : ""}</span>`}</li>`).join("")}</ul>`
    : `<p class="muted">${esc(none)}</p>`}</article>`;

/** What a 360 report could not check (its notes, unreadable assignments, policy types the index couldn't read), as a card. */
function notCheckedCard(r) {
  const warnings = [...r.notes,
    ...(r.unreadable ? [`${r.unreadable} policies' assignments couldn't be read, so they aren't checked.`] : []),
    ...(r.indexErrors.length ? [`The policy index couldn't read: ${r.indexErrors.join(", ")}. Those aren't checked.`] : [])];
  return warnings.length ? `<article class="card"><h2>Not everything could be checked</h2><ul>${warnings.map((w) => `<li>${esc(w)}</li>`).join("")}</ul></article>` : "";
}

/** The "what reaches" card of a 360 report: counts, the table, export buttons under `prefix`, and a note (HTML). */
function reachCard(r, title, prefix, empty, noteHtml) {
  const { applies, filter, uncertain, excluded } = r.counts;
  return `<article class="card">
      <div class="toolbar tight">
        <h2>${esc(title)}</h2>
        <span class="muted">${applies} apply, ${filter} depend on a filter, ${uncertain} uncertain, ${excluded} excluded</span>
        <span class="spacer"></span>
        ${exportButtons(prefix)}
      </div>
      ${r.rows.length ? `<div id="${prefix}-reach">${reachTable(r, prefix)}</div>` : emptyBox(empty)}
      <p class="muted small">${noteHtml}</p>
    </article>`;
}

function renderD360(r) {
  const d = r.device;
  return `
    <article class="card">
      <h2>${link(d.link, d.name)}</h2>
      <div class="facts">
        <div><span>Primary user</span>${esc(userOf(d) || "None")}</div>
        <div><span>OS</span>${esc(friendlyOs(d.os, d.osVersion))}</div>
        <div><span>Compliance</span>${complianceBadge(d.compliance)}</div>
        <div><span>Last check-in</span>${checkInCell(d.lastSync)}</div>
      </div>
    </article>
    ${notCheckedCard(r)}
    ${reachCard(r, "What reaches this device", "d360", "Nothing in the policy index reaches this device.",
      `User targeting is worked out for the primary user; it really follows whoever signs in. Filters aren't evaluated, so those rows say which filter decides.${r.otherPlatform ? ` ${r.otherPlatform} assigned to other platforms left out.` : ""} Policy index from ${esc(ago(r.policyIndexBuiltAt))}.`)}
    ${r.settings ? d360SettingsCard(r.settings) : ""}
    ${groupsCard("Device groups", r.deviceGroups, "This device isn't in any group.")}
    ${r.hasUser ? groupsCard("Primary user's groups", r.userGroups, "The primary user isn't in any group.") : ""}`;
}

/** Copy table / Save CSV rows of a 360 report's "what reaches" table (Device 360, User 360). */
function reachTableRows(report, prefix) {
  return [["Name", "Type", "Result", "Why", "Filter", "Intent"],
    ...reachSorted(report, prefix).map((row) => [row.name, row.typeLabel, D360_BADGE[row.state][1], row.why.join("; "),
      row.filters.map((f) => `${f.mode} ${f.name}`).join("; "), row.intents.join(", ")])];
}

$("#d360-find").addEventListener("click", findD360);
onEnterOrClear($("#d360-query"), findD360);
$("#d360-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-d360]");
  if (pick) { runD360(pick.dataset.d360); return; }
});
$("#d360-results").addEventListener("input", (e) => { if (e.target.id === "d360set-show") drawD360Settings(); });
bindExport("d360", () => reachTableRows(d360Report, "d360"), () => `device-360-${d360Report?.device.name || "device"}.csv`);

// User 360: one user's devices, groups, and what reaches them through their groups or All users.

let u360Report = null;
const u360Run = newestOnly();

function runUser360(u) {
  return runInto($("#u360-results"), u360Run, "Reading the user's groups and policies. The first time, the policy index can take a few minutes...", async (current) => {
    const { report } = await send("user/360", { userId: u.id });
    if (!current()) return;
    u360Report = report;
    reachSorters.u360.reset();
    u360DevSorter.reset();
    return renderUser360(report);
  });
}

const U360DEV_COLS = [{ key: "name", label: "Device" }, { key: "os", label: "OS" }, { key: "compliance", label: "Compliance", type: "num", first: 1 }, { key: "seen", label: "Last check-in", type: "date" }];
const u360DevSorter = createSorter("u360dev", { key: "" }, () => { const el = $("#u360-devices"); if (el && u360Report) el.innerHTML = u360DevTable(u360Report); });
const u360DevTable = (r) => sortedTable(u360DevSorter, U360DEV_COLS, u360DevSorter.apply(r.devices, U360DEV_COLS, (d, k) => ({ name: d.name, os: friendlyOs(d.os, d.osVersion), compliance: complianceRank(d.compliance), seen: d.lastSync }[k])), (d) => [
  td(link(d.link, d.name) + recordsBadge(d.records), "nowrap"), td(esc(friendlyOs(d.os, d.osVersion))), td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)),
]);

function renderUser360(r) {
  const u = r.user;
  return `
    <article class="card">
      <h2>${link(u.link, u.displayName || u.userPrincipalName)}</h2>
      <div class="facts">
        <div><span>Sign-in name</span>${esc(u.userPrincipalName || "")}</div>
        <div><span>Account</span>${u.accountEnabled === false ? '<span class="badge bad">Disabled</span>' : u.accountEnabled ? '<span class="badge ok">Enabled</span>' : "?"}</div>
        <div><span>Job title</span>${esc(u.jobTitle || "-")}</div>
        <div><span>Department</span>${esc(u.department || "-")}</div>
      </div>
    </article>
    ${notCheckedCard(r)}
    <article class="card">
      <h2>Devices <span class="muted">· ${r.devices.length}</span></h2>
      ${r.devices.length ? `<div id="u360-devices">${u360DevTable(r)}</div>` : '<p class="muted">This user is not the primary user of any device in the device list.</p>'}
    </article>
    ${reachCard(r, "What reaches this user", "u360", "Nothing in the policy index reaches this user through their groups or All users.",
      `Through the user's groups and All users. Assignments to devices (device groups, All devices) are on each device's Device 360. Filters aren't evaluated. Policy index from ${esc(ago(r.policyIndexBuiltAt))}.`)}
    ${groupsCard("Groups", r.userGroups, "This user isn't in any group.")}`;
}

setupPicker("u360", runUser360);
bindExport("u360", () => reachTableRows(u360Report, "u360"), () => `user-360-${u360Report?.user.userPrincipalName || "user"}.csv`);
bindExport("d360set", () => d360SetRows(), () => `device-settings-${d360Report?.device.name || "device"}.csv`);
