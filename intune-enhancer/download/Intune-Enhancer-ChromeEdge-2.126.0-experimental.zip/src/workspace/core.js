// Workspace core: what every tool tab shares. The page helpers ($, esc, send, banners, links, badges), the export and
// download buttons, the report table helpers, and the tab list with its registry (registerTab / selectTab) and the shared
// page state. Moved out of workspace.js without changes to the code (see docs/workspace-split-plan.md).

import { PREFS_KEY } from "../core/prefs.js";
import { sampleSend } from "./sample.js";
import { escapeHtml } from "../shared/escape.js";
import { ageText, activityLevel } from "../core/device-reports.js";
import { chipFacets, chipMatch } from "../core/chip-filter.js";
import { reportUrl, deviceUrl } from "../core/portal-links.js";
import { csvText, tsvText } from "./sheet.js";
import { createJobBar } from "./job-bar.js";

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
export const esc = escapeHtml; // the short local name for the one shared escape (AVD Enhancer uses escapeHtml everywhere)

export const inExtension = Boolean(globalThis.chrome?.runtime?.id);
export const SAMPLE = !inExtension || new URLSearchParams(location.search).has("sample");

// The progress bar along the bottom (job-bar.js). Stop on a worker job asks the worker.
export const jobBar = createJobBar({ stopWorker: () => send("job/stop").catch(() => {}) });

// Reads the worker does in one go, with no count to show: just a line on the bar while they run.
const LONG_READS = {
  "device/360": "Reading the device's groups and policies",
  "baseline/applied": "Reading the device's groups and policies",
  "devices/compare": "Reading both devices' groups and policies",
  "users/compare": "Reading both users' groups",
  "policies/duplicates": "Comparing every policy",
  "compliance/summary": "Reading compliance results",
  "compliance/devices": "Reading the devices failing this setting",
  "tenant/health": "Checking tokens, certificates and connectors",
  "devices/orphaned": "Checking primary users", // the worker reports its count as it goes
  "failed/apps": "Reading app install results",
  "autopilot/events": "Reading Autopilot events and their enrollment status details",
};

export function send(type, payload = {}) {
  const label = LONG_READS[type];
  const key = label ? `read:${type}` : "";
  // devices/orphaned and anything else that builds an index can be stopped, so those lines get Stop too.
  if (key) jobBar.set(key, { label, stop: type === "devices/orphaned" || undefined });
  const reply = SAMPLE ? sampleSend(type, payload) : chrome.runtime.sendMessage({ type, ...payload }).then((res) => {
    if (!res) throw new Error("No response from the extension. Try reloading this tab.");
    if (res.ok === false) throw Object.assign(new Error(res.error || "Request failed."), { code: res.code });
    return res;
  });
  return key ? Promise.resolve(reply).finally(() => jobBar.done(key)) : reply;
}

/** How long ago a time (ms) was: "just now", "5 min ago", "3 h ago", or the date after two days. */
export function ago(ms) {
  if (!ms) return "never";
  const mins = Math.round((Date.now() - ms) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  return hours < 48 ? `${hours} h ago` : new Date(ms).toLocaleDateString();
}
export const checkInText = (iso) => ageText(iso) || "never";
/** Last check-in with its activity traffic light (green 8 hours, yellow 7 days, orange 30, red older or never). */
export const checkInCell = (iso) => `<span class="nowrap"><span class="light ${activityLevel(iso)}" aria-hidden="true"></span>${esc(checkInText(iso))}</span>`;
export const friendlyOs = (os, version) => globalThis.IEWindowsBuilds.friendlyOs(os, version); // shared/windows-builds.js
const COMPLIANCE_BADGES = {
  // The same words as Device quick facts (COMPLIANCE_TEXT in content/primary-user-labels.js).
  compliant: ["ok", "Compliant"], noncompliant: ["bad", "Not compliant"], inGracePeriod: ["warn", "In grace period"],
  conflict: ["warn", "Conflict"], error: ["bad", "Error"], unknown: ["", "Unknown"], configManager: ["", "Config Manager"],
};
/** A badge from a table of { key: [class, text] }; the class (ok, warn, bad or none) colours it. An unknown key shows itself. */
export const badge = (map, key) => {
  const [cls, text] = map[key] || ["", key || "Unknown"];
  return `<span class="badge ${cls}">${esc(text)}</span>`;
};
export const complianceBadge = (c) => badge(COMPLIANCE_BADGES, c);
/** A compliance state as a sort key for a Compliance column, most serious first (1 is the worst; a state not listed is empty, so it sorts last). Use with `type: "num", first: 1`. */
const COMPLIANCE_ORDER = ["noncompliant", "error", "conflict", "inGracePeriod", "unknown", "configManager", "compliant"];
export const complianceRank = (c) => COMPLIANCE_ORDER.indexOf(c) + 1 || null;
const VALUE_SHOWN = 120;
/**
 * A setting value's cell (Setting check, Device 360's Settings card): monospace and wrapping anywhere, and a long one
 * (a certificate, a script) cut to its start with its length, so it can't push the other columns off the card. Copy
 * table and Save CSV keep the whole value.
 */
export const valueCell = (value) => { const v = String(value ?? ""); return td(v.length > VALUE_SHOWN ? `${esc(v.slice(0, VALUE_SHOWN))}... <span class="muted">(${v.length.toLocaleString()} characters)</span>` : esc(v), "mono"); };
/** " N Intune records" after a device name that has more than one record (Group roster, User 360), else nothing. */
export const recordsBadge = (n) => (n > 1 ? ` <span class="badge warn">${n} Intune records</span>` : "");
/**
 * For a tool whose answers can arrive out of order (the first search can take a minute while an
 * index builds): `const current = run();` when a request starts, and `if (!current()) return;` before
 * writing its answer, so a slower, older request never replaces a newer one.
 */
export function newestOnly() {
  let latest = 0;
  return () => {
    const mine = ++latest;
    return () => mine === latest;
  };
}
/**
 * For a long read that must not run twice at once (a second click, or coming back to its tab): returns a function that
 * does nothing while run() is going, and otherwise runs it with `button` disabled until it settles. .busy() says
 * whether a run is going.
 */
export function oneAtATime(button, run) {
  let running = false;
  const buttons = [].concat(button); // one button, or several that start the same run (Hardware and Security posture)
  const start = async () => {
    if (running) return;
    running = true;
    buttons.forEach((b) => { b.disabled = true; });
    try {
      await run();
    } finally {
      running = false;
      buttons.forEach((b) => { b.disabled = false; });
    }
  };
  start.busy = () => running;
  return start;
}
export const loading = (text) => `<div class="empty"><span class="spinner"></span>${esc(text)}</div>`;
export const emptyBox = (text, more = "") => `<div class="empty">${esc(text)}${more}</div>`;
/** A link to the admin center home (the signed-in cloud's), where the sign-in is refreshed. */
export const adminCenterLink = () => ` ${link(reportUrl(""), "Open the Intune admin center")}`;
// A sign-in problem (no session, or every cached token refused) also offers the way to fix it.
const SIGN_IN_CODES = new Set(["NO_TOKEN", "FORBIDDEN"]);
export const errorBox = (e) => emptyBox(e?.message || e, SIGN_IN_CODES.has(e?.code) ? adminCenterLink() : "");
/**
 * One run of a tool whose answers can arrive out of order: starts a run of `newRun` (a newestOnly()), shows `text`
 * with a spinner in `out`, then writes the HTML work(current) returns, or the error, only while this run is still the
 * newest. work checks current() itself before it keeps anything (a report for Copy table, say) or draws `out` itself.
 */
export async function runInto(out, newRun, text, work) {
  const current = newRun();
  out.innerHTML = loading(text);
  try {
    const html = await work(current);
    if (current() && typeof html === "string") out.innerHTML = html;
  } catch (err) {
    if (current()) out.innerHTML = errorBox(err);
  }
}
// The note under a table that was cut to its first rows; Copy table and Save CSV still carry every row.
const limitNote = (shown, total, exports = "Copy and Save CSV include all.") => `<p class="muted small">Showing the first ${shown.toLocaleString()} of ${total.toLocaleString()}. ${exports}</p>`;
/** A long list drawn from its first `max` rows (draw(rows) makes the table), with the limitNote when rows were left out. */
export const capped = (list, draw, max = 2000, exports = undefined) => draw(list.slice(0, max)) + (list.length > max ? limitNote(max, list.length, exports) : "");

// Copy table / Save CSV: one markup helper, and one registry served by one click listener. A report registers its
// button prefix with bindExport(prefix, rows, file); rows and file are functions so they read the report on screen.
// csvRows is only for a report whose CSV holds more than its Copy table.
// Every report's buttons come from here, in one order: the most common on the far right (Save CSV on every report, then
// Copy table, then Copy Markdown, Save JSON, Save HTML on the fewest). `extras` names the ones a report adds (any of
// "md", "json", "html"); each keeps the id `<prefix>-<extra>` that its own click handler listens for.
// Icon buttons (as in AVD Enhancer): the full name is the hover text and the accessible name; Copy shows "Copied" the same way.
const svgIcon = (paths) => `<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</svg>`;
const EXPORT_EXTRAS = [
  ["html", "Save HTML", svgIcon('<path d="M8 8l-4 4 4 4M16 8l4 4-4 4M14 5l-4 14"/>')],
  ["json", "Save JSON", svgIcon('<path d="M9 4c-2 0-3 1-3 3v2c0 1-1 2-2 3 1 1 2 2 2 3v2c0 2 1 3 3 3M15 4c2 0 3 1 3 3v2c0 1 1 2 2 3-1 1-2 2-2 3v2c0 2-1 3-3 3"/>')],
  ["md", "Copy Markdown", svgIcon('<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15V9l2.5 3L12 9v6M17 9v6m0 0l-2-2m2 2l2-2"/>')],
];
const EXPORT_BASE = [
  ["copy", "Copy table", svgIcon('<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/>')],
  ["csv", "Save CSV", svgIcon('<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M9 4v16"/>')],
];
export const exportButtons = (prefix, extras = []) => [...EXPORT_EXTRAS.filter(([key]) => extras.includes(key)), ...EXPORT_BASE]
  .map(([key, label, icon]) => `<button type="button" class="export ico" id="${prefix}-${key}" title="${label}" aria-label="${label}">${icon}</button>`).join("");
for (const el of $$("[data-export]")) el.innerHTML = exportButtons(el.dataset.export, (el.dataset.extras || "").split(" ")); // the toolbars' placeholders (data-extras="json")
export const exportDefs = {};
// A report with a Save JSON button passes json: () => ({ file, data }), read when the button is clicked.
export const bindExport = (prefix, rows, file, csvRows = rows, json = null) => { exportDefs[prefix] = { rows, file, csvRows, json }; };
document.addEventListener("click", (e) => {
  const btn = e.target.closest?.('button[id$="-copy"], button[id$="-csv"], button[id$="-json"]');
  const m = btn && /^(.+)-(copy|csv|json)$/.exec(btn.id);
  const def = m && exportDefs[m[1]];
  if (!def) return;
  if (m[2] === "json") { const out = def.json?.(); if (out) saveJson(out.file, out.data); return; }
  const rows = (m[2] === "copy" ? def.rows : def.csvRows)();
  if (!rows) return;
  if (m[2] === "copy") copyTsv(btn, rows);
  else saveCsv(def.file(), rows);
});
export const link = (href, text) => (href ? `<a href="${esc(href)}" target="_blank" rel="noopener">${esc(text)}</a>` : esc(text));

export function showBanner(text, more = "") {
  const b = $("#banner");
  b.innerHTML = esc(text) + more;
  b.hidden = !text;
}

export function flash(btn, text) {
  if (btn.classList.contains("ico")) { // an icon button: the result is its hover text, and it lights up
    const was = btn.title;
    btn.title = text;
    btn.classList.add("flash");
    setTimeout(() => { btn.title = was; btn.classList.remove("flash"); }, 1500);
    return;
  }
  const old = btn.textContent;
  btn.textContent = text;
  setTimeout(() => { btn.textContent = old; }, 1500);
}

export const saveCsv = (filename, rows) => download(filename, new Blob(["\uFEFF" + csvText(rows)], { type: "text/csv;charset=utf-8" }));

export function download(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = Object.assign(document.createElement("a"), { href: url, download: filename.replace(/[\\/:*?"<>|]+/g, "_") });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ------------------------------------------------------------------------------------------
// Shared table helpers for the report tabs

/**
 * The frame every report table sits in: header cells and body rows as HTML (already escaped), with no header row when
 * head is "". attrs go on the scrolling frame (e.g. ' style="margin-top:8px"').
 */
export const tableWrap = (head, body, attrs = "") =>
  `<div class="tablewrap"${attrs}><table>${head ? `<thead><tr>${head}</tr></thead>` : ""}<tbody>${body}</tbody></table></div>`;

/** Header cells from labels: [label | { label, num }]. */
export const headCells = (headers) => headers.map((h) => (typeof h === "string" ? `<th>${esc(h)}</th>` : `<th class="${h.num ? "num" : ""}">${esc(h.label)}</th>`)).join("");

/** headers: [label | { label, num }], rows: arrays of cell HTML (already escaped). */
export function tableHtml(headers, rows, rowAttrs = () => "", attrs = "") {
  return tableWrap(headCells(headers), rows.map((r, i) => `<tr ${rowAttrs(i)}>${r.join("")}</tr>`).join(""), attrs);
}
export const td = (html, cls = "") => `<td${cls ? ` class="${cls}"` : ""}>${html}</td>`;

/** One pill (the All reports pills and chipBar's): html is its label, attrs extra attributes, pressed true or false for a toggle (aria-pressed). */
export function chipButton(html, attrs = "", pressed = null, disabled = false) {
  return `<button type="button" class="chip" ${attrs}${pressed === null ? "" : ` aria-pressed="${pressed}"`}${disabled ? " disabled" : ""}>${html}</button>`;
}

// Quick pill filters for a report (core/chip-filter.js has the rules): chipBar(groups, onChange) gives .html(rows), the
// pills drawn from the rows (a label, then a pill per value with its count; a second click on a pill lets it go, and Clear
// appears while any is picked). Pass the rows the report's own search and filters let through: a pill that would leave none of
// them is greyed out (count 0) unless it is picked. .test(row), which a report uses to filter its rows, and .handle(event), which a click
// listener on a container of the pills calls. The same look as the All reports pills (.chip, aria-pressed).
export function chipBar(groups, onChange) {
  const picked = Object.fromEntries(groups.map((g) => [g.key, new Set()]));
  const any = () => groups.some((g) => picked[g.key].size);
  return {
    test: (row) => chipMatch(row, groups, picked),
    html(rows) {
      const lines = chipFacets(rows, groups, picked).filter((x) => x.options.length > 1)
        .map(({ group: g, options }) => `<div class="chips"><span class="muted small">${esc(g.label)}</span>${options.map((o) => chipButton(`${esc(o.value)} <span class="muted">${o.count.toLocaleString()}</span>`,
          `data-chip-group="${esc(g.key)}" data-chip-value="${esc(o.value)}"`, picked[g.key].has(o.value), o.count === 0 && !picked[g.key].has(o.value))).join("")}</div>`);
      return lines.length ? lines.join("") + (any() ? `<div class="chips">${chipButton("Clear filters", "data-chip-clear")}</div>` : "") : "";
    },
    reset() { for (const g of groups) picked[g.key].clear(); },
    handle(e) {
      const b = e.target.closest?.(".chip[data-chip-group], .chip[data-chip-clear]");
      if (!b) return false;
      if (b.hasAttribute("data-chip-clear")) for (const g of groups) picked[g.key].clear();
      else { const set = picked[b.dataset.chipGroup]; const v = b.dataset.chipValue; if (set.has(v)) set.delete(v); else set.add(v); }
      onChange();
      return true;
    },
  };
}

/** Fill a platform dropdown, keeping the choice. Redone only when the list of names changed, so a pick isn't reset on every redraw. */
export function fillPlatforms(sel, platforms) {
  if (sel.options.length && [...sel.options].slice(1).map((o) => o.value).join("\n") === platforms.join("\n")) return;
  const keep = sel.value;
  sel.innerHTML = '<option value="">All platforms</option>' + platforms.map((p) => `<option>${esc(p)}</option>`).join("");
  sel.value = platforms.includes(keep) ? keep : "";
}

export async function copyText(btn, text) {
  try {
    await navigator.clipboard.writeText(text);
    flash(btn, "Copied");
  } catch {
    flash(btn, "Copy failed");
  }
}
export const copyTsv = (btn, rows) => copyText(btn, tsvText(rows));

const saveJson = (filename, data) => download(filename, new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }));

// Copy table / Save CSV buttons appear only once a report has rows, on every report.
export const showExport = (prefix, on) => { $(`[data-export="${prefix}"]`).hidden = !on; };
/**
 * Run fn on Enter, and when the box is emptied (its clear button, or deleting the text). Not the "search" event:
 * Firefox never fires it.
 */
export function onEnterOrClear(el, fn) {
  el.addEventListener("keydown", (e) => { if (e.key === "Enter") fn(); });
  el.addEventListener("input", () => { if (!el.value) fn(); });
}
export const apCell = (v) => (v !== null && typeof v === "object" ? JSON.stringify(v) : v === null || v === undefined ? "" : String(v));
export const kvTable = (obj) => tableWrap("", (Array.isArray(obj) ? obj : Object.entries(obj || {})).map(([k, v]) => `<tr><td class="nowrap">${esc(k)}</td><td>${esc(apCell(v))}</td></tr>`).join(""));
export const ownerLabel = (o) => ({ company: "Corporate", personal: "Personal" }[o] || o || "");
export const userOf = (d) => d.displayName || d.upn || "";

// ------------------------------------------------------------------------------------------
// Tabs: the list, the shared page state and the tab registry

export const TABS = ["baseline", "setting", "changes", "cleanup", "polexport", "dupes", "impact", "roster", "d360", "cmpdevices", "cmpusers", "os", "hygiene", "storage", "explorer", "hardware", "posture", "compliance", "orphans", "user360", "appdetails", "appver", "failedapps", "failedpolicies", "autopilot", "health", "console", "decode", "errors", "reports", "overview", "settings"];
export const DEFAULT_TAB = "d360"; // the first tool in the sidebar; where a fresh open lands
/** Page state that more than one file reads or sets (a plain `let` cannot be imported and changed). */
export const appState = {
  currentTab: DEFAULT_TAB,
  lastTab: DEFAULT_TAB, // the tab saved from the last visit (Baseline gap can only open once prefs are read)
  turnedOff: false, // set from the worker's status; the banner points to Settings while it is true
  baselineEnabled: false, // Baseline gap is off until Settings > Advanced turns it on
  scopeEnabled: false, // Settings > Advanced > Workspace scope (off by default)
  scope: null, // { id, name, ids: Set of Intune device ids once read }; only while enabled
  devicesCache: null, // the device list (loadDevices), or null until it is read
  compDevices: null, // Compliance: the devices failing the setting picked, or null
  hwData: null, // Hardware: the saved report { at, rows }, or null until read
  polDoc: null, // Policy export: the policy on screen { report, rows, title }, or null
  appDoc: null, // App details: the app on screen { report, rows, title }, or null
};

// What a tool does when its tab opens. A tool file registers its tab names with registerTab(names, onOpen); onOpen(name)
// returns true when nothing should take the focus afterwards (selectTab otherwise focuses the tab's first field).
const tabOpeners = {};
export function registerTab(names, onOpen) {
  for (const n of [].concat(names)) tabOpeners[n] = onOpen;
}

// While it's turned off the banner points to the Settings tab, or below when that tab is open.
export const showOffBanner = () => showBanner(appState.currentTab === "settings"
  ? "Intune Enhancer is turned off. Read what it does below, then turn it on."
  : "Intune Enhancer is turned off. Read what it does on the Settings tab, then turn it on.");

export function selectTab(name) {
  if (name === "baseline" && !appState.baselineEnabled) name = DEFAULT_TAB; // Baseline gap is off (Settings > Advanced)
  appState.currentTab = name;
  for (const btn of $$('[role="tab"], .settings-tab')) {
    const open = btn.dataset.tab === name;
    if (btn.getAttribute("role") === "tab") { btn.setAttribute("aria-selected", String(open)); btn.tabIndex = open ? 0 : -1; } // only the open tool is in the Tab order
    else btn.setAttribute("aria-current", open ? "page" : "false"); // the Settings button is not a tab
  }
  // With Settings open no tool is open: the first visible tool takes the Tab stop, so the sidebar can still be reached by keyboard.
  const stops = $$('[role="tab"]');
  if (!stops.some((b) => b.tabIndex === 0)) { const first = stops.find((b) => b.offsetParent !== null); if (first) first.tabIndex = 0; }
  for (const sec of $$(".tab")) sec.hidden = sec.id !== `tab-${name}`;
  try { localStorage.setItem("ie.workspace.tab", name); } catch { /* storage unavailable */ }
  if (appState.turnedOff) showOffBanner();
  if (tabOpeners[name]?.(name)) return;
  const first = $(`#tab-${name} input[type="search"], #tab-${name} textarea`);
  first?.focus();
}

// ------------------------------------------------------------------------------------------
// Saved settings, the header Scope and the device list: what the tools read before they draw (moved from workspace.js)

let devicesLoading = null;

// Dropdowns and sliders, with their defaults. Switches need none: they're on unless saved as false.
const DEFAULT_PREFS = {
  primaryUserLabels: "name", lastLoggedOnUser: "icon", friendlyOsVersions: "full", groupSizeHints: "all",
  freeStorageFlags: "10", appInstallStatus: "all", policyStatus: "all", widthDeviceName: 150, widthPolicyName: 150, widthGroupName: 150, widthAppName: 200,
  widthScriptName: 200,
  widthMemberName: 250,
  workspaceScope: false, // the header's Scope control; most admins don't need it
  baselineGap: false, // the Baseline gap tab (Settings > Advanced, experimental)
  remediationDates: false, // in-portal switch that is off until turned on: also in DEFAULT_OFF (content/kit.js)
};

let samplePrefs = { ...DEFAULT_PREFS };

export async function loadPrefs() {
  if (SAMPLE) return samplePrefs;
  const saved = (await chrome.storage.local.get(PREFS_KEY))[PREFS_KEY] || {};
  return { ...DEFAULT_PREFS, ...saved };
}

export async function savePrefs(patch) {
  if (SAMPLE) { samplePrefs = { ...samplePrefs, ...patch }; return; }
  // Only what the admin changed is saved, so a later version's new defaults still apply to the rest. The worker
  // writes it (core/prefs.js), one change after another, so changes close together don't overwrite each other.
  await send("prefs/set", { patch });
}

const scopeReady = loadPrefs().then((p) => {
  appState.scopeEnabled = p.workspaceScope === true;
  if (appState.scopeEnabled && p.scopeGroupId) appState.scope = { id: p.scopeGroupId, name: p.scopeGroupName || "Group", ids: null };
  renderScope();
  enableBaseline(p.baselineGap === true, true);
}).catch(() => {});

/** The scope's Intune device ids (null when there is no scope), read once per visit or when the list is refreshed. */
export async function scopeIds(force = false) {
  await scopeReady;
  if (!appState.scopeEnabled || !appState.scope) return null;
  if (appState.scope.ids && !force) return appState.scope.ids;
  const want = appState.scope;
  let res;
  try {
    res = await send("scope/devices", { groupId: want.id });
  } catch (err) {
    throw new Error(`The scope group "${want.name}" could not be read (${err.message}). Clear the scope at the top of the page, or pick another group.`);
  }
  if (appState.scope !== want) return scopeIds(); // the scope changed while this was read
  appState.scope.ids = new Set(res.managedIds);
  appState.scope.name = res.group.name || appState.scope.name;
  renderScope();
  return appState.scope.ids;
}

/** Rows inside the scope (every row when there is none). idOf gives a row's Intune device id. */
export async function scoped(rows, idOf = (r) => r.managedId) {
  const ids = await scopeIds();
  return ids ? (rows || []).filter((r) => ids.has(idOf(r))) : rows || [];
}

export const scopeNote = () => (appState.scopeEnabled && appState.scope ? ` in ${appState.scope.name}` : "");

export function renderScope() {
  $("#scope").hidden = !appState.scopeEnabled;
  const on = !!appState.scope;
  $("#scope").classList.toggle("on", on);
  $("#scope-clear").hidden = !on;
  const text = on ? `Scope: ${appState.scope.name}${appState.scope.ids ? ` (${appState.scope.ids.size.toLocaleString()})` : ""}` : "Scope: All devices";
  $("#scope-text").textContent = text;
  $("#scope-pill").title = on ? `${text}. The workspace's device lists show only this group's devices. Click to change.` : "Show only one device group's devices in the workspace's device lists";
}

export function loadDevices(force = false) {
  if (appState.devicesCache && !force) return Promise.resolve(appState.devicesCache);
  if (!devicesLoading) {
    const want = appState.scope;
    const load = Promise.all([send("devices/list"), scopeIds(force)])
      .then(([res, ids]) => {
        // The scope changed while this was read: read again for the new one, so no list lands in the wrong scope.
        if (appState.scope !== want) { devicesLoading = null; return loadDevices(); }
        // Links and the platform list are made here, once per list, not in the worker or on every redraw.
        for (const d of res.devices) d.link ||= deviceUrl(d.managedId);
        res.total = res.devices.length;
        if (ids) res.devices = res.devices.filter((d) => ids.has(d.managedId)); // the header's scope
        res.platforms = [...new Set(res.devices.map((d) => d.os || "Unknown OS"))].sort();
        appState.devicesCache = res;
        return res;
      })
      .finally(() => { if (devicesLoading === load) devicesLoading = null; });
    devicesLoading = load;
  }
  return devicesLoading;
}

// Baseline gap: its tab shows only when Settings > Advanced (experimental) turns it on. The worker checks the same setting.
export function enableBaseline(on, atStart = false) {
  appState.baselineEnabled = on;
  $('[data-tab="baseline"]').hidden = !on;
  if (!on && appState.currentTab === "baseline") selectTab(DEFAULT_TAB);
  // Prefs load after the first tab is chosen, so a link or the last-used tab that was Baseline gap opens it now.
  if (on && atStart && appState.currentTab === DEFAULT_TAB && (location.hash === "#baseline" || appState.lastTab === "baseline")) selectTab("baseline");
}

/** A count per status as badges ("Pass: 12 Fail: 3"): map is { key: [class, label] }, counts { key: n }. Baseline gap and Security posture. */
// A zero count is greyed (muted), so the counts that matter keep their colour.
export const badgeCounts = (map, counts) => Object.entries(map).map(([k, [cls, label]]) => {
  const n = counts[k] || 0;
  return `<span class="badge ${n ? cls : "muted"}">${esc(label)}: ${n.toLocaleString()}</span>`;
}).join(" ");

/** A headline number with its label (Cleanup's findings, Environment overview's summary); cls colours it (ok, warn, bad). */
export const tile = (value, label, cls = "") => `<div class="tile ${cls}"><strong>${esc(value)}</strong>${esc(label)}</div>`;
