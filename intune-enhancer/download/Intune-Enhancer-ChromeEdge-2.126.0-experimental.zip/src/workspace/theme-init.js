// Sets the workspace theme before the page paints, so a dark-theme user never sees a white flash.
// Loaded as a plain blocking script in <head> (extension pages don't allow inline scripts).
// The saved choice wins; otherwise dark-blue. The old two-theme values map across: "light" is light-blue, "dark" is dark-blue.
// IDS must list the same ids as THEMES in themes.js (a plain script cannot import it; the test run compares the two).
(function () {
  const IDS = "light-blue light-grey light-pink dark-blue dark-green dark-red".split(" ");
  let saved = null;
  try { saved = localStorage.getItem("ie.theme"); } catch { /* storage unavailable */ }
  document.documentElement.dataset.theme = saved === "light" ? "light-blue" : IDS.includes(saved) ? saved : "dark-blue";
})();
