// Click-to-sort for the report tables (docs/sort-plan.md). A table makes one sorter, draws its headings with head(cols) and its rows
// from apply(rows, cols, value); a click or Enter or Space on a heading changes the sort and calls the table's redraw. The rules
// (first click direction, empty last, numeric-aware text) are in core/sort-rules.js. One listener serves every sorter.

import { esc, tableWrap } from "./core.js";
import { nextSort, sortRows } from "../core/sort-rules.js";

const sorters = new Map();

/**
 * A sorter for one table. id is unique per table on the page; start is its starting sort ({ key, dir }, or { key: "" } for the
 * table's own order); redraw draws the table again after a click. The state lasts as long as the page, so a filter or chip redraw keeps it.
 */
export function createSorter(id, start, redraw) {
  let cols = [];
  const sorter = {
    state: { ...start },
    /** The heading cells for these columns: a button-like cell with aria-sort and an arrow on the sorted one. A heading is right-aligned when the column says `num: true`; a column with only `type: "num"` (a rank, such as a badge's severity) stays left-aligned over its text. */
    head(list) {
      cols = list;
      return list.map((c) => {
        const on = sorter.state.key === c.key;
        return `<th data-sorter="${esc(id)}" data-key="${esc(c.key)}" class="${c.num ? "num " : ""}sortable" tabindex="0" aria-sort="${on ? (sorter.state.dir > 0 ? "ascending" : "descending") : "none"}">${esc(c.label)}${on ? (sorter.state.dir > 0 ? " ▲" : " ▼") : ""}</th>`;
      }).join("");
    },
    /** The rows in this sorter's order (cols may be wider than the headings, as Security posture's are). value(row, key) reads a cell; left out, a column's own `get(row)` does, else row[key]. */
    apply: (rows, sortCols, value) => sortRows(rows, sortCols, sorter.state, value || ((r, k) => { const c = sortCols.find((x) => x.key === k); return c?.get ? c.get(r) : r[k]; })),
    /** Back to the starting sort (a new run of the report). */
    reset() { sorter.state = { ...start }; },
    /** A click on a heading: reverse the same column or start another, then draw again. */
    click(key) {
      const col = cols.find((c) => c.key === key);
      if (!col) return;
      sorter.state = nextSort(sorter.state, col);
      redraw();
    },
  };
  sorters.set(id, sorter);
  return sorter;
}

/**
 * A sorted table: the sorter's headings for `cols` (plus `extra` heading cells after them) and one row per item of `rows`, which the
 * caller has already put in the sorter's order (the same list its Copy table reads, so the two cannot differ). cells(row) is the row's
 * cells, an array of td HTML; rowAttrs(row) gives the row's attributes; attrs go on the scrolling frame, as in tableWrap.
 */
export const sortedTable = (sorter, cols, rows, cells, { extra = "", attrs = "", rowAttrs } = {}) =>
  tableWrap(sorter.head(cols) + extra, rows.map((r) => { const a = rowAttrs?.(r); return `<tr${a ? ` ${a}` : ""}>${cells(r).join("")}</tr>`; }).join(""), attrs);

function activate(th, fromKeyboard) {
  const sorter = sorters.get(th.dataset.sorter);
  if (!sorter) return;
  const { sorter: id, key } = th.dataset;
  sorter.click(key);
  // The heading is drawn again with the table; a keyboard user keeps their place on it.
  if (fromKeyboard) document.querySelector(`th[data-sorter="${CSS.escape(id)}"][data-key="${CSS.escape(key)}"]`)?.focus();
}

document.addEventListener("click", (e) => {
  const th = e.target.closest?.("th[data-sorter]");
  if (th) activate(th, false);
});
document.addEventListener("keydown", (e) => {
  if (e.key !== "Enter" && e.key !== " ") return;
  const th = e.target.closest?.("th[data-sorter]");
  if (!th) return;
  e.preventDefault();
  activate(th, true);
});
