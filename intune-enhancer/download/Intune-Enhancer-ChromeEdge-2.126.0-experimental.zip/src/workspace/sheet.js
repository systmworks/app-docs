// Table text for spreadsheets: Save CSV and Copy table. Pure, so tests/test.html checks it.

const pad2 = (n) => String(n).padStart(2, "0");

const TIMESTAMP = /^\d{4}-\d\d-\d\dT\d\d:\d\d(:\d\d(\.\d+)?)?(Z|[+-]\d\d:\d\d)$/;
const DATE_ONLY = /^(\d{4})-(\d\d)-(\d\d)$/;

/** The computer's time zone as "UTC+10" ("UTC+5:30", "UTC-4", "UTC"): what a date column's heading says its times are in. */
export function tzLabel(now = new Date()) {
  const m = -now.getTimezoneOffset();
  if (!m) return "UTC";
  const a = Math.abs(m);
  return `UTC${m < 0 ? "-" : "+"}${Math.floor(a / 60)}${a % 60 ? `:${pad2(a % 60)}` : ""}`;
}

/**
 * An ISO timestamp from Graph ("2026-11-11T00:31:44Z", with or without seconds or fractions) as local "d/mm/yyyy h:mm"
 * (no seconds), which Excel reads as a date and time and sorts. A date alone ("2026-11-09") becomes "9/11/2026". Any
 * other value comes back unchanged.
 */
export function sheetDate(value) {
  const s = String(value ?? "");
  const only = DATE_ONLY.exec(s);
  if (only) {
    const [, y, m, d] = only;
    const check = new Date(Date.UTC(+y, m - 1, +d));
    return check.getUTCMonth() === m - 1 && check.getUTCDate() === +d ? `${+d}/${m}/${y}` : s;
  }
  if (!TIMESTAMP.test(s)) return s;
  const d = new Date(s);
  return Number.isNaN(d.getTime()) ? s : `${d.getDate()}/${pad2(d.getMonth() + 1)}/${d.getFullYear()} ${d.getHours()}:${pad2(d.getMinutes())}`;
}

/**
 * One cell, safe to open in a spreadsheet: a value starting with =, +, -, @, a tab or a carriage return gets a
 * leading ' so Excel and others show it as text instead of running it as a formula (a device or policy name is
 * whatever the tenant's admins typed). A number is left as it is, so a negative one stays a number.
 */
export function sheetCell(value) {
  if (typeof value === "number") return String(value);
  const s = sheetDate(value);
  return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
}

/**
 * The rows with the time zone added to the heading (first row) of every column that holds timestamps:
 * "Last check-in" becomes "Last check-in (UTC+10)". A column's timestamps are looked for in the rows below the first.
 */
function withZone(rows) {
  const cols = new Set();
  for (const row of rows.slice(1)) row.forEach((c, i) => { if (TIMESTAMP.test(String(c ?? "")) && sheetDate(c) !== c) cols.add(i); });
  if (!cols.size) return rows;
  return [rows[0].map((c, i) => (cols.has(i) && typeof c === "string" && c && !TIMESTAMP.test(c) ? `${c} (${tzLabel()})` : c)), ...rows.slice(1)];
}

/** Rows as CSV: every cell quoted, quotes doubled, line breaks inside a cell kept (quoted CSV allows them). */
export const csvText = (rows) => withZone(rows).map((row) => row.map((c) => `"${sheetCell(c).replace(/"/g, '""')}"`).join(",")).join("\r\n");

/** Rows as tab-separated text for the clipboard: tabs and line breaks inside a cell become spaces. */
export const tsvText = (rows) => withZone(rows).map((row) => row.map((c) => sheetCell(typeof c === "number" ? c : String(c ?? "").replace(/[\t\r\n]+/g, " "))).join("\t")).join("\n");
