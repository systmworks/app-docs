// The one HTML-escape for the worker, workspace and report modules. (Content scripts can't import modules, so
// content/kit.js keeps its own copy of the same function.)

const ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };

/** Text made safe to put inside innerHTML or an attribute: & < > " ' become entities; null and undefined become "". */
export const escapeHtml = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESCAPES[c]);
