// App install status for the in-portal pills on app lists: how many devices each app installed on
// and failed on, from Intune's app status overview report (the one behind an app's Overview page;
// it can lag by a few hours). Reports are read with POST, but nothing is changed. Read in batches.

import { isTransient, odataQuote, resolveIdsByName, sayOnce } from "./graph.js";


/**
 * The first row of an Intune report ({ Schema: [{ Column }], Values: [[...]] }) as { column: value }
 * with lower-case column names, or null. Inside $batch a non-JSON body arrives as base64 text.
 */
export const reportRow = (body) => reportRows(body)[0] ?? null;

/** Every row of an Intune report as { column: value } with lower-case column names (reportRow reads only the first). */
export function reportRows(body) {
  let b = body;
  if (typeof b === "string") {
    try { b = JSON.parse(b); } catch { try { b = JSON.parse(atob(b)); } catch { return []; } }
  }
  const names = (b?.Schema || []).map((c) => String(c.Column || c.name || "").toLowerCase());
  return (b?.Values || []).filter(Array.isArray).map((row) => Object.fromEntries(names.map((n, i) => [n, row[i]])));
}

/**
 * items: [{ key, id?, name? }]; apps known only by name are found by exact display name.
 * Returns { [key]: { id, installed, failed } | { notFound: true } | { ambiguous: n } | { retry: true } }
 * (retry: Graph was busy, so don't remember it).
 */
export async function appStatus(graph, items) {
  const out = await resolveIdsByName(graph, items, (name) =>
    `/deviceAppManagement/mobileApps?$filter=${encodeURIComponent(`displayName eq '${odataQuote(name)}'`)}&$select=id&$top=5`);
  const withId = items.filter((i) => i.id && !out[i.key]);
  if (withId.length) {
    const res = await graph.batch(withId.map((i, n) => ({
      id: String(n),
      url: "/deviceManagement/reports/getAppStatusOverviewReport",
      body: { filter: `(ApplicationId eq '${odataQuote(i.id)}')` },
    })));
    withId.forEach((i, n) => {
      const r = res.get(String(n));
      if (isTransient(r)) { out[i.key] = { retry: true }; return; }
      const row = r.status === 200 ? reportRow(r.body) : null;
      if (r.status !== 200) sayOnce("app-status", "warn", "App install status unavailable:", r.status, r.body?.error?.message || "");
      // No row (web links and other app types Intune doesn't report on): no pill.
      out[i.key] = row
        ? { id: i.id, installed: Number(row.installeddevicecount) || 0, failed: Number(row.faileddevicecount) || 0 }
        : { notFound: true };
    });
  }
  return out;
}
