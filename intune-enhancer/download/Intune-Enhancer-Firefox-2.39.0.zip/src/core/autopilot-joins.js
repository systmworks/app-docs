// Autopilot failures: what is joined to each deployment event beyond Intune's own event record. All reads.
//   - attempt history for the serial number (pure)
//   - the managed device record, the Entra device record, and the device's and user's groups
//   - the enrollment status page (ESP) the device should have got, worked out from the ESP assignments and the groups
//     (membership is read now, not as it was when the device enrolled, so a late change can hide the cause)
//   - the Autopilot deployment profile, its assigned groups, and whether the device is in them
// Every join is best effort: a read that fails becomes a note on the row, never an error for the report, and
// "could not read" is never reported as "not a member".

import { isTransient, sayOnce } from "./graph.js";
import { isGuid, isNilGuid } from "../shared/guid.js";

export const J_MAX = 300; // newest events that get the device, Entra and group reads
const jLower = (s) => String(s ?? "").toLowerCase();
const jGuid = (s) => (isGuid(s) && !isNilGuid(s) ? jLower(s) : "");
const jClean = (o) => (o && typeof o === "object" && !Array.isArray(o) ? Object.fromEntries(Object.entries(o).filter(([k]) => !k.startsWith("@odata"))) : null);
const jWhy = (x) => x?.body?.error?.message || (typeof x?.body === "string" ? x.body : "");
const jUniq = (list) => [...new Set(list.filter(Boolean))];

/** Per event: how many deployments this serial number had in the window, and whether a later one succeeded. Pure. */
export function attemptHistory(rows) {
  const bySerial = new Map();
  for (const r of rows) {
    const s = jLower(r.event?.deviceSerialNumber);
    if (!s) continue;
    if (!bySerial.has(s)) bySerial.set(s, []);
    bySerial.get(s).push(r);
  }
  const out = new Map();
  for (const list of bySerial.values()) {
    const asc = [...list].sort((a, b) => String(a.when).localeCompare(String(b.when)));
    asc.forEach((r, i) => {
      const later = asc.slice(i + 1).find((x) => x.state === "success");
      out.set(r.id, {
        attempts: asc.length, position: i + 1, failedOrUnknown: asc.filter((x) => x.state !== "success").length,
        first: asc[0].when, last: asc[asc.length - 1].when, laterSuccess: later ? later.when : "",
      });
    });
  }
  return out;
}

/**
 * Does an ESP configuration target this device or user? Its assignments are group targets, "All devices", "All users"
 * and exclusions. deviceIds / userIds: Sets of group ids, or null when that membership could not be read.
 * @returns { assigned, matches: true|false|null (null = could not tell), via }
 */
export function espTargets(cfg, deviceIds, userIds, names = new Map()) {
  const targets = (cfg.assignments || []).map((a) => a?.target || {});
  if (!targets.length) return { assigned: false, matches: false, via: "" };
  const inGroup = (gid) => {
    const g = jLower(gid);
    return (deviceIds && deviceIds.has(g)) || (userIds && userIds.has(g));
  };
  const label = (gid) => names.get(jLower(gid))?.name || gid;
  // A membership that could not be read leaves both an inclusion and an exclusion unknown: a device included by
  // "All devices" may still be excluded by a group it can't be checked against.
  let included = false, excluded = false, unknown = false, excludeUnknown = false;
  const via = [];
  for (const t of targets) {
    const type = jLower(t["@odata.type"]);
    if (type.includes("exclusiongroup")) {
      if (inGroup(t.groupId)) { excluded = true; via.push(`excluded by ${label(t.groupId)}`); }
      else if (!deviceIds || !userIds) excludeUnknown = true;
    } else if (type.includes("alldevices")) { included = true; via.push("All devices"); }
    else if (type.includes("alllicensedusers") || type.includes("allusers")) { included = true; via.push("All users"); }
    else if (t.groupId) {
      if (inGroup(t.groupId)) { included = true; via.push(label(t.groupId)); }
      else if (!deviceIds || !userIds) unknown = true;
    }
  }
  const matches = excluded ? false : included ? (excludeUnknown ? null : true) : unknown ? null : false;
  return { assigned: true, matches, via: via.join(", ") };
}

/**
 * The ESP Intune would give this device: the assigned configuration with the lowest priority number that targets the
 * device or its user, else the Default one. agrees is null when that cannot be told.
 * @returns { actualId, actualName, expectedId, expectedName, agrees, candidates, note }
 */
export function expectedEsp(configs, deviceIds, userIds, actualId, actualName, names = new Map()) {
  const isDefault = (c) => /default.*enrollmentcompletionpage/i.test(String(c.id || ""));
  const candidates = configs.filter((c) => !isDefault(c)).map((c) => ({ id: c.id, name: c.displayName || c.id, priority: Number(c.priority) || 0, ...espTargets(c, deviceIds, userIds, names) }))
    .filter((c) => c.assigned).sort((a, b) => a.priority - b.priority);
  const hit = candidates.find((c) => c.matches === true);
  const unsure = candidates.some((c) => c.matches === null);
  const dflt = configs.find(isDefault);
  const expected = hit || (unsure ? null : dflt ? { id: dflt.id, name: dflt.displayName || "Default" } : null);
  const agrees = !expected ? null : jLower(expected.id) === jLower(actualId) ? true : false;
  let note = "";
  if (!expected) note = "Could not tell which enrollment status page applies (group membership or assignments were not readable).";
  else if (agrees === false) note = `Expected "${expected.name}"${hit?.via ? ` (${hit.via})` : ""} but the event used "${actualName || actualId || "none"}". Membership is read now, not as at enrollment.`;
  else if (agrees && !hit) note = "The Default enrollment status page applies: no assigned page targets this device or its user (read now).";
  return { actualId: actualId || "", actualName: actualName || "", expectedId: expected?.id || "", expectedName: expected?.name || "", agrees, candidates, note };
}

/** "Hybrid Azure AD join" or "Microsoft Entra join" from a profile's OData type. Pure. */
export function profileKind(type) {
  const t = jLower(type);
  return t.includes("activedirectory") ? "Hybrid Azure AD join" : t.includes("azuread") ? "Microsoft Entra join" : "";
}

/** A list with its assignments: expanded in one read, else one assignments read per item. */
async function listWithAssignments(graph, base) {
  try {
    return await graph.all(`/beta${base}?$expand=assignments`);
  } catch (e) {
    sayOnce(`autopilot-expand-${base}`, "info", "Autopilot: $expand=assignments refused for", base, "- reading per item:", e?.message || e);
  }
  const list = await graph.all(`/beta${base}`);
  const res = await graph.batch(list.map((c, n) => ({ id: String(n), url: `${base}/${encodeURIComponent(c.id)}/assignments` })));
  list.forEach((c, n) => {
    const x = res.get(String(n));
    if (x?.status === 200 && Array.isArray(x.body?.value)) c.assignments = x.body.value;
    else c.assignmentsUnreadable = true;
  });
  return list;
}

// A list with a next page (more than 999 groups) counts as unreadable, so a group on a later page is never taken
// as "not a member": the ESP check then says it can't tell.
const jGroupList = (x) => (x?.status === 200 && Array.isArray(x.body?.value) && !x.body["@odata.nextLink"]
  ? x.body.value.map((g) => ({ id: jLower(g.id), name: g.displayName || "(unnamed)" })) : null);

/**
 * Add to each event row (rows are newest first): history, device (managed device record), entra (Entra device record),
 * deviceGroups, userGroups, esp, profile, joinNotes ({ device, entra, groups, esp, profile }: jWhy a join is empty).
 */
export async function joinAutopilot(graph, rows) {
  const history = attemptHistory(rows);
  for (const r of rows) { r.history = history.get(r.id) || null; r.joinNotes = {}; r.device = r.entra = r.deviceGroups = r.userGroups = r.esp = r.profile = null; }
  const subset = rows.slice(0, J_MAX);
  for (const r of rows.slice(J_MAX)) r.joinNotes.all = `Only the newest ${J_MAX} events get the device, Entra, group and enrollment status page checks.`;
  if (!subset.length) return;
  const step = async (name, fn) => {
    try { await fn(); } catch (e) {
      sayOnce(`autopilot-join-${name}`, "warn", `Autopilot ${name} unavailable:`, e?.message || e);
      for (const r of subset) r.joinNotes[name] ||= `Could not read (${String(e?.message || e).slice(0, 160)})`;
    }
  };

  // Managed device records (Intune), by the event's device id.
  const devId = (r) => jGuid(r.event?.deviceId) || jGuid(r.identity?.managedDeviceId);
  await step("device", async () => {
    const ids = jUniq(subset.map(devId));
    const res = await graph.batch(ids.map((id) => ({ id, url: `/deviceManagement/managedDevices/${id}` })));
    for (const r of subset) {
      const id = devId(r);
      if (!id) { r.joinNotes.device = "The event has no device id."; continue; }
      const x = res.get(id);
      if (x?.status === 200) r.device = jClean(x.body);
      else r.joinNotes.device = isTransient(x) ? "Intune was busy; read again to try once more."
        : x.status === 404 ? "Intune has no managed device record for this event (deleted, or never enrolled)." : `Intune refused the managed device (${x.status})${jWhy(x) ? `: ${String(jWhy(x)).slice(0, 160)}` : ""}.`;
    }
  });

  // Entra device records, by the Entra device id the managed device (or the Autopilot record) carries.
  const aadId = (r) => jGuid(r.device?.azureADDeviceId) || jGuid(r.identity?.azureAdDeviceId) || jGuid(r.identity?.azureActiveDirectoryDeviceId);
  await step("entra", async () => {
    const ids = jUniq(subset.map(aadId));
    const res = await graph.batch(ids.map((id) => ({ id, url: `/devices?$filter=${encodeURIComponent(`deviceId eq '${id}'`)}` })));
    for (const r of subset) {
      const id = aadId(r);
      if (!id) { r.joinNotes.entra = "No Entra device id is known for this event."; continue; }
      const x = res.get(id);
      const found = x?.status === 200 ? x.body?.value?.[0] : null;
      if (found) {
        r.entra = jClean(found);
        if (Date.parse(r.entra.registrationDateTime || "") > Date.parse(r.when || "")) r.joinNotes.entraNewer = "This Entra record was created after the event, so the groups below may not match what the device had at the time.";
      }
      else r.joinNotes.entra = isTransient(x) ? "Entra was busy; read again to try once more."
        : x?.status === 200 ? "Entra has no record of this device (a stale Autopilot stub was removed, or the join has not finished)." : `Entra refused the device (${x.status}).`;
    }
  });

  // Group membership of each device and user (including nested groups).
  await step("groups", async () => {
    const qs = "/transitiveMemberOf/microsoft.graph.group?$select=id,displayName&$top=999";
    const userKey = (r) => jGuid(r.device?.userId) || r.event?.userPrincipalName || "";
    const devs = jUniq(subset.map((r) => r.entra?.id));
    const users = jUniq(subset.map(userKey));
    const res = await graph.batch([
      ...devs.map((id) => ({ id: `d:${id}`, url: `/devices/${id}${qs}` })),
      ...users.map((id) => ({ id: `u:${id}`, url: `/users/${encodeURIComponent(id)}${qs}` })),
    ]);
    for (const r of subset) {
      if (r.entra?.id) {
        r.deviceGroups = jGroupList(res.get(`d:${r.entra.id}`));
        if (!r.deviceGroups) r.joinNotes.groups = "The device's groups could not be read.";
      } else r.joinNotes.groups = "The device has no Entra record, so its device groups are unknown.";
      const uk = userKey(r);
      if (uk) {
        r.userGroups = jGroupList(res.get(`u:${uk}`));
        if (!r.userGroups) r.joinNotes.groups = `${r.joinNotes.groups ? `${r.joinNotes.groups} ` : ""}The user's groups could not be read.`;
      }
    }
  });

  // ESP configurations, Autopilot profiles, and the names of the groups they are assigned to.
  let configs = null, profiles = null;
  await step("esp", async () => {
    configs = (await listWithAssignments(graph, "/deviceManagement/deviceEnrollmentConfigurations"))
      .filter((c) => /windows10enrollmentcompletionpage/i.test(String(c["@odata.type"] || "")) || /enrollmentcompletionpage/i.test(String(c.id || "")));
  });
  await step("profile", async () => { profiles = await listWithAssignments(graph, "/deviceManagement/windowsAutopilotDeploymentProfiles"); });
  const names = new Map();
  const groupIds = jUniq([...(configs || []), ...(profiles || [])].flatMap((c) => (c.assignments || []).map((a) => jLower(a?.target?.groupId))));
  if (groupIds.length) {
    try {
      for (const g of await graph.getByIds(groupIds, ["group"])) names.set(jLower(g.id), { name: g.displayName || "(unnamed)", rule: g.membershipRule || "" });
    } catch (e) { sayOnce("autopilot-groupnames", "warn", "Autopilot group names unavailable:", e?.message || e); }
  }

  const setOf = (list) => (list ? new Set(list.map((g) => g.id)) : null);
  for (const r of subset) {
    const ev = r.event || {};
    const devSet = setOf(r.deviceGroups), userSet = setOf(r.userGroups);
    if (configs) {
      const actualId = ev.windows10EnrollmentCompletionPageConfigurationId || "";
      // A user who could not be read counts as unknown, but an event with no user at all (self-deploying) as an empty set.
      r.esp = expectedEsp(configs, devSet, r.userGroups || !(ev.userPrincipalName || r.device?.userId) ? userSet || new Set() : null, actualId, ev.windows10EnrollmentCompletionPageConfigurationDisplayName, names);
    } else r.joinNotes.esp ||= "Enrollment status page assignments were not readable.";
    const name = ev.windowsAutopilotDeploymentProfileDisplayName;
    if (profiles && name) {
      const p = profiles.find((x) => jLower(x.displayName) === jLower(name));
      if (p) {
        const { assignments, ...rest } = jClean(p);
        r.profile = {
          ...rest, kind: profileKind(p["@odata.type"]),
          assignedGroups: (assignments || []).map((a) => a?.target || {}).filter((t) => t.groupId).map((t) => ({
            id: jLower(t.groupId), name: names.get(jLower(t.groupId))?.name || t.groupId, rule: names.get(jLower(t.groupId))?.rule || "",
            excluded: jLower(t["@odata.type"]).includes("exclusion"), deviceIsMember: devSet ? devSet.has(jLower(t.groupId)) : null,
          })),
        };
      } else r.joinNotes.profile = `No Autopilot profile named "${name}" now (renamed or deleted since).`;
    } else if (!profiles) r.joinNotes.profile ||= "Autopilot profiles were not readable.";
  }
}
