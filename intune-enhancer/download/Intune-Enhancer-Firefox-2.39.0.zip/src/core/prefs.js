// The one writer of ie.prefs (the Settings tab's switches, dropdowns and sliders, and column widths dragged in the
// admin center). Every change goes through the service worker and is written one after another, so two changes
// close together can't overwrite each other: each read-merge-write sees the one before it.

export const PREFS_KEY = "ie.prefs";

const KEY_RE = /^[A-Za-z]\w{0,63}$/;
const MAX_LIST = 200; // names in a list pref (the starred reports and tabs)
const isText = (v, max) => typeof v === "string" && v.length <= max;
const isValue = (v) => typeof v === "boolean" || (typeof v === "number" && Number.isFinite(v)) || isText(v, 64)
  || (Array.isArray(v) && v.length <= MAX_LIST && v.every((s) => isText(s, 100)));

/** Only well-formed keys with a switch, number, short text or a short list of names; anything else is dropped. Pure. */
export function cleanPatch(patch) {
  if (!patch || typeof patch !== "object") return {};
  return Object.fromEntries(Object.entries(patch).filter(([key, value]) => KEY_RE.test(key) && isValue(value)));
}

/** storage: { get(key) -> Promise<object>, set(items) -> Promise, remove(key) -> Promise } (chrome.storage.local). */
export function createPrefsWriter(storage) {
  let queue = Promise.resolve();
  const after = (job) => {
    const write = queue.then(job);
    queue = write.catch(() => {});
    return write;
  };
  return {
    /** Merge patch into the saved prefs, after every change already queued. */
    set(patch) {
      const clean = cleanPatch(patch);
      return after(async () => {
        if (!Object.keys(clean).length) return;
        const saved = (await storage.get(PREFS_KEY))[PREFS_KEY] || {};
        await storage.set({ [PREFS_KEY]: { ...saved, ...clean } });
      });
    },
    /** Every setting back to its default (nothing saved), after every change already queued. */
    reset() {
      return after(() => storage.remove(PREFS_KEY));
    },
  };
}
