// Discovered apps rolled up by app name: every version found and how many devices run it. Pure, so it
// is tested offline and runs on sample data.

import { compareVersions } from "./device-reports.js";

const MAX_APPS = 50;

/** True when `version` is older than `minimum`. (compareVersions sorts newest first, so older is positive.) */
export const isBelowVersion = (version, minimum) => compareVersions(version, minimum) > 0;

/**
 * @param detected Graph detectedApps: { id, displayName, version, publisher, deviceCount, platform }
 * @returns [{ name, publisher, platform, total, versions: [{ id, version, devices }] }], busiest app
 *   first, each app's versions newest first
 */
export function rollupApps(detected) {
  const apps = new Map();
  for (const item of detected || []) {
    const name = String(item.displayName || "").trim();
    if (!name) continue;
    const publisher = String(item.publisher || "").trim();
    const key = `${name.toLowerCase()}|${publisher.toLowerCase()}`;
    if (!apps.has(key)) apps.set(key, { name, publisher, platform: String(item.platform || ""), total: 0, versions: [] });
    const app = apps.get(key);
    const devices = Number(item.deviceCount) || 0;
    app.versions.push({ id: item.id, version: String(item.version || ""), devices });
    app.total += devices;
  }
  for (const app of apps.values()) app.versions.sort((a, b) => compareVersions(a.version, b.version));
  return [...apps.values()].sort((a, b) => b.total - a.total || a.name.localeCompare(b.name)).slice(0, MAX_APPS);
}
