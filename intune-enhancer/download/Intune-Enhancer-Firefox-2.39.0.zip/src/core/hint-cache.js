// Short-lived answers for the in-portal hints (group sizes, app and policy status, filter rules,
// policy names), so scrolling a list or reopening a blade doesn't repeat Graph calls. Kept in memory
// and copied to a store (IndexedDB in the worker), because the worker sleeps after about 30 s idle
// and would forget them. Pure apart from the store and clock it is given, so it is tested offline.

export const HINT_TTL_MS = 30 * 60 * 1000;
const SAVE_DELAY_MS = 2000;

/**
 * @param store { get(): Promise<[key, { at, value }][] | undefined>, set(entries): Promise }
 * @param now the clock, in ms (tests pass a fake one)
 */
export function createHintCache({ store, now = Date.now, ttlMs = HINT_TTL_MS, saveDelayMs = SAVE_DELAY_MS }) {
  const answers = new Map(); // key -> { at, value }
  const loading = new Map(); // key -> promise, so requests that arrive together share one load
  let restored = null;
  let saveTimer = 0;
  let generation = 0; // bumped by clear(), so a load that started before the clear can't refill the cache

  const isFresh = (hit) => Boolean(hit) && now() - hit.at < ttlMs;

  /** Bring back the answers saved before the worker last slept (once per wake). */
  function restore() {
    restored ||= (async () => {
      const startedAt = generation;
      const saved = await store.get();
      if (startedAt !== generation) return; // cleared meanwhile: the saved copy is the old one
      for (const [key, hit] of saved || []) if (isFresh(hit) && !answers.has(key)) answers.set(key, hit);
    })().catch(() => {});
    return restored;
  }

  /** Remember an answer; the fresh ones are saved a moment later, in one write for a burst of answers. */
  function remember(key, value, loadedAt = generation) {
    if (loadedAt !== generation) return;
    answers.set(key, { at: now(), value });
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      for (const [k, hit] of answers) if (!isFresh(hit)) answers.delete(k); // expired answers are dropped here
      store.set([...answers]).catch(() => {});
    }, saveDelayMs);
  }

  return {
    /** One answer by key: load() runs only when there is no fresh one, and callers that arrive together share it. */
    async cached(key, load) {
      await restore();
      const hit = answers.get(key);
      if (isFresh(hit)) return hit.value;
      if (!loading.has(key)) {
        const startedAt = generation;
        loading.set(key, load().then((value) => { remember(key, value, startedAt); return value; }).finally(() => loading.delete(key)));
      }
      return loading.get(key);
    },

    /** Drop one answer if it is older than `olderThanMs`, so the next cached() call reads it again. */
    forget(key, olderThanMs = 0) {
      const hit = answers.get(key);
      if (hit && now() - hit.at >= olderThanMs) answers.delete(key);
    },

    /**
     * Per-item answers: load(itemsNotCached) -> { [itemKey]: value }. A { retry: true } answer (Graph was busy)
     * and a { notFound: true } one (it may be created a minute later) aren't remembered.
     * An item already being loaded for another caller (two portal frames asking together) waits for that load
     * instead of asking Graph again.
     */
    async cachedItems(tid, kind, items, load) {
      await restore();
      const startedAt = generation;
      const keyOf = (item) => `${tid}|${kind}|${item.key}`;
      const out = {};
      const todo = [];
      const waits = [];
      for (const item of items) {
        const hit = answers.get(keyOf(item));
        if (isFresh(hit)) out[item.key] = hit.value;
        else if (loading.has(keyOf(item))) waits.push(loading.get(keyOf(item)).then((value) => { if (value !== undefined) out[item.key] = value; }, () => {}));
        else todo.push(item);
      }
      if (todo.length) {
        const all = load(todo);
        for (const item of todo) {
          const one = all.then((res) => res?.[item.key]);
          one.catch(() => {}); // a failed load is the caller's error, not one per waiting item
          loading.set(keyOf(item), one);
          one.finally(() => { if (loading.get(keyOf(item)) === one) loading.delete(keyOf(item)); }).catch(() => {});
        }
        for (const [key, value] of Object.entries((await all) || {})) {
          if (!value?.retry && !value?.notFound) remember(`${tid}|${kind}|${key}`, value, startedAt);
          out[key] = value;
        }
      }
      await Promise.all(waits);
      return out;
    },

    /** Forget every answer, in memory and saved (turned off, or Clear stored data). */
    clear() {
      generation++;
      clearTimeout(saveTimer);
      answers.clear();
      return store.set([]).catch(() => {});
    },
  };
}
