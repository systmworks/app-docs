// Device reports for the workspace: OS build spread, stale devices and duplicate device records.
// Pure functions over the device list (see resolve.js toDevice), so they run the same on real and
// sample data and are tested offline.

// Importing it sets globalThis.IEActivity; the in-portal scripts load the same file.
import "../shared/activity.js";
import { gb } from "./format.js";

/** Days since an ISO time (null for never / unparseable), and the activity traffic light for it: see shared/activity.js. */
export const { ageDays, activityLevel } = globalThis.IEActivity;

/** Numeric sort key from a version string ("10.0.26100.4349" -> [10, 0, 26100, 4349]). */
const versionKey = (v) => String(v || "").split(/[.\s]/).map((n) => Number(n) || 0);
export const compareVersions = (a, b) => {
  const x = versionKey(a);
  const y = versionKey(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) {
    if ((x[i] || 0) !== (y[i] || 0)) return (y[i] || 0) - (x[i] || 0); // newest first
  }
  return 0;
};

/**
 * The release a device is on, for grouping: Windows by named release ("Win11 24H2"), other
 * platforms by major version ("iOS 18"). friendly is IEWindowsBuilds.friendly.
 */
export function releaseOf(device, friendly = () => null) {
  const os = device.os || "Unknown OS";
  const v = device.osVersion || "";
  if (/^windows/i.test(os)) {
    const named = friendly(v);
    if (named) return { label: named.replace(/\s*\(.*\)$/, ""), sort: v };
    const build = v.match(/^10\.0\.(\d{5})/)?.[1];
    return { label: build ? `Windows build ${build}` : "Windows (version unknown)", sort: v };
  }
  const major = v.split(".")[0];
  return { label: major ? `${os} ${major}` : `${os} (version unknown)`, sort: v };
}

/**
 * Devices grouped by platform, then release, newest release first.
 * -> { total, platforms: [{ os, count, releases: [{ label, count, devices }] }] }
 */
export function osSpread(devices, friendly) {
  const byOs = new Map();
  for (const d of devices) {
    const os = d.os || "Unknown OS";
    const r = releaseOf(d, friendly);
    if (!byOs.has(os)) byOs.set(os, new Map());
    const releases = byOs.get(os);
    if (!releases.has(r.label)) releases.set(r.label, { label: r.label, sort: r.sort, devices: [] });
    const rel = releases.get(r.label);
    rel.devices.push(d);
    if (compareVersions(r.sort, rel.sort) < 0) rel.sort = r.sort; // keep the newest version as the key
  }
  const total = devices.length;
  const platforms = [...byOs.entries()].map(([os, releases]) => {
    const list = [...releases.values()]
      .map((r) => ({ label: r.label, count: r.devices.length, sort: r.sort, devices: r.devices }))
      .sort((a, b) => compareVersions(a.sort, b.sort));
    return { os, count: list.reduce((n, r) => n + r.count, 0), releases: list };
  }).sort((a, b) => b.count - a.count);
  return { total, platforms };
}

/** Devices not checked in for more than `days` (or never), oldest first. */
export function staleDevices(devices, days = 30, now = Date.now()) {
  return devices
    .map((d) => ({ ...d, age: ageDays(d.lastSync, now) }))
    .filter((d) => d.age === null || d.age > days)
    .sort((a, b) => (b.age ?? Infinity) - (a.age ?? Infinity) || a.name.localeCompare(b.name));
}

/**
 * Devices with less than `limitGb` free, least free first. Devices Intune reports no storage for
 * (total 0) are left out and counted in `unknown`. -> { list: [{ ...device, freeGb, totalGb }], unknown }
 */
export function lowStorageDevices(devices, limitGb = 10) {
  const list = [];
  let unknown = 0;
  for (const d of devices) {
    if (!(d.totalBytes > 0)) { unknown++; continue; }
    const freeGb = gb(d.freeBytes);
    if (freeGb < limitGb) list.push({ ...d, freeGb, totalGb: gb(d.totalBytes) });
  }
  list.sort((a, b) => a.freeGb - b.freeGb || a.name.localeCompare(b.name));
  return { list, unknown };
}

/**
 * Device names with more than one Intune record (re-imaged or re-enrolled devices leave old
 * records behind). Each group is newest check-in first; the first is marked current.
 * -> [{ name, count, records: [{ ...device, age, current }] }]
 */
export function duplicateDevices(devices, now = Date.now()) {
  const byName = new Map();
  for (const d of devices) {
    const key = String(d.name || "").trim().toLowerCase();
    if (!key) continue;
    if (!byName.has(key)) byName.set(key, []);
    byName.get(key).push(d);
  }
  return [...byName.values()]
    .filter((list) => list.length > 1)
    .map((list) => {
      const records = list
        .map((d) => ({ ...d, age: ageDays(d.lastSync, now) }))
        .sort((a, b) => String(b.lastSync || "").localeCompare(String(a.lastSync || "")))
        .map((d, i) => ({ ...d, current: i === 0 }));
      return { name: records[0].name, count: records.length, records };
    })
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name));
}
