// Compare two devices: what they are, which groups each is in, and which policies, apps and scripts reach
// each. Built from two Device 360 reports (device-360.js), so it carries the same limits: it is worked out
// from assignments and group membership, filters are not evaluated, and a group that couldn't be read is
// reported, never treated as "not a member". Pure, so it is tested offline.

import { gbText, day } from "./format.js";
import { compareGroups } from "./group-tools.js";

const cmpGb = (bytes) => (Number(bytes) > 0 ? gbText(bytes) : "");

/** [label, read from a device row] for the side-by-side facts. The first two are never marked as differences. */
const FACTS = [
  ["Device", (d) => d.name],
  ["Primary user", (d) => d.displayName || d.upn],
  ["OS", (d) => d.os],
  ["OS version", (d) => d.osVersion],
  ["Model", (d) => d.model],
  ["Ownership", (d) => d.owner],
  ["Compliance", (d) => d.compliance],
  ["Storage", (d) => cmpGb(d.totalBytes)],
  ["Free storage", (d) => (Number(d.totalBytes) > 0 ? cmpGb(d.freeBytes) : "")],
  ["Enrolled", (d) => day(d.enrolled)],
  ["Last check-in", (d) => day(d.lastSync)],
];

/** Split two group lists (or null where unreadable) into both, only the first and only the second. */
function splitGroups(a, b) {
  const byId = (list) => list && new Map(list.map((g) => [g.id, g]));
  return compareGroups(byId(a), byId(b));
}

/** Policies, apps and scripts that apply (or may apply) to each device; Excluded ones are not applying. */
function splitPolicies(ra, rb) {
  const applying = (r) => r.rows.filter((x) => x.state !== "excluded");
  const stateIn = (r, id) => r.rows.find((x) => x.id === id)?.state || "";
  const a = applying(ra);
  const b = applying(rb);
  const inB = new Map(b.map((x) => [x.id, x]));
  const inA = new Set(a.map((x) => x.id));
  const slim = (x) => ({ id: x.id, name: x.name, typeLabel: x.typeLabel, link: x.link });
  const byName = (x, y) => x.typeLabel.localeCompare(y.typeLabel) || x.name.localeCompare(y.name);
  return {
    both: a.filter((x) => inB.has(x.id)).map((x) => ({ ...slim(x), stateA: x.state, stateB: inB.get(x.id).state, differs: x.state !== inB.get(x.id).state })).sort(byName),
    onlyA: a.filter((x) => !inB.has(x.id)).map((x) => ({ ...slim(x), state: x.state, otherState: stateIn(rb, x.id) })).sort(byName),
    onlyB: b.filter((x) => !inA.has(x.id)).map((x) => ({ ...slim(x), state: x.state, otherState: stateIn(ra, x.id) })).sort(byName),
  };
}

/** @param ra, rb  two buildDevice360 reports */
export function compareDevices(ra, rb) {
  const facts = FACTS.map(([label, get], i) => {
    const a = String(get(ra.device) || "");
    const b = String(get(rb.device) || "");
    return { label, a, b, differs: i > 1 && a !== b };
  });
  return {
    a: { name: ra.device.name, link: ra.device.link },
    b: { name: rb.device.name, link: rb.device.link },
    facts,
    deviceGroups: splitGroups(ra.deviceGroups, rb.deviceGroups),
    userGroups: splitGroups(ra.userGroups, rb.userGroups),
    policies: splitPolicies(ra, rb),
    notes: [...new Set([...ra.notes, ...rb.notes])],
    otherPlatform: { a: ra.otherPlatform, b: rb.otherPlatform },
  };
}
