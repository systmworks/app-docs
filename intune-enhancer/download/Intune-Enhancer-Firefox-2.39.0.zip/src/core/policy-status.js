// Configuration policy status for the in-portal pills on the Configuration list: how many devices
// each policy succeeded on and failed on (error or conflict), from the device summary report behind
// a policy's Overview page (getDeviceConfigurationPolicyStatusSummary was refused with a 400 on a
// live tenant). Reports are read with POST, but nothing is changed. Read in batches.

import { isTransient, odataQuote, sayOnce } from "./graph.js";
import { reportRow } from "./app-status.js";

// The kinds of configuration policy the list shows, and where their names live.
const POLICY_KINDS = [
  // platforms, technologies and the template: what the platform name and the policy's deep link need.
  { kind: "catalog", path: "/beta/deviceManagement/configurationPolicies?$select=id,name,platforms,technologies,templateReference", name: "name" },
  { kind: "template", path: "/beta/deviceManagement/deviceConfigurations?$select=id,displayName", name: "displayName" },
  { kind: "admx", path: "/beta/deviceManagement/groupPolicyConfigurations?$select=id,displayName", name: "displayName" },
];
// The policy families the summary report covers, as the portal's own request names them.
export const BASE_TYPES = ["Microsoft.Management.Services.Api.DeviceConfiguration", "DeviceManagementConfigurationPolicy",
  "DeviceConfigurationAdmxPolicy", "Microsoft.Management.Services.Api.DeviceManagementIntent"];

/**
 * Every configuration policy as Map(lower-case name -> [{ id, kind }]). A kind the admin's role
 * can't read is skipped; a busy Graph throws, so the caller can ask again later.
 */
export async function policyNames(graph) {
  // All three lists at once: one after another took about 5 s on a live tenant.
  const lists = await Promise.all(POLICY_KINDS.map((k) => graph.all(k.path).catch((e) => {
    if (e?.code === "FORBIDDEN" || (e?.code === "HTTP" && e.status < 500)) return [];
    throw e;
  })));
  const out = new Map();
  POLICY_KINDS.forEach((k, n) => {
    for (const it of lists[n]) {
      const name = String(it[k.name] || "").toLowerCase();
      if (!name) continue;
      if (!out.has(name)) out.set(name, []);
      out.get(name).push({ id: String(it.id).toLowerCase(), kind: k.kind, name: String(it[k.name]), platform: policyPlatform(k.kind, it), meta: k.kind === "catalog" ? catalogMeta(it) : undefined });
    }
  });
  return out;
}

/**
 * Succeeded and failed (error or conflict) counts from a status row, whatever Intune names its columns.
 * The report can carry overlapping columns (non-compliant and error count the same devices, as can succeeded
 * and compliant), so the error-like columns count once, by their largest, and so do the success-like ones;
 * conflicts are added. Pure.
 */
export function statusParts(row) {
  let succeeded = 0;
  let errors = 0;
  let conflicts = 0;
  for (const [col, v] of Object.entries(row || {})) {
    const n = Number(v) || 0;
    if (/error|fail|noncompliant/.test(col)) errors = Math.max(errors, n);
    else if (/conflict/.test(col)) conflicts += n;
    else if (/succe|compliant/.test(col)) succeeded = Math.max(succeeded, n);
  }
  return { succeeded, errors, conflicts };
}

export function statusCounts(row) {
  const { succeeded, errors, conflicts } = statusParts(row);
  return { succeeded, failed: errors + conflicts };
}

/** What a settings catalog policy's deep link needs (portal-links.js catalogPolicyUrl), from its list entry. Pure. */
export function catalogMeta(it) {
  return { platforms: it.platforms || "", technologies: it.technologies || "", templateId: it.templateReference?.templateId || "" };
}

/** The platform a policy is for, as a display name, from its list entry. Pure. */
export function policyPlatform(kind, it) {
  if (kind === "admx") return "Windows";
  const text = kind === "catalog" ? String(it.platforms || "") : String(it["@odata.type"] || "");
  if (/windows/i.test(text)) return "Windows";
  if (/macos/i.test(text)) return "macOS";
  if (/ios|ipados/i.test(text)) return "iOS/iPadOS";
  if (/android/i.test(text)) return "Android";
  if (/linux/i.test(text)) return "Linux";
  return "Other";
}

/**
 * items: [{ key, id?, name? }]; loadNames({ refresh }) resolves to policyNames' map, cached by the caller;
 * refresh asks it to read the list again (the caller limits how often), used once when an item isn't in the
 * cached list, so a policy created since then is found.
 * Returns { [key]: { id, succeeded, failed } | { notFound: true } | { ambiguous: n } | { retry: true } }.
 */
export async function policyStatus(graph, items, loadNames) {
  const out = {};
  const resolve = (names, list) => {
    const byId = new Map([...names.values()].flat().map((p) => [p.id, p]));
    return list.map((i) => ({ i, found: i.id ? [byId.get(i.id.toLowerCase())].filter(Boolean) : names.get(i.name.toLowerCase()) || [] }));
  };
  let hits;
  try {
    hits = resolve(await loadNames(), items);
    const missing = hits.filter((h) => !h.found.length).map((h) => h.i);
    if (missing.length) {
      const again = new Map(resolve(await loadNames({ refresh: true }), missing).map((h) => [h.i, h]));
      hits = hits.map((h) => again.get(h.i) || h);
    }
  } catch {
    for (const i of items) out[i.key] = { retry: true };
    return out;
  }
  const todo = [];
  for (const { i, found } of hits) {
    if (found.length === 1) todo.push({ key: i.key, ...found[0] });
    else out[i.key] = found.length ? { ambiguous: found.length } : { notFound: true };
  }
  if (!todo.length) return out;

  const types = BASE_TYPES.map((t) => `(PolicyBaseTypeName eq '${t}')`).join(" or ");
  const res = await graph.batch(todo.map((p, n) => ({
    id: String(n),
    url: "/deviceManagement/reports/getConfigurationPolicyDeviceSummaryReport",
    body: { select: [], filter: `(${types}) and (PolicyId eq '${odataQuote(p.id)}')` },
  })));
  todo.forEach((p, n) => {
    const r = res.get(String(n));
    if (isTransient(r)) { out[p.key] = { retry: true }; return; }
    if (r.status !== 200) sayOnce("policy-status", "warn", "Policy status unavailable:", p.kind, r.status, JSON.stringify(r.body ?? "").slice(0, 300));
    const row = r.status === 200 ? reportRow(r.body) : null;
    if (row) sayOnce("policy-status-columns", "info", "Policy status report columns:", Object.keys(row).join(", "));
    out[p.key] = row ? { id: p.id, ...statusCounts(row) } : { notFound: true };
  });
  return out;
}
