// Remediation (script package) created and modified dates for the Remediations list: one read of all
// packages. A read; nothing is changed.

/** Resolves to { [id lowercase]: { created, modified } } (ISO times, "" when Graph gave none). */
export async function scriptDates(graph) {
  const scripts = await graph.all("/beta/deviceManagement/deviceHealthScripts?$select=id,createdDateTime,lastModifiedDateTime&$top=100");
  return Object.fromEntries(scripts.map((s) => [String(s.id).toLowerCase(), { created: s.createdDateTime || "", modified: s.lastModifiedDateTime || "" }]));
}
