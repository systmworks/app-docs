// Consent gate. Nothing is read from the portal and nothing is shown in it until the user has
// accepted the disclosure on the workspace's Settings tab. Content scripts can't import modules,
// so kit.js repeats CONSENT_KEY and CONSENT_VERSION; keep it in step with this file.

export const CONSENT_KEY = "ie.consent";
export const CONSENT_VERSION = 1;

export const isConsented = (value) => (value?.version || 0) >= CONSENT_VERSION;

export async function readConsent() {
  const stored = await chrome.storage.local.get(CONSENT_KEY);
  return isConsented(stored[CONSENT_KEY]);
}

export async function grantConsent() {
  await chrome.storage.local.set({ [CONSENT_KEY]: { version: CONSENT_VERSION, at: Date.now() } });
}
