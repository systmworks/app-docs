// The check-in age and activity light rule, written once. A classic script, so the content scripts can use
// it (listed in the manifests before them); modules get it by importing this file for its effect, as
// core/device-reports.js does. Both see it as globalThis.IEActivity.

(function () {
  if (globalThis.IEActivity) return;

  const HOUR = 36e5;
  const DAY = 864e5;

  /** When a check-in time happened (ms), or null for never or unparseable. */
  const timeOf = (iso) => {
    const t = Date.parse(iso);
    return Number.isFinite(t) && t > DAY ? t : null;
  };

  /** Rolling hours since a time, or null. A time a little ahead of this computer's clock (it runs behind the server's) counts as now. */
  function hoursSince(iso, now = Date.now()) {
    const t = timeOf(iso);
    return t === null ? null : Math.max(0, (now - t) / HOUR);
  }

  /** Whole days since a time, or null (a time ahead of this computer's clock counts as today). */
  function ageDays(iso, now = Date.now()) {
    const t = timeOf(iso);
    return t === null ? null : Math.max(0, Math.floor((now - t) / DAY));
  }

  /** The traffic light: green within 8 hours, yellow within 7 days (168 h), orange within 30 days (720 h), red otherwise or never. */
  function activityLevel(iso, now = Date.now()) {
    const hours = hoursSince(iso, now);
    return hours === null || hours > 720 ? "red" : hours > 168 ? "orange" : hours >= 8 ? "yellow" : "green";
  }

  globalThis.IEActivity = { hoursSince, ageDays, activityLevel };
})();
