// Settings tab rows (workspace.html, .srow) and the one shared card behind their i buttons. Kept apart from
// workspace.js so tests/test.html can drive it with its own fixture rows.

/** A CSS time from a custom property ("150ms" or "0.2s") in milliseconds. 0 stays 0; a missing value gives 0. */
export function cssMs(value) {
  const v = String(value ?? "").trim();
  const n = parseFloat(v);
  if (!Number.isFinite(n)) return 0;
  return /[^m]s$/.test(v) ? n * 1000 : n;
}

/** A CSS length in px from a custom property ("6px"). 0 stays 0; a missing value gives 0. */
export function cssPx(value) {
  const n = parseFloat(String(value ?? ""));
  return Number.isFinite(n) ? n : 0;
}

/**
 * Finishes every setting row under root, so each name is written once in the HTML:
 * - a label.srow-name is tied to the row's [data-pref] control, so clicking the name flips a toggle or opens a dropdown;
 * - a row with a template.tip gets its i button (aria-label "More about <name>") and the has-tip class, which cuts
 *   its description to two lines (the card has the rest). Rows without a tip show their whole description.
 * Safe to run twice.
 */
export function setupRows(root) {
  for (const row of root.querySelectorAll(".srow")) {
    const name = row.querySelector(".srow-name");
    const ctl = row.querySelector("[data-pref]");
    if (name?.tagName === "LABEL" && ctl) {
      if (!ctl.id) ctl.id = `pref-${ctl.dataset.pref}`;
      name.htmlFor = ctl.id;
    }
    if (!name || !row.querySelector("template.tip") || row.querySelector(".info")) continue;
    const btn = row.ownerDocument.createElement("button");
    btn.type = "button";
    btn.className = "info";
    btn.textContent = "i";
    btn.setAttribute("aria-label", `More about ${name.textContent.trim()}`);
    btn.setAttribute("aria-expanded", "false");
    name.after(btn);
    row.classList.add("has-tip");
  }
}

/**
 * The shared card for the i buttons under root: the row's template.tip under its name, shown on hover or keyboard
 * focus and pinned open by a click or tap (touch has no hover). Escape, scrolling, resizing, a tab change, a link
 * in the card or a click elsewhere closes it. The gap to the button, the margin to the window edge and the hide
 * delay are --tip-gap, --tip-edge and --tip-delay on :root, read each time the card opens.
 */
export function createTipCard(card, root) {
  const doc = card.ownerDocument;
  const win = doc.defaultView;
  let forBtn = null;
  let pinned = false;
  let timer = 0;
  let delay = 0;

  function show(btn) {
    const text = btn.closest(".srow-text");
    const tpl = text?.querySelector("template.tip");
    if (!tpl) return false;
    win.clearTimeout(timer);
    // Moving to another button (focus or a click) leaves the old one's pin behind.
    if (forBtn && forBtn !== btn) { forBtn.setAttribute("aria-expanded", "false"); pinned = false; }
    const css = win.getComputedStyle(doc.documentElement);
    const gap = cssPx(css.getPropertyValue("--tip-gap"));
    const edge = cssPx(css.getPropertyValue("--tip-edge"));
    delay = cssMs(css.getPropertyValue("--tip-delay"));
    const title = doc.createElement("strong");
    title.className = "tip-title";
    title.textContent = text.querySelector(".srow-name")?.textContent || "";
    card.replaceChildren(title, tpl.content.cloneNode(true));
    card.hidden = false;
    forBtn = btn;
    btn.setAttribute("aria-expanded", "true");
    const r = btn.getBoundingClientRect();
    const w = card.offsetWidth, h = card.offsetHeight;
    const below = r.bottom + gap + h <= win.innerHeight - edge;
    card.style.left = `${Math.max(edge, Math.min(r.left, win.innerWidth - w - edge))}px`;
    card.style.top = `${below ? r.bottom + gap : Math.max(edge, r.top - gap - h)}px`;
    return true;
  }

  function close() {
    win.clearTimeout(timer);
    card.hidden = true;
    pinned = false;
    forBtn?.setAttribute("aria-expanded", "false");
    forBtn = null;
  }

  function hideSoon() {
    if (pinned) return;
    win.clearTimeout(timer);
    timer = win.setTimeout(close, delay);
  }

  /** A click or tap on an i button: pins its card, or closes the card if it was already pinned to this button. */
  function toggle(btn) {
    const unpin = pinned && forBtn === btn;
    if (unpin) { close(); return; }
    if (show(btn)) pinned = true;
  }

  const infoOf = (e) => e.target.closest?.(".info");
  root.addEventListener("mouseover", (e) => { const b = infoOf(e); if (b && !pinned) show(b); });
  root.addEventListener("mouseout", (e) => { if (infoOf(e)) hideSoon(); });
  root.addEventListener("focusin", (e) => { const b = infoOf(e); if (b) show(b); });
  root.addEventListener("focusout", (e) => { if (infoOf(e)) hideSoon(); });
  card.addEventListener("mouseover", () => win.clearTimeout(timer));
  card.addEventListener("mouseout", hideSoon);
  doc.addEventListener("click", (e) => {
    const b = infoOf(e);
    if (b && root.contains(b)) { toggle(b); return; }
    // A link in the card (Setting check) moves to another tab, so the card goes too.
    if (!card.contains(e.target) || e.target.closest?.("a")) close();
  });
  doc.addEventListener("keydown", (e) => { if (e.key === "Escape") close(); });
  win.addEventListener("scroll", close, true);
  win.addEventListener("resize", close);
  win.addEventListener("hashchange", close);

  return { show, close, toggle, hideSoon, state: () => ({ pinned, forBtn, hidden: card.hidden }) };
}
