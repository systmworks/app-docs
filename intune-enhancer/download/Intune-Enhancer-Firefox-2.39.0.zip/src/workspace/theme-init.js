// Sets the workspace theme before the page paints, so a dark-theme user never sees a white flash.
// Loaded as a plain blocking script in <head> (extension pages don't allow inline scripts).
// The toggle's saved choice wins; otherwise dark. The toggle lives in workspace.js.
(function () {
  let theme = null;
  try { theme = localStorage.getItem("ie.theme"); } catch { /* storage unavailable */ }
  document.documentElement.dataset.theme = theme === "light" ? "light" : "dark";
})();
