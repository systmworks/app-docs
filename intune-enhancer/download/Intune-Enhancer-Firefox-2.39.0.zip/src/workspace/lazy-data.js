// The workspace's large data files, loaded on first use instead of when the page opens. Each loads once; later
// calls get the same promise. Workspace only: a Chrome service worker cannot use import().
// tests/build-test.py rewrites these import() calls for the inlined preview page, so keep the "../data/x.js" form.

import { buildErrorIndex } from "../core/error-codes.js";

/** One load shared by every caller. A failed load is forgotten, so the next call tries again (not until a reload). */
function loadOnce(loader) {
  let load = null;
  return () => (load ||= loader().catch((err) => { load = null; throw err; }));
}

/** Microsoft's error tables: { index, sources, built }. */
export const loadErrorCodes = loadOnce(() => import("../data/error-codes.js").then((m) => ({ index: buildErrorIndex(m.ERROR_CODE_ROWS), sources: m.ERROR_CODE_SOURCES, built: m.ERROR_CODES_BUILT })));

/** The All reports list: the rows from data/reports.js. */
export const loadReports = loadOnce(() => import("../data/reports.js").then((m) => m.REPORTS));

/** The security baselines: { baselines, built }. */
export const loadBaselines = loadOnce(() => import("../data/baselines.js").then((m) => ({ baselines: m.BASELINES, built: m.BASELINES_BUILT })));
