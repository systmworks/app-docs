// "Related" button on a device's page: one more command in the toolbar that opens a small card with the
// primary user's other devices and the groups this device is in.
//
// The device isn't in the page's address (the portal passes it into the frame separately), so it is found by
// the Serial number shown on the Overview page (the same panel the activity light reads). The button is a copy
// of one of the toolbar's own plain buttons, with its icon, id and overflow handling removed, so it looks like
// the portal's. Display only; turning the switch off removes it.

(function () {
  if (window.__ieRelated) return;
  window.__ieRelated = true;

  const { feature, onPass, send, adoptStyles, styleOnce, commandPillCss, escapeHtml: esc, ADDED } = globalThis.IEKit;
  const BTN = "ie-related-btn";
  const HOST = "ie-related-card";
  let unwatch = null;
  let open = null; // { host, off }
  let asked = 0; // which request the open card is waiting for, so an old answer can't draw over a newer card
  const toolbar = () => document.querySelector("[role='toolbar'].intune-ResourceViewToolbar, #resourceViewToolbar");

  /** Close the card. */
  function hideCard() {
    open?.off();
    open?.host.remove();
    open = null;
  }

  function remove() {
    hideCard();
    document.querySelectorAll(`.${BTN}`).forEach((el) => el.remove());
  }

  /** A copy of one of the toolbar's plain buttons, made ours. */
  function makeButton(bar) {
    const source = [...bar.querySelectorAll("button")].filter((b) => !b.hasAttribute("aria-haspopup") && !b.classList.contains(BTN))
      .sort((a, b) => Number(a.disabled) - Number(b.disabled))[0];
    if (!source) return null;
    const btn = source.cloneNode(false);
    for (const attr of ["id", "disabled", "aria-disabled", "label", "data-overflow-item", "data-overflow-group", "data-tabster", "elementtiming"]) btn.removeAttribute(attr);
    btn.classList.add(BTN);
    btn.textContent = "Related";
    btn.setAttribute("aria-label", "Related");
    btn.title = `The primary user's other devices and this device's groups${ADDED}`;
    btn.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); toggleCard(btn); });
    return btn;
  }

  function pass() {
    const bar = toolbar();
    const page = globalThis.IEKit.overviewPage?.();
    if (!bar || !page?.serial) { remove(); return; }
    let btn = bar.querySelector(`.${BTN}`);
    if (btn) {
      if (btn.dataset.ieSerial !== page.serial) hideCard(); // the page moved to another device
      btn.dataset.ieSerial = page.serial;
      return;
    }
    btn = makeButton(bar);
    if (!btn) return;
    btn.dataset.ieSerial = page.serial;
    const more = [...bar.querySelectorAll("button")].find((b) => /^more items$/i.test(b.getAttribute("aria-label") || ""));
    if (more?.parentElement) more.parentElement.insertBefore(btn, more); else bar.append(btn);
  }

  // ---------------------------------------------------------------------------------------
  // The card. In a closed shadow root so the portal's CSS can't reach it.

  function cardHtml(data) {
    const user = data.user ? `${esc(data.user.name)}${data.user.upn && data.user.upn !== data.user.name ? `<span class="sub">${esc(data.user.upn)}</span>` : ""}` : '<span class="muted">None (shared or userless)</span>';
    const others = data.others.length
      ? `<ul>${data.others.map((d) => `<li><button class="link" data-device="${esc(d.managedId)}">${esc(d.name)}</button><span class="sub">${esc([d.os, d.compliance, globalThis.IEKit.checkInText?.(d.lastSync)].filter(Boolean).join(", "))}</span></li>`).join("")}</ul>${data.othersTotal > data.others.length ? `<p class="muted">${data.othersTotal - data.others.length} more not shown.</p>` : ""}`
      : '<p class="muted">None.</p>';
    const groups = data.groups === null ? `<p class="muted">${esc(data.groupsNote)}</p>`
      : data.groups.length ? `<ul>${data.groups.map((g) => `<li><button class="link" data-group="${esc(g.id)}">${esc(g.name)}</button>${g.direct ? "" : `<span class="sub">nested${g.via ? `, via ${esc(g.via)}` : ""}</span>`}</li>`).join("")}</ul>` : '<p class="muted">In no groups.</p>';
    return `<div class="head"><strong>Related to ${esc(data.device.name)}</strong><button class="x" aria-label="Close">&times;</button></div>
      ${data.sameSerial ? `<p class="muted">${data.sameSerial} other record${data.sameSerial === 1 ? "" : "s"} in Intune share this serial number. Showing the most recently checked in.</p>` : ""}
      <h4>Primary user</h4><p>${user}</p>
      <h4>Their other devices (${data.othersTotal})</h4>${others}
      <h4>This device's groups${data.groups ? ` (${data.groups.length})` : ""}</h4>${groups}
      <p class="foot">Intune Enhancer</p>`;
  }

  // Every look-and-feel value is a custom property on :host, so it can be tweaked live in DevTools.
  const CSS = `
    :host { --card-width: 340px; --card-max-height: 70vh; --card-pad: 12px 14px; --card-radius: 8px; --card-gap: 6px; --card-edge: 8px;
      --card-font: 13px/1.4 "Segoe UI", system-ui, sans-serif; --card-shadow: 0 6px 24px rgba(0, 0, 0, 0.25);
      --card-bg: #fff; --card-fg: #1b1b1b; --card-border: #aec7ea; --card-head: #175cd3; --card-link: #175cd3; }
    :host(.dark) { --card-bg: #081420; --card-fg: #d8ecff; --card-border: #1d3f66; --card-head: #008aff; --card-link: #3da3ff; }
    .card { position: fixed; z-index: 2147483000; width: var(--card-width); max-height: var(--card-max-height); overflow: auto; box-sizing: border-box; padding: var(--card-pad); border-radius: var(--card-radius);
      font: var(--card-font); background: var(--card-bg); color: var(--card-fg); border: 1px solid var(--card-border); box-shadow: var(--card-shadow); }
    .head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
    h4 { margin: 10px 0 3px; font-size: 12px; text-transform: uppercase; letter-spacing: 0.06em; color: var(--card-head); }
    p { margin: 2px 0; } ul { margin: 2px 0; padding: 0; list-style: none; } li { padding: 2px 0; }
    .sub { display: block; font-size: 12px; opacity: 0.7; } .muted { opacity: 0.7; }
    .foot { margin-top: 10px; font-size: 11px; opacity: 0.6; }
    button { font: inherit; color: inherit; cursor: pointer; background: transparent; border: 0; padding: 0; }
    button.link { color: var(--card-link); text-align: left; }
    button.x { font-size: 18px; line-height: 1; padding: 0 4px; }`;

  function showCard(anchor, data) {
    hideCard();
    const host = document.createElement("div");
    host.className = HOST;
    const root = host.attachShadow({ mode: "closed" });
    // Where a constructed sheet can't be adopted, a <style> in the shadow root, as the quick facts card does.
    if (!adoptStyles(CSS, root)) root.append(Object.assign(document.createElement("style"), { textContent: CSS }));
    const card = document.createElement("div");
    card.className = "card";
    if (document.documentElement.hasAttribute("data-ie-dark")) host.classList.add("dark");
    card.innerHTML = cardHtml(data);
    root.append(card);
    document.body.append(host);
    const r = anchor.getBoundingClientRect();
    const px = (name) => parseFloat(getComputedStyle(host).getPropertyValue(name)) || 0;
    const gap = px("--card-gap");
    const edge = px("--card-edge");
    card.style.top = `${Math.min(r.bottom + gap, Math.max(edge, innerHeight - card.offsetHeight - edge))}px`;
    card.style.left = `${Math.max(edge, Math.min(r.left, innerWidth - card.offsetWidth - edge))}px`;
    root.addEventListener("click", (e) => {
      if (e.target.closest(".x")) { hideCard(); return; }
      const link = e.target.closest("button[data-device], button[data-group]");
      if (!link) return;
      const kind = link.dataset.device ? "device" : "group";
      send({ type: "portal/open", kind, id: link.dataset[kind], newTab: e.ctrlKey || e.metaKey }).catch(() => {});
    });
    const onKey = (e) => { if (e.key === "Escape") hideCard(); };
    const onOutside = (e) => { if (!host.contains(e.target) && !e.target.closest?.(`.${BTN}`)) hideCard(); };
    window.addEventListener("keydown", onKey, true);
    window.addEventListener("pointerdown", onOutside, true);
    open = { host, off: () => { window.removeEventListener("keydown", onKey, true); window.removeEventListener("pointerdown", onOutside, true); } };
  }

  async function toggleCard(btn) {
    if (open) { hideCard(); return; }
    const mine = ++asked;
    const serial = btn.dataset.ieSerial;
    const say = (note) => showCard(btn, { device: { name: "this device" }, user: null, others: [], othersTotal: 0, groups: null, groupsNote: note });
    say("Reading...");
    try {
      const res = await send({ type: "device/related", serial });
      if (mine !== asked || !open) return; // closed, or closed and reopened, while we waited
      if (!res?.ok) throw new Error(res?.error || "no answer from the extension");
      if (!res.found) { say("This device isn't in the device list yet. Refresh the device list in Settings."); return; }
      showCard(btn, res.related);
    } catch (e) {
      if (mine === asked && open) say(`Couldn't read: ${e?.message || e}`);
    }
  }

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.related = { pass, remove, cardHtml, makeButton };

  const ensureStyles = styleOnce(commandPillCss(`.${BTN}`));
  feature("deviceRelated", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() { unwatch?.(); unwatch = null; remove(); },
    onChange() { pass(); },
  });
})();
