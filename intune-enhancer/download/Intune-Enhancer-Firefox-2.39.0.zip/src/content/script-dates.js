// Remediations list (Devices > Scripts and remediations): the created and modified dates under each
// script package's name, and a "Sort by" dropdown above the list: Created or Modified (newest first), because
// the list has neither column, and the list's own Author, Status and count columns (the Intune list can only
// sort a few of them itself). Dates come from the service worker, one read of all packages.
//
// Display only. Rows are matched by the package id the list keeps in a hidden element in each row.
// Sorting reorders the rows the list has drawn, with CSS only (the list's own markup is never moved).

(function () {
  if (window.__ieScriptDates) return;
  window.__ieScriptDates = true;

  const { feature, styleOnce, onPass, send, grid: G, rules, GUID_EXACT, ADDED } = globalThis.IEKit;
  const DATES = "ie-script-dates";
  const BAR = "ie-script-sort";
  const NOTE = "ie-script-note";
  // value, label, and for the list's own columns: the header to read and how to compare it. Columns the list
  // doesn't show are greyed out in the dropdown.
  const MODES = [
    ["", "Default (as Intune sorts it)"],
    ["modified", "Modified, newest first"],
    ["created", "Created, newest first"],
    ["author", "Author, A to Z", /^(author|publisher|created by)$/, "text"],
    ["status", "Status, A to Z", /^status$/, "text"],
    ["without", "Without issues, most first", /without issues?/, "num"],
    ["with", "With issues, most first", /^with issues?/, "num"],
    ["fixed", "Issue fixed, most first", /issues? fixed|^fixed/, "num"],
    ["recurred", "Recurred, most first", /recurr/, "num"],
    ["total", "Total remediated, most first", /total.*remediat|^remediated/, "num"],
  ];
  const DATE_MODES = ["modified", "created"];

  let dates = null; // id (lowercase) -> { created, modified }
  let loadedAt = 0;
  const FRESH_MS = 30 * 60 * 1000; // as long as the worker keeps them: read again after this (new or edited packages)
  let loading = false;
  let note = ""; // why the dates aren't showing, drawn beside the Sort by dropdown
  let mode = "";
  let unwatch = null;

  const day = (iso) => (iso ? new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" }) : "unknown");

  /** The package id of a row: the GUID id on a hidden element the list keeps in each row (it also keeps hidden tooltips), or "". */
  const idOf = (row) => {
    const hit = [...row.querySelectorAll("[hidden][id]")].find((el) => GUID_EXACT.test(el.id));
    return hit ? hit.id.toLowerCase() : "";
  };

  /** Rows (as { id }) in sort order: newest first by the chosen date; ids with no date come last. Pure. */
  function ranked(ids, byId, by) {
    const time = (id) => Date.parse(byId[id]?.[by] || "") || 0;
    return [...ids].sort((a, b) => time(b) - time(a));
  }

  /**
   * Row ids in sort order by a column's text. "text": A to Z, empty last. "num": the number in the cell, largest
   * first, cells with no number last. Ties keep the order the list had. Pure.
   */
  function rankedByText(ids, textById, kind) {
    const num = (id) => { const n = parseFloat(String(textById[id] ?? "").replace(/[,\s]/g, "")); return Number.isFinite(n) ? n : -Infinity; };
    const str = (id) => String(textById[id] ?? "").trim();
    const order = new Map(ids.map((id, i) => [id, i]));
    return [...ids].sort((a, b) => {
      let d;
      if (kind === "num") d = num(b) === num(a) ? 0 : num(b) > num(a) ? 1 : -1;
      else d = !str(a) && str(b) ? 1 : str(a) && !str(b) ? -1 : str(a).localeCompare(str(b), undefined, { sensitivity: "base" });
      return d || order.get(a) - order.get(b);
    });
  }

  /** Whether to read the dates: none yet, or older than FRESH_MS, and no read already running. Pure. */
  const needsLoad = (s, now) => !s.loading && (!s.dates || now - s.loadedAt >= FRESH_MS);

  /** Read the dates when needed (the old ones stay drawn while new ones are read). */
  function load(now = Date.now()) {
    if (!needsLoad({ dates, loadedAt, loading }, now)) return;
    loading = true;
    send({ type: "scripts/dates" })
      .then((res) => { if (!res?.ok) throw new Error(res?.error || "no answer from the extension"); dates = res.dates || {}; loadedAt = Date.now(); note = ""; loading = false; if (unwatch) pass(); })
      .catch((e) => {
        // The extension was updated or reloaded: this orphaned copy stays quiet (the page's next load runs the new one).
        if (!globalThis.chrome?.runtime?.id) return;
        note = `Dates couldn't be read: ${e?.message || e}`;
        showNote();
        setTimeout(() => { loading = false; if (unwatch) pass(); }, 15000); // no session yet, or Graph said no: ask again later
      });
  }

  /** Show `note` (or clear it) beside every Sort by dropdown. */
  function showNote() {
    for (const bar of document.querySelectorAll(`.${BAR}`)) {
      let el = bar.querySelector(`.${NOTE}`);
      if (!note) { el?.remove(); continue; }
      if (!el) { el = document.createElement("span"); el.className = NOTE; bar.append(el); }
      if (el.textContent !== note) el.textContent = note;
    }
  }

  function bar(listEl) {
    const host = listEl.closest('[data-automationid="DetailsList"]') || listEl;
    let el = host.previousElementSibling?.classList.contains(BAR) ? host.previousElementSibling : null;
    if (el) return;
    el = document.createElement("div");
    el.className = BAR;
    const label = Object.assign(document.createElement("label"), { textContent: "Sort by " });
    const select = document.createElement("select");
    select.setAttribute("aria-label", "Sort the Remediations list");
    for (const [value, text] of MODES) select.append(Object.assign(document.createElement("option"), { value, textContent: text }));
    select.title = `Sorts the packages shown below by date, or by one of the list's own columns.${ADDED}`;
    select.value = mode;
    select.addEventListener("change", () => { mode = select.value; pass(); });
    label.append(select);
    el.append(label);
    host.before(el);
  }

  /** Put the drawn rows in `order` (a list of ids), or back as Intune has them when mode is "". */
  function reorder(cells, order) {
    const first = cells[0];
    if (!first) return;
    let root = first.parentElement;
    while (root && !cells.every((c) => root.contains(c))) root = root.parentElement;
    if (!root) return;
    const active = Boolean(mode);
    root.toggleAttribute("data-ie-sortroot", active);
    for (const cell of cells) {
      cell.style.order = active ? String(Math.max(0, order.indexOf(cell.dataset.ieId))) : "";
      for (let p = cell.parentElement; p && p !== root; p = p.parentElement) p.toggleAttribute("data-ie-sortpage", active);
    }
    // The list keeps empty spacer blocks for the rows it hasn't drawn. Left at order 0 they sit between the first
    // row and the rest as a big gap, so send them to the end.
    for (const child of root.children) {
      if (!cells.some((cell) => child.contains(cell))) child.style.order = active ? String(order.length + 1) : "";
    }
  }

  /** Grey out the dropdown choices whose column the list doesn't show. */
  function enableModes(el, cols) {
    const bar = (el.closest('[data-automationid="DetailsList"]') || el).previousElementSibling;
    const select = bar?.classList.contains(BAR) ? bar.querySelector("select") : null;
    if (!select) return;
    for (const [value, , re] of MODES) {
      if (!re) continue;
      const option = [...select.options].find((o) => o.value === value);
      if (option) option.disabled = !cols.find(re);
    }
  }

  function pass(grids = G.scan()) {
    for (const { el, cols } of grids) {
      const col = rules.listName(cols, "script");
      if (!col) continue;
      bar(el);
      enableModes(el, cols);
      load();
      const sortBy = MODES.find((m) => m[0] === mode && m[2]);
      const sortCol = sortBy ? cols.find(sortBy[2]) : null;
      const cells = [];
      const texts = {};
      for (const row of G.rowsOf(el)) {
        const id = idOf(row);
        const cellsOfRow = G.cellsOf(row);
        const cell = G.cellFor(cellsOfRow, col, cols);
        const item = row.closest('[data-automationid="ListCell"]');
        if (!id || !cell || !item) continue;
        item.dataset.ieId = id;
        cells.push(item);
        if (sortCol) texts[id] = G.cellText(G.cellFor(cellsOfRow, sortCol, cols));
        const d = dates?.[id];
        const host = cell.querySelector("button")?.parentElement || cell;
        let line = cell.querySelector(`.${DATES}`);
        if (!d) { line?.remove(); continue; }
        const text = `Created ${day(d.created)} · Modified ${day(d.modified)}`;
        if (!line) { line = document.createElement("div"); line.className = DATES; host.append(line); }
        if (line.textContent !== text) line.textContent = text;
      }
      // Rows are drawn but none could be matched to a package: say so instead of silently doing nothing.
      if (!cells.length && G.rowsOf(el).length && !note) { note = "Couldn't match the list's rows to script packages."; }
      else if (cells.length && note.startsWith("Couldn't match")) note = "";
      showNote();
      const ids = cells.map((c) => c.dataset.ieId);
      if (sortCol) reorder(cells, rankedByText(ids, texts, sortBy[3]));
      else if (DATE_MODES.includes(mode) && !dates) reorder(cells, ids); // dates not read yet: leave the list as it is
      else reorder(cells, ranked(ids, dates || {}, mode || "modified"));
    }
  }

  const CSS = `
    .${DATES} { font-size: 11px; opacity: 0.7; line-height: 1.2; white-space: nowrap; }
    .${BAR} { padding: 6px 0; font-size: 12px; }
    .${BAR} select { font: inherit; color: inherit; background: transparent; border: 1px solid rgba(128, 128, 128, 0.5); border-radius: 4px; padding: 2px 6px; margin-left: 4px; }
    .${NOTE} { margin-left: 10px; color: #c76a00; }
    :root[data-ie-dark] .${NOTE} { color: #f0a030; }
    .${BAR} option { color: CanvasText; background: Canvas; }
    [data-ie-sortroot] { display: flex !important; flex-direction: column; }
    [data-ie-sortpage] { display: contents !important; }`;

  const ensureStyles = styleOnce(CSS);
  feature("remediationDates", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      mode = "";
      document.querySelectorAll(`.${DATES}, .${BAR}, .${NOTE}`).forEach((el) => el.remove());
      document.querySelectorAll("[data-ie-sortroot]").forEach((root) => { for (const child of root.children) child.style.order = ""; });
      document.querySelectorAll("[data-ie-sortroot], [data-ie-sortpage]").forEach((el) => { el.removeAttribute("data-ie-sortroot"); el.removeAttribute("data-ie-sortpage"); });
      document.querySelectorAll("[data-ie-id]").forEach((el) => { el.style.order = ""; el.removeAttribute("data-ie-id"); });
    },
  });

  if (globalThis.__IE_TEST__) Object.assign(globalThis.__IE_TEST__, { scriptDates: { ranked, rankedByText, idOf, day, needsLoad, FRESH_MS } });
})();
