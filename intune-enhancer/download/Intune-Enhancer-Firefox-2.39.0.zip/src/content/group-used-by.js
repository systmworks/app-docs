// "Used by" button on a group's page: one more command in the bar beside Delete that opens the workspace's
// Group assignments for the group you're looking at (every policy, app and script that references it).
//
// The group's id isn't in the page's address (the portal passes it into the frame separately), so it is read
// from the page itself: the Object ID shown in the group's Overview and Properties, found as the element
// the "Object ID" label points at. The button is a copy of the bar's own Delete command with our text, so it
// looks like the portal's; it only appears on a group page, recognised by the telemetry name on its buttons.
//
// Display only. Turning the switch off removes it.

(function () {
  if (window.__ieUsedBy) return;
  window.__ieUsedBy = true;

  const { feature, onPass, send, styleOnce, commandPillCss, GUID, ADDED } = globalThis.IEKit;
  const CLASS = "ie-usedby";
  const GUID_RE = new RegExp(`^${GUID}`, "i"); // the id leads the text; the portal runs "Copy object ID to clipboard" straight after it
  let unwatch = null;

  /** The group's Object ID as the page shows it, or "". */
  function objectId() {
    for (const label of document.querySelectorAll("label")) {
      if (!/^object id$/i.test(label.textContent.trim()) || !label.htmlFor) continue;
      const text = (document.getElementById(label.htmlFor)?.textContent || "").trim();
      const id = text.match(GUID_RE);
      if (id) return id[0].toLowerCase();
    }
    return "";
  }

  /** The bar's Delete command on a group page: its item and button, or null. */
  function deleteCommand() {
    for (const button of document.querySelectorAll(".ms-CommandBar-primaryCommand button")) {
      if (/delete group/i.test(button.getAttribute("data-telemetryname") || "")) return { button, item: button.closest(".ms-OverflowSet-item") };
    }
    return null;
  }

  function remove() {
    document.querySelectorAll(`.${CLASS}`).forEach((el) => el.remove());
  }

  function pass() {
    const id = objectId();
    const del = id ? deleteCommand() : null;
    if (!del?.item) { remove(); return; }
    let item = document.querySelector(`.${CLASS}`);
    if (item && item.previousElementSibling !== del.item) { item.remove(); item = null; }
    if (!item) {
      item = del.item.cloneNode(true);
      item.classList.add(CLASS);
      item.querySelectorAll("[id]").forEach((el) => el.removeAttribute("id"));
      item.querySelectorAll("[data-telemetryname]").forEach((el) => el.removeAttribute("data-telemetryname"));
      item.querySelectorAll("i, svg, img, [data-icon-name], .ms-Button-icon").forEach((el) => el.remove());
      const button = item.querySelector("button");
      const label = item.querySelector(".ms-Button-label") || button;
      label.textContent = "Used by";
      button.setAttribute("name", "Used by");
      button.setAttribute("aria-label", "Used by");
      button.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        send({ type: "workspace/open", tab: "impact", group: item.dataset.ieGroup }).catch(() => {});
      });
      del.item.after(item);
    }
    item.dataset.ieGroup = id;
    item.querySelector("button").title = `Show every policy, app and script that uses this group, in the workspace (Group assignments)${ADDED}`;
  }

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.usedBy = { objectId, deleteCommand, pass, remove };

  const ensureStyles = styleOnce(commandPillCss(`.${CLASS} button`));
  feature("usedByButton", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() { unwatch?.(); unwatch = null; remove(); },
    onChange() { pass(); },
  });
})();
