// The one GUID pattern for the worker and workspace modules. (Content scripts can't import modules, so
// content/kit.js keeps its own copy of the same pattern.)

export const GUID_PATTERN = "[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}";

const GUID_EXACT = new RegExp(`^${GUID_PATTERN}$`, "i");

/** True when the whole value is a GUID. */
export const isGuid = (s) => GUID_EXACT.test(String(s || ""));
