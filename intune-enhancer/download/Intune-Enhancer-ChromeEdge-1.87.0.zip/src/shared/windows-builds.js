// Windows build number -> release name. A classic script (not a module) so the same file can be
// loaded by content scripts (listed first in manifest.json), the workspace page and the service
// worker. It defines globalThis.IEWindowsBuilds.
//
// Only client builds are named. 26100 is also Windows Server 2025 and 17763/14393 are also
// Server 2019/2016, but Intune device lists are almost all client devices, so the client name is
// used. A build that isn't in the table is left exactly as it was.

(function () {
  const BUILDS = {
    10240: ["Win10", "1507"],
    10586: ["Win10", "1511"],
    14393: ["Win10", "1607"],
    15063: ["Win10", "1703"],
    16299: ["Win10", "1709"],
    17134: ["Win10", "1803"],
    17763: ["Win10", "1809"],
    18362: ["Win10", "1903"],
    18363: ["Win10", "1909"],
    19041: ["Win10", "2004"],
    19042: ["Win10", "20H2"],
    19043: ["Win10", "21H1"],
    19044: ["Win10", "21H2"],
    19045: ["Win10", "22H2"],
    22000: ["Win11", "21H2"],
    22621: ["Win11", "22H2"],
    22631: ["Win11", "23H2"],
    26100: ["Win11", "24H2"],
    26200: ["Win11", "25H2"],
  };

  // "10.0.26100.4349" (the form Intune shows); the revision is optional. Shared as source text so
  // each caller builds its own RegExp (a shared global one keeps state between uses).
  const PATTERN = String.raw`\b10\.0\.(\d{5})(?:\.(\d{1,5}))?\b`;
  const ONE_RE = new RegExp(PATTERN);

  /** "10.0.26100.4349" -> "Win11 24H2 (26100.4349)", or null if the build isn't known. */
  function friendly(version) {
    const m = ONE_RE.exec(String(version || ""));
    if (!m) return null;
    const known = BUILDS[m[1]];
    if (!known) return null;
    return `${known[0]} ${known[1]} (${m[1]}${m[2] ? `.${m[2]}` : ""})`;
  }

  globalThis.IEWindowsBuilds = { PATTERN, friendly };
})();
