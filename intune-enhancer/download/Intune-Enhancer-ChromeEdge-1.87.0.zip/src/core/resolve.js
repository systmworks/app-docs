// Pure lookup logic, kept free of chrome.* so it's tested offline (tests/test.html).
//
// An index row is a compact array (see ROW below) so a large tenant's index stays small in
// storage. The portal identifies a device in different ways depending on the list: by its
// Intune managed device id, by its Entra device id (azureADDeviceId), by its Entra object id
// (which needs a separate mapping to a device id), or only by its name.

export const ROW = {
  id: 0, name: 1, aadId: 2, upn: 3, displayName: 4, os: 5, lastSync: 6,
  osVersion: 7, compliance: 8, enrolled: 9, owner: 10, model: 11,
  lastUser: 12, lastUserName: 13, lastLogOn: 14, // last logged-on user (Windows only)
  freeBytes: 15, totalBytes: 16, // storage, 0 when Intune doesn't report it
  userId: 17, // primary user's Entra id, "" when none
  serial: 18, // serial number, "" when Intune has none
};

export const norm = (s) => String(s || "").trim().toLowerCase();

/** Build lookup maps from rows. */
export function buildMaps(rows) {
  const byId = new Map();
  const byAad = new Map();
  const byName = new Map();
  const byUpn = new Map();
  const bySerial = new Map();
  const push = (map, key, row) => {
    if (!key) return;
    const list = map.get(key);
    if (list) list.push(row); else map.set(key, [row]);
  };
  for (const row of rows) {
    byId.set(norm(row[ROW.id]), row);
    push(byAad, norm(row[ROW.aadId]), row);
    push(byName, norm(row[ROW.name]), row);
    push(byUpn, norm(row[ROW.upn]), row);
    push(bySerial, norm(row[ROW.serial]), row);
  }
  return { byId, byAad, byName, byUpn, bySerial };
}

/** Devices a user is the primary user of, most recent check-in first. */
export function devicesForUpn(maps, upn) {
  return [...(maps?.byUpn.get(norm(upn)) || [])].sort(byRecentSync).map(toDevice);
}

// Worst first: a user with one non-compliant device shows as non-compliant.
const COMPLIANCE_RANK = ["noncompliant", "error", "conflict", "inGracePeriod", "unknown", "configManager", "compliant"];
const UNKNOWN_RANK = COMPLIANCE_RANK.indexOf("unknown");

/**
 * Group roster fields for a user from the devices they're the primary user of (newest check-in
 * first, as devicesForUpn returns them): worst compliance, the latest device's OS, and its
 * check-in.
 */
export function userDeviceSummary(devices) {
  if (!devices.length) return { devices: [], deviceCount: 0 };
  const rank = (c) => {
    const i = COMPLIANCE_RANK.indexOf(c);
    return i < 0 ? UNKNOWN_RANK : i;
  };
  const worst = devices.map((d) => d.compliance || "unknown").reduce((a, b) => (rank(b) < rank(a) ? b : a));
  const latest = devices[0];
  return {
    devices: devices.map((d) => ({ name: d.name, managedId: d.managedId, compliance: d.compliance, lastSync: d.lastSync })),
    deviceCount: devices.length,
    compliance: worst,
    os: latest.os || "",
    osVersion: latest.osVersion || "",
    lastCheckIn: latest.lastSync || "",
  };
}

export const toDevice = (row) => ({
  managedId: row[ROW.id],
  name: row[ROW.name],
  upn: row[ROW.upn] || "",
  displayName: row[ROW.displayName] || "",
  os: row[ROW.os] || "",
  lastSync: row[ROW.lastSync] || "",
  osVersion: row[ROW.osVersion] || "",
  compliance: row[ROW.compliance] || "",
  enrolled: row[ROW.enrolled] || "",
  owner: row[ROW.owner] || "",
  model: row[ROW.model] || "",
  freeBytes: row[ROW.freeBytes] || 0,
  totalBytes: row[ROW.totalBytes] || 0,
  userId: row[ROW.userId] || "",
  aadId: row[ROW.aadId] || "",
  serial: row[ROW.serial] || "",
  lastUser: row[ROW.lastLogOn] ? { upn: row[ROW.lastUser] || "", displayName: row[ROW.lastUserName] || "", at: row[ROW.lastLogOn] } : null,
});

/** The most recent entry of a managedDevice's usersLoggedOn: { userId, at }, or null. */
export function latestLogon(usersLoggedOn) {
  let best = null;
  for (const u of usersLoggedOn || []) {
    const at = String(u?.lastLogOnDateTime || "");
    if (u?.userId && (!best || at > best.at)) best = { userId: u.userId, at };
  }
  return best;
}

/** Newest sync first, so the device someone is actually using leads. */
const byRecentSync = (a, b) => String(b[ROW.lastSync] || "").localeCompare(String(a[ROW.lastSync] || ""));

/**
 * Resolve one device reference.
 * @param {{managedId?:string, deviceId?:string, objectId?:string, serial?:string, name?:string}} ref
 * @param {ReturnType<typeof buildMaps>} maps
 * @param {Map<string,string>} objectToDevice  Entra object id -> Entra device id
 * @returns {{status:"user"|"noUser"|"multiple"|"notFound", devices:object[], users:object[]}}
 */
export function resolveRef(ref, maps, objectToDevice = new Map()) {
  let rows = [];
  const managedId = norm(ref.managedId);
  const deviceId = norm(ref.deviceId) || norm(objectToDevice.get(norm(ref.objectId)));

  if (managedId && maps.byId.has(managedId)) rows = [maps.byId.get(managedId)];
  else if (deviceId && maps.byAad.has(deviceId)) rows = maps.byAad.get(deviceId);
  else if (ref.serial && maps.bySerial?.has(norm(ref.serial))) rows = maps.bySerial.get(norm(ref.serial));
  else if (ref.name) rows = maps.byName.get(norm(ref.name)) || [];

  if (!rows.length) return { status: "notFound", devices: [], users: [] };

  const sorted = [...rows].sort(byRecentSync);
  const devices = sorted.map(toDevice);
  const users = [];
  const seen = new Set();
  for (const d of devices) {
    if (!d.upn && !d.displayName) continue;
    const key = norm(d.upn || d.displayName);
    if (seen.has(key)) continue;
    seen.add(key);
    users.push({ upn: d.upn, displayName: d.displayName });
  }

  if (!users.length) return { status: "noUser", devices, users };
  return { status: users.length > 1 ? "multiple" : "user", devices, users };
}

