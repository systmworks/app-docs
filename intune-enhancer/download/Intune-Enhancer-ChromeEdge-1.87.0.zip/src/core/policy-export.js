// One indexed policy written up for a change record: its details, assignments and settings, as
// Markdown and as CSV rows. Pure, so it is tested offline. Settings come from the policy index, so a
// type the index holds no settings for (apps, scripts, remediations) says so rather than showing none.

import { policyRef } from "./portal-links.js";

const exportDay = (iso) => String(iso || "").slice(0, 10);
/** One line of a Markdown table cell: line breaks flattened, pipes escaped. */
const exportCell = (text) => String(text ?? "").replace(/\s*\r?\n\s*/g, " ").replace(/\|/g, "\\|");

/** "Include: Sales (Intent: required; filter: Only Corporate)" for one normalised assignment. */
function exportAssignment(a, names, filters) {
  const group = (names[a.groupId] || a.groupId || "unknown group");
  const target = a.kind === "allDevices" ? "All devices" : a.kind === "allUsers" ? "All users"
    : a.kind === "exclude" ? `Exclude: ${group}` : a.kind === "include" ? `Include: ${group}` : "Other target";
  const extras = [];
  if (a.intent) extras.push(`intent ${a.intent}`);
  if (a.filterId) {
    const f = filters[String(a.filterId).toLowerCase()];
    extras.push(`filter ${a.filterType === "exclude" ? "excludes" : "includes"}: ${f?.name || a.filterId}`);
  }
  return extras.length ? `${target} (${extras.join("; ")})` : target;
}

/**
 * @param policy   an entry of the policy index
 * @param names    { lower-case group id: display name }
 * @param filters  { lower-case filter id: { name } }
 * @returns { title, markdown, rows } where rows is [Section, Name, Value, Path] for CSV
 */
export function policyDocument(policy, names = {}, filters = {}) {
  const ref = policyRef(policy);
  const info = [
    ["Type", ref.typeLabel],
    ...(policy.meta?.platforms ? [["Platform", policy.meta.platforms]] : []),
    ["Created", exportDay(policy.created)],
    ["Last modified", exportDay(policy.modified)],
    ["Id", policy.id],
  ].filter(([, v]) => v);
  const assignments = (policy.assignments || []).map((a) => exportAssignment(a, names, filters));
  const settings = policy.settings;

  const md = [`# ${policy.name}`, "", ...info.map(([k, v]) => `- ${k}: ${v}`), "", "## Assignments", ""];
  if (policy.assignmentsUnknown) md.push("Assignments couldn't be read.");
  else if (!assignments.length) md.push("Not assigned.");
  else md.push(...assignments.map((a) => `- ${a}`));
  md.push("", "## Settings", "");
  if (!settings) md.push("Settings aren't indexed for this type of policy.");
  else if (!settings.length) md.push("No settings configured.");
  else md.push("| Setting | Value | Path |", "|---|---|---|", ...settings.map((s) => `| ${exportCell(s.n)} | ${exportCell(s.v)} | ${exportCell(s.p)} |`));

  const rows = [
    ["Section", "Name", "Value", "Path"],
    ["Policy", "Name", policy.name, ""],
    ...info.map(([k, v]) => ["Policy", k, v, ""]),
    ...(policy.assignmentsUnknown ? [["Assignment", "Couldn't be read", "", ""]]
      : assignments.length ? assignments.map((a) => ["Assignment", a, "", ""]) : [["Assignment", "Not assigned", "", ""]]),
    ...(settings || []).map((s) => ["Setting", s.n, s.v, s.p]),
  ];
  return { title: policy.name, markdown: md.join("\n") + "\n", rows, hasSettings: Boolean(settings) };
}
