// Deep links into the Intune and Entra admin centers, in one place so they're easy to fix when
// the portal changes. The portal has no documented deep-link scheme; these follow the
// #view/<extension>/<blade>/... form the portal itself puts in the address bar.
//
// VERIFIED marks a pattern confirmed against the live portal. Policy types whose own link
// isn't known yet open their list page instead (areaUrl).

import { TYPE_BY_KEY } from "./policy-types.js";

const PORTAL = "https://intune.microsoft.com/";

const enc = encodeURIComponent;

/** Intune managed device overview. VERIFIED 2026-10-26 (opens the device's Overview blade). */
export const deviceUrl = (managedId) =>
  `${PORTAL}#view/Microsoft_Intune_Devices/DeviceSettingsMenuBlade/~/overview/mdmDeviceId/${enc(managedId)}`;

/** Entra group overview. VERIFIED 2026-10-27 (opens the group's Overview). */
export const groupUrl = (groupId) =>
  `${PORTAL}#view/Microsoft_AAD_IAM/GroupDetailsMenuBlade/~/Overview/groupId/${enc(groupId)}`;

/** Entra user overview. Not yet verified on the live portal. */
export const userUrl = (userId) =>
  `${PORTAL}#view/Microsoft_AAD_UsersAndTenants/UserProfileMenuBlade/~/overview/userId/${enc(userId)}`;

/** Intune app overview. VERIFIED 2026-10-26 (opens the app). */
export const appUrl = (appId) =>
  `${PORTAL}#view/Microsoft_Intune_Apps/SettingsMenu/~/0/appId/${enc(appId)}`;

// List pages, used where a direct link to the object isn't known yet.
const LIST_PAGES = {
  configuration: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/configuration`,
  compliance: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/compliance`,
  scripts: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/scripts`,
  remediations: `${PORTAL}#view/Microsoft_Intune_Enrollment/UXAnalyticsMenu/~/proactiveRemediations`,
  apps: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/AppsMenu/~/allApps`,
  updates: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/windows10Update`,
  enrollment: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/DevicesMenu/~/enrollment`,
  endpointSecurity: `${PORTAL}#view/Microsoft_Intune_Workflows/SecurityManagementMenu/~/overview`,
  appProtection: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/AppsMenu/~/protection`,
  tenantAdmin: `${PORTAL}#view/Microsoft_Intune_DeviceSettings/TenantAdminMenu/~/roles`,
  home: PORTAL,
};

/** Best available link for a policy-like object of the given kind (see policy-types.js `area`). */
export function areaUrl(area) {
  return LIST_PAGES[area] || LIST_PAGES.home;
}

/**
 * A settings catalog policy's summary page (also used by endpoint security policies built on the
 * catalog). VERIFIED 2026-10-26 from a live tenant's address bar:
 *   #blade/Microsoft_Intune_Workflows/PolicySummaryBlade/policyId/<id>/isAssigned/true
 *     /technology/mdm/templateId//platformName/windows10
 * meta: { platforms, technologies, templateId } as Graph returns them; isAssigned from assignments.
 */
export function catalogPolicyUrl(id, meta = {}, isAssigned = false) {
  const tech = String(meta.technologies || "mdm").split(",")[0].trim() || "mdm";
  const platform = String(meta.platforms || "windows10").split(",")[0].trim() || "windows10";
  return `${PORTAL}#blade/Microsoft_Intune_Workflows/PolicySummaryBlade/policyId/${enc(id)}/isAssigned/${isAssigned ? "true" : "false"}` +
    `/technology/${enc(tech)}/templateId/${enc(meta.templateId || "")}/platformName/${enc(platform)}`;
}

/**
 * Link for any indexed policy: the policy itself where its URL format is known (settings
 * catalog), otherwise the list page for its kind. typeInfo is its POLICY_TYPES entry.
 */
export function policyUrl(policy, typeInfo) {
  if (policy?.type === "settingsCatalog") {
    return catalogPolicyUrl(policy.id, policy.meta || {}, (policy.assignments || []).some((a) => a.kind !== "exclude"));
  }
  if (policy?.type === "app") return appUrl(policy.id);
  return areaUrl(typeInfo?.area);
}

/** The type, its label and the link for an indexed policy, as every report row shows them. */
export function policyRef(policy) {
  const typeInfo = TYPE_BY_KEY[policy.type];
  return { type: policy.type, typeLabel: typeInfo?.label || policy.type, link: policyUrl(policy, typeInfo) };
}
