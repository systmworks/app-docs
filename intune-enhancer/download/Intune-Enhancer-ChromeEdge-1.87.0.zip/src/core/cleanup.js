// Cleanup report: Intune objects that do nothing, or point at groups that don't help.
// Pure: built from the policy index plus group names and member counts the caller looked up, so
// it's tested offline and runs on sample data.
//
// Findings:
//   unassigned    no assignments at all
//   excludeOnly   only exclusions, so it targets nobody
//   deletedGroup  assigned to a group that no longer exists
//   emptyGroup    assigned to a group with no members (including nested)

import { policyRef } from "./portal-links.js";

const lower = (s) => String(s || "").toLowerCase();

/**
 * @param index the policy index ({ policies })
 * @param names { [groupId]: displayName } for every referenced group that still exists
 * @param sizes { [groupId]: { devices, users, groups } } member counts (null counts = unknown)
 */
export function buildCleanup(index, names = {}, sizes = {}) {
  const findings = { unassigned: [], excludeOnly: [], deletedGroup: [], emptyGroup: [] };
  const base = (p) => ({
    policyId: p.id,
    policyName: p.name,
    ...policyRef(p),
  });
  const known = new Map(Object.entries(names).map(([id, n]) => [lower(id), n]));
  const sizeOf = new Map(Object.entries(sizes).map(([id, s]) => [lower(id), s]));
  let unchecked = 0;
  // A group's size is unknown when Graph was busy or wouldn't say (a null count, or no size at all).
  const sizeKnown = (s) => Boolean(s) && [s.devices, s.users, s.groups].every((n) => Number.isFinite(n));
  const groupsUnchecked = [...known.keys()].filter((id) => !sizeKnown(sizeOf.get(id))).length;

  for (const p of index?.policies || []) {
    const as = p.assignments || [];
    if (p.assignmentsUnknown) { unchecked++; continue; } // Graph wouldn't say who it's assigned to
    if (!as.length) { findings.unassigned.push(base(p)); continue; }
    if (as.every((a) => a.kind === "exclude")) findings.excludeOnly.push({ ...base(p), count: as.length });
    for (const a of as) {
      if (!a.groupId) continue;
      const id = lower(a.groupId);
      if (!known.has(id)) {
        findings.deletedGroup.push({ ...base(p), groupId: a.groupId, kind: a.kind, intent: a.intent || "" });
        continue;
      }
      const s = sizeOf.get(id);
      const isEmpty = s && [s.devices, s.users, s.groups].every((n) => n === 0);
      if (isEmpty) findings.emptyGroup.push({ ...base(p), groupId: a.groupId, groupName: known.get(id), kind: a.kind, intent: a.intent || "" });
    }
  }

  const byName = (a, b) => a.typeLabel.localeCompare(b.typeLabel) || a.policyName.localeCompare(b.policyName);
  Object.values(findings).forEach((list) => list.sort(byName));
  return {
    ...findings,
    summary: {
      policies: index?.policies?.length || 0,
      unchecked, // assignments couldn't be read, so they're in no list
      groupsUnchecked, // member counts couldn't be read, so an empty group may be missing from the list
      groups: known.size,
      unassigned: findings.unassigned.length,
      excludeOnly: findings.excludeOnly.length,
      deletedGroup: findings.deletedGroup.length,
      // Excluding an empty group is harmless; count only the includes as problems.
      emptyGroup: findings.emptyGroup.filter((f) => f.kind !== "exclude").length,
    },
  };
}

/** Every group id the index's assignments reference. */
export function referencedGroupIds(index) {
  const ids = new Set();
  for (const p of index?.policies || []) for (const a of p.assignments || []) if (a.groupId) ids.add(lower(a.groupId));
  return [...ids];
}
