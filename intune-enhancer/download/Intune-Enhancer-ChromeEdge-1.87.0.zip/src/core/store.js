// Key-value storage for the worker's big lists (device and policy indexes), in IndexedDB rather
// than chrome.storage.local: every content script in every portal frame is sent each
// chrome.storage change in full, which for a large tenant meant megabytes per write. Only the
// worker opens this database. Local to this computer, like chrome.storage.local.

const DB_NAME = "ie";
const STORE = "kv";
let opening = null;

function db() {
  opening ||= new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => req.result.createObjectStore(STORE);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => { opening = null; reject(req.error); };
  });
  return opening;
}

/** Run one request in a transaction; resolves with its result once the transaction completes. */
async function run(mode, make) {
  const tx = (await db()).transaction(STORE, mode);
  const req = make(tx.objectStore(STORE));
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve(req.result);
    tx.onerror = tx.onabort = () => reject(tx.error);
  });
}

export const getItem = (key) => run("readonly", (s) => s.get(key));
export const setItem = (key, value) => run("readwrite", (s) => s.put(value, key));
/** Delete every key that starts with `prefix`. */
export const removePrefix = (prefix) => run("readwrite", (s) => s.delete(IDBKeyRange.bound(prefix, `${prefix}￿`)));
