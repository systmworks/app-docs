// The extra rows of Device quick facts, from one managed device's full record (read when the admin asks
// for "More details"). Pure, so it is tested offline. Only values Graph returned are shown.

const GIB = 1024 ** 3;
const gigabytes = (bytes) => `${(bytes / GIB).toFixed(1)} GB`;
/** "windowsAzureADJoin" -> "Windows Azure AD Join". */
const words = (text) => String(text).replace(/([a-z])([A-Z])/g, "$1 $2").replace(/([A-Z])([A-Z][a-z])/g, "$1 $2").replace(/^./, (c) => c.toUpperCase());

/** [[label, value], ...] for the rows Graph filled in. */
export function detailRows(device) {
  const hardware = device?.hardwareInformation || {};
  const rows = [];
  const add = (label, value) => {
    if (value !== undefined && value !== null && String(value).trim() !== "") rows.push([label, String(value)]);
  };
  const known = (value) => (value && value !== "unknown" ? words(value) : "");
  const total = Number(device?.totalStorageSpaceInBytes) || 0;
  const free = Number(device?.freeStorageSpaceInBytes);

  add("Serial number", device?.serialNumber);
  add("Manufacturer", device?.manufacturer);
  add("Memory", Number(device?.physicalMemoryInBytes) > 0 ? gigabytes(device.physicalMemoryInBytes) : "");
  add("Storage", total > 0 && Number.isFinite(free) ? `${gigabytes(free)} free of ${gigabytes(total)}` : "");
  add("Encrypted", typeof device?.isEncrypted === "boolean" ? (device.isEncrypted ? "Yes" : "No") : "");
  add("TPM version", hardware.tpmSpecificationVersion);
  add("Windows edition", hardware.operatingSystemEdition);
  add("IP address", hardware.ipAddressV4 || (hardware.wiredIPv4Addresses || [])[0]);
  add("Wi-Fi MAC", device?.wiFiMacAddress);
  add("Ethernet MAC", device?.ethernetMacAddress);
  add("Enrolment type", known(device?.deviceEnrollmentType));
  add("Join type", known(device?.joinType));
  add("Managed by", known(device?.managementAgent));
  return rows;
}
