// Configuration policy status for the in-portal pills on the Configuration list: how many devices
// each policy succeeded on and failed on (error or conflict), from the device summary report behind
// a policy's Overview page (getDeviceConfigurationPolicyStatusSummary was refused with a 400 on a
// live tenant). Reports are read with POST, but nothing is changed. Read in batches.

import { isTransient, odataQuote, sayOnce } from "./graph.js";
import { reportRow } from "./app-status.js";

// The kinds of configuration policy the list shows, and where their names live.
const POLICY_KINDS = [
  { kind: "catalog", path: "/beta/deviceManagement/configurationPolicies?$select=id,name", name: "name" },
  { kind: "template", path: "/beta/deviceManagement/deviceConfigurations?$select=id,displayName", name: "displayName" },
  { kind: "admx", path: "/beta/deviceManagement/groupPolicyConfigurations?$select=id,displayName", name: "displayName" },
];
// The policy families the summary report covers, as the portal's own request names them.
const BASE_TYPES = ["Microsoft.Management.Services.Api.DeviceConfiguration", "DeviceManagementConfigurationPolicy",
  "DeviceConfigurationAdmxPolicy", "Microsoft.Management.Services.Api.DeviceManagementIntent"];

/**
 * Every configuration policy as Map(lower-case name -> [{ id, kind }]). A kind the admin's role
 * can't read is skipped; a busy Graph throws, so the caller can ask again later.
 */
export async function policyNames(graph) {
  // All three lists at once: one after another took about 5 s on a live tenant.
  const lists = await Promise.all(POLICY_KINDS.map((k) => graph.all(k.path).catch((e) => {
    if (e?.code === "FORBIDDEN" || (e?.code === "HTTP" && e.status < 500)) return [];
    throw e;
  })));
  const out = new Map();
  POLICY_KINDS.forEach((k, n) => {
    for (const it of lists[n]) {
      const name = String(it[k.name] || "").toLowerCase();
      if (!name) continue;
      if (!out.has(name)) out.set(name, []);
      out.get(name).push({ id: String(it.id).toLowerCase(), kind: k.kind });
    }
  });
  return out;
}

/**
 * Succeeded and failed (error or conflict) counts from a status row, whatever Intune names its columns.
 * The report can carry overlapping failure columns (non-compliant and error count the same devices), so
 * the error-like columns count once, by their largest, and conflicts are added. Pure.
 */
export function statusCounts(row) {
  let succeeded = 0;
  let errors = 0;
  let conflicts = 0;
  for (const [col, v] of Object.entries(row || {})) {
    const n = Number(v) || 0;
    if (/error|fail|noncompliant/.test(col)) errors = Math.max(errors, n);
    else if (/conflict/.test(col)) conflicts += n;
    else if (/succe|compliant/.test(col)) succeeded += n;
  }
  return { succeeded, failed: errors + conflicts };
}

/**
 * items: [{ key, id?, name? }]; loadNames() resolves to policyNames' map (cached by the caller).
 * Returns { [key]: { id, succeeded, failed } | { notFound: true } | { ambiguous: n } | { retry: true } }.
 */
export async function policyStatus(graph, items, loadNames) {
  const out = {};
  let names;
  try {
    names = await loadNames();
  } catch {
    for (const i of items) out[i.key] = { retry: true };
    return out;
  }
  const byId = new Map([...names.values()].flat().map((p) => [p.id, p]));
  const todo = [];
  for (const i of items) {
    const found = i.id ? [byId.get(i.id.toLowerCase())].filter(Boolean) : names.get(i.name.toLowerCase()) || [];
    if (found.length === 1) todo.push({ key: i.key, ...found[0] });
    else out[i.key] = found.length ? { ambiguous: found.length } : { notFound: true };
  }
  if (!todo.length) return out;

  const types = BASE_TYPES.map((t) => `(PolicyBaseTypeName eq '${t}')`).join(" or ");
  const res = await graph.batch(todo.map((p, n) => ({
    id: String(n),
    url: "/deviceManagement/reports/getConfigurationPolicyDeviceSummaryReport",
    body: { select: [], filter: `(${types}) and (PolicyId eq '${odataQuote(p.id)}')` },
  })));
  todo.forEach((p, n) => {
    const r = res.get(String(n));
    if (isTransient(r)) { out[p.key] = { retry: true }; return; }
    if (r.status !== 200) sayOnce("policy-status", "warn", "Policy status unavailable:", p.kind, r.status, JSON.stringify(r.body ?? "").slice(0, 300));
    const row = r.status === 200 ? reportRow(r.body) : null;
    if (row) sayOnce("policy-status-columns", "info", "Policy status report columns:", Object.keys(row).join(", "));
    out[p.key] = row ? { id: p.id, ...statusCounts(row) } : { notFound: true };
  });
  return out;
}
