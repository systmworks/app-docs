// Device 360: every indexed policy, app and script that reaches one device, and why. Worked out from
// assignments and group membership, not from what the device reports, so wherever the answer can't be
// known from those (an assignment filter, a mix of user and device targeting, groups we couldn't read)
// it says so instead of guessing.
//
// The rules, from Intune's documentation:
// - An exclusion beats an inclusion of the same kind (device group against device group, user group
//   against user group).
// - Intune doesn't support mixing the kinds (include users, exclude a device group, or the reverse), so
//   that result is "uncertain".
// - An exclude assignment that doesn't reach the device, and an include that doesn't, mean nothing.
// - "All users" and user groups are taken to mean the primary user; they really follow whoever signs in.

import { policyRef, deviceUrl, groupUrl } from "./portal-links.js";
import { norm } from "./resolve.js";

/** The platform family of a managedDevice's operatingSystem, or "" if we don't recognise it. */
export function osFamily(os) {
  const s = norm(os);
  if (s.includes("windows")) return "windows";
  if (s.startsWith("ios") || s.startsWith("ipados")) return "ios";
  if (s.includes("mac")) return "macos";
  if (s.includes("android")) return "android";
  if (s.includes("linux")) return "linux";
  return "";
}

// Policy types that only ever target one platform, or none in particular.
const TYPE_FAMILIES = {
  adminTemplate: ["windows"], remediation: ["windows"], windowsScript: ["windows"],
  featureUpdate: ["windows"], qualityUpdate: ["windows"], driverUpdate: ["windows"], autopilotProfile: ["windows"],
  macScript: ["macos"], macCustomAttribute: ["macos"],
  appProtectionIos: ["ios"], appProtectionAndroid: ["android"], appProtectionWindows: ["windows"],
  enrollmentConfig: ["any"], termsAndConditions: ["any"], policySet: ["any"], appConfigApps: ["any"],
};

/** Families from a settings catalog policy's `platforms` value ("windows10", "macOS,iOS", ...). */
function catalogFamilies(platforms) {
  return String(platforms || "").split(",").map((p) => norm(p).trim()).flatMap((p) => {
    if (p.startsWith("windows")) return ["windows"];
    if (p === "ios") return ["ios"];
    if (p === "macos") return ["macos"];
    if (p.startsWith("android") || p === "aosp") return ["android"];
    if (p === "linux") return ["linux"];
    return [];
  });
}

/** The family a Graph type name belongs to ("#microsoft.graph.win32LobApp" -> windows), or "". */
function odataFamily(odataType) {
  const t = norm(odataType).replace("#microsoft.graph.", "");
  if (/^(managed)?ios/.test(t)) return "ios";
  if (t.startsWith("macos")) return "macos";
  if (/^(managed)?android|^aosp/.test(t)) return "android";
  if (/^(windows|win32|winget|officesuite|microsoftstore|sharedpc|editionupgrade)/.test(t)) return "windows";
  if (t === "webapp") return "any";
  return "";
}

/** Which families a policy targets. An empty list means we can't tell. */
export function policyFamilies(policy) {
  if (TYPE_FAMILIES[policy.type]) return TYPE_FAMILIES[policy.type];
  if (policy.type === "settingsCatalog") return catalogFamilies(policy.meta?.platforms);
  const family = odataFamily(policy.odataType);
  return family ? [family] : [];
}

/**
 * How one assignment's target reaches this device: "device", "user", both or neither.
 * Whether a group is a device or a user group shows from whose membership it's in.
 * -> [{ how, why }]
 */
function reaches(a, deviceGroups, userGroups, hasUser) {
  if (a.kind === "allDevices") return [{ how: "device", why: "All devices" }];
  if (a.kind === "allUsers") return hasUser ? [{ how: "user", why: "All users (primary user)" }] : [];
  if (!a.groupId) return [];
  const label = (g, kind) => `${kind} group: ${g.name}${g.direct ? "" : g.via ? ` (nested, via ${g.via})` : " (nested)"}`;
  const id = norm(a.groupId);
  const out = [];
  const d = deviceGroups?.get(id);
  if (d) out.push({ how: "device", why: label(d, "Device") });
  const u = userGroups?.get(id);
  if (u) out.push({ how: "user", why: label(u, "User") });
  return out;
}

const STATE_ORDER = { applies: 0, filter: 1, uncertain: 2, excluded: 3 };

/** The verdict on one policy for this device, or null if it doesn't reach the device at all. */
function verdictFor(policy, ctx, hasUser) {
  const { deviceGroups, userGroups, filters } = ctx;
  const includes = [];
  const excludes = [];
  let excludeUnknown = false;
  for (const a of policy.assignments || []) {
    const hits = reaches(a, deviceGroups, userGroups, hasUser);
    if (a.kind === "exclude") {
      excludes.push(...hits);
      if (!hits.length && (!deviceGroups || !userGroups)) excludeUnknown = true;
    } else if (a.kind !== "other") {
      for (const h of hits) includes.push({ ...h, filterId: a.filterId || "", filterType: a.filterType || "", intent: a.intent || "" });
    }
  }
  if (!includes.length) return null;

  // An exclusion of the same kind removes an include; one of the other kind leaves it in doubt.
  const live = includes.filter((i) => !excludes.some((e) => e.how === i.how));
  if (!live.length) {
    return { state: "excluded", why: [...new Set(excludes.map((e) => `Excluded by ${e.why}`))], intents: [], filters: [] };
  }
  const clean = excludes.length ? [] : live;
  const chosen = clean.length ? clean : live;
  const unfiltered = chosen.filter((i) => !i.filterId);
  const used = unfiltered.length ? unfiltered : chosen;
  const why = [...new Set(used.map((i) => i.why))];
  const intents = [...new Set(used.map((i) => i.intent).filter(Boolean))];
  const usedFilters = unfiltered.length ? [] : used.map((i) => {
    const f = filters.get(norm(i.filterId));
    return { name: f?.name || "an assignment filter", rule: f?.rule || "", mode: i.filterType === "exclude" ? "exclude" : "include" };
  });

  let state = unfiltered.length ? "applies" : "filter";
  if (!clean.length) {
    state = "uncertain";
    why.push(...new Set(excludes.map((e) => `Also excluded by ${e.why}. Intune doesn't support mixing user and device targeting, so this may not hold`)));
  } else if (excludeUnknown) {
    state = "uncertain";
    why.push("It also has an exclusion, and this device's or user's groups couldn't be read to check it");
  }
  return { state, why, intents, filters: usedFilters };
}

/**
 * The report for one device.
 * @param device  from the device index
 * @param index   the policy index
 * @param ctx     { deviceGroups, userGroups, filters, notes }: Map(lower-case id -> { id, name, direct, via }),
 *                null if it couldn't be read; filters is Map(lower-case id -> { name, rule })
 */
export function buildDevice360(device, index, ctx) {
  const family = osFamily(device.os);
  const hasUser = Boolean(device.upn || device.userId);
  const rows = [];
  let otherPlatform = 0;
  let unreadable = 0;
  for (const policy of index?.policies || []) {
    if (policy.assignmentsUnknown) { unreadable++; continue; }
    const verdict = verdictFor(policy, ctx, hasUser);
    if (!verdict) continue;
    const families = policyFamilies(policy);
    if (family && families.length && !families.includes("any") && !families.includes(family)) { otherPlatform++; continue; }
    rows.push({ id: policy.id, name: policy.name, ...policyRef(policy), ...verdict, platformUnknown: !families.length });
  }
  rows.sort((a, b) => STATE_ORDER[a.state] - STATE_ORDER[b.state] || a.typeLabel.localeCompare(b.typeLabel) || a.name.localeCompare(b.name));

  const counts = { applies: 0, filter: 0, uncertain: 0, excluded: 0 };
  for (const r of rows) counts[r.state]++;
  const groupList = (map) => (map ? [...map.values()].map((g) => ({ ...g, link: groupUrl(g.id) })).sort((a, b) => a.name.localeCompare(b.name)) : null);
  return {
    device: { ...device, link: deviceUrl(device.managedId) },
    rows,
    counts,
    otherPlatform,
    unreadable,
    deviceGroups: groupList(ctx.deviceGroups),
    userGroups: groupList(ctx.userGroups),
    hasUser,
    notes: ctx.notes || [],
    indexErrors: Object.keys(index?.errors || {}),
    policyIndexBuiltAt: index?.builtAt || 0,
  };
}

/** Every group an object is in, direct or nested, and for a nested one the direct group it came through. */
export async function memberGroups(graph, path) {
  const query = "microsoft.graph.group?$select=id,displayName&$top=999";
  const [all, direct] = await Promise.all([
    graph.all(`/v1.0${path}/transitiveMemberOf/${query}`),
    graph.all(`/v1.0${path}/memberOf/${query}`),
  ]);
  const directIds = new Set(direct.map((g) => norm(g.id)));
  const out = new Map(all.map((g) => [norm(g.id), { id: norm(g.id), name: g.displayName || "(unnamed)", direct: directIds.has(norm(g.id)), via: "" }]));
  if ([...out.values()].some((g) => !g.direct) && direct.length) {
    const res = await graph.batch(direct.map((g, n) => ({ id: String(n), url: `/groups/${g.id}/transitiveMemberOf/microsoft.graph.group?$select=id&$top=999` })));
    direct.forEach((g, n) => {
      for (const parent of res.get(String(n))?.body?.value || []) {
        const hit = out.get(norm(parent.id));
        if (hit && !hit.direct && !hit.via) hit.via = g.displayName || "";
      }
    });
  }
  return out;
}

/**
 * Every group a device is in, direct or nested. A device that can't be read gives groups null and either a
 * note (no Entra record) or the error, so "couldn't read" is never mistaken for "in no groups".
 * @returns { groups: Map|null, note: string, error: Error|null }
 */
export async function readDeviceGroups(graph, device) {
  if (!device.aadId) return { groups: null, note: "This device has no Entra record, so its device groups can't be read. Only All devices and user targeting are listed.", error: null };
  try {
    const found = await graph.get(`/v1.0/devices?$filter=${encodeURIComponent(`deviceId eq '${device.aadId}'`)}&$select=id`);
    const objectId = found?.value?.[0]?.id;
    if (!objectId) return { groups: null, note: "Entra doesn't have this device's record any more, so its device groups can't be read.", error: null };
    return { groups: await memberGroups(graph, `/devices/${objectId}`), note: "", error: null };
  } catch (e) {
    return { groups: null, note: "", error: e };
  }
}

/**
 * Read what the report needs for one device from Graph. A read that fails becomes a note and a null,
 * so the report can't mistake "couldn't read" for "not a member".
 * @param listFilters  (graph) => [{ id, name, rule }], from group-tools.js
 */
export async function device360Context(graph, device, listFilters) {
  const notes = [];
  const fail = (what, e) => notes.push(`Couldn't read ${what}${e?.message ? ` (${e.message})` : ""}. Anything reaching this device that way isn't listed.`);

  const readGroups = async () => {
    const r = await readDeviceGroups(graph, device);
    if (r.note) notes.push(r.note);
    if (r.error) fail("this device's groups", r.error);
    return r.groups;
  };
  const readUserGroups = async () => {
    if (!device.userId) return new Map(); // a shared or userless device: no user targeting at all
    try {
      return await memberGroups(graph, `/users/${device.userId}`);
    } catch (e) {
      fail("the primary user's groups", e);
      return null;
    }
  };
  const readFilters = async () => {
    try {
      return new Map((await listFilters(graph)).map((f) => [norm(f.id), f]));
    } catch {
      return new Map(); // only costs the filter's name and rule; the row still says it depends on a filter
    }
  };
  const [deviceGroups, userGroups, filters] = await Promise.all([readGroups(), readUserGroups(), readFilters()]);
  return { deviceGroups, userGroups, filters, notes };
}
