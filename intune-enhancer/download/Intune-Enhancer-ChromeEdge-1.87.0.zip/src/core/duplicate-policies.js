// Pairs of policies that set the same settings to the same values, whether or not they reach the same
// groups. Intune flags a "Conflict" only when values differ on one device, so these overlaps often go
// unnoticed. Values that differ are not listed here: that is a conflict, not a duplicate.
// Reads the policy index only; pure, so it is tested offline.

import { policyRef } from "./portal-links.js";

/** Two policies that are not identical are listed once they share at least this many setting values. */
const MIN_SHARED = 3;
/** Pairs kept in the answer; the rest are counted. */
const MAX_PAIRS = 300;
const EXAMPLE_COUNT = 5;

const settingKey = (s) => `${s.d}\u0000${String(s.v ?? "")}`;
const assignmentKey = (policy) => (policy.assignments || [])
  .map((a) => `${a.kind}:${a.groupId || ""}:${a.filterId || ""}`).sort().join("|");

/**
 * @param index  the policy index ({ policies: [{ id, name, type, settings, assignments }] })
 * @returns { pairs, total } where each pair is { a, b, shared, sizeA, sizeB, match, sameAssignments, sample };
 *          match is "identical" (same settings and values), "inside" (all of one is in the other) or "partial"
 */
export function duplicatePolicies(index) {
  const withSettings = (index?.policies || []).filter((p) => !p.assignmentsUnknown && Array.isArray(p.settings) && p.settings.length);
  // Setting value -> the policies that set it, so only policies sharing something are ever compared.
  const holders = new Map();
  for (const p of withSettings) {
    for (const k of new Set(p.settings.map(settingKey))) {
      if (!holders.has(k)) holders.set(k, []);
      holders.get(k).push(p);
    }
  }
  const counts = new Map(); // "idA\u0000idB" -> { a, b, keys: [] }
  for (const [k, list] of holders) {
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const [a, b] = list[i].id < list[j].id ? [list[i], list[j]] : [list[j], list[i]];
        const id = `${a.id}\u0000${b.id}`;
        if (!counts.has(id)) counts.set(id, { a, b, keys: [] });
        counts.get(id).keys.push(k);
      }
    }
  }

  const names = new Map(withSettings.flatMap((p) => p.settings.map((s) => [settingKey(s), s.n])));
  const pairs = [];
  for (const { a, b, keys } of counts.values()) {
    const sizeA = new Set(a.settings.map(settingKey)).size;
    const sizeB = new Set(b.settings.map(settingKey)).size;
    const shared = keys.length;
    const match = shared === sizeA && shared === sizeB ? "identical" : shared === Math.min(sizeA, sizeB) ? "inside" : "partial";
    if (match !== "identical" && shared < MIN_SHARED) continue;
    pairs.push({
      a: { id: a.id, name: a.name, ...policyRef(a) }, b: { id: b.id, name: b.name, ...policyRef(b) },
      shared, sizeA, sizeB, match, sameAssignments: assignmentKey(a) === assignmentKey(b),
      sample: keys.slice(0, EXAMPLE_COUNT).map((k) => `${names.get(k)} = ${k.split("\u0000")[1]}`),
    });
  }
  const order = { identical: 0, inside: 1, partial: 2 };
  pairs.sort((x, y) => order[x.match] - order[y.match] || y.shared - x.shared || x.a.name.localeCompare(y.a.name));
  return { pairs: pairs.slice(0, MAX_PAIRS), total: pairs.length };
}
