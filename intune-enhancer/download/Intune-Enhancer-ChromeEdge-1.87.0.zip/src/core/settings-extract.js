// Pure functions that turn Graph's policy payloads into flat "setting = value" entries for the
// Setting check search. No chrome.* or network, so they're tested offline.
//
// Entry shape (compact, since a tenant can have tens of thousands):
//   { d: definition id or property key, n: display name, p: path (CSP / ADMX category / OMA-URI), v: value text,
//     k: catalog keywords (optional), x: 1 when the catalog definition's description says it's deprecated }

const T = "#microsoft.graph.deviceManagementConfiguration";

/** "passwordMinimumLength" -> "Password minimum length" */
export function humanize(key) {
  const words = String(key)
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1 $2")
    .replace(/_/g, " ")
    .trim()
    .toLowerCase();
  return words.charAt(0).toUpperCase() + words.slice(1);
}

/**
 * Settings catalog: the items from GET .../configurationPolicies/{id}/settings?$expand=settingDefinitions.
 * Each item has a settingInstance tree and the definitions it uses.
 */
export function extractCatalog(items) {
  const out = [];
  for (const item of items || []) {
    const defs = new Map((item.settingDefinitions || []).map((d) => [d.id, d]));
    walk(item.settingInstance, defs, out);
  }
  return out;
}

function optionName(def, itemId) {
  const opt = (def?.options || []).find((o) => o.itemId === itemId);
  return opt?.displayName || opt?.name || shortValue(itemId, def?.id);
}

// Choice values are ids like "device_vendor_msft_policy_config_x_1"; without a definition, show the tail.
function shortValue(value, defId) {
  const s = String(value ?? "");
  if (defId && s.startsWith(`${defId}_`)) return s.slice(defId.length + 1);
  return s;
}

function entryFor(defId, defs, value) {
  const def = defs.get(defId);
  const path = def ? `${def.baseUri || ""}${def.offsetUri ? `/${def.offsetUri}` : ""}`.replace(/\/+/g, "/") : "";
  return {
    d: defId,
    n: def?.displayName || def?.name || defId,
    p: path || defId,
    v: value,
    ...(def?.keywords?.length ? { k: def.keywords.join(" ") } : {}),
    ...(deprecatedByDescription(def) ? { x: 1 } : {}),
  };
}

// A description that opens with, or has a sentence saying, the setting itself is deprecated.
// Mentions of something else being deprecated ("replaces the deprecated X") don't count.
const DEPRECATED_DESC_RE = /(^|[.!]\s+)(\[?\(?deprecated\b|this (setting|policy) (is|has been|will be) deprecated\b)/i;
const deprecatedByDescription = (def) => DEPRECATED_DESC_RE.test(String(def?.description || "").trim());

function walk(inst, defs, out) {
  if (!inst) return;
  const type = inst["@odata.type"] || "";
  const id = inst.settingDefinitionId;
  const def = defs.get(id);

  if (type === `${T}ChoiceSettingInstance`) {
    const cv = inst.choiceSettingValue || {};
    out.push(entryFor(id, defs, optionName(def, cv.value)));
    (cv.children || []).forEach((c) => walk(c, defs, out));
  } else if (type === `${T}ChoiceSettingCollectionInstance`) {
    const values = inst.choiceSettingCollectionValue || [];
    out.push(entryFor(id, defs, values.map((v) => optionName(def, v.value)).join(", ")));
    values.forEach((v) => (v.children || []).forEach((c) => walk(c, defs, out)));
  } else if (type === `${T}SimpleSettingInstance`) {
    out.push(entryFor(id, defs, simpleText(inst.simpleSettingValue)));
  } else if (type === `${T}SimpleSettingCollectionInstance`) {
    out.push(entryFor(id, defs, (inst.simpleSettingCollectionValue || []).map(simpleText).join(", ")));
  } else if (type === `${T}GroupSettingInstance`) {
    (inst.groupSettingValue?.children || []).forEach((c) => walk(c, defs, out));
  } else if (type === `${T}GroupSettingCollectionInstance`) {
    (inst.groupSettingCollectionValue || []).forEach((g) => (g.children || []).forEach((c) => walk(c, defs, out)));
  } else if (id) {
    out.push(entryFor(id, defs, ""));
  }
}

function simpleText(sv) {
  if (!sv) return "";
  if (String(sv["@odata.type"] || "").includes("Secret")) return "(secret)";
  const v = sv.value;
  return v === undefined || v === null ? "" : String(v);
}

/**
 * Administrative templates: items from GET .../groupPolicyConfigurations/{id}/definitionValues
 * ?$expand=definition($select=displayName,categoryPath,classType)
 */
export function extractAdmx(items) {
  return (items || []).map((dv) => {
    const def = dv.definition || {};
    const scope = def.classType === "user" ? "User" : def.classType === "machine" ? "Computer" : "";
    return {
      d: def.id || dv.id,
      n: def.displayName || "(unnamed setting)",
      p: [scope, def.categoryPath].filter(Boolean).join(": "),
      v: dv.enabled ? "Enabled" : "Disabled",
    };
  });
}

// Properties that describe the policy object itself rather than a setting it configures.
const META_KEYS = new Set([
  "id", "displayName", "description", "createdDateTime", "lastModifiedDateTime", "version",
  "roleScopeTagIds", "supportsScopeTags", "deviceManagementApplicabilityRuleOsEdition",
  "deviceManagementApplicabilityRuleOsVersion", "deviceManagementApplicabilityRuleDeviceMode",
  "assignments", "scheduledActionsForRule", "deviceStatuses", "userStatuses", "deviceStatusOverview",
  "userStatusOverview", "deviceSettingStateSummaries", "groupAssignments", "omaSettings",
]);

/** Values that mean "not configured" in the template-based (legacy) profile types. */
function isUnset(v) {
  return v === null || v === undefined || v === "" || v === false || v === "notConfigured" ||
    (Array.isArray(v) && v.length === 0) || (typeof v === "object" && !Array.isArray(v) && Object.keys(v).length === 0);
}

function valueText(v) {
  if (Array.isArray(v)) return v.map((x) => (typeof x === "object" ? JSON.stringify(x) : String(x))).join(", ").slice(0, 300);
  if (typeof v === "object") return JSON.stringify(v).slice(0, 300);
  return String(v);
}

/**
 * Template-based device configuration and compliance policies: the configured properties of the
 * policy object, plus each OMA-URI row of custom profiles.
 */
export function extractProperties(policy) {
  const out = [];
  const odataType = String(policy?.["@odata.type"] || "").replace("#microsoft.graph.", "");
  for (const [key, value] of Object.entries(policy || {})) {
    if (key.startsWith("@") || key.includes("@odata") || META_KEYS.has(key) || isUnset(value)) continue;
    out.push({ d: `${odataType}.${key}`, n: humanize(key), p: `${odataType}.${key}`, v: valueText(value) });
  }
  for (const oma of policy?.omaSettings || []) {
    const secret = String(oma["@odata.type"] || "").includes("Base64") || oma.isEncrypted;
    out.push({
      d: `oma:${oma.omaUri}`,
      n: oma.displayName || oma.omaUri,
      p: oma.omaUri || "",
      v: secret ? "(encrypted)" : valueText(oma.value ?? ""),
    });
  }
  return out;
}

/**
 * Normalise an assignment's target.
 * -> { kind: "include"|"exclude"|"allDevices"|"allUsers"|"other", groupId?, filterId?, filterType?, intent? }
 */
export function normaliseAssignment(a) {
  const t = a?.target || {};
  const type = String(t["@odata.type"] || "");
  let kind = "other";
  if (type.endsWith("exclusionGroupAssignmentTarget")) kind = "exclude";
  else if (type.endsWith("groupAssignmentTarget")) kind = "include";
  else if (type.endsWith("allDevicesAssignmentTarget")) kind = "allDevices";
  else if (type.endsWith("allLicensedUsersAssignmentTarget")) kind = "allUsers";
  const out = { kind };
  if (t.groupId) out.groupId = String(t.groupId).toLowerCase();
  const filterId = t.deviceAndAppManagementAssignmentFilterId;
  if (filterId && filterId !== "00000000-0000-0000-0000-000000000000") {
    out.filterId = filterId;
    out.filterType = t.deviceAndAppManagementAssignmentFilterType || "";
  }
  if (a?.intent) out.intent = a.intent;
  return out;
}
