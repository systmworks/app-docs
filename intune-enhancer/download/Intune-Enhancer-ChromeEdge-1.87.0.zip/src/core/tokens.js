// Pool of Graph access tokens read from the portal's sign-in cache. Held in memory and mirrored
// to chrome.storage.session (RAM only, cleared when the browser closes) so a sleeping service
// worker can pick them up again. Never written to disk, never sent anywhere but Graph.

const MAX_TOKENS = 12;
const SESSION_KEY = "ie.tokens";
// Scopes that can read Intune managed devices (and so their primary users).
const DEVICE_READ_RE = /DeviceManagementManagedDevices\.(Read|ReadWrite|PrivilegedOperations)\.All/i;

function decodeJwt(jwt) {
  try {
    const part = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
    // atob gives one character per byte: decode as UTF-8 so a non-ASCII name or UPN survives.
    return JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(part), (c) => c.charCodeAt(0))));
  } catch {
    return null;
  }
}

export function createTokenPool({ onIdentityChange = () => {} } = {}) {
  /** token -> { seenAt, exp, scopes, deviceRead, verified } (claims decoded once, on add) */
  const pool = new Map();
  let identity = null;

  const ready = chrome.storage.session.get(SESSION_KEY).then((v) => {
    const saved = v[SESSION_KEY];
    if (!saved) return;
    identity = saved.identity || null;
    for (const [token, meta] of saved.entries || []) pool.set(token, meta);
  }).catch(() => {});

  function persist() {
    chrome.storage.session.set({ [SESSION_KEY]: { identity, entries: [...pool.entries()] } }).catch(() => {});
  }

  /** Drop tokens within a minute of expiry. */
  function prune(now = Date.now()) {
    for (const [token, meta] of pool) if (meta.exp && meta.exp * 1000 < now + 60000) pool.delete(token);
  }

  return {
    ready,

    get identity() { return identity; },

    add(token) {
      const claims = decodeJwt(token);
      if (!claims?.tid) return;
      const id = { tid: claims.tid, oid: claims.oid || "", upn: claims.upn || claims.preferred_username || claims.unique_name || "" };
      const known = pool.has(token);
      const changed = !identity || identity.tid !== id.tid || identity.oid !== id.oid;
      if (changed) {
        // First sign-in, or a different admin or tenant: the old tokens no longer apply.
        const previous = identity;
        pool.clear();
        identity = id;
        onIdentityChange(id, previous);
      }
      const scopes = String(claims.scp || claims.roles || "").trim();
      const verified = pool.get(token)?.verified || false;
      pool.set(token, { seenAt: Date.now(), exp: claims.exp || 0, scopes, deviceRead: DEVICE_READ_RE.test(scopes), verified });
      prune();
      while (pool.size > MAX_TOKENS) {
        const oldest = [...pool.entries()].sort((a, b) => a[1].seenAt - b[1].seenAt)[0][0];
        pool.delete(oldest);
      }
      // A token seen again only moves its timestamp, which the saved copy doesn't need: the portal re-sends
      // every token each minute.
      if (!known || changed) persist();
    },

    /** Remember that a token worked, so it's tried before untested ones. */
    markGood(token) {
      const meta = pool.get(token);
      if (!meta || meta.verified) return;
      meta.verified = true;
      persist();
    },

    /** Best first: device-read scopes, then proven to work, then newest. One per scope set. */
    candidates() {
      prune();
      const ranked = [...pool.entries()].sort(([, a], [, b]) =>
        Number(b.deviceRead) - Number(a.deviceRead) || Number(b.verified) - Number(a.verified) || b.seenAt - a.seenAt);
      const seen = new Set();
      return ranked.filter(([, m]) => !seen.has(m.scopes) && seen.add(m.scopes)).map(([token]) => token);
    },

    get size() { prune(); return pool.size; },

    clear() {
      pool.clear();
      identity = null;
      chrome.storage.session.remove(SESSION_KEY).catch(() => {});
    },
  };
}
