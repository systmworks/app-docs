// What the "Related" card on a device's page shows: the primary user's other devices and the groups the
// device is in. Pure shaping of what the worker has already read, so it is tested offline.

const RELATED_MAX_DEVICES = 15;

/**
 * @param device  the device row for the page (from the device index)
 * @param others  every device of the primary user, including this one
 * @param groups  Map(lower-case id -> { id, name, direct, via }) of the device's groups, or null if unreadable
 * @param note    why the groups couldn't be read, when they couldn't
 * @param sameSerial  how many other index rows share this device's serial number (a re-enrolled device)
 */
export function shapeRelated(device, others, groups, note = "", sameSerial = 0) {
  const name = device.displayName || device.upn || "";
  const rest = (others || []).filter((d) => d.managedId !== device.managedId);
  return {
    device: { managedId: device.managedId, name: device.name },
    user: name ? { name, upn: device.upn || "" } : null,
    sameSerial,
    others: rest.slice(0, RELATED_MAX_DEVICES).map((d) => ({ managedId: d.managedId, name: d.name, os: d.os, osVersion: d.osVersion, lastSync: d.lastSync, compliance: d.compliance })),
    othersTotal: rest.length,
    groups: groups ? [...groups.values()].map((g) => ({ id: g.id, name: g.name, direct: g.direct, via: g.via || "" })).sort((a, b) => a.name.localeCompare(b.name)) : null,
    groupsNote: groups ? "" : note || "This device's groups couldn't be read.",
  };
}
