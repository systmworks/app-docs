// Workspace page: one tab per tool, plus Settings (turning it on, and the in-portal switches).
// All data comes from the service worker (which holds the Graph session). With ?sample=1 (hidden,
// for screenshots, previews and store reviewers), or when
// opened outside the extension, it answers from the fictional tenant in sample.js instead, sending
// nothing anywhere.

import { sampleSend } from "./sample.js";
import { osSpread, staleDevices, lowStorageDevices, duplicateDevices, ageDays, activityLevel } from "../core/device-reports.js";
import { isBelowVersion } from "../core/app-versions.js";
import { grantConsent } from "../shared/consent.js";
import { POLICY_TYPES } from "../core/policy-types.js";
import { policyDocument } from "../core/policy-export.js";
import { hardwareColumns } from "../core/hardware.js";
import { deviceUrl } from "../core/portal-links.js";

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
const ESCAPES = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ESCAPES[c]);

const inExtension = Boolean(globalThis.chrome?.runtime?.id);
const SAMPLE = !inExtension || new URLSearchParams(location.search).has("sample");

// The progress bar along the bottom: one line for the job that last reported, redrawn every JOB_REDRAW_MS so it
// doesn't flicker. A job with a total shows a meter; with a stop it shows Stop (a function, or true for a
// worker job, which is stopped by asking the worker).
const JOB_REDRAW_MS = 2000;
const JOB_DONE_MS = 6000; // how long a final message ("Stopped. Kept ...") stays
const jobBar = (() => {
  const jobs = new Map(); // key -> { label, done, total, stop, startedAt, touched }
  let timer = 0;
  let hideTimer = 0;
  const el = (id) => document.getElementById(id);

  function draw() {
    const bar = el("jobbar");
    if (!bar) return;
    const list = [...jobs.values()];
    if (!list.length) { bar.hidden = true; document.body.classList.remove("has-job"); return; }
    const job = list.reduce((a, b) => (b.touched >= a.touched ? b : a));
    const seconds = Math.round((Date.now() - job.startedAt) / 1000);
    const count = job.total ? ` (${job.done.toLocaleString()} of ${job.total.toLocaleString()})` : job.done ? ` (${job.done.toLocaleString()} so far)` : "";
    el("job-text").textContent = job.final || `${job.label}${count}`;
    const pct = job.total ? Math.min(100, Math.round((job.done / job.total) * 100)) : 0;
    el("job-meter").hidden = !job.total || Boolean(job.final);
    el("job-fill").style.width = `${pct}%`;
    el("job-detail").textContent = job.final ? "" : `${job.total ? `${pct}%, ` : ""}${seconds} s`;
    el("job-stop").hidden = !job.stop || Boolean(job.final);
    el("job-stop").disabled = Boolean(job.stopping);
    bar.hidden = false;
    document.body.classList.add("has-job");
  }
  const tick = () => { draw(); if (!jobs.size) { clearInterval(timer); timer = 0; } };
  const ensureTimer = () => { if (!timer) timer = setInterval(tick, JOB_REDRAW_MS); };

  return {
    /** Start or update a job; the first report draws at once, later ones wait for the next redraw. */
    set(key, update) {
      const first = !jobs.has(key);
      const job = jobs.get(key) || { label: "", done: 0, total: 0, stop: null, startedAt: Date.now() };
      Object.assign(job, update, { touched: Date.now() });
      delete job.final;
      jobs.set(key, job);
      clearTimeout(hideTimer);
      if (first) draw();
      ensureTimer();
    },
    /** End a job, optionally leaving a final message on the bar for a few seconds. */
    done(key, message = "") {
      const job = jobs.get(key);
      if (!job) return;
      if (message) {
        job.final = message;
        job.touched = Date.now();
        draw();
        hideTimer = setTimeout(() => { jobs.delete(key); draw(); }, JOB_DONE_MS);
      } else {
        jobs.delete(key);
        draw();
      }
    },
    /** Stop the shown job: a function runs, true asks the worker. */
    stop() {
      const job = [...jobs.values()].reduce((a, b) => (b.touched >= a.touched ? b : a), null);
      if (!job?.stop) return;
      job.stopping = true;
      job.label = "Stopping...";
      draw();
      if (typeof job.stop === "function") job.stop();
      else send("job/stop").catch(() => {});
    },
  };
})();

// Reads the worker does in one go, with no count to show: just a line on the bar while they run.
const LONG_READS = {
  "device/360": "Reading the device's groups and policies",
  "devices/compare": "Reading both devices' groups and policies",
  "users/compare": "Reading both users' groups",
  "policies/duplicates": "Comparing every policy",
  "compliance/summary": "Reading compliance results",
  "compliance/devices": "Reading the devices failing this setting",
  "tenant/health": "Checking tokens, certificates and connectors",
  "devices/orphaned": "Checking primary users", // the worker reports its count as it goes
};

function send(type, payload = {}) {
  const label = LONG_READS[type];
  const key = label ? `read:${type}` : "";
  // devices/orphaned and anything else that builds an index can be stopped, so those lines get Stop too.
  if (key) jobBar.set(key, { label, stop: type === "devices/orphaned" || undefined });
  const reply = SAMPLE ? sampleSend(type, payload) : chrome.runtime.sendMessage({ type, ...payload }).then((res) => {
    if (!res) throw new Error("No response from the extension. Try reloading this tab.");
    if (res.ok === false) throw Object.assign(new Error(res.error || "Request failed."), { code: res.code });
    return res;
  });
  return key ? Promise.resolve(reply).finally(() => jobBar.done(key)) : reply;
}

// ------------------------------------------------------------------------------------------
// Small helpers

/** How long ago a time (ms) was: "just now", "5 min ago", "3 h ago", or the date after two days. */
function ago(ms) {
  if (!ms) return "never";
  const mins = Math.round((Date.now() - ms) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins} min ago`;
  const hours = Math.round(mins / 60);
  return hours < 48 ? `${hours} h ago` : new Date(ms).toLocaleDateString();
}
function checkInText(iso) {
  const d = ageDays(iso);
  if (d === null) return "never";
  const h = Math.floor((Date.now() - Date.parse(iso)) / 36e5);
  if (h < 24) return h < 1 ? "under 1 hour ago" : `${h} hour${h === 1 ? "" : "s"} ago`;
  return `${d} day${d === 1 ? "" : "s"} ago`;
}
/** Last check-in with its activity traffic light (green 8 hours, yellow 7 days, orange 30, red older or never). */
const checkInCell = (iso) => `<span class="nowrap"><span class="light ${activityLevel(iso)}" aria-hidden="true"></span>${esc(checkInText(iso))}</span>`;
const friendlyOs = (os, version) => globalThis.IEWindowsBuilds?.friendly(version) || [os, version].filter(Boolean).join(" ");
const COMPLIANCE_BADGES = {
  compliant: ["ok", "Compliant"], noncompliant: ["bad", "Not compliant"], inGracePeriod: ["warn", "Grace period"],
  conflict: ["warn", "Conflict"], error: ["bad", "Error"],
};
const complianceBadge = (c) => {
  const [cls, text] = COMPLIANCE_BADGES[c] || ["", c ? c : "Unknown"];
  return `<span class="badge ${cls}">${esc(text)}</span>`;
};
/**
 * For a tool whose answers can arrive out of order (the first search can take a minute while an
 * index builds): `const current = run();` when a request starts, and `if (!current()) return;` before
 * writing its answer, so a slower, older request never replaces a newer one.
 */
function newestOnly() {
  let latest = 0;
  return () => {
    const mine = ++latest;
    return () => mine === latest;
  };
}
const loading = (text) => `<div class="empty"><span class="spinner"></span>${esc(text)}</div>`;
const errorBox = (e) => `<div class="empty">${esc(e?.message || e)}</div>`;
const link = (href, text) => (href ? `<a href="${esc(href)}" target="_blank" rel="noopener">${esc(text)}</a>` : esc(text));

function showBanner(text) {
  const b = $("#banner");
  b.textContent = text;
  b.hidden = !text;
}

// While it's turned off the banner points to the Settings tab, or below when that tab is open.
let turnedOff = false;
const showOffBanner = () => showBanner(currentTab === "settings"
  ? "Intune Enhancer is turned off. Read what it does below, then turn it on."
  : "Intune Enhancer is turned off. Read what it does on the Settings tab, then turn it on.");

// ------------------------------------------------------------------------------------------
// Session and tabs

async function refreshSession() {
  // A dot on the Settings tab: green when there's a session, red when not; the text is its tooltip.
  const setSession = (text, live) => { const el = $("#session"); el.title = text; el.className = `session ${live ? "live" : "none"}`; };
  try {
    const s = await send("status");
    turnedOff = !SAMPLE && !s.consented;
    if (SAMPLE) {
      setSession("Sample data (fictional)", true);
      showBanner("You're looking at sample data for a fictional tenant. Nothing is read from or sent to any tenant.");
    } else if (!s.consented) {
      setSession("Turned off", false);
      showOffBanner();
    } else if (!s.signedIn) {
      setSession("No Intune session", false);
      showBanner("Open the Intune admin center (intune.microsoft.com) in another tab and sign in. This page uses that session.");
    } else {
      setSession(s.upn || "Signed in", true);
      showBanner("");
    }
    renderIndexLine(s.policies);
    renderSettingsTab(s);
    return s;
  } catch (e) {
    setSession("Extension not reachable", false);
    return null;
  }
}

const TABS = ["setting", "changes", "cleanup", "polexport", "dupes", "impact", "roster", "d360", "cmpdevices", "cmpusers", "os", "hygiene", "storage", "hardware", "compliance", "orphans", "appver", "health", "decode", "settings"];
const DEFAULT_TAB = "d360"; // the first tool in the sidebar; where a fresh open lands
let currentTab = DEFAULT_TAB;

function selectTab(name) {
  currentTab = name;
  for (const btn of $$('[role="tab"]')) btn.setAttribute("aria-selected", String(btn.dataset.tab === name));
  for (const sec of $$(".tab")) sec.hidden = sec.id !== `tab-${name}`;
  try { localStorage.setItem("ie.workspace.tab", name); } catch { /* storage unavailable */ }
  if (turnedOff) showOffBanner();
  // The device report tabs load the device list the first time they're shown.
  if (name === "os" || name === "hygiene" || name === "storage") { showDeviceTab(name); return; }
  if (name === "orphans") { if (!orphans) runOrphans(); return; }
  if (name === "hardware") { if (!hwData) loadSavedHardware(); return; }
  if (name === "health") { if (!health) runHealth(); return; }
  const first = $(`#tab-${name} input[type="search"], #tab-${name} textarea`);
  first?.focus();
}
$$('[role="tab"]').forEach((btn) => btn.addEventListener("click", () => selectTab(btn.dataset.tab)));
// The toolbar icon and the admin center's "turned off" note open #settings, also in an open tab.
// "#impact/<group id>" (from the Used by button in the portal) opens Group impact for that group.
function openFromHash() {
  const [tab, arg] = location.hash.slice(1).split("/");
  if (!TABS.includes(tab)) return false;
  selectTab(tab);
  if (tab === "impact" && /^[0-9a-f-]{36}$/i.test(arg || "")) {
    $('[data-picker="impact"] input').value = arg;
    runImpact({ id: arg });
  }
  return true;
}
window.addEventListener("hashchange", openFromHash);

// ------------------------------------------------------------------------------------------
// Setting check

// The policy index line, on every tab that reads the policy index.
const setIndexLines = (html) => $$(".policy-index-line").forEach((el) => { el.innerHTML = html; });

/** Group ids named in the assignments of a Setting check or deprecated-settings answer. */
const settingGroupIds = (res) => [...new Set(res.settings.flatMap((s) => s.hits.flatMap((h) => h.assignments.map((a) => a.groupId))))];

function renderIndexLine(p) {
  if (!p) { setIndexLines(""); return; }
  if (p.building) { setIndexLines('<span class="spinner"></span>Reading your policies...'); return; }
  const errs = Object.keys(p.errors || {}).filter((k) => !k.includes(":"));
  setIndexLines(p.builtAt
    ? `Policy index: ${p.count} policies, updated ${esc(ago(p.builtAt))}${p.stale ? " (refresh recommended)" : ""}. <button class="link" data-refresh-policies>Refresh</button>${errs.length ? `<br>Couldn't read: ${esc(errs.join(", "))}. Results don't include those.` : ""}`
    : 'Your policies are read the first time you use a tool that needs them. <button class="link" data-refresh-policies>Read them now</button>');
}

async function rebuildPolicies() {
  renderIndexLine({ building: true });
  try {
    const res = await send("policies/build");
    renderIndexLine(res.policies);
    changes = null; // re-read with the new index
    if (shown) showChanges(); // refresh results already on screen
  } catch (e) {
    setIndexLines(esc(e.message));
  }
}
document.addEventListener("click", (e) => { if (e.target.closest?.("[data-refresh-policies]")) rebuildPolicies(); });

let groupNames = {};
async function namesFor(ids) {
  const missing = ids.filter((id) => id && !(id in groupNames));
  if (missing.length) {
    try { Object.assign(groupNames, (await send("groups/names", { ids: missing })).names); } catch { /* show ids */ }
  }
  return groupNames;
}

function assignmentText(assignments) {
  if (!assignments?.length) return '<span class="muted">Not assigned</span>';
  return assignments.map((a) => {
    const filter = a.filterId ? ` <span class="muted">(filter ${esc(a.filterType || "")})</span>` : "";
    if (a.kind === "allDevices") return `All devices${filter}`;
    if (a.kind === "allUsers") return `All users${filter}`;
    const name = groupNames[a.groupId] || a.groupId;
    return `${a.kind === "exclude" ? '<span class="badge warn">Exclude</span> ' : ""}${esc(name)}${filter}`;
  }).join("<br>");
}

const settingRun = newestOnly(); // Check and Deprecated settings share one results area

$("#setting-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query = $("#setting-query").value.trim();
  const out = $("#setting-results");
  const current = settingRun();
  if (!query) { out.innerHTML = ""; return; }
  out.innerHTML = loading("Searching your policies (the first search reads them, which can take a minute)...");
  try {
    const res = await send("settings/search", { query });
    renderIndexLine(res.policies);
    await namesFor(settingGroupIds(res));
    if (current()) out.innerHTML = renderSettings(query, res);
  } catch (err) {
    if (current()) out.innerHTML = errorBox(err);
  }
});

function renderSettings(query, res) {
  if (!res.settings.length) {
    return `<div class="card"><h2>Not configured</h2>
      <p>No setting matching <strong>${esc(query)}</strong> is configured in any of the ${res.policyCount} policies with settings (${res.settingCount.toLocaleString()} configured settings checked).</p>
      <p class="muted">This searches settings that are <em>set</em> in a policy. A setting that exists in the catalog but isn't set anywhere won't appear, so check the spelling if you expected a match.</p></div>`;
  }
  const indexed = res.policies?.count ? ` of the ${res.policies.count} indexed (apps, scripts and similar have no settings)` : "";
  return `<p class="muted">${res.total} matching setting${res.total === 1 ? "" : "s"}${res.truncated ? `, showing the first ${res.settings.length}` : ""}. Checked the ${res.policyCount} policies that configure settings${indexed}.</p>` + settingCards(res.settings);
}

function renderDeprecated(res) {
  if (!res.settings.length) {
    return `<div class="card"><h2>No deprecated settings found</h2>
      <p>None of the ${res.settingCount.toLocaleString()} settings configured in your ${res.policyCount} policies is marked deprecated.</p></div>`;
  }
  const uses = res.settings.reduce((n, s) => n + s.hits.length, 0);
  return `<p class="muted">${res.total} deprecated setting${res.total === 1 ? " is" : "s are"} still configured, ${uses} time${uses === 1 ? "" : "s"} across your policies${res.truncated ? ` (showing the first ${res.settings.length})` : ""}. Found by "Deprecated" in the setting's name or catalog description: plan to remove or replace them.</p>` + settingCards(res.settings);
}

function settingCards(settings) {
  return settings.map((s) => `
    <article class="card">
      <h2>${esc(s.name)}</h2>
      <div class="path">${esc(s.path)}</div>
      <div class="badges">
        <span class="badge ok">Configured in ${s.hits.length} polic${s.hits.length === 1 ? "y" : "ies"}</span>
        ${s.differs ? '<span class="badge warn">Values differ between policies</span>' : ""}
      </div>
      <div class="tablewrap"><table>
        <thead><tr><th>Policy</th><th>Type</th><th>Value</th><th>Assigned to</th></tr></thead>
        <tbody>${s.hits.map((h) => `<tr><td>${link(h.link, h.policyName)}</td><td>${esc(h.typeLabel)}</td><td class="mono">${esc(h.value || "(set)")}</td><td>${assignmentText(h.assignments)}</td></tr>`).join("")}</tbody>
      </table></div>
    </article>`).join("");
}

$("#deprecated-run").addEventListener("click", async () => {
  const out = $("#setting-results");
  const current = settingRun();
  out.innerHTML = loading("Looking for deprecated settings (the first run reads your policies, which can take a minute)...");
  try {
    const res = await send("settings/deprecated");
    renderIndexLine(res.policies);
    await namesFor(settingGroupIds(res));
    if (current()) out.innerHTML = renderDeprecated(res);
  } catch (err) {
    if (current()) out.innerHTML = errorBox(err);
  }
});

// ------------------------------------------------------------------------------------------
// Recent changes

let changes = null;
let changesLoading = null;
let shown = null; // rows of the last search, for Copy table and Save CSV

// Every type up front, so it can be picked before the first search.
$("#changes-type").innerHTML = '<option value="">All types</option>' +
  POLICY_TYPES.map((t) => t.label).sort().map((t) => `<option>${esc(t)}</option>`).join("");

async function showChanges() {
  if (!changes) {
    $("#changes-results").innerHTML = loading("Reading your policies (the first time can take a minute)...");
    try {
      if (!changesLoading) changesLoading = send("policies/changes").finally(() => { changesLoading = null; });
      const res = await changesLoading;
      renderIndexLine(res.policies);
      await namesFor([...new Set(res.items.flatMap((i) => i.assignments.map((a) => a.groupId)))]);
      changes = res.items;
    } catch (err) {
      $("#changes-results").innerHTML = errorBox(err);
      return;
    }
  }
  drawChanges();
}

function changesView() {
  const days = Number($("#changes-days").value) || 7;
  const by = $("#changes-by").value;
  const type = $("#changes-type").value;
  const text = $("#changes-filter").value.trim().toLowerCase();
  const since = new Date(Date.now() - days * 864e5).toISOString();
  return changes
    .filter((i) => i[by] && i[by] >= since && (!type || i.typeLabel === type) && (!text || i.name.toLowerCase().includes(text)))
    .sort((a, b) => b[by].localeCompare(a[by]));
}

const dateAgo = (iso) => (iso ? `${esc(new Date(iso).toLocaleDateString())} <span class="muted small">${esc(checkInText(iso))}</span>` : '<span class="muted">unknown</span>');

function drawChanges() {
  const rows = (shown = changesView());
  const days = Number($("#changes-days").value) || 7;
  const undated = changes.filter((i) => !i.modified).length;
  $("#changes-count").textContent = `${rows.length} of ${changes.length}`;
  $("#changes-results").innerHTML = (rows.length
    ? tableHtml(["Name", "Type", "Modified", "Created", "Assigned to"], rows.map((i) => [
      td(link(i.link, i.name)), td(esc(i.typeLabel)), td(dateAgo(i.modified), "nowrap"), td(dateAgo(i.created), "nowrap"), td(assignmentText(i.assignments)),
    ]))
    : `<div class="empty">Nothing ${$("#changes-by").value === "created" ? "created" : "changed"} in the last ${days} days.</div>`) +
    (undated ? `<p class="muted small">${undated} item${undated === 1 ? " has" : "s have"} no dates in Graph, so ${undated === 1 ? "isn't" : "aren't"} listed.</p>` : "");
}

// Runs on Show changes or Enter only, so the period and filters can be set first.
$("#changes-form").addEventListener("submit", (e) => { e.preventDefault(); showChanges(); });

function changesRows() {
  const target = (a) => (a.kind === "allDevices" ? "All devices" : a.kind === "allUsers" ? "All users"
    : `${a.kind === "exclude" ? "Exclude: " : ""}${groupNames[a.groupId] || a.groupId}`);
  return [["Name", "Type", "Modified", "Created", "Assigned to", "ID"],
    ...shown.map((i) => [i.name, i.typeLabel, i.modified, i.created, i.assignments.map(target).join("; "), i.id])];
}
$("#changes-copy").addEventListener("click", (e) => shown && copyTsv(e.currentTarget, changesRows()));
$("#changes-csv").addEventListener("click", () => shown && saveCsv("recent-changes.csv", changesRows()));

// ------------------------------------------------------------------------------------------
// Group picker (shared by Group impact and Group roster)

function setupPicker(name, onPick) {
  const root = $(`[data-picker="${name}"]`);
  const input = $("input", root);
  const button = $("button", root);
  const list = $(".picker-list", root);
  let items = [];
  let active = -1;
  let empty = "No groups found";

  const close = () => { list.hidden = true; active = -1; };
  const draw = () => {
    list.innerHTML = items.length
      ? items.map((g, i) => `<li role="option" data-i="${i}" aria-selected="${i === active}">${esc(g.displayName)}<span class="sub">${esc(g.userPrincipalName ?? kindOf(g))}</span></li>`).join("")
      : `<li class="muted">${esc(empty)}</li>`;
    list.hidden = false;
  };
  // A user shows with their sign-in name, since the same person can exist under more than one domain.
  const pick = (g) => { input.value = root.dataset.key === "users" && g.userPrincipalName ? `${g.displayName} (${g.userPrincipalName})` : g.displayName; close(); onPick(g); };

  // Searches on Enter or the Search button only, one at a time, so answers can't arrive out of order.
  root.addEventListener("submit", async (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q || button.disabled) return;
    button.disabled = true;
    try {
      const key = root.dataset.key || "groups";
      items = (await send(root.dataset.search || "groups/search", { query: q }))[key] || [];
      empty = `No ${key} found`;
    } catch (err) {
      items = [];
      empty = err.message;
    } finally {
      button.disabled = false;
    }
    active = -1;
    draw();
  });
  input.addEventListener("keydown", (e) => {
    if (list.hidden) return;
    if (e.key === "ArrowDown") { active = Math.min(items.length - 1, active + 1); draw(); e.preventDefault(); }
    else if (e.key === "ArrowUp") { active = Math.max(0, active - 1); draw(); e.preventDefault(); }
    else if (e.key === "Enter" && items[active]) { pick(items[active]); e.preventDefault(); }
    else if (e.key === "Escape") close();
  });
  list.addEventListener("click", (e) => {
    const li = e.target.closest("li[data-i]");
    if (li) pick(items[Number(li.dataset.i)]);
  });
  document.addEventListener("click", (e) => { if (!root.contains(e.target)) close(); });
}

function kindOf(g) {
  const dynamic = (g.groupTypes || []).includes("DynamicMembership");
  const m365 = (g.groupTypes || []).includes("Unified");
  const kind = m365 ? "Microsoft 365" : g.securityEnabled ? "Security" : "Distribution";
  return `${kind}, ${dynamic ? "dynamic" : "assigned"}${g.description ? `: ${g.description}` : ""}`;
}

// ------------------------------------------------------------------------------------------
// Group impact

const impactRun = newestOnly();

async function runImpact(g) {
  const out = $("#impact-results");
  const current = impactRun();
  out.innerHTML = loading("Checking everything that references this group...");
  try {
    const { report } = await send("group/impact", { groupId: g.id });
    if (!current()) return;
    out.innerHTML = renderImpact(report);
    $("#impact-csv")?.addEventListener("click", () => saveCsv(`group-impact-${report.group.name}.csv`, impactRows(report)));
  } catch (e) {
    if (current()) out.innerHTML = errorBox(e);
  }
}
setupPicker("impact", runImpact);

const ICON = { clear: "✅", "in-use": "⚠️", unknown: "❔" };

function renderImpact(r) {
  const verdictText = {
    clear: ["Looks safe to retire", "Nothing found that references this group."],
    unknown: ["Couldn't check everything", "Nothing found so far, but some checks couldn't run. See below."],
    "in-use": ["In use", "Retiring this group would change what the items below apply to."],
  }[r.verdict];
  const members = (n) => (n === null || n === undefined ? "?" : n.toLocaleString());
  const section = (title, rows) => (rows ? `<h3>${esc(title)}</h3>${rows}` : "");
  const simpleList = (arr, fmt) => (arr?.length ? `<ul>${arr.map((x) => `<li>${fmt(x)}</li>`).join("")}</ul>` : "");

  return `
    <article class="card">
      <h2>${link(r.link, r.group.name)}</h2>
      <div class="muted">${esc(r.group.kind)}${r.group.synced ? ", synced from on-premises" : ""}</div>
      ${r.group.description ? `<div>${esc(r.group.description)}</div>` : ""}
      ${r.group.rule ? `<div class="path">Rule: ${esc(r.group.rule)}</div>` : ""}
      <div class="facts">
        <div><span>Devices (incl. nested)</span>${members(r.members.devices)}</div>
        <div><span>Users (incl. nested)</span>${members(r.members.users)}</div>
        <div><span>Owners</span>${r.owners ? esc(r.owners.join(", ") || "None") : "?"}</div>
        <div><span>Created</span>${r.group.created ? esc(new Date(r.group.created).toLocaleDateString()) : "?"}</div>
      </div>
    </article>

    <div class="verdict ${esc(r.verdict)}"><div>${ICON[r.verdict]}</div><div><strong>${esc(verdictText[0])}</strong>${esc(verdictText[1])}</div></div>

    <article class="card">
      <h2>Retirement checklist</h2>
      <ul class="checklist">${r.checklist.map((c) => `
        <li><span>${ICON[c.status]}</span><span>${esc(c.label)}</span><span>${c.count === null ? "?" : c.count}</span>
        ${c.detail && c.status !== "clear" ? `<span class="detail">${esc(c.detail)}</span>` : ""}</li>`).join("")}
      </ul>
      <p class="muted">Policy index from ${esc(ago(r.policyIndexBuiltAt))}. Refresh it on the Setting check tab if policies changed since.</p>
    </article>

    <article class="card">
      <div class="toolbar" style="margin:0"><h2 style="margin:0">Intune assignments</h2><span class="spacer"></span>${r.intune.length ? '<button id="impact-csv">Save CSV</button>' : ""}</div>
      ${r.intune.length ? `<div class="tablewrap" style="margin-top:8px"><table>
        <thead><tr><th>Name</th><th>Type</th><th>Target</th><th>Intent</th><th>Filter</th></tr></thead>
        <tbody>${r.intune.map((i) => `<tr><td>${link(i.link, i.policyName)}</td><td>${esc(i.typeLabel)}</td>
          <td>${i.kind === "exclude" ? '<span class="badge warn">Exclude</span>' : '<span class="badge">Include</span>'}</td>
          <td>${esc(i.intent || "")}</td><td>${i.filterId ? esc(i.filterType || "yes") : ""}</td></tr>`).join("")}</tbody>
      </table></div>` : '<p class="muted">No Intune policy, app, script or profile is assigned to this group.</p>'}
      ${section("Conditional Access", simpleList(r.conditionalAccess, (p) => `${esc(p.name)} <span class="muted">(${esc(p.mode)}, ${esc(p.state)})</span>`))}
      ${section("Enterprise apps", simpleList(r.appAssignments, esc))}
      ${section("Licences", simpleList(r.licenses, esc))}
      ${section("Intune role assignments", simpleList(r.roleAssignments, (x) => `${esc(x.name)} <span class="muted">(as ${esc(x.as)})</span>`))}
      ${section("Member of", simpleList(r.parents, (x) => esc(x.displayName)))}
      ${section("Contains groups", simpleList(r.children, (x) => esc(x.displayName)))}
    </article>`;
}

function impactRows(r) {
  return [
    ["Name", "Type", "Target", "Intent", "Filter type"],
    ...r.intune.map((i) => [i.policyName, i.typeLabel, i.kind, i.intent, i.filterType]),
  ];
}

// ------------------------------------------------------------------------------------------
// Group roster

let roster = null;

const rosterRun = newestOnly();

setupPicker("roster", async (g) => {
  const out = $("#roster-results");
  const current = rosterRun();
  $("#roster-tools").hidden = true;
  out.innerHTML = loading("Reading members...");
  try {
    const answer = (await send("group/roster", { groupId: g.id })).roster;
    if (!current()) return;
    roster = answer;
    $("#roster-tools").hidden = false;
    drawRoster();
  } catch (e) {
    if (current()) out.innerHTML = errorBox(e);
  }
});

function rosterView() {
  if (!roster) return [];
  const text = $("#roster-filter").value.trim().toLowerCase();
  const type = $("#roster-type").value;
  const stale = $("#roster-stale").checked ? Number($("#roster-days").value) || 30 : null;
  return roster.rows.filter((r) => {
    if (type && r.type !== type) return false;
    if (stale !== null) {
      // Devices by their own check-in; users by their most recent device. Users with no devices
      // and groups have nothing to be stale.
      if (r.type === "Group" || (r.type === "User" && !r.deviceCount)) return false;
      const d = ageDays(r.lastCheckIn);
      if (d !== null && d <= stale) return false;
    }
    if (text && !rosterHaystack(r).includes(text)) return false;
    return true;
  });
}

// The lowercased text the filter looks in, built once per row (not on every filter run).
const rosterTexts = new WeakMap();
function rosterHaystack(r) {
  let text = rosterTexts.get(r);
  if (text === undefined) {
    text = [r.type, r.name, r.upn, r.primaryUser, r.department, r.jobTitle, r.compliance, r.os, r.osVersion,
      ...(r.devices || []).map((d) => d.name)].filter(Boolean).join(" ").toLowerCase();
    rosterTexts.set(r, text);
  }
  return text;
}

// Rows with a check-in to show: Intune devices, and users by their most recent device.
const hasCheckIn = (r) => (r.type === "Device" && r.intune) || (r.type === "User" && r.deviceCount > 0);

// One definition per column, used by the table, Copy table and Save CSV.
const ROSTER_COLUMNS = [
  ["Type", (r) => r.type],
  ["Name", (r) => r.name],
  ["Primary user / UPN", (r) => (r.type === "Device" ? r.primaryUser : r.upn || "")],
  ["Devices", (r) => (r.type === "User" ? (r.devices || []).map((d) => d.name).join("; ") : "")],
  ["Compliance", (r) => (hasCheckIn(r) ? r.compliance || "" : "")],
  ["OS", (r) => (hasCheckIn(r) ? friendlyOs(r.os?.split(" ")[0], r.osVersion) : "")],
  ["Last check-in", (r) => (hasCheckIn(r) ? checkInText(r.lastCheckIn) : r.type === "Device" ? "not in Intune" : "")],
  ["Department", (r) => r.department || ""],
  ["Job title", (r) => r.jobTitle || ""],
];
const COL = Object.fromEntries(ROSTER_COLUMNS.map(([h, f]) => [h, f]));

function userDevicesCell(r) {
  if (r.type !== "User") return "";
  if (!r.deviceCount) return '<span class="muted">None</span>';
  const shown = r.devices.slice(0, 3).map((d) => `<span class="nowrap">${link(d.link, d.name)}</span>`).join(", ");
  return r.deviceCount > 3 ? `${shown} <span class="muted">+${r.deviceCount - 3} more</span>` : shown;
}

function drawRoster() {
  const rows = rosterView();
  $("#roster-count").textContent = `${rows.length} of ${roster.rows.length}`;
  if (!rows.length) { $("#roster-results").innerHTML = '<div class="empty">No members match.</div>'; return; }
  const hasUsers = rows.some((r) => r.type === "User");
  $("#roster-results").innerHTML = `<div class="tablewrap"><table>
    <thead><tr><th>Type</th><th>Name</th><th>Primary user / UPN</th>${hasUsers ? "<th>Devices</th>" : ""}<th>Compliance</th><th>OS</th><th>Last check-in</th></tr></thead>
    <tbody>${rows.slice(0, 2000).map((r) => {
      const sub = r.type === "User" ? [r.jobTitle, r.department].filter(Boolean).join(", ") : "";
      return `<tr>
      <td>${esc(r.type)}</td>
      <td>${r.link ? link(r.link, r.name) : esc(r.name)}${r.duplicates ? ` <span class="badge warn">${r.duplicates} Intune records</span>` : ""}${sub ? `<div class="muted small">${esc(sub)}</div>` : ""}</td>
      <td>${esc(COL["Primary user / UPN"](r))}${r.type === "User" && r.enabled === false ? ' <span class="badge">Disabled</span>' : ""}</td>
      ${hasUsers ? `<td>${userDevicesCell(r)}</td>` : ""}
      <td>${hasCheckIn(r) ? complianceBadge(r.compliance) : ""}</td>
      <td>${esc(COL.OS(r))}</td>
      <td>${hasCheckIn(r) ? checkInCell(r.lastCheckIn) : esc(COL["Last check-in"](r))}</td></tr>`;
    }).join("")}</tbody>
  </table></div>${rows.length > 2000 ? `<p class="muted">Showing the first 2,000 rows. Copy or save includes all ${rows.length}.</p>` : ""}`;
}

// The text filter runs on Enter or when cleared (a search box's "search" event), like the other searches;
// the dropdown, checkbox and day count apply at once.
$("#roster-filter").addEventListener("search", drawRoster);
["#roster-type", "#roster-stale", "#roster-days"].forEach((sel) => $(sel).addEventListener("input", drawRoster));

function rosterTable() {
  return [ROSTER_COLUMNS.map(([h]) => h).concat("Object ID"), ...rosterView().map((r) => ROSTER_COLUMNS.map(([, f]) => f(r)).concat(r.objectId))];
}
$("#roster-copy").addEventListener("click", (e) => copyTsv(e.currentTarget, rosterTable()));
$("#roster-csv").addEventListener("click", () => saveCsv(`group-roster-${roster?.group?.name || "group"}.csv`, rosterTable()));

function flash(btn, text) {
  const old = btn.textContent;
  btn.textContent = text;
  setTimeout(() => { btn.textContent = old; }, 1500);
}

function saveCsv(filename, rows) {
  const csv = rows.map((row) => row.map((c) => {
    const s = String(c ?? "");
    // Quote everything; neutralise leading =,+,-,@ so spreadsheets don't run it as a formula.
    const safe = /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
    return `"${safe.replace(/"/g, '""')}"`;
  }).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: filename.replace(/[\\/:*?"<>|]+/g, "_") });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

// ------------------------------------------------------------------------------------------
// ID decoder

$("#decode-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = $("#decode-input").value;
  const out = $("#decode-results");
  out.innerHTML = loading("Looking these up...");
  try {
    const res = await send("ids/decode", { text });
    if (!res.ids.length) { out.innerHTML = `<div class="empty">${esc(res.message)}</div>`; return; }
    out.innerHTML = res.ids.map((x) => `
      <article class="card">
        <h2 class="mono">${esc(x.guid)}</h2>
        ${x.hint ? `<div class="muted">The link labels this as: ${esc(x.hint)}</div>` : ""}
        ${x.matches.length ? `<div class="tablewrap" style="margin-top:8px"><table>
          <thead><tr><th>What it is</th><th>Name</th><th>Details</th></tr></thead>
          <tbody>${x.matches.map((m) => `<tr><td>${esc(m.kind)}</td><td>${link(m.link, m.name)}</td>
            <td>${esc(m.extra)}${m.assigned ? `<div class="small" style="margin-top:2px">${esc(m.assigned)}</div>` : ""}</td></tr>`).join("")}</tbody>
        </table></div>` : '<p class="muted">Not found as any object type this tool checks, or your role can\'t read it.</p>'}
      </article>`).join("") + (!res.policyIndexBuiltAt && res.ids.some((x) => x.matches.some((m) => /polic|profile|script|app|update|configuration|remediation/i.test(m.kind)))
      ? '<p class="muted">Tip: run a Setting check once (it reads your policies) and the decoder will also show who each policy is assigned to.</p>' : "");
  } catch (err) {
    out.innerHTML = errorBox(err);
  }
});

// ------------------------------------------------------------------------------------------
// Shared table helpers for the report tabs

/** headers: [label | { label, num }], rows: arrays of cell HTML (already escaped). */
function tableHtml(headers, rows, rowAttrs = () => "") {
  const th = headers.map((h) => (typeof h === "string" ? `<th>${esc(h)}</th>` : `<th class="${h.num ? "num" : ""}">${esc(h.label)}</th>`)).join("");
  return `<div class="tablewrap"><table><thead><tr>${th}</tr></thead><tbody>${rows.map((r, i) => `<tr ${rowAttrs(i)}>${r.join("")}</tr>`).join("")}</tbody></table></div>`;
}
const td = (html, cls = "") => `<td${cls ? ` class="${cls}"` : ""}>${html}</td>`;

async function copyTsv(btn, rows) {
  const tsv = rows.map((row) => row.map((c) => String(c ?? "").replace(/[\t\n]/g, " ")).join("\t")).join("\n");
  try {
    await navigator.clipboard.writeText(tsv);
    flash(btn, "Copied");
  } catch {
    flash(btn, "Copy failed");
  }
}

const ownerLabel = (o) => ({ company: "Corporate", personal: "Personal" }[o] || o || "");
const userOf = (d) => d.displayName || d.upn || "";

// ------------------------------------------------------------------------------------------
// Device list (shared by OS builds and Stale & duplicates), loaded once per visit

let devicesCache = null;
let devicesLoading = null;

function loadDevices(force = false) {
  if (devicesCache && !force) return Promise.resolve(devicesCache);
  if (!devicesLoading) {
    devicesLoading = send("devices/list")
      .then((res) => {
        // Links and the platform list are made here, once per list, not in the worker or on every redraw.
        for (const d of res.devices) d.link ||= deviceUrl(d.managedId);
        res.platforms = [...new Set(res.devices.map((d) => d.os || "Unknown OS"))].sort();
        devicesCache = res;
        return res;
      })
      .finally(() => { devicesLoading = null; });
  }
  return devicesLoading;
}

function renderDeviceIndexLine() {
  for (const el of $$(".device-index-line")) {
    el.innerHTML = devicesCache
      ? `Device list: ${devicesCache.devices.length.toLocaleString()} devices, updated ${esc(ago(devicesCache.builtAt))}. <button class="link" data-refresh-devices>Refresh</button>`
      : "";
  }
}

document.addEventListener("click", async (e) => {
  if (!e.target.closest?.("[data-refresh-devices]")) return;
  for (const el of $$(".device-index-line")) el.innerHTML = '<span class="spinner"></span>Reading devices...';
  try {
    if (!SAMPLE) await send("index/rebuild");
    await loadDevices(true);
    showDeviceTab(currentTab);
  } catch (err) {
    for (const el of $$(".device-index-line")) el.textContent = err.message;
  }
});

async function showDeviceTab(name) {
  const out = $(name === "os" ? "#os-results" : name === "storage" ? "#storage-results" : "#stale-results");
  if (!devicesCache) {
    out.innerHTML = loading("Reading your devices...");
    if (name === "hygiene") $("#dupe-results").innerHTML = "";
  }
  try {
    await loadDevices();
  } catch (err) {
    out.innerHTML = errorBox(err);
    return;
  }
  renderDeviceIndexLine();
  if (name === "os") renderOs();
  else if (name === "storage") renderStorage();
  else renderHygiene();
}

// ------------------------------------------------------------------------------------------
// OS builds

let spread = null;

function renderOs() {
  spread = osSpread(devicesCache.devices, globalThis.IEWindowsBuilds?.friendly);
  if (!spread.total) { $("#os-results").innerHTML = '<div class="empty">No managed devices.</div>'; return; }
  $("#os-results").innerHTML = spread.platforms.map((p, pi) => {
    const top = Math.max(...p.releases.map((r) => r.count));
    const rows = p.releases.flatMap((r, ri) => [
      [
        td(esc(r.label)),
        td(r.count.toLocaleString(), "num"),
        td(`${(r.count / p.count * 100).toFixed(r.count / p.count < 0.1 ? 1 : 0)}%`, "num"),
        td(`<div class="bar" title="${esc(`${r.count} of ${p.count} ${p.os} devices`)}"><span style="width:${(r.count / top * 100).toFixed(1)}%"></span></div>`),
        td(`<button class="link" data-os="${pi}:${ri}">Show devices</button>`),
      ],
      [`<td colspan="5" data-os-sub="${pi}:${ri}"></td>`],
    ]);
    return `<article class="card">
      <h2>${esc(p.os)} <span class="muted">· ${p.count.toLocaleString()} device${p.count === 1 ? "" : "s"} (${(p.count / spread.total * 100).toFixed(0)}% of all)</span></h2>
      ${tableHtml(["Release", { label: "Devices", num: true }, { label: "Share", num: true }, "", ""], rows, (i) => (i % 2 ? 'class="sub" hidden' : ""))}
    </article>`;
  }).join("");
}

$("#os-results").addEventListener("click", (e) => {
  const btn = e.target.closest("button[data-os]");
  if (btn) {
    const cell = $(`[data-os-sub="${btn.dataset.os}"]`);
    const row = cell.parentElement;
    const open = row.hidden;
    row.hidden = !open;
    btn.textContent = open ? "Hide devices" : "Show devices";
    if (open && !cell.innerHTML) {
      const [pi, ri] = btn.dataset.os.split(":").map(Number);
      const rel = spread.platforms[pi].releases[ri];
      const list = [...rel.devices].sort((a, b) => a.name.localeCompare(b.name));
      cell.innerHTML = `<div class="toolbar" style="margin:8px 10px">
          <strong>${esc(rel.label)}</strong><span class="spacer"></span>
          <button data-os-copy="${btn.dataset.os}">Copy table</button><button data-os-csv="${btn.dataset.os}">Save CSV</button></div>` +
        tableHtml(["Device", "Primary user", "OS version", "Compliance", "Last check-in"], list.slice(0, 1000).map((d) => [
          td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
          td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)),
        ])) + (list.length > 1000 ? `<p class="muted small" style="margin:6px 10px">Showing 1,000 of ${list.length}. Copy or save includes all.</p>` : "");
    }
    return;
  }
  const exp = e.target.closest("button[data-os-copy], button[data-os-csv]");
  if (!exp) return;
  const [pi, ri] = (exp.dataset.osCopy || exp.dataset.osCsv).split(":").map(Number);
  const rel = spread.platforms[pi].releases[ri];
  const rows = [["Device", "Primary user", "UPN", "OS", "OS version", "Release", "Compliance", "Last check-in"],
    ...rel.devices.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, rel.label, d.compliance, d.lastSync])];
  if (exp.dataset.osCopy) copyTsv(exp, rows);
  else saveCsv(`os-build-${rel.label}.csv`, rows);
});

// ------------------------------------------------------------------------------------------
// Compliance breakdown

let compData = null;
let compDevices = null;
let compRun = 0;

function renderCompliance(r) {
  if (!r.rows.length) return `<div class="empty">No compliance setting is failing on any device${r.passing ? ` (${r.passing.toLocaleString()} settings checked)` : ""}.</div>`;
  return `<article class="card">
    <div class="toolbar" style="margin:0 0 8px">
      <span class="muted">${r.rows.length.toLocaleString()} failing setting${r.rows.length === 1 ? "" : "s"}; ${r.passing.toLocaleString()} with no failures</span>
      <span class="spacer"></span>
      <button id="comp-copy">Copy table</button>
      <button id="comp-csv">Save CSV</button>
    </div>` +
    tableHtml(["Setting", "Platform", { label: "Failing", num: true }, { label: "Not compliant", num: true }, { label: "Error", num: true }, { label: "Conflict", num: true }, { label: "Compliant", num: true }, ""],
      r.rows.map((x) => [td(esc(x.setting)), td(esc(x.platform)), td(`<strong>${x.failing.toLocaleString()}</strong>`, "num"), td(x.nonCompliant.toLocaleString(), "num"),
        td(x.error.toLocaleString(), "num"), td(x.conflict.toLocaleString(), "num"), td(x.compliant.toLocaleString(), "num"),
        td(`<button class="link" data-comp="${esc(x.id)}" data-name="${esc(x.setting)}">Devices</button>`)])) + "</article>";
}

function compRows() {
  return [["Setting", "Platform", "Failing", "Not compliant", "Error", "Conflict", "Compliant"],
    ...(compData?.rows || []).map((x) => [x.setting, x.platform, x.failing, x.nonCompliant, x.error, x.conflict, x.compliant])];
}

function compDeviceRows() {
  return [["Device", "User", "State", "OS", "Last check-in"], ...(compDevices?.list || []).map((d) => [d.name, d.user, d.state, d.os, d.lastSync])];
}

function renderCompDevices(name, list) {
  return `<article class="card">
    <div class="toolbar" style="margin:0 0 8px">
      <h2 style="margin:0">${esc(name)}: ${list.length.toLocaleString()} failing device${list.length === 1 ? "" : "s"}</h2>
      <span class="spacer"></span>
      <button id="compdev-copy">Copy table</button>
      <button id="compdev-csv">Save CSV</button>
    </div>` + (list.length
      ? tableHtml(["Device", "User", "State", "OS", "Last check-in"], list.slice(0, 2000).map((d) => [td(d.inList ? link(d.link, d.name) : esc(d.name), "nowrap"), td(esc(d.user)), td(esc(d.state)), td(esc(d.os)), td(d.lastSync ? checkInCell(d.lastSync) : '<span class="muted">unknown</span>')]))
      : '<p class="muted">No device is failing this setting now.</p>') + "</article>";
}

$("#comp-run").addEventListener("click", async () => {
  const run = ++compRun;
  const out = $("#comp-results");
  $("#comp-devices").innerHTML = "";
  out.innerHTML = loading("Reading compliance results...");
  try {
    const r = await send("compliance/summary");
    if (run !== compRun) return;
    compData = r;
    out.innerHTML = renderCompliance(r);
  } catch (err) {
    if (run === compRun) out.innerHTML = errorBox(err);
  }
});
$("#comp-results").addEventListener("click", async (e) => {
  const pick = e.target.closest("button[data-comp]");
  if (pick) {
    const run = ++compRun;
    const out = $("#comp-devices");
    out.innerHTML = loading("Reading the devices failing this setting...");
    try {
      const { devices } = await send("compliance/devices", { id: pick.dataset.comp });
      if (run !== compRun) return;
      compDevices = { list: devices };
      out.innerHTML = renderCompDevices(pick.dataset.name, devices);
      out.scrollIntoView({ behavior: "smooth", block: "nearest" });
    } catch (err) {
      if (run === compRun) out.innerHTML = errorBox(err);
    }
    return;
  }
  if (e.target.closest("#comp-copy")) copyTsv(e.target, compRows());
  if (e.target.closest("#comp-csv")) saveCsv("compliance-breakdown.csv", compRows());
});
$("#comp-devices").addEventListener("click", (e) => {
  if (e.target.closest("#compdev-copy")) copyTsv(e.target, compDeviceRows());
  if (e.target.closest("#compdev-csv")) saveCsv("compliance-failing-devices.csv", compDeviceRows());
});

// Hardware report


const HW_CHUNK = 100; // devices per request to the worker, so progress and Stop respond between chunks
const HW_SHOWN = 1000;
let hwData = null; // { at, rows } as saved
let hwSort = { key: "name", dir: 1 };
let hwStop = false;
let hwRunning = false;

function hwSorted(rows) {
  const col = hardwareColumns(rows).find((c) => c.key === hwSort.key);
  return [...rows].sort((a, b) => {
    const x = a[hwSort.key];
    const y = b[hwSort.key];
    if (x === "" || x === undefined) return y === "" || y === undefined ? 0 : 1; // empty last, whichever way
    if (y === "" || y === undefined) return -1;
    return (col?.num ? x - y : String(x).localeCompare(String(y), undefined, { numeric: true })) * hwSort.dir;
  });
}

function renderHardware() {
  const out = $("#hw-results");
  if (!hwData?.rows.length) { out.innerHTML = '<div class="empty">Nothing read yet.</div>'; return; }
  const cols = hardwareColumns(hwData.rows);
  const sorted = hwSorted(hwData.rows);
  const head = cols.map((c) => `<th data-hw-sort="${esc(c.key)}" class="${c.num ? "num " : ""}sortable" aria-sort="${hwSort.key === c.key ? (hwSort.dir > 0 ? "ascending" : "descending") : "none"}">${esc(c.label)}${hwSort.key === c.key ? (hwSort.dir > 0 ? " ▲" : " ▼") : ""}</th>`).join("");
  const body = sorted.slice(0, HW_SHOWN).map((r) => `<tr>${cols.map((c) => td(esc(r[c.key] ?? ""), c.num ? "num" : "")).join("")}</tr>`).join("");
  out.innerHTML = `<article class="card">
    <div class="toolbar" style="margin:0 0 8px">
      <span class="muted">${hwData.rows.length.toLocaleString()} devices, read ${esc(ago(hwData.at))}. Click a heading to sort.</span>
      <span class="spacer"></span>
      <button id="hw-copy">Copy table</button>
      <button id="hw-csv">Save CSV</button>
    </div>
    <div class="tablewrap"><table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table></div>
    ${sorted.length > HW_SHOWN ? `<p class="muted small">Showing the first ${HW_SHOWN.toLocaleString()}. Copy and Save CSV include all ${sorted.length.toLocaleString()}.</p>` : ""}
  </article>`;
}

function hwTableRows() {
  const cols = hardwareColumns(hwData?.rows || []);
  return [cols.map((c) => c.label), ...hwSorted(hwData?.rows || []).map((r) => cols.map((c) => r[c.key] ?? ""))];
}

async function runHardware() {
  if (hwRunning) return;
  hwRunning = true;
  hwStop = false;
  const out = $("#hw-results");
  $("#hw-run").disabled = true;
  out.innerHTML = loading("Reading your devices...");
  const rows = [];
  let failed = 0;
  try {
    await loadDevices();
    const ids = [...new Set(devicesCache.devices.map((d) => d.managedId).filter(Boolean))];
    for (let i = 0; i < ids.length && !hwStop; i += HW_CHUNK) {
      jobBar.set("hardware", { label: "Reading hardware", done: i, total: ids.length, stop: () => { hwStop = true; } });
      out.innerHTML = loading("Reading hardware for every device. Stop keeps what is read so far.");
      const res = await send("hardware/read", { ids: ids.slice(i, i + HW_CHUNK) });
      rows.push(...res.rows);
      failed += res.failed;
    }
    hwData = { at: Date.now(), rows };
    await send("hardware/save", { rows });
    jobBar.done("hardware", hwStop ? `Stopped. Kept ${rows.length.toLocaleString()} of ${ids.length.toLocaleString()} devices.` : "");
    renderHardware();
    if (failed) out.insertAdjacentHTML("afterbegin", `<p class="muted small">${failed.toLocaleString()} devices couldn't be read and are left out.</p>`);
    if (hwStop) out.insertAdjacentHTML("afterbegin", '<p class="muted small">Stopped early: this is a partial list.</p>');
  } catch (err) {
    out.innerHTML = errorBox(err);
  } finally {
    hwRunning = false;
    jobBar.done("hardware");
    $("#hw-run").disabled = false;
  }
}

async function loadSavedHardware() {
  try {
    const { saved } = await send("hardware/load");
    if (saved && !hwRunning) { hwData = saved; renderHardware(); }
  } catch { /* nothing saved, or no session yet: the button still works */ }
}

$("#hw-run").addEventListener("click", runHardware);
$("#job-stop").addEventListener("click", () => jobBar.stop());
$("#hw-results").addEventListener("click", (e) => {
  const th = e.target.closest("th[data-hw-sort]");
  if (th) {
    hwSort = { key: th.dataset.hwSort, dir: hwSort.key === th.dataset.hwSort ? -hwSort.dir : 1 };
    renderHardware();
    return;
  }
  if (e.target.closest("#hw-copy")) copyTsv(e.target, hwTableRows());
  if (e.target.closest("#hw-csv")) saveCsv("hardware.csv", hwTableRows());
});

// Duplicate policies

let dupPolReport = null;
let dupPolRun = 0;
const DUP_POL_MATCH = { identical: ["bad", "Identical"], inside: ["warn", "One is inside the other"], partial: ["", "Partly the same"] };

function renderDupPolicies(r) {
  if (!r.pairs.length) return '<div class="empty">No two policies set the same values.</div>';
  return `<article class="card">
    <div class="toolbar" style="margin:0 0 8px">
      <span class="muted">${r.total.toLocaleString()} pair${r.total === 1 ? "" : "s"}${r.total > r.pairs.length ? `, showing the first ${r.pairs.length}` : ""}</span>
      <span class="spacer"></span>
      <button id="dupes-copy">Copy table</button>
      <button id="dupes-csv">Save CSV</button>
    </div>` +
    tableHtml(["Policy", "Other policy", "Same settings", "Match", "Same assignments", "Examples"], r.pairs.map((p) => [
      td(link(p.a.link, p.a.name) + `<div class="muted small">${esc(p.a.typeLabel)}</div>`), td(link(p.b.link, p.b.name) + `<div class="muted small">${esc(p.b.typeLabel)}</div>`),
      td(`${p.shared} of ${p.sizeA} and ${p.sizeB}`, "nowrap"), td(`<span class="badge ${DUP_POL_MATCH[p.match][0]}">${DUP_POL_MATCH[p.match][1]}</span>`),
      td(p.sameAssignments ? "Yes" : "No"), td(esc(p.sample.join("; ")), "small")])) + "</article>";
}

function dupPolRows() {
  return [["Policy", "Type", "Other policy", "Other type", "Same settings", "Settings in first", "Settings in second", "Match", "Same assignments", "Examples"],
    ...(dupPolReport?.pairs || []).map((p) => [p.a.name, p.a.typeLabel, p.b.name, p.b.typeLabel, p.shared, p.sizeA, p.sizeB, DUP_POL_MATCH[p.match][1], p.sameAssignments ? "Yes" : "No", p.sample.join("; ")])];
}

$("#dupes-run").addEventListener("click", async () => {
  const run = ++dupPolRun;
  const out = $("#dupes-results");
  out.innerHTML = loading("Comparing every policy. The first time, the policy index can take a few minutes to build...");
  try {
    const r = await send("policies/duplicates");
    if (run !== dupPolRun) return;
    dupPolReport = r;
    out.innerHTML = renderDupPolicies(r);
  } catch (err) {
    if (run === dupPolRun) out.innerHTML = errorBox(err);
  }
});
$("#dupes-results").addEventListener("click", (e) => {
  if (e.target.closest("#dupes-copy")) copyTsv(e.target, dupPolRows());
  if (e.target.closest("#dupes-csv")) saveCsv("duplicate-policies.csv", dupPolRows());
});

// Policy export

let polDoc = null;
let polRun = 0;

async function findPolicy() {
  const q = $("#polexp-query").value.trim();
  if (!q) return;
  const run = ++polRun;
  const out = $("#polexp-results");
  out.innerHTML = loading("Searching the policy index. The first time, it can take a few minutes to build...");
  try {
    const { policies, total } = await send("policy/find", { query: q });
    if (run !== polRun) return;
    if (policies.length === 1) { openPolicy(policies[0].id); return; }
    out.innerHTML = policies.length
      ? `<article class="card"><p class="muted">${total.toLocaleString()} policies match. Pick one.</p>` +
        tableHtml(["Policy", "Type"], policies.map((p) => [td(`<button class="link" data-pol="${esc(p.id)}">${esc(p.name)}</button>`, "nowrap"), td(esc(p.typeLabel))])) +
        (total > policies.length ? `<p class="muted small">Showing the first ${policies.length}. Type more of the name.</p>` : "") + "</article>"
      : '<div class="empty">No policy has that in its name.</div>';
  } catch (err) {
    if (run === polRun) out.innerHTML = errorBox(err);
  }
}

async function openPolicy(id) {
  const run = ++polRun;
  const out = $("#polexp-results");
  out.innerHTML = loading("Reading the policy...");
  try {
    const { policy, names, filters } = await send("policy/get", { id });
    if (run !== polRun) return;
    polDoc = policyDocument(policy, names, filters);
    out.innerHTML = `<article class="card">
      <div class="toolbar" style="margin:0 0 8px">
        <h2 style="margin:0">${link(policy.link, polDoc.title)}</h2>
        <span class="spacer"></span>
        <button id="polexp-md">Copy Markdown</button>
        <button id="polexp-copy">Copy table</button>
        <button id="polexp-csv">Save CSV</button>
      </div>
      ${polDoc.hasSettings ? "" : '<p class="muted small">This type of policy has no settings in the index.</p>'}
      <pre class="path" style="white-space:pre-wrap">${esc(polDoc.markdown)}</pre>
    </article>`;
  } catch (err) {
    if (run === polRun) out.innerHTML = errorBox(err);
  }
}

$("#polexp-find").addEventListener("click", findPolicy);
$("#polexp-query").addEventListener("keydown", (e) => { if (e.key === "Enter") findPolicy(); });
$("#polexp-results").addEventListener("click", async (e) => {
  const pick = e.target.closest("button[data-pol]");
  if (pick) { openPolicy(pick.dataset.pol); return; }
  if (!polDoc) return;
  if (e.target.closest("#polexp-copy")) copyTsv(e.target, polDoc.rows);
  if (e.target.closest("#polexp-csv")) saveCsv(`policy-${polDoc.title.replace(/[^\w.-]+/g, "-")}.csv`, polDoc.rows);
  if (e.target.closest("#polexp-md")) {
    const btn = e.target.closest("#polexp-md");
    try { await navigator.clipboard.writeText(polDoc.markdown); flash(btn, "Copied"); } catch { flash(btn, "Copy failed"); }
  }
});

// Compare devices

const cmpDevPicked = {};
let cmpDevReport = null;
let cmpDevRun = 0;
const CMP_DEV_STATE = { applies: "Applies", filter: "Depends on filter", uncertain: "Uncertain", excluded: "Excluded" };

for (const side of ["cmpda", "cmpdb"]) {
  setupPicker(side, (d) => { cmpDevPicked[side] = d; $("#cmpdevices-run").disabled = !(cmpDevPicked.cmpda && cmpDevPicked.cmpdb); });
}

function renderCompareDevices(r) {
  const a = r.a.name;
  const b = r.b.name;
  const how = (g) => (g.direct ? "direct" : `nested${g.via ? `, via ${g.via}` : ""}`);
  const groupCards = (title, g) => {
    if (g.unreadable) return `<article class="card"><h2>${esc(title)}</h2><p class="muted">Couldn't be read for one of the devices, so nothing is compared.</p></article>`;
    const list = (groups, none, text) => (groups.length ? `<ul>${groups.map((x) => `<li>${link(x.link, x.name)} <span class="muted">${esc(text(x))}</span></li>`).join("")}</ul>` : `<p class="muted">${esc(none)}</p>`);
    return `<article class="card"><h2>${esc(title)}</h2>
      <h3>In both (${g.both.length})</h3>${list(g.both, "None in common.", (x) => `${a}: ${how(x)}; ${b}: ${how(x.other)}`)}
      <h3>Only ${esc(a)} (${g.onlyA.length})</h3>${list(g.onlyA, "None.", how)}
      <h3>Only ${esc(b)} (${g.onlyB.length})</h3>${list(g.onlyB, "None.", how)}</article>`;
  };
  const p = r.policies;
  const state = (s) => esc(CMP_DEV_STATE[s] || "");
  const notAssigned = '<span class="muted">not assigned</span>';
  const polTable = (title, list, headers, cols) => `<h3>${esc(title)} (${list.length})</h3>` + (list.length
    ? tableHtml(headers, list.map((x) => [td(link(x.link, x.name)), td(esc(x.typeLabel)), ...cols(x)])) : '<p class="muted">None.</p>');
  const notes = r.notes.length ? `<article class="card"><h2>Not everything could be checked</h2><ul>${r.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul></article>` : "";
  const unknown = '<span class="muted">unknown</span>';
  return `${notes}
    <article class="card"><h2>Details</h2>${tableHtml(["", a, b], r.facts.map((f) => [td(esc(f.label)), td(esc(f.a) || unknown, f.differs ? "differs" : ""), td(esc(f.b) || unknown, f.differs ? "differs" : "")]))}</article>
    ${groupCards("Device groups", r.deviceGroups)}
    ${groupCards("Primary users' groups", r.userGroups)}
    <article class="card">
      <div class="toolbar" style="margin:0 0 8px"><h2 style="margin:0">Policies, apps and scripts</h2><span class="spacer"></span>
        <button id="cmpdevices-copy">Copy table</button><button id="cmpdevices-csv">Save CSV</button></div>
      ${polTable("Reach both", p.both, ["Name", "Type", a, b], (x) => [td(state(x.stateA)), td(state(x.stateB))])}
      ${polTable(`Only ${a}`, p.onlyA, ["Name", "Type", "State", `On ${b}`], (x) => [td(state(x.state)), td(x.otherState ? state(x.otherState) : notAssigned)])}
      ${polTable(`Only ${b}`, p.onlyB, ["Name", "Type", "State", `On ${a}`], (x) => [td(state(x.state)), td(x.otherState ? state(x.otherState) : notAssigned)])}
      ${r.otherPlatform.a || r.otherPlatform.b ? `<p class="muted small">Policies for other platforms are left out: ${r.otherPlatform.a} for ${esc(a)}, ${r.otherPlatform.b} for ${esc(b)}.</p>` : ""}
    </article>`;
}

function cmpDevRows() {
  const r = cmpDevReport;
  if (!r) return [];
  const g = (title, s) => (s.unreadable ? [[title, "Couldn't be read", "", ""]]
    : [...s.both.map((x) => [title, x.name, "Both", ""]), ...s.onlyA.map((x) => [title, x.name, `Only ${r.a.name}`, ""]), ...s.onlyB.map((x) => [title, x.name, `Only ${r.b.name}`, ""])]);
  const pol = r.policies;
  return [["Section", "Item", r.a.name, r.b.name],
    ...r.facts.map((f) => ["Details", f.label, f.a, f.b]),
    ...g("Device group", r.deviceGroups), ...g("User group", r.userGroups),
    ...pol.both.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.stateA], CMP_DEV_STATE[x.stateB]]),
    ...pol.onlyA.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.state], CMP_DEV_STATE[x.otherState] || "Not assigned"]),
    ...pol.onlyB.map((x) => ["Policy", x.name, CMP_DEV_STATE[x.otherState] || "Not assigned", CMP_DEV_STATE[x.state]])];
}

$("#cmpdevices-run").addEventListener("click", async () => {
  const run = ++cmpDevRun;
  const out = $("#cmpdevices-results");
  if (cmpDevPicked.cmpda.id === cmpDevPicked.cmpdb.id) {
    out.innerHTML = '<div class="empty">Both sides are the same device. Pick two different devices to compare.</div>';
    return;
  }
  out.innerHTML = loading("Reading both devices' groups and policies. The first time, the policy index can take a few minutes...");
  try {
    const r = await send("devices/compare", { a: cmpDevPicked.cmpda.id, b: cmpDevPicked.cmpdb.id });
    if (run !== cmpDevRun) return;
    cmpDevReport = r;
    out.innerHTML = renderCompareDevices(r);
  } catch (err) {
    if (run === cmpDevRun) out.innerHTML = errorBox(err);
  }
});
$("#cmpdevices-results").addEventListener("click", (e) => {
  if (e.target.closest("#cmpdevices-copy")) copyTsv(e.target, cmpDevRows());
  if (e.target.closest("#cmpdevices-csv")) saveCsv(`compare-${cmpDevPicked.cmpda?.displayName}-${cmpDevPicked.cmpdb?.displayName}.csv`, cmpDevRows());
});

// Compare users

const cmpPicked = {};
let cmpReport = null;
let cmpRun = 0;

for (const side of ["cmpa", "cmpb"]) {
  setupPicker(side, (u) => { cmpPicked[side] = u; $("#cmpusers-run").disabled = !(cmpPicked.cmpa && cmpPicked.cmpb); });
}

const userLabel = (u) => (u?.userPrincipalName ? `${u.displayName} (${u.userPrincipalName})` : u?.displayName || "");

function renderCompare(r) {
  const a = userLabel(cmpPicked.cmpa);
  const b = userLabel(cmpPicked.cmpb);
  // Short names inside the lists, unless the two share a name (the same person under two domains).
  const sameName = cmpPicked.cmpa.displayName === cmpPicked.cmpb.displayName;
  const shortA = sameName ? cmpPicked.cmpa.userPrincipalName : cmpPicked.cmpa.displayName;
  const shortB = sameName ? cmpPicked.cmpb.userPrincipalName : cmpPicked.cmpb.displayName;
  const warnings = [r.unreadable.a && a, r.unreadable.b && b].filter(Boolean).map((n) => `${n}'s groups couldn't be read.`);
  if (r.unreadable.a || r.unreadable.b) return `<div class="empty">${esc(warnings.join(" "))} Nothing is compared, so it isn't guessed.</div>`;
  const how = (g) => (g.direct ? "direct" : `nested${g.via ? `, via ${g.via}` : ""}`);
  const card = (title, groups, none, extra = () => "") => `<article class="card"><h2>${esc(title)} (${groups.length})</h2>${groups.length
    ? `<ul>${groups.map((g) => `<li>${link(g.link, g.name)} <span class="muted">${esc(extra(g) || how(g))}</span></li>`).join("")}</ul>`
    : `<p class="muted">${esc(none)}</p>`}</article>`;
  return card("In both", r.both, "No group in common.", (g) => `${shortA}: ${how(g)}; ${shortB}: ${how(g.other)}`) +
    card(`Only ${a}`, r.onlyA, `Everything ${a} is in, ${b} is in too.`) +
    card(`Only ${b}`, r.onlyB, `Everything ${b} is in, ${a} is in too.`) +
    '<div class="toolbar"><button id="cmpusers-copy">Copy table</button><button id="cmpusers-csv">Save CSV</button></div>';
}

function cmpRows() {
  const a = userLabel(cmpPicked.cmpa) || "A";
  const b = userLabel(cmpPicked.cmpb) || "B";
  const r = cmpReport;
  return [["Group", "Result"], ...(r ? [
    ...r.both.map((g) => [g.name, "Both"]), ...r.onlyA.map((g) => [g.name, `Only ${a}`]), ...r.onlyB.map((g) => [g.name, `Only ${b}`])] : [])];
}

$("#cmpusers-run").addEventListener("click", async () => {
  const run = ++cmpRun;
  const out = $("#cmpusers-results");
  if (cmpPicked.cmpa.id === cmpPicked.cmpb.id) {
    out.innerHTML = '<div class="empty">Both sides are the same user. Pick two different users to compare.</div>';
    return;
  }
  out.innerHTML = loading("Reading both users' groups...");
  try {
    const r = await send("users/compare", { a: cmpPicked.cmpa.id, b: cmpPicked.cmpb.id });
    if (run !== cmpRun) return;
    cmpReport = r;
    out.innerHTML = renderCompare(r);
  } catch (err) {
    if (run === cmpRun) out.innerHTML = errorBox(err);
  }
});
$("#cmpusers-results").addEventListener("click", (e) => {
  if (e.target.closest("#cmpusers-copy")) copyTsv(e.target, cmpRows());
  if (e.target.closest("#cmpusers-csv")) saveCsv(`compare-${cmpPicked.cmpa?.displayName}-${cmpPicked.cmpb?.displayName}.csv`, cmpRows());
});

// Device 360

let d360Report = null;
let d360Run = 0; // only the latest search may draw
const D360_BADGE = {
  applies: ["ok", "Applies"], filter: ["warn", "Depends on filter"],
  uncertain: ["warn", "Uncertain"], excluded: ["", "Excluded"],
};

async function findD360() {
  const q = $("#d360-query").value.trim().toLowerCase();
  if (!q) return;
  const run = ++d360Run;
  const out = $("#d360-results");
  out.innerHTML = loading("Reading your devices...");
  try {
    await loadDevices();
  } catch (err) {
    if (run === d360Run) out.innerHTML = errorBox(err);
    return;
  }
  if (run !== d360Run) return;
  const hits = devicesCache.devices.filter((d) => [d.name, d.upn, d.displayName].some((s) => String(s || "").toLowerCase().includes(q))).sort((x, y) => x.name.localeCompare(y.name));
  if (hits.length === 1) { runD360(hits[0].managedId); return; }
  out.innerHTML = hits.length
    ? `<article class="card"><p class="muted">${hits.length.toLocaleString()} devices match. Pick one.</p>` +
      tableHtml(["Device", "Primary user", "OS", "Last check-in"], hits.slice(0, 50).map((d) => [
        td(`<button class="link" data-d360="${esc(d.managedId)}">${esc(d.name)}</button>`, "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)),
      ])) + (hits.length > 50 ? '<p class="muted small">Showing the first 50. Search for more of the name.</p>' : "") + "</article>"
    : '<div class="empty">No device matches that name or primary user.</div>';
}

async function runD360(managedId) {
  const run = ++d360Run;
  const out = $("#d360-results");
  out.innerHTML = loading("Reading groups and policies. The first time, the policy index can take a few minutes...");
  try {
    const { report } = await send("device/360", { managedId });
    if (run !== d360Run) return;
    d360Report = report;
    out.innerHTML = renderD360(report);
  } catch (err) {
    if (run === d360Run) out.innerHTML = errorBox(err);
  }
}

function renderD360(r) {
  const d = r.device;
  const badge = (state) => `<span class="badge ${D360_BADGE[state][0]}">${D360_BADGE[state][1]}</span>`;
  const filterText = (f) => `${f.mode === "exclude" ? "Unless" : "Only if"} filter "${f.name}" matches`;
  const whyCell = (row) => [...row.why.map((w) => esc(w)),
    ...row.filters.map((f) => `<span title="${esc(f.rule)}">${esc(filterText(f))}</span>`),
    ...(row.platformUnknown ? ['<span class="muted">Platform not known, may not apply to this device</span>'] : [])].join("<br>");
  const groupsCard = (title, groups, none) => `<article class="card"><h2>${esc(title)}</h2>${groups === null ? '<p class="muted">Couldn\'t be read.</p>'
    : groups.length ? `<ul>${groups.map((g) => `<li>${link(g.link, g.name)}${g.direct ? "" : ` <span class="muted">nested${g.via ? `, via ${esc(g.via)}` : ""}</span>`}</li>`).join("")}</ul>`
      : `<p class="muted">${esc(none)}</p>`}</article>`;
  const warnings = [...r.notes,
    ...(r.unreadable ? [`${r.unreadable} policies' assignments couldn't be read, so they aren't checked.`] : []),
    ...(r.indexErrors.length ? [`The policy index couldn't read: ${r.indexErrors.join(", ")}. Those aren't checked.`] : [])];
  const { applies, filter, uncertain, excluded } = r.counts;
  return `
    <article class="card">
      <h2>${link(d.link, d.name)}</h2>
      <div class="facts">
        <div><span>Primary user</span>${esc(userOf(d) || "None")}</div>
        <div><span>OS</span>${esc(friendlyOs(d.os, d.osVersion))}</div>
        <div><span>Compliance</span>${complianceBadge(d.compliance)}</div>
        <div><span>Last check-in</span>${checkInCell(d.lastSync)}</div>
      </div>
    </article>
    ${warnings.length ? `<article class="card"><h2>Not everything could be checked</h2><ul>${warnings.map((w) => `<li>${esc(w)}</li>`).join("")}</ul></article>` : ""}
    <article class="card">
      <div class="toolbar" style="margin:0 0 8px">
        <h2 style="margin:0">What reaches this device</h2>
        <span class="muted">${applies} apply, ${filter} depend on a filter, ${uncertain} uncertain, ${excluded} excluded</span>
        <span class="spacer"></span>
        <button id="d360-copy">Copy table</button>
        <button id="d360-csv">Save CSV</button>
      </div>
      ${r.rows.length ? tableHtml(["Name", "Type", "Result", "Why", "Intent"], r.rows.map((row) => [
    td(link(row.link, row.name)), td(esc(row.typeLabel)), td(badge(row.state)), td(whyCell(row)), td(esc(row.intents.join(", "))),
  ])) : '<div class="empty">Nothing in the policy index reaches this device.</div>'}
      <p class="muted small">User targeting is worked out for the primary user; it really follows whoever signs in. Filters aren't evaluated, so those rows say which filter decides.${r.otherPlatform ? ` ${r.otherPlatform} assigned to other platforms left out.` : ""} Policy index from ${esc(ago(r.policyIndexBuiltAt))}.</p>
    </article>
    ${groupsCard("Device groups", r.deviceGroups, "This device isn't in any group.")}
    ${r.hasUser ? groupsCard("Primary user's groups", r.userGroups, "The primary user isn't in any group.") : ""}`;
}

function d360Rows() {
  return [["Name", "Type", "Result", "Why", "Filter", "Intent"],
    ...(d360Report?.rows || []).map((row) => [row.name, row.typeLabel, D360_BADGE[row.state][1], row.why.join("; "),
      row.filters.map((f) => `${f.mode} ${f.name}`).join("; "), row.intents.join(", ")])];
}

$("#d360-find").addEventListener("click", findD360);
$("#d360-query").addEventListener("keydown", (e) => { if (e.key === "Enter") findD360(); });
$("#d360-results").addEventListener("click", (e) => {
  const pick = e.target.closest("button[data-d360]");
  if (pick) { runD360(pick.dataset.d360); return; }
  if (e.target.closest("#d360-copy")) copyTsv(e.target, d360Rows());
  if (e.target.closest("#d360-csv")) saveCsv(`device-360-${d360Report?.device.name || "device"}.csv`, d360Rows());
});

// ------------------------------------------------------------------------------------------
// Tenant health

let health = null; // last answer: { rows }
const HEALTH_BADGE = {
  expired: ["bad", "Expired"], soon: ["warn", "Expires soon"], attention: ["warn", "Needs a look"],
  ok: ["ok", "OK"], none: ["", "Not set up"], error: ["bad", "Couldn't check"],
};

async function runHealth() {
  $("#health-results").innerHTML = loading("Checking tokens, certificates and connectors...");
  $("#health-count").textContent = "";
  try {
    health = await send("tenant/health");
  } catch (err) {
    health = null;
    $("#health-results").innerHTML = errorBox(err);
    return;
  }
  const worried = health.rows.filter((r) => r.status === "expired" || r.status === "soon").length;
  $("#health-count").textContent = worried ? `${worried} need action` : "Nothing expiring soon";
  $("#health-results").innerHTML = tableHtml(["Area", "Name", "Status", "Expires", { label: "Days left", num: true }, "Detail"], health.rows.map((r) => [
    td(esc(r.area), "nowrap"), td(esc(r.name)), td(`<span class="badge ${HEALTH_BADGE[r.status][0]}">${HEALTH_BADGE[r.status][1]}</span>`),
    td(r.expires ? esc(new Date(r.expires).toLocaleDateString()) : ""), td(r.daysLeft === null ? "" : String(r.daysLeft), "num"), td(esc(r.detail)),
  ]));
}

function healthRowsOut() {
  return [["Area", "Name", "Status", "Expires", "Days left", "Detail"],
    ...(health?.rows || []).map((r) => [r.area, r.name, HEALTH_BADGE[r.status][1], r.expires, r.daysLeft ?? "", r.detail])];
}

$("#health-run").addEventListener("click", runHealth);
$("#health-copy").addEventListener("click", (e) => copyTsv(e.currentTarget, healthRowsOut()));
$("#health-csv").addEventListener("click", () => saveCsv("tenant-health.csv", healthRowsOut()));

// ------------------------------------------------------------------------------------------
// Orphaned users

let orphans = null; // last answer: { devices, unknown, checked }

async function runOrphans() {
  $("#orphans-results").innerHTML = loading("Checking each primary user...");
  $("#orphans-count").textContent = "";
  try {
    orphans = await send("devices/orphaned");
  } catch (err) {
    orphans = null;
    $("#orphans-results").innerHTML = errorBox(err);
    return;
  }
  const { devices, unknown, checked } = orphans;
  $("#orphans-count").textContent = `${devices.length.toLocaleString()} devices, from ${checked.toLocaleString()} users checked`
    + (unknown ? `, ${unknown.toLocaleString()} devices couldn't be checked` : "");
  $("#orphans-results").innerHTML = devices.length
    ? tableHtml(["Device", "Primary user", "User", "OS", "Last check-in", "Ownership"], devices.slice(0, 2000).map((d) => [
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))),
      td(d.userState === "deleted" ? '<span class="badge bad">Deleted</span>' : '<span class="badge warn">Disabled</span>'),
      td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ])) + (devices.length > 2000 ? `<p class="muted small">Showing 2,000 of ${devices.length}. Copy or save includes all.</p>` : "")
    : '<div class="empty">Every primary user is active.</div>';
}

function orphanRows() {
  return [["Device", "Primary user", "UPN", "User", "OS", "OS version", "Last check-in", "Ownership", "Model"],
    ...(orphans?.devices || []).map((d) => [d.name, d.displayName, d.upn, d.userState, d.os, d.osVersion, d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#orphans-run").addEventListener("click", runOrphans);
$("#orphans-copy").addEventListener("click", (e) => copyTsv(e.currentTarget, orphanRows()));
$("#orphans-csv").addEventListener("click", () => saveCsv("orphaned-users.csv", orphanRows()));

// ------------------------------------------------------------------------------------------
// Low storage

let storageList = [];

function renderStorage() {
  const limit = Number($("#storage-gb").value) || 10;
  const os = $("#storage-os").value;
  const platforms = devicesCache.platforms;
  const sel = $("#storage-os");
  if (sel.options.length !== platforms.length + 1) {
    sel.innerHTML = '<option value="">All platforms</option>' + platforms.map((p) => `<option>${esc(p)}</option>`).join("");
    sel.value = platforms.includes(os) ? os : "";
  }
  const { list, unknown } = lowStorageDevices(devicesCache.devices, limit);
  storageList = list.filter((d) => !sel.value || (d.os || "Unknown OS") === sel.value);
  $("#storage-count").textContent = `${storageList.length.toLocaleString()} low` + (unknown ? `, ${unknown.toLocaleString()} report no storage` : "");
  $("#storage-results").innerHTML = storageList.length
    ? tableHtml(["Device", "Primary user", "OS", { label: "Free", num: true }, { label: "Total", num: true }, { label: "Free %", num: true }, "Last check-in"], storageList.slice(0, 2000).map((d) => [
      td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(`${d.freeGb.toFixed(1)} GB`, "num"), td(`${d.totalGb.toFixed(0)} GB`, "num"), td(`${(d.freeGb / d.totalGb * 100).toFixed(0)}%`, "num"),
      td(checkInCell(d.lastSync)),
    ])) + (storageList.length > 2000 ? `<p class="muted small">Showing 2,000 of ${storageList.length}. Copy or save includes all.</p>` : "")
    : `<div class="empty">No device has less than ${limit} GB free.</div>`;
}

function storageRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Free GB", "Total GB", "Free %", "Last check-in", "Ownership", "Model"],
    ...storageList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.freeGb.toFixed(1), d.totalGb.toFixed(0),
      (d.freeGb / d.totalGb * 100).toFixed(0), d.lastSync, ownerLabel(d.owner), d.model])];
}

$("#storage-gb").addEventListener("input", () => devicesCache && renderStorage());
$("#storage-os").addEventListener("input", () => devicesCache && renderStorage());
$("#storage-copy").addEventListener("click", (e) => copyTsv(e.currentTarget, storageRows()));
$("#storage-csv").addEventListener("click", () => saveCsv("low-storage.csv", storageRows()));

// ------------------------------------------------------------------------------------------
// Stale & duplicates

let staleList = [];
let dupes = []; // found once per device list; the stale list reads it on every keystroke

function renderHygiene() {
  const platforms = devicesCache.platforms;
  const sel = $("#stale-os");
  if (sel.options.length !== platforms.length + 1) {
    const keep = sel.value;
    sel.innerHTML = '<option value="">All platforms</option>' + platforms.map((p) => `<option>${esc(p)}</option>`).join("");
    sel.value = platforms.includes(keep) ? keep : "";
  }
  dupes = duplicateDevices(devicesCache.devices);
  renderStale();
  renderDupes();
}

function renderStale() {
  const days = Number($("#stale-days").value) || 30;
  const os = $("#stale-os").value;
  staleList = staleDevices(devicesCache.devices, days).filter((d) => !os || (d.os || "Unknown OS") === os);
  // A stale record that has a newer record under the same name is usually a re-imaged device's
  // leftover, not a missing device. Say so.
  const olderRecords = new Set(dupes.flatMap((g) => g.records.filter((r) => !r.current).map((r) => r.managedId)));
  staleList.forEach((d) => { d.olderDuplicate = olderRecords.has(d.managedId); });
  $("#stale-count").textContent = `${staleList.length.toLocaleString()} of ${devicesCache.devices.length.toLocaleString()}`;
  $("#stale-results").innerHTML = staleList.length
    ? tableHtml(["Device", "Primary user", "OS", "Compliance", "Last check-in", "Ownership"], staleList.slice(0, 2000).map((d) => [
      td(`${link(d.link, d.name)}${d.olderDuplicate ? ' <span class="badge" title="A newer Intune record has the same name">older duplicate</span>' : ""}`, "nowrap"),
      td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))),
      td(complianceBadge(d.compliance)), td(checkInCell(d.lastSync)), td(esc(ownerLabel(d.owner))),
    ])) + (staleList.length > 2000 ? `<p class="muted small">Showing 2,000 of ${staleList.length}. Copy or save includes all.</p>` : "")
    : `<div class="empty">Every device has checked in within ${days} days.</div>`;
}

function staleRows() {
  return [["Device", "Primary user", "UPN", "OS", "OS version", "Compliance", "Last check-in", "Days since", "Ownership", "Model", "Older duplicate"],
    ...staleList.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.compliance, d.lastSync, d.age ?? "never",
      ownerLabel(d.owner), d.model, d.olderDuplicate ? "yes" : ""])];
}

function renderDupes() {
  const records = dupes.reduce((n, g) => n + g.count, 0);
  $("#dupe-count").textContent = dupes.length ? `${dupes.length} names, ${records} records` : "";
  if (!dupes.length) { $("#dupe-results").innerHTML = '<div class="empty">No device name has more than one Intune record.</div>'; return; }
  const rows = [];
  const older = [];
  for (const g of dupes) {
    g.records.forEach((d, i) => {
      rows.push([
        td(i === 0 ? `<strong>${esc(g.name)}</strong> <span class="muted">×${g.count}</span>` : "", "nowrap"),
        td(link(d.link, "Open in Intune")),
        td(esc(userOf(d))),
        td(esc(d.enrolled ? new Date(d.enrolled).toLocaleDateString() : "")),
        td(checkInCell(d.lastSync)),
        td(d.current ? '<span class="badge ok">Current</span>' : '<span class="badge">Older record</span>'),
      ]);
      older.push(!d.current);
    });
  }
  $("#dupe-results").innerHTML = tableHtml(["Device name", "Record", "Primary user", "Enrolled", "Last check-in", ""], rows.slice(0, 3000), (i) => (older[i] ? 'class="older"' : ""));
}

function dupeRows() {
  return [["Device name", "Record", "Primary user", "UPN", "Enrolled", "Last check-in", "Days since", "Intune device ID"],
    ...dupes.flatMap((g) => g.records.map((d) => [g.name, d.current ? "Current" : "Older record", d.displayName, d.upn,
      d.enrolled, d.lastSync, d.age ?? "never", d.managedId]))];
}

$("#stale-days").addEventListener("input", () => devicesCache && renderStale());
$("#stale-os").addEventListener("input", () => devicesCache && renderStale());
$("#stale-copy").addEventListener("click", (e) => copyTsv(e.currentTarget, staleRows()));
$("#stale-csv").addEventListener("click", () => saveCsv("stale-devices.csv", staleRows()));
$("#dupe-copy").addEventListener("click", (e) => copyTsv(e.currentTarget, dupeRows()));
$("#dupe-csv").addEventListener("click", () => saveCsv("duplicate-devices.csv", dupeRows()));

// ------------------------------------------------------------------------------------------
// App versions

const appverRun = newestOnly();
let appverApps = [];
let appverRows = []; // the device table shown, for copy and CSV

$("#appver-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query = $("#appver-query").value.trim();
  const out = $("#appver-results");
  const current = appverRun();
  $("#appver-devices").innerHTML = "";
  $("#appver-tools").hidden = true;
  if (!query) { out.innerHTML = ""; return; }
  out.innerHTML = loading("Reading the discovered apps...");
  try {
    const res = await send("apps/versions", { query });
    if (!current()) return;
    appverApps = res.apps;
    drawAppVersions();
  } catch (err) {
    if (current()) out.innerHTML = errorBox(err);
  }
});

function drawAppVersions() {
  const below = $("#appver-below").value.trim();
  const out = $("#appver-results");
  if (!appverApps.length) { out.innerHTML = '<div class="empty">No discovered app has that name.</div>'; return; }
  out.innerHTML = appverApps.map((app, ai) => {
    const older = below ? app.versions.filter((v) => isBelowVersion(v.version, below)) : [];
    const olderDevices = older.reduce((n, v) => n + v.devices, 0);
    return `<article class="card">
      <h2>${esc(app.name)}</h2>
      <div class="muted">${esc([app.publisher, app.platform].filter(Boolean).join(", "))}${app.publisher || app.platform ? " - " : ""}${app.total.toLocaleString()} devices, ${app.versions.length} version${app.versions.length === 1 ? "" : "s"}</div>
      ${tableHtml(["Version", { label: "Devices", num: true }, ""], app.versions.map((v, vi) => [
        td(esc(v.version || "(none)"), "mono"),
        td(v.devices.toLocaleString(), "num"),
        td(`${below && isBelowVersion(v.version, below) ? '<span class="badge warn">older</span> ' : ""}<button type="button" data-app="${ai}" data-ver="${vi}">List devices</button>`),
      ]))}
      ${app.versions.length > 1 ? `<p><button type="button" data-app="${ai}" data-all="1">List all ${app.total.toLocaleString()} devices, every version</button></p>` : ""}
      ${older.length ? `<p><button type="button" class="primary" data-app="${ai}" data-below="1">List ${olderDevices.toLocaleString()} devices below ${esc(below)}</button></p>` : ""}
    </article>`;
  }).join("");
}

$("#appver-below").addEventListener("search", () => { if (appverApps.length) drawAppVersions(); });

$("#appver-results").addEventListener("click", async (e) => {
  const btn = e.target.closest("button[data-app]");
  if (!btn) return;
  const app = appverApps[Number(btn.dataset.app)];
  const below = $("#appver-below").value.trim();
  const picked = btn.dataset.all ? app.versions : btn.dataset.below ? app.versions.filter((v) => isBelowVersion(v.version, below)) : [app.versions[Number(btn.dataset.ver)]];
  const out = $("#appver-devices");
  const current = appverRun();
  out.innerHTML = loading("Reading the devices...");
  $("#appver-tools").hidden = true;
  try {
    const res = await send("apps/devices", { items: picked.map((v) => ({ id: v.id, version: v.version })) });
    if (!current()) return;
    // Graph may leave out primary user and check-in here, or send an empty date (0001-01-01): only then wait
    // for the whole device list to fill them.
    const known = !res.devices.some((d) => !(Date.parse(d.lastSync) > 864e5)) ? new Map() : await loadDevices().then((r) => new Map(r.devices.map((x) => [String(x.managedId).toLowerCase(), x]))).catch(() => new Map());
    if (!current()) return;
    for (const d of res.devices) {
      const full = known.get(String(d.managedId).toLowerCase());
      if (full) Object.assign(d, { upn: full.upn, displayName: full.displayName, lastSync: full.lastSync, compliance: full.compliance });
    }
    appverRows = [["Device", "Primary user", "UPN", "OS", "OS version", "Compliance", "Last check-in", "App", "App version"],
      ...res.devices.map((d) => [d.name, d.displayName, d.upn, d.os, d.osVersion, d.compliance, d.lastSync, app.name, d.appVersion])];
    $("#appver-tools").hidden = !res.devices.length;
    out.innerHTML = (res.failed ? `<p class="muted small">${res.failed} version${res.failed === 1 ? "" : "s"} couldn't be read.</p>` : "") + (res.devices.length
      ? `<p class="muted small">${res.devices.length.toLocaleString()} devices${res.devices.length > 2000 ? ", showing the first 2,000. Copy or save includes all" : ""}.</p>` + tableHtml(["Device", "Primary user", "OS", "Last check-in", "App version"], res.devices.slice(0, 2000).map((d) => [
        td(link(d.link, d.name), "nowrap"), td(esc(userOf(d))), td(esc(friendlyOs(d.os, d.osVersion))), td(checkInCell(d.lastSync)), td(esc(d.appVersion), "mono"),
      ]))
      : '<div class="empty">No devices reported for that selection.</div>');
  } catch (err) {
    if (current()) out.innerHTML = errorBox(err);
  }
});
$("#appver-copy").addEventListener("click", (e) => copyTsv(e.currentTarget, appverRows));
$("#appver-csv").addEventListener("click", () => saveCsv("app-versions.csv", appverRows));

// ------------------------------------------------------------------------------------------
// Cleanup report

let cleanup = null;

$("#cleanup-run").addEventListener("click", async () => {
  const out = $("#cleanup-results");
  $("#cleanup-run").disabled = true;
  $("#cleanup-csv").hidden = true;
  out.innerHTML = loading("Reading your policies and checking every group they use...");
  try {
    const res = await send("cleanup/report");
    cleanup = res.report;
    if (res.policies) renderIndexLine(res.policies);
    out.innerHTML = renderCleanup(cleanup);
    $("#cleanup-csv").hidden = false;
  } catch (err) {
    out.innerHTML = errorBox(err);
  } finally {
    $("#cleanup-run").disabled = false;
    $("#cleanup-run").textContent = "Run again";
  }
});

function renderCleanup(r) {
  const s = r.summary;
  const tile = (n, label, cls) => `<div class="tile ${n ? cls : "ok"}"><strong>${n}</strong>${esc(label)}</div>`;
  const target = (f) => (f.kind === "exclude" ? '<span class="badge warn">Exclude</span>' : `<span class="badge">Include</span>${f.intent ? ` <span class="muted small">${esc(f.intent)}</span>` : ""}`);
  const section = (title, note, list, headers, row, { count = String(list.length), rowAttrs } = {}) => `<article class="card">
      <h2>${esc(title)} <span class="muted">· ${esc(count)}</span></h2>
      <p class="muted small" style="margin:2px 0 8px">${esc(note)}</p>
      ${list.length ? tableHtml(headers, list.map(row), rowAttrs) : '<p class="muted">None found.</p>'}
    </article>`;
  // Empty groups: includes (the problem, and what the tile counts) first; harmless excludes greyed out after.
  const emptyGroup = [...r.emptyGroup].sort((a, b) => Number(a.kind === "exclude") - Number(b.kind === "exclude"));
  const emptyExcludes = emptyGroup.length - s.emptyGroup;
  return `<div class="tiles">
      ${tile(s.deletedGroup, "assignments to deleted groups", "bad")}
      ${tile(s.emptyGroup, "assigned to empty groups", "warn")}
      ${tile(s.excludeOnly, "exclude-only (target nobody)", "warn")}
      ${tile(s.unassigned, "not assigned", "warn")}
    </div>
    <p class="muted small">Checked ${s.policies} policies, profiles, scripts and apps, and ${s.groups} groups they use.${s.unchecked ? ` ${s.unchecked} couldn't be checked: Graph wouldn't return their assignments.` : ""}${s.groupsUnchecked ? ` ${s.groupsUnchecked} group${s.groupsUnchecked === 1 ? "" : "s"} couldn't be sized (Graph was busy), so some empty groups may be missing. Run Cleanup again.` : ""}</p>
    ${section("Assigned to deleted groups", "The group no longer exists, so this assignment does nothing. Safe to remove from the policy.", r.deletedGroup,
      ["Name", "Type", "Missing group ID", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(esc(f.groupId), "mono"), td(target(f))])}
    ${section("Assigned to empty groups", "The group has no members (including nested). An include reaches nobody; an exclude is harmless.", emptyGroup,
      ["Name", "Type", "Group", "Target"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(link(f.groupLink, f.groupName)), td(target(f))],
      { count: `${s.emptyGroup} include${s.emptyGroup === 1 ? "" : "s"}${emptyExcludes ? ` + ${emptyExcludes} harmless exclude${emptyExcludes === 1 ? "" : "s"}` : ""}`,
        rowAttrs: (i) => (emptyGroup[i].kind === "exclude" ? 'class="older"' : "") })}
    ${section("Exclude-only", "Only exclusions, no includes, so it targets nobody.", r.excludeOnly,
      ["Name", "Type", "Exclusions"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel)), td(String(f.count), "num")])}
    ${section("Not assigned", "No assignments at all. Unassigned apps aren't listed (the app catalogue includes many built-in apps).", r.unassigned,
      ["Name", "Type"], (f) => [td(link(f.link, f.policyName)), td(esc(f.typeLabel))])}`;
}

$("#cleanup-csv").addEventListener("click", () => {
  if (!cleanup) return;
  const rows = [["Finding", "Name", "Type", "Group", "Group ID", "Target"]];
  for (const f of cleanup.deletedGroup) rows.push(["Assigned to deleted group", f.policyName, f.typeLabel, "", f.groupId, f.kind]);
  for (const f of cleanup.emptyGroup) rows.push(["Assigned to empty group", f.policyName, f.typeLabel, f.groupName, f.groupId, f.kind]);
  for (const f of cleanup.excludeOnly) rows.push(["Exclude-only", f.policyName, f.typeLabel, "", "", `${f.count} exclusions`]);
  for (const f of cleanup.unassigned) rows.push(["Not assigned", f.policyName, f.typeLabel, "", "", ""]);
  saveCsv("intune-cleanup.csv", rows);
});

// ------------------------------------------------------------------------------------------
// Settings: the disclosure until it's accepted, then status and the in-portal feature switches.
// Each switch saves its own key in ie.prefs (data-pref); every switch is on unless saved as false
// (the content scripts read them the same way). In sample mode nothing is saved.

const PREFS_KEY = "ie.prefs";
// Dropdowns and sliders, with their defaults. Switches need none: they're on unless saved as false.
const DEFAULT_PREFS = {
  primaryUserLabels: "name", lastLoggedOnUser: "icon", friendlyOsVersions: "full", groupSizeHints: "all",
  freeStorageFlags: "10", appInstallStatus: "all", policyStatus: "all", widthDeviceName: 150, widthPolicyName: 150, widthGroupName: 150, widthAppName: 200,
  widthScriptName: 200,
  widthMemberName: 250,
};
let samplePrefs = { ...DEFAULT_PREFS };

async function loadPrefs() {
  if (SAMPLE) return samplePrefs;
  const saved = (await chrome.storage.local.get(PREFS_KEY))[PREFS_KEY] || {};
  return { ...DEFAULT_PREFS, ...saved };
}

async function savePrefs(patch) {
  if (SAMPLE) { samplePrefs = { ...samplePrefs, ...patch }; return; }
  // Only what the admin changed is saved, so a later version's new defaults still apply to the rest.
  const saved = (await chrome.storage.local.get(PREFS_KEY))[PREFS_KEY] || {};
  await chrome.storage.local.set({ [PREFS_KEY]: { ...saved, ...patch } });
}

// The controls are set from storage once, then follow storage changes (below). A device list build sends
// a progress update every 1,000 devices, and re-setting them each time would snap a slider back mid-drag.
let prefsShown = false;

async function renderSettingsTab(s) {
  const on = SAMPLE || s.consented;
  $("#consent").hidden = on;
  $("#settings-main").hidden = !on;
  if (!on) return;
  const ix = s.index || {};
  $("#set-session").textContent = SAMPLE ? "Sample data (fictional)" : s.signedIn ? s.upn || "Signed in" : "Not signed in: open the Intune admin center";
  $("#set-count").textContent = ix.building ? `building... ${ix.count || 0}` : (ix.count || 0).toLocaleString();
  $("#set-built").textContent = ago(ix.builtAt);
  $("#set-rebuild").disabled = Boolean(ix.building) || !s.signedIn;
  $("#set-error").textContent = ix.error || "";
  $("#set-error").hidden = !ix.error;
  if (!prefsShown) {
    prefsShown = true;
    await showPrefs();
  }
}

/** Set every switch, dropdown and slider from the saved prefs. */
async function showPrefs() {
  const prefs = await loadPrefs();
  for (const el of $$("[data-pref]")) {
    if (el.type === "checkbox") el.checked = prefs[el.dataset.pref] !== false;
    else el.value = prefs[el.dataset.pref];
  }
  showWidths();
}

// A column width dragged in the admin center (or a change in another workspace tab) shows here at once.
if (!SAMPLE) {
  chrome.storage.onChanged.addListener((changes, area) => { if (area === "local" && changes[PREFS_KEY]) showPrefs(); });
}

// A slider's percentage beside it.
const showWidths = () => $$("output[data-for]").forEach((o) => { o.textContent = `${$(`[data-pref="${o.dataset.for}"]`).value}%`; });

for (const el of $$("[data-pref]")) {
  const value = () => (el.type === "checkbox" ? el.checked : el.type === "range" ? Number(el.value) : el.value);
  el.addEventListener("change", () => savePrefs({ [el.dataset.pref]: value() }));
  if (el.type === "range") el.addEventListener("input", showWidths);
}

$("#agree").addEventListener("click", async () => {
  await grantConsent();
  $("#all-set").hidden = false;
  await refreshSession();
});

$("#set-rebuild").addEventListener("click", async () => {
  $("#set-rebuild").disabled = true;
  await send("index/rebuild").catch((e) => { $("#set-error").textContent = e.message; $("#set-error").hidden = false; });
  devicesCache = null; // OS builds and Stale & duplicates read the new list
  refreshSession();
});

$("#set-clear").addEventListener("click", async () => {
  await send("data/clear").catch(() => {});
  devicesCache = null;
  changes = null;
  refreshSession();
});

// ------------------------------------------------------------------------------------------
// Theme toggle (theme-init.js has already applied the saved or OS theme)

function syncThemeButton() {
  const dark = document.documentElement.dataset.theme === "dark";
  const label = dark ? "Switch to light theme" : "Switch to dark theme";
  const btn = $("#theme-toggle");
  btn.setAttribute("aria-label", label);
  btn.title = label;
}
$("#theme-toggle").addEventListener("click", () => {
  const next = document.documentElement.dataset.theme === "dark" ? "light" : "dark";
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem("ie.theme", next); } catch { /* storage unavailable: still switches for this visit */ }
  syncThemeButton();
});
syncThemeButton();

// ------------------------------------------------------------------------------------------
// Start

if (inExtension) {
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === "policies/progress") {
      if (msg.building) {
        // One plain label while the index walks the item types; the settings stage keeps its type's name.
        const what = / settings$/.test(msg.step || "") ? msg.step : "policy types";
        setIndexLines(`<span class="spinner"></span>Reading ${esc(what)}${msg.total ? ` (${msg.done} of ${msg.total})` : ""}...`);
        jobBar.set("policies", { label: `Reading ${what}`, done: msg.done || 0, total: msg.total || 0, stop: true });
      } else {
        jobBar.done("policies");
      }
    }
    if (msg?.type === "index/progress") {
      if (msg.building) jobBar.set("devices", { label: "Reading your devices", done: msg.count || 0, total: 0, stop: true });
      else jobBar.done("devices");
    }
    if (msg?.type === "job/progress") jobBar.set(msg.key, { label: msg.label, done: msg.done, total: msg.total, stop: true });
    if (msg?.type === "job/done") jobBar.done(msg.key);
    if (msg?.type === "index/progress" && currentTab === "settings") refreshSession();
  });
}

let initialTab = DEFAULT_TAB;
try { initialTab = localStorage.getItem("ie.workspace.tab") || initialTab; } catch { /* storage unavailable */ }
if (!openFromHash()) selectTab(TABS.includes(initialTab) ? initialTab : DEFAULT_TAB);
// Until it's turned on, the only useful place is Settings.
refreshSession().then((s) => { if (s && !s.consented && !SAMPLE) selectTab("settings"); });
