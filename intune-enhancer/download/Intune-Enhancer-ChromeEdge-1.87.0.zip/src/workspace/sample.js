// Sample data for the workspace: a small fictional tenant ("Fabrikam") so the tools can be tried
// without an Intune account (store reviewers, demos, offline UI testing). Answers go through the
// same search and assignment logic as real data. Nothing is read from or sent to any tenant.

import { rollupApps } from "../core/app-versions.js";
import { searchSettings, policiesForGroup, deprecatedSettings, changedPolicies } from "../core/setting-search.js";
import { parseIds, assignmentSummary } from "../core/id-decoder.js";
import { buildCleanup, referencedGroupIds } from "../core/cleanup.js";
import { orphanedDevices } from "../core/orphaned-users.js";
import { healthRows } from "../core/tenant-health.js";
import { buildDevice360 } from "../core/device-360.js";
import { policyRef } from "../core/portal-links.js";
import { duplicatePolicies } from "../core/duplicate-policies.js";
import { hardwareRow } from "../core/hardware.js";
import { compareDevices } from "../core/device-compare.js";
import { rankSettings, failingDevices } from "../core/compliance-breakdown.js";

const today = Date.now();
const iso = (daysAgo) => new Date(today - daysAgo * 86400000).toISOString();

const G = {
  corp: "11111111-aaaa-4000-8000-000000000001",
  pilot: "11111111-aaaa-4000-8000-000000000002",
  kiosk: "11111111-aaaa-4000-8000-000000000003",
  old: "11111111-aaaa-4000-8000-000000000004",
  finance: "11111111-aaaa-4000-8000-000000000005",
};
const inc = (groupId, extra = {}) => ({ kind: "include", groupId, ...extra });
const exc = (groupId) => ({ kind: "exclude", groupId });

const GROUPS = [
  { id: G.corp, displayName: "SG-Devices-Windows-Corporate", groupTypes: ["DynamicMembership"], securityEnabled: true, description: "All corporate Windows devices" },
  { id: G.pilot, displayName: "SG-Devices-Windows-Pilot", groupTypes: [], securityEnabled: true, description: "Early update ring" },
  { id: G.kiosk, displayName: "SG-Devices-Kiosk", groupTypes: [], securityEnabled: true },
  { id: G.old, displayName: "SG-Devices-Legacy-VPN", groupTypes: [], securityEnabled: true, description: "Old VPN rollout, probably unused" },
  { id: G.finance, displayName: "SG-Users-Finance", groupTypes: [], securityEnabled: true },
];

const INDEX = {
  builtAt: Date.now() - 40 * 60000,
  errors: {},
  policies: [
    { id: "p1", type: "settingsCatalog", name: "WIN - BitLocker - Corporate", assignments: [inc(G.corp), exc(G.kiosk)], meta: { platforms: "windows10", technologies: "mdm", templateId: "" }, settings: [
      { d: "device_vendor_msft_bitlocker_requiredeviceencryption", n: "Require Device Encryption", p: "./Device/Vendor/MSFT/BitLocker/RequireDeviceEncryption", v: "Enabled" },
      { d: "device_vendor_msft_bitlocker_encryptionmethodbydrivetype", n: "Choose drive encryption method and cipher strength", p: "./Device/Vendor/MSFT/BitLocker/EncryptionMethodByDriveType", v: "XTS-AES 256-bit" },
    ] },
    { id: "p2", type: "settingsCatalog", name: "WIN - BitLocker - Pilot", assignments: [inc(G.pilot)], settings: [
      { d: "device_vendor_msft_bitlocker_requiredeviceencryption", n: "Require Device Encryption", p: "./Device/Vendor/MSFT/BitLocker/RequireDeviceEncryption", v: "Enabled" },
      { d: "device_vendor_msft_bitlocker_encryptionmethodbydrivetype", n: "Choose drive encryption method and cipher strength", p: "./Device/Vendor/MSFT/BitLocker/EncryptionMethodByDriveType", v: "XTS-AES 128-bit" },
    ] },
    { id: "p3", type: "settingsCatalog", name: "WIN - Device lock", assignments: [{ kind: "allDevices", filterId: "f1", filterType: "exclude" }], settings: [
      { d: "device_vendor_msft_policy_config_devicelock_maxinactivitytimedevicelock", n: "Max Inactivity Time Device Lock", p: "./Device/Vendor/MSFT/Policy/Config/DeviceLock/MaxInactivityTimeDeviceLock", v: "15" },
      { d: "device_vendor_msft_policy_config_devicelock_mindevicepasswordlength", n: "Min Device Password Length", p: "./Device/Vendor/MSFT/Policy/Config/DeviceLock/MinDevicePasswordLength", v: "12" },
      { d: "device_vendor_msft_policy_config_devicelock_allowsimpledevicepassword", n: "Allow Simple Device Password (Deprecated)", p: "./Device/Vendor/MSFT/Policy/Config/DeviceLock/AllowSimpleDevicePassword", v: "Block" },
    ] },
    { id: "p4", type: "adminTemplate", name: "WIN - Edge baseline (ADMX)", assignments: [inc(G.corp)], settings: [
      { d: "edge-homepage", n: "Configure the home page URL", p: "Computer: Microsoft Edge/Startup, home page and new tab page", v: "Enabled" },
      { d: "edge-smartscreen", n: "Configure Microsoft Defender SmartScreen", p: "Computer: Microsoft Edge/SmartScreen settings", v: "Enabled" },
    ] },
    { id: "p5", type: "deviceConfig", name: "WIN - Custom OMA - Legacy VPN", assignments: [inc(G.old)], settings: [
      { d: "oma:./Vendor/MSFT/VPNv2/FabrikamVPN/ProfileXML", n: "Fabrikam VPN profile", p: "./Vendor/MSFT/VPNv2/FabrikamVPN/ProfileXML", v: "<VPNProfile>...</VPNProfile>" },
    ] },
    { id: "p6", type: "compliance", name: "WIN - Compliance - Corporate", assignments: [inc(G.corp)], settings: [
      { d: "windows10CompliancePolicy.bitLockerEnabled", n: "Bit locker enabled", p: "windows10CompliancePolicy.bitLockerEnabled", v: "true" },
      { d: "windows10CompliancePolicy.passwordMinimumLength", n: "Password minimum length", p: "windows10CompliancePolicy.passwordMinimumLength", v: "12" },
    ] },
    { id: "p15", type: "compliance", name: "WIN - Compliance - Corporate (copy)", assignments: [inc(G.pilot)], settings: [
      { d: "windows10CompliancePolicy.bitLockerEnabled", n: "Bit locker enabled", p: "windows10CompliancePolicy.bitLockerEnabled", v: "true" },
      { d: "windows10CompliancePolicy.passwordMinimumLength", n: "Password minimum length", p: "windows10CompliancePolicy.passwordMinimumLength", v: "12" },
    ] },
    { id: "p7", type: "remediation", name: "Clear Teams cache", assignments: [inc(G.pilot)] },
    { id: "p8", type: "app", name: "Fabrikam VPN client", assignments: [inc(G.old, { intent: "required" })] },
    { id: "p9", type: "app", name: "Company Portal", assignments: [{ kind: "allUsers", intent: "available" }] },
    { id: "p10", type: "featureUpdate", name: "Windows 11 24H2 - Broad", assignments: [inc(G.corp), exc(G.pilot)] },
    // Cleanup findings
    { id: "p11", type: "settingsCatalog", name: "WIN - Old proxy settings (test)", assignments: [], settings: [] },
    { id: "p12", type: "windowsScript", name: "Map legacy drives", assignments: [inc("99999999-dead-4000-8000-000000000001")] },
    { id: "p13", type: "compliance", name: "WIN - Compliance - Kiosk", assignments: [inc(G.kiosk)], settings: [] },
    { id: "p14", type: "remediation", name: "Disable SMBv1 (paused)", assignments: [exc(G.corp)] },
  ],
};
// Created and modified dates for Recent changes: a spread over the last few months.
const AGES = [2, 5, 9, 15, 26, 40, 61, 3, 120, 12, 33, 200, 7, 1, 18];
INDEX.policies.forEach((p, i) => {
  p.modified = iso(AGES[i]);
  p.created = iso(AGES[i] + 30 + i * 9);
  // Every sample policy is for Windows, so Device 360 can tell its platform.
  if (p.type === "settingsCatalog") p.meta ||= { platforms: "windows10", technologies: "mdm", templateId: "" };
  else p.odataType = p.type === "app" ? "#microsoft.graph.win32LobApp" : "#microsoft.graph.windows10CustomConfiguration";
});

// The deleted group (p12) has no entry here; the kiosk group is empty.
const SAMPLE_SIZES = {
  [G.corp]: { devices: 1204, users: 0, groups: 0 }, [G.pilot]: { devices: 42, users: 0, groups: 0 },
  [G.kiosk]: { devices: 0, users: 0, groups: 0 }, [G.old]: { devices: 3, users: 0, groups: 0 },
  [G.finance]: { devices: 0, users: 4, groups: 0 },
};

// A small mixed fleet for OS builds and Stale & duplicates.
const SAMPLE_DEVICES = (() => {
  const mix = [
    ["Windows", "10.0.26100.4349", 40], ["Windows", "10.0.26200.6584", 5], ["Windows", "10.0.22631.5472", 18], ["Windows", "10.0.19045.5965", 9],
    ["iOS", "18.6.2", 10], ["iOS", "17.7.1", 3], ["Android", "15", 6], ["Android", "14", 2], ["macOS", "15.6", 4],
  ];
  const people = ["Ana Lima", "Ben Okafor", "Chen Wei", "Dana Smith", "Eli Novak", "Farah Haddad", "Gus Moreau", "Hana Sato"];
  const compliance = ["compliant", "compliant", "compliant", "compliant", "noncompliant", "inGracePeriod"];
  const list = [];
  let n = 0;
  for (const [os, osVersion, count] of mix) {
    for (let i = 0; i < count; i++, n++) {
      const who = people[n % people.length];
      const prefix = os === "Windows" ? "FAB-LT" : os === "macOS" ? "FAB-MAC" : os === "iOS" ? "FAB-IPH" : "FAB-AND";
      // Days since check-in: mostly recent, some 8-30 (orange), some long gone (red).
      const stale = n % 11 === 0 ? 40 + (n % 5) * 25 : n % 7 === 0 ? 10 + (n % 3) * 6 : n % 4;
      list.push({
        managedId: `md-${n}`, name: `${prefix}-${String(100 + n).padStart(4, "0")}`, displayName: who,
        upn: `${who.toLowerCase().replace(" ", ".")}@fabrikam.example`, os, osVersion, compliance: compliance[n % compliance.length],
        lastSync: n === 7 ? "" : iso(stale), enrolled: iso(200 + n * 3), owner: n % 9 === 0 ? "personal" : "company", model: os === "Windows" ? "Surface Laptop 6" : "",
        // 256 GB or 512 GB disks, mostly roomy, some nearly full
        userId: `user-${n % people.length}`,
        totalBytes: (n % 3 ? 256 : 512) * 1024 ** 3, freeBytes: (n % 5 === 0 ? 2 + (n % 4) * 3 : 40 + (n % 7) * 20) * 1024 ** 3,
        link: "",
      });
    }
  }
  // Re-imaged devices leave older records behind.
  for (const k of [3, 12, 25]) list.push({ ...list[k], managedId: `md-old-${k}`, lastSync: iso(160 + k), enrolled: iso(700 + k), compliance: "noncompliant" });
  return list;
})();

const ROSTERS = {
  [G.corp]: [
    { type: "Device", name: "FAB-LT-0142", objectId: "o-1", primaryUser: "Ana Lima", upn: "ana.lima@fabrikam.example", compliance: "compliant", os: "Windows", osVersion: "10.0.26100.4349", lastCheckIn: iso(0), managedId: "md-1", intune: true },
    { type: "Device", name: "FAB-LT-0177", objectId: "o-2", primaryUser: "Ben Okafor", upn: "ben.okafor@fabrikam.example", compliance: "noncompliant", os: "Windows", osVersion: "10.0.22631.5472", lastCheckIn: iso(3), managedId: "md-2", intune: true },
    { type: "Device", name: "FAB-LT-0201", objectId: "o-3", primaryUser: "", upn: "", compliance: "compliant", os: "Windows", osVersion: "10.0.26100.4349", lastCheckIn: iso(1), managedId: "md-3", intune: true },
    { type: "Device", name: "FAB-DT-0033", objectId: "o-4", primaryUser: "Chen Wei", upn: "chen.wei@fabrikam.example", compliance: "inGracePeriod", os: "Windows", osVersion: "10.0.19045.5965", lastCheckIn: iso(47), managedId: "md-4", intune: true, duplicates: 2 },
    { type: "Device", name: "FAB-LT-0099", objectId: "o-5", primaryUser: "", upn: "", compliance: "", os: "Windows", osVersion: "", lastCheckIn: "", managedId: "", intune: false },
  ],
  [G.finance]: [
    { type: "User", name: "Ana Lima", objectId: "u-1", upn: "ana.lima@fabrikam.example", enabled: true, department: "Finance", jobTitle: "Accountant",
      devices: [{ name: "FAB-LT-0142" }], deviceCount: 1, compliance: "compliant", os: "Windows", osVersion: "10.0.26100.4349", lastCheckIn: iso(0) },
    { type: "User", name: "Ben Okafor", objectId: "u-2", upn: "ben.okafor@fabrikam.example", enabled: true, department: "Finance", jobTitle: "Finance Manager",
      devices: [{ name: "FAB-LT-0177" }, { name: "FAB-TAB-0012" }], deviceCount: 2, compliance: "noncompliant", os: "Windows", osVersion: "10.0.22631.5472", lastCheckIn: iso(3) },
    { type: "User", name: "Chen Wei", objectId: "u-3", upn: "chen.wei@fabrikam.example", enabled: false, department: "Finance", jobTitle: "Analyst",
      devices: [{ name: "FAB-DT-0033" }], deviceCount: 1, compliance: "inGracePeriod", os: "Windows", osVersion: "10.0.19045.5965", lastCheckIn: iso(47) },
    { type: "User", name: "Dana Smith", objectId: "u-4", upn: "dana.smith@fabrikam.example", enabled: true, department: "Finance", jobTitle: "Contractor", devices: [], deviceCount: 0 },
  ],
};

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

export async function sampleSend(type, payload) {
  await delay(250);
  const policies = { count: INDEX.policies.length, builtAt: INDEX.builtAt, stale: false, building: false, errors: {} };
  switch (type) {
    case "status":
      return { ok: true, consented: true, signedIn: true, upn: "admin@fabrikam.example", policies, index: { count: SAMPLE_DEVICES.length, builtAt: Date.now() - 25 * 60000 } };
    case "policies/build":
      return { ok: true, policies };
    case "settings/search":
      return { ok: true, ...searchSettings(INDEX, payload.query), policies };
    case "settings/deprecated":
      return { ok: true, ...deprecatedSettings(INDEX), policies };
    case "policies/changes":
      return { ok: true, items: changedPolicies(INDEX), policies };
    case "groups/search": {
      const q = String(payload.query || "").toLowerCase();
      return { ok: true, groups: GROUPS.filter((g) => g.displayName.toLowerCase().includes(q)) };
    }
    case "groups/names":
      return { ok: true, names: Object.fromEntries(GROUPS.map((g) => [g.id, g.displayName])) };
    case "group/impact": {
      const g = GROUPS.find((x) => x.id === payload.groupId);
      const intune = policiesForGroup(INDEX, payload.groupId);
      const isOld = g.id === G.old;
      const checklist = [
        { label: "Intune assignments", count: intune.length, status: intune.length ? "in-use" : "clear", detail: `${intune.filter((i) => i.kind === "include").length} include, ${intune.filter((i) => i.kind === "exclude").length} exclude` },
        { label: "Conditional Access policies", count: g.id === G.corp ? 1 : 0, status: g.id === G.corp ? "in-use" : "clear", detail: "" },
        { label: "Enterprise app assignments", count: 0, status: "clear", detail: "" },
        { label: "Group-based licences", count: 0, status: "clear", detail: "" },
        { label: "Intune role assignments", count: null, status: "unknown", detail: "Couldn't check (your role or session doesn't have access): sample of a permission gap" },
        { label: "Member of other groups", count: 0, status: "clear", detail: "Removing this group changes the membership of these parent groups" },
        { label: "Contains other groups", count: 0, status: "clear", detail: "" },
      ];
      const verdict = checklist.some((c) => c.status === "in-use") ? "in-use" : checklist.some((c) => c.status === "unknown") ? "unknown" : "clear";
      return { ok: true, report: {
        group: { id: g.id, name: g.displayName, description: g.description || "", kind: `Security group, ${(g.groupTypes || []).includes("DynamicMembership") ? "dynamic" : "assigned"} membership`, rule: g.id === G.corp ? '(device.deviceOwnership -eq "Company") and (device.deviceOSType -eq "Windows")' : "", synced: false, created: iso(900) },
        members: { devices: isOld ? 3 : g.id === G.corp ? 1204 : 42, users: 0 },
        owners: ["Dana Smith"],
        intune,
        conditionalAccess: g.id === G.corp ? [{ name: "Require compliant device for Office", mode: "include", state: "enabled" }] : [],
        appAssignments: [], licenses: [], roleAssignments: [], parents: [], children: [],
        checklist, verdict, policyIndexBuiltAt: INDEX.builtAt, link: "",
      } };
    }
    case "group/roster": {
      const g = GROUPS.find((x) => x.id === payload.groupId);
      return { ok: true, roster: { group: { id: g.id, name: g.displayName }, rows: ROSTERS[g.id] || ROSTERS[G.corp] } };
    }
    case "apps/versions": {
      const apps = [["Google Chrome", "Google LLC", [["141.0.7390.123", 566], ["140.0.7339.208", 24], ["138.0.7204.101", 6]]],
        ["7-Zip", "Igor Pavlov", [["25.01", 410], ["24.09", 120], ["23.01", 44]]]];
      const q = String(payload.query || "").toLowerCase();
      return { ok: true, apps: rollupApps(apps.filter(([name]) => name.toLowerCase().includes(q)).flatMap(([displayName, publisher, versions]) =>
        versions.map(([version, deviceCount], i) => ({ id: `00000000-0000-4000-8000-0000000000${displayName.length}${i}`, displayName, publisher, version, deviceCount, platform: "windows" })))) };
    }
    case "apps/devices":
      return { ok: true, failed: 0, devices: SAMPLE_DEVICES.slice(0, 8).map((d, i) => ({ ...d, appVersion: payload.items[i % payload.items.length].version })) };
    case "devices/list":
      return { ok: true, devices: SAMPLE_DEVICES.map((d) => ({ ...d })), builtAt: Date.now() - 25 * 60000 };
    case "devices/orphaned": {
      // Two of the eight sample people have left: one deleted, one disabled.
      const states = new Map([["user-2", "deleted"], ["user-5", "disabled"]]);
      const { list, unknown } = orphanedDevices(SAMPLE_DEVICES, states);
      return { ok: true, devices: list, unknown, checked: 8, builtAt: Date.now() - 25 * 60000 };
    }
    case "compliance/summary":
      return { ok: true, ...rankSettings([
        { id: "c1", setting: "Windows10CompliancePolicy.BitLockerEnabled", platformType: "windows10", nonCompliantDeviceCount: 14, errorDeviceCount: 1, conflictDeviceCount: 0, compliantDeviceCount: 71, remediatedDeviceCount: 0 },
        { id: "c2", setting: "Windows10CompliancePolicy.PasswordMinimumLength", platformType: "windows10", nonCompliantDeviceCount: 5, errorDeviceCount: 0, conflictDeviceCount: 2, compliantDeviceCount: 80, remediatedDeviceCount: 0 },
        { id: "c3", setting: "Windows10CompliancePolicy.SecureBootEnabled", platformType: "windows10", nonCompliantDeviceCount: 0, errorDeviceCount: 0, conflictDeviceCount: 0, compliantDeviceCount: 86, remediatedDeviceCount: 0 },
      ]) };
    case "compliance/devices": {
      const states = SAMPLE_DEVICES.slice(0, payload.id === "c1" ? 8 : 4).map((d, i) => ({ deviceId: d.managedId, deviceName: d.name, userPrincipalName: d.upn, state: i % 5 === 4 ? "error" : "nonCompliant" }));
      return { ok: true, devices: failingDevices(states, SAMPLE_DEVICES) };
    }
    case "devices/search": {
      const q = String(payload.query || "").toLowerCase();
      const hits = SAMPLE_DEVICES.filter((d) => [d.name, d.upn, d.displayName].some((x) => String(x || "").toLowerCase().includes(q))).slice(0, 25);
      return { ok: true, devices: hits.map((d) => ({ id: d.managedId, displayName: d.name, userPrincipalName: [d.displayName || d.upn || "No primary user", d.os].filter(Boolean).join(", ") })) };
    }
    case "devices/compare": {
      const g = (id, direct = true, via = "") => [id, { id, name: GROUPS.find((x) => x.id === id).displayName, direct, via }];
      const report = (device, groups, userGroups) => buildDevice360(device, INDEX, {
        deviceGroups: new Map(groups), userGroups: new Map(userGroups),
        filters: new Map([["f1", { name: "Exclude kiosks", rule: '(device.deviceCategory -eq "Kiosk")' }]]), notes: [] });
      const a = SAMPLE_DEVICES.find((d) => d.managedId === payload.a);
      const b = SAMPLE_DEVICES.find((d) => d.managedId === payload.b);
      return { ok: true, ...compareDevices(
        report(a, [g(G.corp), g(G.pilot, false, "SG-Devices-Windows-Corporate")], [g(G.finance)]),
        report(b, [g(G.corp), g(G.kiosk)], [])) };
    }
    case "hardware/load":
      return { ok: true, saved: null };
    case "hardware/save":
      return { ok: true };
    case "hardware/read": {
      const rows = payload.ids.map((id) => SAMPLE_DEVICES.find((d) => d.managedId === id)).filter(Boolean).map((d, i) => hardwareRow({
        id: d.managedId, deviceName: d.name, userPrincipalName: d.upn, manufacturer: d.model ? "Microsoft" : "", model: d.model, operatingSystem: d.os, osVersion: d.osVersion,
        physicalMemoryInBytes: [8, 16, 32][i % 3] * 1024 ** 3, totalStorageSpaceInBytes: d.totalBytes, freeStorageSpaceInBytes: d.freeBytes,
        isEncrypted: i % 7 !== 0, enrolledDateTime: d.enrolled, lastSyncDateTime: d.lastSync, managedDeviceOwnerType: d.owner,
        hardwareInformation: { tpmSpecificationVersion: "2.0", batteryHealthPercentage: 70 + (i * 3) % 30 } }));
      return { ok: true, rows, failed: 0 };
    }
    case "policies/duplicates":
      return { ok: true, ...duplicatePolicies(INDEX), builtAt: INDEX.builtAt };
    case "policy/find": {
      const q = String(payload.query || "").toLowerCase();
      const hits = INDEX.policies.filter((p) => p.type !== "app" && p.name.toLowerCase().includes(q));
      return { ok: true, total: hits.length, policies: hits.map((p) => ({ id: p.id, name: p.name, typeLabel: policyRef(p).typeLabel })) };
    }
    case "policy/get": {
      const policy = INDEX.policies.find((p) => p.id === payload.id);
      return { ok: true, policy: { ...policy, ...policyRef(policy) }, names: Object.fromEntries(GROUPS.map((g) => [g.id, g.displayName])),
        filters: { f1: { name: "Exclude kiosks" } } };
    }
    case "users/search": {
      const q = String(payload.query || "").toLowerCase();
      const people = ["Ana Lima", "Ben Okafor", "Chen Wei", "Dana Smith"];
      return { ok: true, users: people.filter((n) => n.toLowerCase().includes(q)).map((n, i) => ({ id: `user-${i}`, displayName: n, userPrincipalName: `${n.toLowerCase().replace(" ", ".")}@fabrikam.example` })) };
    }
    case "users/compare": {
      const g = (id, direct = true, via = "") => ({ id, name: GROUPS.find((x) => x.id === id).displayName, direct, via, link: "" });
      return { ok: true, both: [{ ...g(G.finance), other: g(G.finance) }], onlyA: [g(G.corp, false, "SG-Users-Finance")], onlyB: [g(G.kiosk)], unreadable: { a: false, b: false } };
    }
    case "device/360": {
      const device = SAMPLE_DEVICES.find((d) => d.managedId === payload.managedId);
      const g = (id, direct = true, via = "") => [id, { id, name: GROUPS.find((x) => x.id === id).displayName, direct, via }];
      const windows = device.os === "Windows";
      return { ok: true, report: buildDevice360(device, INDEX, {
        deviceGroups: new Map(windows ? [g(G.corp), g(G.pilot, false, "SG-Devices-Windows-Corporate")] : []),
        userGroups: new Map([g(G.finance)]),
        filters: new Map([["f1", { name: "Exclude kiosks", rule: '(device.deviceCategory -eq "Kiosk")' }]]),
        notes: [],
      }) };
    }
    case "tenant/health": {
      const inDays = (n) => new Date(Date.now() + n * 86400000).toISOString();
      const answers = new Map([
        ["apple", { status: 200, body: { appleIdentifier: "mdm@fabrikam.example", expirationDateTime: inDays(12) } }],
        ["vpp", { status: 200, body: { value: [{ organizationName: "Fabrikam Education", expirationDateTime: inDays(210), state: "valid" }] } }],
        ["ade", { status: 200, body: { value: [{ tokenName: "Fabrikam ADE", tokenExpirationDateTime: inDays(-3) }] } }],
        ["play", { status: 200, body: { ownerUserPrincipalName: "admin@fabrikam.example", bindStatus: "boundAndValidated" } }],
        ["ndes", { status: 403 }],
      ]);
      return { ok: true, rows: healthRows(answers), at: Date.now() };
    }
    case "index/rebuild":
    case "data/clear":
      return { ok: true };
    case "cleanup/report": {
      const known = new Set(GROUPS.map((g) => g.id));
      const names = Object.fromEntries(referencedGroupIds(INDEX).filter((id) => known.has(id)).map((id) => [id, GROUPS.find((g) => g.id === id).displayName]));
      return { ok: true, report: buildCleanup(INDEX, names, SAMPLE_SIZES), policies };
    }
    case "ids/decode": {
      const ids = parseIds(payload.text);
      if (!ids.length) return { ok: true, ids: [], message: "No IDs found. Paste an ID (a GUID) or an admin center link." };
      const names = Object.fromEntries(GROUPS.map((g) => [g.id, g.displayName]));
      return { ok: true, policyIndexBuiltAt: INDEX.builtAt, ids: ids.map(({ guid, hint }) => {
        const group = GROUPS.find((x) => x.id === guid);
        if (group) return { guid, hint, matches: [{ kind: "Group", name: group.displayName, extra: group.description || "", link: "" }] };
        // Any other id decodes as the sample BitLocker policy, to show the policy details.
        const p = INDEX.policies[0];
        return { guid, hint, matches: [{ kind: "Settings catalog", name: p.name, link: "",
          extra: `Windows · ${p.settings.length} settings · modified ${new Date(today - 9 * 86400000).toLocaleDateString()}`,
          assigned: assignmentSummary(p.assignments, names) }] };
      }) };
    }
    default:
      return { ok: false, error: `Sample mode doesn't handle ${type}` };
  }
}
