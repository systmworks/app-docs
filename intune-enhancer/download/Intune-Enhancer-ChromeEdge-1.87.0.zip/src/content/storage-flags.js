// Free storage flags: wherever the portal shows a device's free storage (the device's pages, or a
// "Free storage" column in a device list), colour it orange under the chosen limit (10 GB by default) and red under half of it, with
// a small warning icon whose tooltip says why.
//
// Display only: our icon, plus a data attribute on the value our stylesheet colours. Turning it
// off removes both.

(function () {
  if (window.__ieStorageFlags) return;
  window.__ieStorageFlags = true;

  const { feature, choice, styleOnce, onPass, grid: G, ADDED } = globalThis.IEKit;
  const ICON = "ie-storage-flag";
  const ATTR = "data-ie-storage";
  // Orange and red limits in GB for each Low storage flag choice; "10" is the default.
  const LIMITS = { 10: [10, 5], 20: [20, 10], 5: [5, 2] };
  const limits = () => LIMITS[choice("freeStorageFlags", ["10", "20", "5"])] || LIMITS[10];
  // "Free storage", "Free storage space", "Free space (GB)": as a label, or a column header.
  const LABEL_RE = /^free (storage|space|storage space)( \((gb|mb)\))?\s*:?$/i;
  const WARN_ICON = '<svg viewBox="0 0 16 16" width="12" height="12" aria-hidden="true"><path fill="currentColor" d="M8 1.5 15 14H1L8 1.5zm-.8 4.5v4h1.6V6H7.2zm0 5.2v1.6h1.6v-1.6H7.2z"/></svg>';

  let unwatch = null;

  /**
   * "48.39 GB" -> 48.39, "1,024 MB" -> 1, "48,39 GB" -> 48.39. A number without a unit only
   * counts when the column says its unit ("Free storage (GB)"). Returns GB, or null.
   */
  function parseGb(text, defaultUnit = "") {
    const m = String(text || "").match(/(\d[\d.,]*)\s*(TB|GB|MB|KB)?/i);
    if (!m) return null;
    const unit = (m[2] || defaultUnit).toUpperCase();
    if (!unit) return null;
    let n = m[1];
    const lastSep = Math.max(n.lastIndexOf("."), n.lastIndexOf(","));
    // The last separator is the decimal point unless it's followed by exactly 3 digits (1,024).
    if (lastSep >= 0 && n.length - lastSep - 1 !== 3) n = `${n.slice(0, lastSep).replace(/[.,]/g, "")}.${n.slice(lastSep + 1)}`;
    else n = n.replace(/[.,]/g, "");
    const value = Number(n);
    if (!Number.isFinite(value)) return null;
    return value * { TB: 1024, GB: 1, MB: 1 / 1024, KB: 1 / 1048576 }[unit];
  }

  const level = (gb) => {
    const [orange, red] = limits();
    return gb === null ? "" : gb < red ? "red" : gb < orange ? "orange" : "";
  };

  /** Flag (or un-flag) the element showing a free storage value. */
  function mark(el, gb) {
    const lvl = level(gb);
    let icon = el.querySelector(`:scope > .${ICON}`);
    if (!lvl) {
      icon?.remove();
      el.removeAttribute(ATTR);
      return;
    }
    el.setAttribute(ATTR, lvl);
    if (!icon) {
      icon = document.createElement("span");
      icon.className = ICON;
      icon.innerHTML = WARN_ICON;
      el.prepend(icon);
    }
    const [orange, red] = limits();
    icon.title = `Low free storage: ${gb.toFixed(1)} GB (orange under ${orange} GB, red under ${red} GB)${ADDED}`;
  }

  /**
   * The element holding the value next to a "Free storage" label: the next sibling of the label
   * or of one of its first few ancestors, holding a short size like "48.39 GB" (longer text is
   * some other container, not the value).
   */
  function valueFor(labelEl) {
    for (let el = labelEl, i = 0; el && i < 3; el = el.parentElement, i++) {
      const v = el.nextElementSibling;
      const text = v ? G.cellText(v) : "";
      if (text && text.length <= 40 && parseGb(text) !== null) return v;
    }
    return null;
  }

  function pass(grids = G.scan()) {
    // Device lists with a Free storage column.
    for (const { el: gridEl, cols: c } of grids) {
      const col = c.find(LABEL_RE);
      if (!col) continue;
      const unit = col.label.match(/\((gb|mb)\)/)?.[1] || "";
      for (const row of G.rowsOf(gridEl)) {
        const cell = G.cellFor(G.cellsOf(row), col, c);
        if (cell) mark(cell, parseGb(G.cellText(cell), unit));
      }
    }
    // Label and value pairs (device overview, hardware details).
    const walker = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (LABEL_RE.test(n.nodeValue.trim()) && !n.parentElement?.closest("[role='columnheader'], th")
        ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
    });
    while (walker.nextNode()) {
      const v = valueFor(walker.currentNode.parentElement);
      if (v) mark(v, parseGb(G.cellText(v)));
    }
  }

  function removeAll() {
    document.querySelectorAll(`.${ICON}`).forEach((el) => el.remove());
    document.querySelectorAll(`[${ATTR}]`).forEach((el) => el.removeAttribute(ATTR));
  }

  const CSS = `
    [${ATTR}] { font-weight: 600; }
    [${ATTR}="orange"] { color: #c76a00 !important; }
    [${ATTR}="red"] { color: #cf222e !important; }
    .${ICON} { display: inline-flex; vertical-align: -1px; margin-right: 4px; cursor: help; }
    :root[data-ie-dark] { /* the portal's dark theme (kit.js markTheme) */
      [${ATTR}="orange"] { color: #f0a030 !important; }
      [${ATTR}="red"] { color: #f85149 !important; }
    }`;

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.storageFlags = { parseGb, level, mark, valueFor, pass, removeAll };

  const ensureStyles = styleOnce(CSS);
  feature("freeStorageFlags", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      removeAll();
    },
    onChange(changes) {
      if (changes["ie.prefs"]) pass(); // new thresholds
    },
  });
})();
