// Runs on intune.microsoft.com (top frame, after kit.js). The portal signs in with MSAL, which
// caches access tokens in this page's web storage. After consent, this finds the cached Microsoft
// Graph access tokens and passes them to the service worker. Refresh tokens, ID tokens and
// account entries are never parsed or sent.

(function () {
  const GRAPH_APP_ID = "00000003-0000-0000-c000-000000000000";
  const sent = new Set();

  function jwtPayload(jwt) {
    try {
      const part = jwt.split(".")[1].replace(/-/g, "+").replace(/_/g, "/");
      return JSON.parse(atob(part));
    } catch {
      return null;
    }
  }

  function isGraphAccessToken(entry) {
    if (entry?.credentialType !== "AccessToken" || typeof entry.secret !== "string") return false;
    const aud = String(jwtPayload(entry.secret)?.aud || "");
    return aud === GRAPH_APP_ID || aud.includes("graph.microsoft.com");
  }

  function scan() {
    for (const store of [window.sessionStorage, window.localStorage]) {
      for (let i = 0; i < store.length; i++) {
        const raw = store.getItem(store.key(i));
        // Cheap pre-filter so only MSAL access-token entries are ever parsed.
        if (!raw || raw[0] !== "{" || !raw.includes('"AccessToken"')) continue;
        let entry;
        try { entry = JSON.parse(raw); } catch { continue; }
        if (!isGraphAccessToken(entry) || sent.has(entry.secret)) continue;
        sent.add(entry.secret);
        try {
          chrome.runtime.sendMessage({ type: "token/seen", token: entry.secret }).catch(() => {});
        } catch {
          // Extension was reloaded; this old content script is orphaned.
        }
      }
    }
  }

  function start() {
    scan();
    // MSAL often writes the Intune-capable token a few seconds after the first one, then renews
    // tokens roughly hourly, so check briefly at speed and then once a minute.
    let quick = 0;
    const burst = setInterval(() => { scan(); if (++quick >= 10) clearInterval(burst); }, 3000);
    setInterval(() => {
      if (document.visibilityState !== "visible") return;
      if (sent.size > 100) sent.clear();
      scan();
    }, 60000);
  }

  globalThis.IEKit.whenConsented(start);
})();
