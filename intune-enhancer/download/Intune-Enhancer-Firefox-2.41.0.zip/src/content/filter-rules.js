// Filter rule on hover: wherever the portal shows an assignment filter's name in a "Filter"
// column, add a small info icon whose tooltip is the filter's rule and platform, so you can see
// what the filter actually matches without opening it.
//
// Display only. The filter list comes from the service worker (one Graph call, cached for
// 30 minutes there).

(function () {
  if (window.__ieFilterRules) return;
  window.__ieFilterRules = true;

  const { feature, styleOnce, onPass, send, retrier, grid: G, ADDED } = globalThis.IEKit;
  const CLASS = "ie-filter-rule";
  const FILTER_COL_RE = /^(filter|filters|filter name|assignment filter|assignment filters)$/;

  let unwatch = null;
  const FRESH_MS = 30 * 60 * 1000; // same as the worker's cache: re-read after this
  let filters = null; // Map(lower-case name -> { name, rule, platform })
  let loadedAt = 0;
  let loading = false;

  /** "Include: Corporate devices" or "Corporate devices (Include)" -> "corporate devices". Pure. */
  function filterKey(text) {
    return String(text || "")
      .replace(/^(include|exclude|included|excluded)\s*:\s*/i, "")
      .replace(/\s*\((include|exclude|included|excluded)\)\s*$/i, "")
      .trim()
      .toLowerCase();
  }

  /** Tooltip text for a filter. Pure. */
  function tooltip(f) {
    return `Filter "${f.name}"${f.platform ? ` (${f.platform})` : ""}\n\n${f.rule || "(no rule)"}\n${ADDED}`;
  }

  function draw(cell, f) {
    let icon = cell.querySelector(`.${CLASS}`);
    if (!f) { icon?.remove(); return; }
    if (!icon) {
      icon = document.createElement("span");
      icon.className = CLASS;
      icon.setAttribute("role", "img");
      icon.innerHTML = '<svg viewBox="0 0 16 16" width="13" height="13" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.5"><circle cx="8" cy="8" r="6.3"/><path d="M8 7.2v4" stroke-linecap="round"/><circle cx="8" cy="4.9" r=".6" fill="currentColor"/></svg>';
      (cell.querySelector(".ms-DetailsRow-cellContent") || cell).appendChild(icon);
    }
    const text = tooltip(f);
    if (icon.title !== text) {
      icon.title = text;
      icon.setAttribute("aria-label", text);
    }
  }

  function pass(grids = G.scan()) {
    const lists = grids.filter(({ cols }) => cols.find(FILTER_COL_RE));
    if (!lists.length) return; // no Filter column on this page: nothing to fetch or draw
    if (!filters) { load(); return; }
    if (Date.now() - loadedAt > FRESH_MS) load(); // keep drawing the old list until the new one arrives
    for (const { el: gridEl, cols } of lists) {
      const col = cols.find(FILTER_COL_RE);
      for (const row of G.rowsOf(gridEl)) {
        const cell = G.cellFor(G.cellsOf(row), col, cols);
        if (cell) draw(cell, filters.get(filterKey(G.cellText(cell))) || null);
      }
    }
  }

  // Only redraw while running: the filter list can arrive after the feature was switched off.
  const passIfRunning = () => { if (unwatch) pass(); };
  const RETRY_MS = 15000; // no session yet: ask again after this
  let waitUntil = 0; // after a failure, page changes (scrolling) don't ask again before the retry
  const retry = retrier(RETRY_MS, passIfRunning);
  const later = () => { waitUntil = Date.now() + RETRY_MS; retry.schedule(); };

  function load() {
    if (loading || Date.now() < waitUntil) return;
    loading = true;
    send({ type: "filters/list" }).then((res) => {
      loading = false;
      if (!res?.ok) { later(); return; }
      filters = new Map((res.filters || []).map((f) => [f.name.toLowerCase(), f]));
      loadedAt = Date.now();
      passIfRunning();
    }, () => {
      loading = false;
      // No answer (the worker restarted): ask again, unless this script outlived a reload of the extension.
      if (globalThis.chrome?.runtime?.id) later();
    });
  }

  const CSS = `
    .${CLASS} { display: inline-flex; vertical-align: middle; margin-left: 6px; color: #1f5fbf; cursor: help; }
    :root[data-ie-dark] .${CLASS} { color: #8ab4ff; }`;

  const ensureStyles = styleOnce(CSS);
  feature("filterRuleHints", {
    start() {
      ensureStyles();
      unwatch = onPass(pass);
    },
    stop() {
      unwatch?.();
      unwatch = null;
      retry.cancel();
      filters = null; // re-read on next start, in case filters changed
      document.querySelectorAll(`.${CLASS}`).forEach((el) => el.remove());
    },
  });

  if (globalThis.__IE_TEST__) globalThis.__IE_TEST__.filterRules = { filterKey, tooltip, draw };
})();
