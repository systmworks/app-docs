// Status pills on Intune lists, after each item's name: how many devices it worked on and failed on,
// in green and red (grey when zero), from Intune's own reports (which can lag by a few hours).
//   - App install status: app lists (All apps, Windows apps...); clicking opens the app (Ctrl+click: new tab).
//   - Policy status: the Configuration list; succeeded, and failed (error or conflict).
//
// Display only. Counts come from the service worker (cached for 30 minutes there), in batches.

(function () {
  if (window.__ieAppStatus) return;
  window.__ieAppStatus = true;

  const { feature, choice, styleOnce, onPass, send, clickable, lookups, grid: G, rules, pillCss, ADDED, GUID } = globalThis.IEKit;
  const CLASS = "ie-app-status";
  const idIn = (names) => new RegExp(`(?:${names})(?:/|=|%2f|%3d)(${GUID})`, "i");

  const LISTS = {
    app: {
      pref: "appInstallStatus",
      type: "apps/status",
      kind: "app", // which Name column rules.listName looks for
      idRe: idIn("appId"),
      worked: "Installed on",
      report: "Intune's app status report",
      open: "app", // clicking opens it through portal/open
    },
    policy: {
      pref: "policyStatus",
      type: "policies/status",
      kind: "policy",
      idRe: idIn("policyId|configurationId"),
      worked: "Succeeded on",
      failedNote: " (error or conflict)",
      report: "Intune's device status report for the policy",
      open: null, // the pill sits in the name's own link, which opens the policy
    },
  };


  function statusPills(L) {
    let unwatch = null;
    // Counts by item key, retried while there's no session yet.
    // Asked again after 30 minutes (the worker keeps them as long), so a long-open tab picks up new installs.
    const lookup = lookups({ type: L.type, field: "status", retryMs: 15000, ttlMs: 30 * 60 * 1000, redraw: () => { if (unwatch) pass(); } });

    /** The Name column of this kind of list, or null. */
    const nameColumn = (cols) => rules.listName(cols, L.kind);

    /** Text and tooltip for an item's counts, or null for no pill ("failed": only items with failures). Pure. */
    function format(s, mode = "all") {
      if (!s || s.notFound || s.ambiguous) return null;
      const worked = s.installed ?? s.succeeded ?? 0;
      if (!worked && !s.failed) return null; // nothing worked or failed: nothing to say
      if (mode === "failed" && !s.failed) return null;
      const n = (v) => v.toLocaleString();
      return {
        installed: n(worked),
        some: worked > 0,
        failed: n(s.failed),
        bad: s.failed > 0,
        said: `${L.worked} ${n(worked)} device${worked === 1 ? "" : "s"}, failed on ${n(s.failed)}${L.failedNote || ""}`,
      };
    }

    /** Show, update or remove an item's pill, after the name in its cell. */
    function draw(cell, key, s, mode) {
      const f = format(s, mode);
      let pill = cell.querySelector(`.${CLASS}`);
      if (!f) { pill?.remove(); return; }
      const host = G.firstText(cell)?.parentElement || cell;
      // Already showing these counts in the right place: leave it (a scrolling list is redrawn often).
      const signature = `${s.id}|${f.installed}|${f.failed}`;
      if (pill && pill.parentElement === host && pill.dataset.signature === signature) return;
      if (!pill) {
        pill = document.createElement("span");
        if (L.open) {
          clickable(pill, "", (e) => {
            send({ type: "portal/open", kind: L.open, id: e.currentTarget.dataset.id, newTab: e.ctrlKey || e.metaKey }).catch(() => {});
          });
        }
        pill.className = CLASS;
        pill.dataset.list = L.pref;
      }
      if (pill.parentElement !== host) host.appendChild(pill); // new, or the portal redrew the name
      pill.dataset.signature = signature;
      pill.dataset.key = key;
      pill.dataset.id = s.id;
      pill.dataset.bad = String(f.bad);
      // Worked in green, failed in red, each grey when zero, so no symbols are needed.
      pill.replaceChildren(
        Object.assign(document.createElement("span"), { className: f.some ? "ok some" : "ok", textContent: f.installed }),
        " · ",
        Object.assign(document.createElement("span"), { className: "bad", textContent: f.failed }),
      );
      pill.setAttribute("aria-label", L.open ? `${f.said}. Open the ${L.open}` : f.said);
      pill.title = `${f.said} (${L.report}, which can lag by a few hours).` +
        `${L.open ? `\nClick to open the ${L.open} (Ctrl+click: new tab)` : ""}${ADDED}`;
    }

    function pass(grids = G.scan()) {
      const mode = choice(L.pref, ["all", "failed"]);
      const pending = new Map();
      for (const { el, cols } of grids) {
        const col = nameColumn(cols);
        if (!col) continue;
        for (const row of G.rowsOf(el)) {
          const cell = G.cellFor(G.cellsOf(row), col, cols);
          if (!cell) continue;
          const name = G.nameText(cell);
          const id = (G.attrText(row).match(L.idRe)?.[1] || "").toLowerCase();
          if (!id && !name) continue;
          const key = id ? `i:${id}` : `n:${name.toLowerCase()}`;
          const s = lookup.results.get(key);
          if (s) draw(cell, key, s, mode);
          else {
            const old = cell.querySelector(`.${CLASS}`);
            if (old && old.dataset.key !== key) old.remove(); // a recycled row showing another item
          }
          // An answer older than ttlMs keeps showing until the new one arrives.
          if (lookup.wanted(key)) pending.set(key, { key, id, name });
        }
      }
      if (pending.size) lookup.request([...pending.values()].slice(0, 40));
    }

    feature(L.pref, {
      start() {
        ensureStyles();
        unwatch = onPass(pass);
      },
      stop() {
        unwatch?.();
        unwatch = null;
        lookup.cancel();
        // Only this list's pills: the other kind may still be on.
        document.querySelectorAll(`.${CLASS}[data-list="${L.pref}"]`).forEach((el) => el.remove());
      },
      onChange(changes) {
        if (changes["ie.prefs"]) pass(); // all <-> failures only
      },
    });

    return { nameColumn, format, draw, pass };
  }

  // The shared pill look (kit.js pillCss), plus the worked and failed counts in green and red (grey when zero).
  const CSS = `
    ${pillCss(CLASS, { warn: '[data-bad="true"]', action: '[role="button"]' })}
    .${CLASS} { display: inline-block; }
    .${CLASS} .ok, .${CLASS} .bad { opacity: 0.6; }
    .${CLASS} .ok.some { color: #0b7a3b; font-weight: 600; opacity: 1; }
    .${CLASS}[data-bad="true"] .bad { color: #c4141f; opacity: 1; }
    :root[data-ie-dark] {
      .${CLASS} .ok, .${CLASS} .bad { opacity: 1; }
      .${CLASS} .ok.some { color: #3ddc84; }
      .${CLASS}[data-bad="true"] .bad { color: #ff6b6b; }
    }`;
  const ensureStyles = styleOnce(CSS);

  const apps = statusPills(LISTS.app);
  const policies = statusPills(LISTS.policy);

  if (globalThis.__IE_TEST__) Object.assign(globalThis.__IE_TEST__, { appStatus: apps, policyStatus: policies });
})();
