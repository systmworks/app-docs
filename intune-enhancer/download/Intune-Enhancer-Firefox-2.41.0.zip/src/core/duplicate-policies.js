// Pairs of policies that set the same settings to the same values, whether or not they reach the same
// groups. Intune flags a "Conflict" only when values differ on one device, so these overlaps often go
// unnoticed. Values that differ are not listed here: that is a conflict, not a duplicate.
// Reads the policy index only; pure, so it is tested offline.

import { policyRef } from "./portal-links.js";

/** Two policies that are not identical are listed once they share at least this many setting values. */
const MIN_SHARED = 3;
/** Pairs kept in the answer; the rest are counted. */
const MAX_PAIRS = 300;
const EXAMPLE_COUNT = 5;
/**
 * A setting value set by more policies than this (a tenant-wide baseline value) isn't used to pair policies up:
 * every pair of N holders would be counted, N * (N - 1) / 2 of them. Identical policies are still found (by
 * their whole set of values), and the number of values left out is reported.
 */
const MAX_HOLDERS = 100;

const settingKey = (s) => `${s.d}\u0000${String(s.v ?? "")}`;
const assignmentKey = (policy) => (policy.assignments || [])
  .map((a) => `${a.kind}:${a.groupId || ""}:${a.filterId || ""}`).sort().join("|");

/**
 * @param index  the policy index ({ policies: [{ id, name, type, settings, assignments }] })
 * @returns { pairs, total, skippedValues } where each pair is { a, b, shared, sizeA, sizeB, match, sameAssignments, sample };
 *          match is "identical" (same settings and values), "inside" (all of one is in the other) or "partial";
 *          skippedValues counts the values set by more than MAX_HOLDERS policies, left out of "Same settings"
 */
export function duplicatePolicies(index) {
  const withSettings = (index?.policies || []).filter((p) => !p.assignmentsUnknown && Array.isArray(p.settings) && p.settings.length);
  const keysOf = new Map(withSettings.map((p) => [p, [...new Set(p.settings.map(settingKey))].sort()]));
  const signatures = new Map([...keysOf].map(([p, keys]) => [p, keys.join("\u0001")]));
  const signature = (p) => signatures.get(p);
  // Setting value -> the policies that set it, so only policies sharing something are ever compared.
  const holders = new Map();
  for (const p of withSettings) {
    for (const k of keysOf.get(p)) {
      if (!holders.has(k)) holders.set(k, []);
      holders.get(k).push(p);
    }
  }
  const counts = new Map(); // "idA\u0000idB" -> { a, b, keys: [] }
  const pairOf = (x, y) => (x.id < y.id ? [x, y] : [y, x]);
  // Identical policies, found by their whole set of values (so a baseline value left out below can't hide them).
  const bySignature = new Map();
  for (const p of withSettings) {
    if (!bySignature.has(signature(p))) bySignature.set(signature(p), []);
    bySignature.get(signature(p)).push(p);
  }
  for (const list of bySignature.values()) {
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const [a, b] = pairOf(list[i], list[j]);
        counts.set(`${a.id}\u0000${b.id}`, { a, b, keys: keysOf.get(a) });
      }
    }
  }
  let skippedValues = 0;
  for (const [k, list] of holders) {
    if (list.length > MAX_HOLDERS) { skippedValues++; continue; }
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        if (signature(list[i]) === signature(list[j])) continue; // already listed as identical
        const [a, b] = pairOf(list[i], list[j]);
        const id = `${a.id}\u0000${b.id}`;
        if (!counts.has(id)) counts.set(id, { a, b, keys: [] });
        counts.get(id).keys.push(k);
      }
    }
  }

  const names = new Map(withSettings.flatMap((p) => p.settings.map((s) => [settingKey(s), s.n])));
  const pairs = [];
  for (const { a, b, keys } of counts.values()) {
    const sizeA = keysOf.get(a).length;
    const sizeB = keysOf.get(b).length;
    const shared = keys.length;
    const match = signature(a) === signature(b) ? "identical" : shared === Math.min(sizeA, sizeB) ? "inside" : "partial";
    if (match !== "identical" && shared < MIN_SHARED) continue;
    pairs.push({
      a: { id: a.id, name: a.name, ...policyRef(a) }, b: { id: b.id, name: b.name, ...policyRef(b) },
      shared, sizeA, sizeB, match, sameAssignments: assignmentKey(a) === assignmentKey(b),
      sample: keys.slice(0, EXAMPLE_COUNT).map((k) => `${names.get(k)} = ${k.split("\u0000")[1]}`),
    });
  }
  const order = { identical: 0, inside: 1, partial: 2 };
  pairs.sort((x, y) => order[x.match] - order[y.match] || y.shared - x.shared || x.a.name.localeCompare(y.a.name));
  return { pairs: pairs.slice(0, MAX_PAIRS), total: pairs.length, skippedValues };
}
