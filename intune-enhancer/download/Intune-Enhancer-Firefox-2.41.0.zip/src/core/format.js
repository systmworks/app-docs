// Small text and number formatters shared by the report modules. Pure.

const BYTES_PER_GIB = 1024 ** 3;

/** Bytes as a number of GB (1024 ** 3 bytes). */
export const gb = (bytes) => Number(bytes) / BYTES_PER_GIB;

/** Bytes as "12.3 GB". */
export const gbText = (bytes) => `${gb(bytes).toFixed(1)} GB`;

/** The date part ("2025-01-31") of an ISO date-time, or "" when it is missing or the 1970 placeholder. */
export const day = (iso) => (Date.parse(iso) > 864e5 ? String(iso).slice(0, 10) : "");

/** "windowsAzureADJoin" -> "Windows Azure AD Join". */
export const words = (text) => String(text).replace(/([a-z])([A-Z])/g, "$1 $2").replace(/([A-Z])([A-Z][a-z])/g, "$1 $2").replace(/^./, (c) => c.toUpperCase());
