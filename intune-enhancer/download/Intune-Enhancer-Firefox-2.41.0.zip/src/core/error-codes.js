// Error code lookup: turns what a technician reads off a screen or log (0x80070002, 80070002, -2147024894, 2, AADSTS50058,
// or a few words) into the matching entries of Microsoft's published error tables (data/error-codes.js, built by
// tools/build-error-codes.py). Pure; works offline. The data is large, so the workspace loads it on first use
// (workspace/lazy-data.js) and passes the index in.

const EC_FACILITY_WIN32 = 0x8007; // an HRESULT 0x8007xxxx is the Win32 error xxxx
const EC_MAX_TEXT_RESULTS = 40;

/** Rows as objects, grouped by key. */
export function buildErrorIndex(rows) {
  const byKey = new Map();
  const list = rows.map(([key, code, name, desc, fix, source]) => ({ key, code, name, desc, fix, source }));
  for (const r of list) {
    if (!byKey.has(r.key)) byKey.set(r.key, []);
    byKey.get(r.key).push(r);
  }
  return { byKey, list };
}

const ecHex = (n) => (n >>> 0).toString(16).toUpperCase().padStart(8, "0");

/** The keys a 32-bit value can be filed under: itself, and the Win32 error inside a 0x8007xxxx HRESULT (or a bare small number). */
function numberKeys(n, note) {
  const out = [{ key: `h:${ecHex(n)}`, label: `0x${ecHex(n)}` }];
  if ((n >>> 16) === EC_FACILITY_WIN32) out.push({ key: `w:${n & 0xffff}`, label: `Win32 error ${n & 0xffff} (an 0x8007xxxx code is a Win32 error)` });
  else if (n <= 0xffff) out.push({ key: `w:${n}`, label: `Win32 error ${n}` });
  return note ? out.map((o) => ({ ...o, label: `${o.label} - ${note}` })) : out;
}

/** What a typed code could mean: [{ key, label }], most likely first. Empty when the text does not look like a code. Pure. */
export function codeInterpretations(text) {
  const t = String(text ?? "").trim().replace(/[.,;:]+$/, "");
  let m;
  if ((m = /^AADSTS(\d{3,7})$/i.exec(t))) return [{ key: `a:${Number(m[1])}`, label: `AADSTS${Number(m[1])}` }];
  if ((m = /^0x([0-9a-f]{1,8})$/i.exec(t))) return numberKeys(parseInt(m[1], 16));
  if ((m = /^-(\d{1,10})$/.exec(t)) && Number(m[1]) <= 2 ** 31) return numberKeys((-Number(m[1])) >>> 0, "signed number");
  if (/^[0-9a-f]{8}$/i.test(t)) {
    const out = numberKeys(parseInt(t, 16));
    if (/^\d+$/.test(t) && Number(t) < 2 ** 32) out.push(...numberKeys(Number(t), "as a decimal number"));
    return out;
  }
  if ((m = /^(\d{1,7})$/.exec(t))) {
    const n = Number(m[1]);
    const out = [];
    if (n <= 0xffff) out.push({ key: `w:${n}`, label: `Win32 error ${n}` });
    if (m[1].length >= 4) out.push({ key: `a:${n}`, label: `AADSTS${n}` });
    if (m[1].length >= 5 && n < 2 ** 32) out.push({ key: `h:${ecHex(n)}`, label: `0x${ecHex(n)}` });
    return out;
  }
  return [];
}

/** Every error code written in a longer text (a failure message, a log line), as strings that codeInterpretations understands. Pure. */
export function codesInText(text) {
  const found = String(text ?? "").match(/AADSTS\d{3,7}|0x[0-9a-f]{5,8}\b|(?<![\w-])-\d{9,10}(?!\d)|\b[8c][0-9a-f]{7}\b(?=[^\w]|$)/gi) || [];
  const out = [];
  for (const f of found) if (!out.some((o) => o.toLowerCase() === f.toLowerCase())) out.push(f);
  return out;
}

/**
 * Look something up. A code gives its entries (several pages can describe one code); anything else is a words search over
 * names, meanings and fixes. -> { kind: "code"|"words"|"empty", interpretations, matches: [{...row, via}], more: number }
 */
export function lookupError(text, index) {
  const t = String(text ?? "").trim();
  if (!t) return { kind: "empty", interpretations: [], matches: [], more: 0 };
  const interpretations = codeInterpretations(t);
  const matches = [];
  const seen = new Set();
  for (const it of interpretations) {
    for (const r of index.byKey.get(it.key) || []) {
      const id = `${r.key}|${r.name}|${r.source}`;
      if (!seen.has(id)) { seen.add(id); matches.push({ ...r, via: it.label }); }
    }
  }
  if (interpretations.length) return { kind: "code", interpretations, matches, more: 0 };
  const words = t.toLowerCase().split(/\s+/).filter(Boolean);
  const hits = [];
  for (const r of index.list) {
    const head = `${r.code} ${r.name}`.toLowerCase();
    const all = `${head} ${r.desc} ${r.fix}`.toLowerCase();
    if (!words.every((w) => all.includes(w))) continue;
    hits.push({ ...r, via: "", rank: words.every((w) => head.includes(w)) ? 0 : 1 });
  }
  hits.sort((a, b) => a.rank - b.rank || a.key.localeCompare(b.key));
  return { kind: "words", interpretations: [], matches: hits.slice(0, EC_MAX_TEXT_RESULTS), more: Math.max(0, hits.length - EC_MAX_TEXT_RESULTS) };
}
