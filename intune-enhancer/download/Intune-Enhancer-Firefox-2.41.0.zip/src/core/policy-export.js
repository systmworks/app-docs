// One indexed policy written up for a change record: its details, assignments and settings, as
// Markdown and as CSV rows. Pure, so it is tested offline. Settings come from the policy index, so a
// type the index holds no settings for (apps, scripts, remediations) says so rather than showing none.

import { policyRef } from "./portal-links.js";

const exportDay = (iso) => String(iso || "").slice(0, 10);
/** One line of a Markdown table cell: line breaks flattened, pipes escaped. */
const exportCell = (text) => String(text ?? "").replace(/\s*\r?\n\s*/g, " ").replace(/\|/g, "\\|");

/** "Include: Sales (Intent: required; filter: Only Corporate)" for one normalised assignment. */
function exportAssignment(a, names, filters) {
  const group = (names[a.groupId] || a.groupId || "unknown group");
  const target = a.kind === "allDevices" ? "All devices" : a.kind === "allUsers" ? "All users"
    : a.kind === "exclude" ? `Exclude: ${group}` : a.kind === "include" ? `Include: ${group}` : "Other target";
  const extras = [];
  if (a.intent) extras.push(`intent ${a.intent}`);
  if (a.filterId) {
    const f = filters[String(a.filterId).toLowerCase()];
    extras.push(`filter ${a.filterType === "exclude" ? "excludes" : "includes"}: ${f?.name || a.filterId}`);
  }
  return extras.length ? `${target} (${extras.join("; ")})` : target;
}

/**
 * @param policy   an entry of the policy index
 * @param names    { lower-case group id: display name }
 * @param filters  { lower-case filter id: { name } }
 * @param describe optional (path) => { name, desc, since } | null: what a custom profile's CSP path is (csp-names.js)
 * @returns { title, markdown, rows } where rows is [Section, Name, Value, Path] for CSV, plus "What it does" when describe knew a path
 */
export function policyDocument(policy, names = {}, filters = {}, describe = null) {
  const ref = policyRef(policy);
  const info = [
    ["Type", ref.typeLabel],
    ...(policy.meta?.platforms ? [["Platform", policy.meta.platforms]] : []),
    ["Created", exportDay(policy.created)],
    ["Last modified", exportDay(policy.modified)],
    ["Id", policy.id],
  ].filter(([, v]) => v);
  const assignments = (policy.assignments || []).map((a) => exportAssignment(a, names, filters));
  const settings = policy.settings;
  const what = (st) => {
    const d = describe && String(st.p || "").startsWith("./") ? describe(st.p) : null;
    return d ? [d.name, d.since, d.desc].filter(Boolean).join(". ") : "";
  };
  const hasWhat = Boolean(settings?.some((st) => what(st)));

  const md = [`# ${policy.name}`, "", ...info.map(([k, v]) => `- ${k}: ${v}`), "", "## Assignments", ""];
  if (policy.assignmentsUnknown) md.push("Assignments couldn't be read.");
  else if (!assignments.length) md.push("Not assigned.");
  else md.push(...assignments.map((a) => `- ${a}`));
  md.push("", "## Settings", "");
  if (!settings) md.push(policy.settingsUnknown ? "Settings couldn't be read." : "Settings aren't indexed for this type of policy.");
  else if (!settings.length) md.push("No settings configured.");
  else if (hasWhat) md.push("| Setting | Value | Path | What it does |", "|---|---|---|---|", ...settings.map((s) => `| ${exportCell(s.n)} | ${exportCell(s.v)} | ${exportCell(s.p)} | ${exportCell(what(s))} |`));
  else md.push("| Setting | Value | Path |", "|---|---|---|", ...settings.map((s) => `| ${exportCell(s.n)} | ${exportCell(s.v)} | ${exportCell(s.p)} |`));

  const more = (cell) => (hasWhat ? [cell] : []);
  const rows = [
    ["Section", "Name", "Value", "Path", ...more("What it does")],
    ["Policy", "Name", policy.name, "", ...more("")],
    ...info.map(([k, v]) => ["Policy", k, v, "", ...more("")]),
    ...(policy.assignmentsUnknown ? [["Assignment", "Couldn't be read", "", "", ...more("")]]
      : assignments.length ? assignments.map((a) => ["Assignment", a, "", "", ...more("")]) : [["Assignment", "Not assigned", "", "", ...more("")]]),
    ...(settings || []).map((s) => ["Setting", s.n, s.v, s.p, ...more(what(s))]),
  ];
  return { title: policy.name, markdown: md.join("\n") + "\n", rows, hasSettings: Boolean(settings) };
}
