// Microsoft Graph client for the service worker. The extension's host permission on
// graph.microsoft.com means these fetches are not subject to CORS.
//
// The portal caches several Graph tokens, each with a different set of scopes. getTokens()
// supplies them best-first; a 401/403 moves on to the next one, and the first that works is
// reported back through onGood so it is tried first next time.

import { GRAPH_HOSTS, CLOUDS, DEFAULT_CLOUD } from "./clouds.js";

// Requests go to the signed-in cloud's Graph host (see createGraphClient's getHost); commercial by default.

/**
 * True only for https URLs on a known Graph host (commercial, GCC High or DoD); when `host` is given, only that one.
 * Every request goes through this check,
 * including the "next page" links Graph returns, so the extension cannot send a token or any
 * data to another host even if a response pointed somewhere else.
 */
export function isGraphUrl(url, host = "") {
  try {
    const u = new URL(url);
    return u.protocol === "https:" && GRAPH_HOSTS.includes(u.hostname) && (!host || u.hostname === host) && !u.username && !u.password && (u.port === "" || u.port === "443");
  } catch {
    return false;
  }
}

/**
 * The only POSTs the extension may send, all of which read: directory lookups by id and Intune's
 * report endpoints (which take their filter in a POST body). Everything else must be a GET, so the
 * read-only promise holds in code, not only by convention. `$batch` is allowed because each item
 * inside it is checked the same way.
 */
const READ_ONLY_POST = /^\/(?:deviceManagement\/reports\/get\w+|directoryObjects\/getByIds)$/;
const BATCH_PATH = /^\/(?:v1\.0|beta)\/\$batch$/;

function assertReadOnly(method, path) {
  const allowed = method === "GET" || BATCH_PATH.test(path) || READ_ONLY_POST.test(path.replace(/^\/(?:v1\.0|beta)/, ""));
  if (!allowed) throw graphError(`Blocked a ${method} request: the extension only reads (${String(path).slice(0, 100)})`, "BLOCKED_METHOD");
}

const TIMEOUT_MS = 30000;
const MAX_THROTTLE_RETRIES = 3;
// Answers worth asking again after a wait: throttled, or a gateway or service that is briefly unavailable. Not a
// 500: Intune's report endpoints answer some requests with a 500 every time, and callers retry those later.
const RETRY_STATUS = new Set([429, 502, 503, 504]);
// $batch calls in flight at once: much faster than one after another, and well inside Graph's
// limits (items it throttles are retried).
const PARALLEL_BATCHES = 4;
const GET_BY_IDS_LIMIT = 1000; // ids per directoryObjects/getByIds request
const MAX_PAGES = 500; // a safety stop for a paged list whose next links never end

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Run fn over items with at most `limit` running at once. After a failure nothing new starts; the
 * ones already running finish, then the first error is thrown.
 */
async function eachLimited(items, limit, fn) {
  let next = 0;
  let failed = null;
  const run = async () => {
    while (!failed && next < items.length) {
      try { await fn(items[next++]); } catch (e) { failed ||= e; }
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
  if (failed) throw failed;
}

/** The error a stopped job throws, so callers can tell a Stop from a failure. */
export const stoppedError = () => Object.assign(new Error("Stopped."), { code: "CANCELLED" });

/** A $batch item that failed for a passing reason (throttled, server error, no answer): worth asking again. */
export const isTransient = (r) => !r || r.status === 429 || r.status >= 500;

const said = new Set();

/**
 * Log to the service worker's console once per key, so a Graph refusal that would otherwise leave no
 * pill and no trace is visible without flooding the console. level is a console method ("warn", "info").
 */
export function sayOnce(key, level, ...message) {
  if (said.has(key)) return;
  said.add(key);
  console[level](...message);
}

/** A string as an OData literal, for use inside single quotes in a $filter. */
export const odataQuote = (s) => String(s).replace(/'/g, "''");

/**
 * Give each item known only by name an id, by exact display name lookups in one batch. urlFor(name)
 * is the $filter query for that name (ids only, a handful of hits), relative to the version root.
 * An item found exactly once gets its `id`; the others are answered here, by item key:
 * { retry: true } (Graph was busy), { ambiguous: n } or { notFound: true }.
 */
export async function resolveIdsByName(graph, items, urlFor) {
  const answers = {};
  const byName = items.filter((i) => !i.id && i.name);
  if (!byName.length) return answers;
  const res = await graph.batch(byName.map((i, n) => ({ id: `n${n}`, url: urlFor(i.name) })));
  byName.forEach((i, n) => {
    const r = res.get(`n${n}`);
    if (isTransient(r)) { answers[i.key] = { retry: true }; return; }
    const found = r.body?.value || [];
    if (found.length === 1) i.id = found[0].id;
    else answers[i.key] = found.length ? { ambiguous: found.length } : { notFound: true };
  });
  return answers;
}

function graphError(message, code, extra = {}) {
  return Object.assign(new Error(message), { code }, extra);
}

/**
 * @param {() => string[]} getTokens  candidate bearer tokens, best first
 * @param {(token: string) => void} onGood  told which token succeeded
 * @param {() => string} getHost  the Graph host for the signed-in cloud
 */
export function createGraphClient(getTokens, onGood = () => {}, getHost = () => CLOUDS[DEFAULT_CLOUD].graphHost) {
  /**
   * One request, body included, inside the time limit: a body that stalls after the headers arrive is cut off too.
   * @returns { status, ok, headers, text }
   */
  async function once(url, init, token) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);
    try {
      const res = await fetch(url, {
        ...init,
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
          ...(init.headers || {}),
        },
      });
      // An error answer whose body can't be read still reports its status; a good one must have its body.
      const text = await res.text().catch((e) => { if (res.ok) throw e; return ""; });
      return { status: res.status, ok: res.ok, headers: res.headers, text };
    } catch (e) {
      if (e?.name === "AbortError") throw graphError(`Graph request timed out: ${url}`, "TIMEOUT");
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  async function request(path, init = {}) {
    const tokens = getTokens();
    if (!tokens.length) {
      throw graphError("No Intune session yet. Open the Intune admin center and sign in.", "NO_TOKEN");
    }
    const host = getHost();
    const url = path.startsWith("/") ? `https://${host}${path}` : path;
    if (!isGraphUrl(url, host)) {
      throw graphError(`Blocked a request to a non-Graph address: ${String(url).slice(0, 100)}`, "BLOCKED_HOST");
    }
    assertReadOnly((init.method || "GET").toUpperCase(), new URL(url).pathname);
    let denied = null;

    for (const token of tokens) {
      let throttles = 0;
      for (;;) {
        const res = await once(url, init, token);
        if (RETRY_STATUS.has(res.status)) {
          if (++throttles > MAX_THROTTLE_RETRIES) {
            throw graphError(`Graph is busy or unavailable (${res.status}). Try again in a few minutes.`, "THROTTLED", { status: res.status });
          }
          const wait = Number(res.headers.get("Retry-After")) || 2 ** throttles;
          await sleep(Math.min(wait, 60) * 1000);
          continue;
        }
        if (res.status === 401 || res.status === 403) {
          // Keep Graph's own message: Intune reports RBAC denials as 401 and names the cause.
          let detail = "";
          try { detail = JSON.parse(res.text)?.error?.message || ""; } catch { detail = res.text.slice(0, 200); }
          denied = graphError(`Graph ${res.status}${detail ? `: ${detail}` : ""}`, "FORBIDDEN", { status: res.status });
          break; // try the next token
        }
        if (!res.ok) {
          throw graphError(`Graph ${res.status} on ${path}: ${res.text.slice(0, 300)}`, "HTTP", { status: res.status });
        }
        onGood(token);
        return res.status === 204 || !res.text ? null : JSON.parse(res.text);
      }
    }
    throw denied;
  }

  /**
   * Run many reads through Graph's JSON batching, 20 per call. Each request is
   * { id, url, headers?, body? } with url relative to the version root (e.g. "/deviceManagement/...");
   * a body makes it a POST (Intune's report endpoints read with POST). Items Graph throttles inside a
   * batch are retried. Resolves to Map(id -> { status, body }).
   */
  async function batch(requests, { onProgress = () => {}, shouldStop = () => false } = {}) {
    const out = new Map();
    for (const r of requests) assertReadOnly(r.body ? "POST" : "GET", r.url.split("?")[0]);
    let queue = requests.map((r) => (r.body
      ? { id: String(r.id), method: "POST", url: r.url, headers: { "Content-Type": "application/json", ...r.headers }, body: r.body }
      : { id: String(r.id), method: "GET", url: r.url, headers: r.headers }));
    let attempts = 0;
    while (queue.length && attempts++ <= MAX_THROTTLE_RETRIES) {
      const retry = [];
      let wait = 0;
      const chunks = [];
      for (let i = 0; i < queue.length; i += 20) chunks.push(queue.slice(i, i + 20));
      await eachLimited(chunks, PARALLEL_BATCHES, async (chunk) => {
        if (shouldStop()) throw stoppedError();
        const res = await request("/beta/$batch", { method: "POST", body: JSON.stringify({ requests: chunk }) });
        for (const r of res?.responses || []) {
          if (RETRY_STATUS.has(r.status)) {
            retry.push(chunk.find((c) => c.id === String(r.id)));
            wait = Math.max(wait, Number(r.headers?.["Retry-After"]) || 2 ** attempts);
          } else {
            out.set(String(r.id), { status: r.status, body: r.body });
          }
        }
        onProgress(out.size, requests.length);
      });
      queue = retry.filter(Boolean);
      if (queue.length) await sleep(Math.min(wait, 60) * 1000);
    }
    for (const r of queue) out.set(r.id, { status: 429, body: { error: { message: "Throttled" } } });
    return out;
  }

  /** Follow @odata.nextLink, calling onPage with each page's items. */
  async function pages(path, onPage) {
    let next = path;
    for (let n = 0; next && n < MAX_PAGES; n++) {
      const page = await request(next);
      await onPage(Array.isArray(page?.value) ? page.value : []);
      next = page?.["@odata.nextLink"] || null;
    }
    if (next) throw graphError(`This list has more than ${MAX_PAGES} pages, so it was not read in full.`, "TOO_MANY_PAGES");
  }

  return {
    get: (path, headers) => request(path, headers ? { headers } : {}),
    post: (path, body) => request(path, { method: "POST", body: JSON.stringify(body) }),
    /** The directory objects (of the given types, e.g. ["user"]) for these ids, 1,000 per request. */
    async getByIds(ids, types) {
      const found = [];
      for (let i = 0; i < ids.length; i += GET_BY_IDS_LIMIT) {
        const res = await request("/v1.0/directoryObjects/getByIds", {
          method: "POST", body: JSON.stringify({ ids: ids.slice(i, i + GET_BY_IDS_LIMIT), types }),
        });
        found.push(...(res?.value || []));
      }
      return found;
    },
    batch,
    pages,
    /** All items from a paged list. */
    async all(path) {
      const items = [];
      await pages(path, (page) => { items.push(...page); });
      return items;
    },
  };
}
