// Tenant health: the tokens, certificates and connectors Intune quietly depends on, with days left.
// Each source is read on its own, so a role that can't read one still sees the others ("couldn't check").

const WARN_DAYS = 30; // "expires soon" at or under this many days left

const SOURCES = [
  { key: "apple", area: "Apple push certificate", url: "/deviceManagement/applePushNotificationCertificate" },
  { key: "vpp", area: "Apple VPP token", url: "/deviceAppManagement/vppTokens" },
  { key: "ade", area: "Apple enrolment (ADE) token", url: "/deviceManagement/depOnboardingSettings" },
  { key: "play", area: "Managed Google Play", url: "/deviceManagement/androidManagedStoreAccountEnterpriseSettings" },
  { key: "ndes", area: "Certificate connector (NDES)", url: "/deviceManagement/ndesConnectors" },
  { key: "domainjoin", area: "Domain join connector (hybrid Autopilot)", url: "/deviceManagement/domainJoinConnectors" },
];

const DAY_MS = 24 * 60 * 60 * 1000;
const STALE_CONNECTOR_DAYS = 7; // a connector silent for longer than this needs a look
const STALE_DOMAIN_JOIN_DAYS = 1; // the domain join connector polls all the time; hybrid Autopilot fails while it is silent

/** Whole days from now until `iso` (negative once past), or null without a date. */
function daysUntil(iso, now) {
  const t = Date.parse(iso || "");
  return Number.isFinite(t) ? Math.floor((t - now) / DAY_MS) : null;
}

/** A row for something with an expiry date. */
function expiring(area, name, iso, now, detail = "") {
  const daysLeft = daysUntil(iso, now);
  if (daysLeft === null) return { area, name, status: "attention", expires: "", daysLeft: null, detail: detail || "No expiry date reported" };
  const status = daysLeft < 0 ? "expired" : daysLeft <= WARN_DAYS ? "soon" : "ok";
  return { area, name, status, expires: iso, daysLeft, detail };
}

const noDateRow = (area, name, status, detail) => ({ area, name, status, expires: "", daysLeft: null, detail });

/** Turn one source's answer into rows. */
function rowsFor(source, r, now) {
  const { area } = source;
  if (!r || r.status === 403) return [noDateRow(area, "", "error", "Couldn't check: the signed-in role can't read this")];
  if (r.status === 404) return [noDateRow(area, "", "none", "Not set up")];
  if (r.status !== 200) return [noDateRow(area, "", "error", `Couldn't check (HTTP ${r.status})`)];
  const body = r.body || {};
  const list = Array.isArray(body.value) ? body.value : [];
  switch (source.key) {
    case "apple":
      return [expiring(area, body.appleIdentifier || "", body.expirationDateTime, now)];
    case "vpp":
      return list.length ? list.map((t) => expiring(area, t.organizationName || t.displayName || "", t.expirationDateTime, now,
        t.state && t.state !== "valid" ? `State: ${t.state}` : "")) : [noDateRow(area, "", "none", "Not set up")];
    case "ade":
      return list.length ? list.map((t) => expiring(area, t.tokenName || t.appleIdentifier || "", t.tokenExpirationDateTime, now)) : [noDateRow(area, "", "none", "Not set up")];
    case "play": {
      const bound = body.bindStatus === "boundAndValidated" || body.bindStatus === "bound";
      if (body.bindStatus === "notBound" || !body.bindStatus) return [noDateRow(area, "", "none", "Not set up")];
      return [noDateRow(area, body.ownerUserPrincipalName || "", bound ? "ok" : "attention", `Binding: ${body.bindStatus}`)];
    }
    case "ndes":
      return list.length ? list.map((c) => {
        const silent = daysUntil(c.lastConnectionDateTime, now);
        const quiet = silent === null || -silent > STALE_CONNECTOR_DAYS || c.state === "inactive";
        return noDateRow(area, c.displayName || "", quiet ? "attention" : "ok",
          `State: ${c.state || "unknown"}; last contact ${c.lastConnectionDateTime ? new Date(c.lastConnectionDateTime).toLocaleDateString() : "never"}`);
      }) : [noDateRow(area, "", "none", "Not set up")];
    case "domainjoin":
      return list.length ? list.map((c) => {
        const silent = daysUntil(c.lastConnectionDateTime, now);
        const quiet = silent === null || -silent > STALE_DOMAIN_JOIN_DAYS || (c.state && c.state !== "active");
        return noDateRow(area, c.displayName || c.serverName || "", quiet ? "attention" : "ok",
          `State: ${c.state || "unknown"}; last contact ${c.lastConnectionDateTime ? new Date(c.lastConnectionDateTime).toLocaleString() : "never"}${c.version ? `; version ${c.version}` : ""}`);
      }) : [noDateRow(area, "", "none", "Not set up (hybrid Autopilot needs one)")];
    default:
      return [];
  }
}

const ORDER = { expired: 0, soon: 1, attention: 2, ok: 3, none: 4, error: 5 };

/** Rows from batch answers (Map(key -> { status, body })), worst first, soonest expiry first. */
export function healthRows(answers, now = Date.now()) {
  return SOURCES.flatMap((s) => rowsFor(s, answers.get(s.key), now))
    .sort((a, b) => ORDER[a.status] - ORDER[b.status] || (a.daysLeft ?? Infinity) - (b.daysLeft ?? Infinity) || a.area.localeCompare(b.area));
}

/** Read every source in one batch. -> rows */
export async function tenantHealth(graph, now = Date.now()) {
  return healthRows(await graph.batch(SOURCES.map((s) => ({ id: s.key, url: s.url }))), now);
}
