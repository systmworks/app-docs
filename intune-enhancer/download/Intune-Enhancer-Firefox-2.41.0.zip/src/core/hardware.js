// Hardware report: the hardware facts Graph gives for each managed device. The device list holds only a
// few of them; memory and the rest of the hardware details are in each device's full record, so the
// report reads one record per device (batched) when asked. Only values Graph returned are kept, and a
// column nobody has a value for is left out, so nothing is invented. Pure apart from readHardware.

import { gb, day, words } from "./format.js";

const hwText = (value) => {
  const s = value === undefined || value === null ? "" : String(value).trim();
  return s === "" || s.toLowerCase() === "unknown" ? "" : s;
};
const hwGb = (bytes) => (Number(bytes) > 0 ? Math.round(gb(bytes) * 10) / 10 : "");
const hwNum = (value) => (value === undefined || value === null || value === "" || !Number.isFinite(Number(value)) ? "" : Number(value));
const hwWords = (value) => words(hwText(value));
const hwHardware = (rec) => rec?.hardwareInformation || {};

/** Every column the report can show: [key, label, number?, read from a managedDevice record]. */
/** Where the Hardware report's saved rows live (one entry per tenant); "Clear stored data" removes this prefix. */
export const HARDWARE_KEY = "hardware|";
export const hardwareKey = (tid) => `${HARDWARE_KEY}${tid}`;

const HARDWARE_FIELDS = [
  { key: "name", label: "Device", get: (r) => hwText(r.deviceName) },
  { key: "user", label: "Primary user", get: (r) => hwText(r.userPrincipalName) },
  { key: "manufacturer", label: "Manufacturer", get: (r) => hwText(r.manufacturer) },
  { key: "model", label: "Model", get: (r) => hwText(r.model) },
  { key: "chassis", label: "Chassis", get: (r) => hwWords(r.chassisType) },
  { key: "serial", label: "Serial number", get: (r) => hwText(r.serialNumber) },
  { key: "os", label: "OS", get: (r) => hwText(r.operatingSystem) },
  { key: "osVersion", label: "OS version", get: (r) => hwText(r.osVersion) },
  { key: "edition", label: "OS edition", get: (r) => hwText(hwHardware(r).operatingSystemEdition) },
  { key: "arch", label: "Processor", get: (r) => hwText(r.processorArchitecture) },
  { key: "ramGb", label: "Memory (GB)", num: true, get: (r) => hwGb(r.physicalMemoryInBytes) },
  { key: "totalGb", label: "Storage (GB)", num: true, get: (r) => hwGb(r.totalStorageSpaceInBytes) },
  { key: "freeGb", label: "Free (GB)", num: true, get: (r) => (Number(r.totalStorageSpaceInBytes) > 0 ? hwGb(r.freeStorageSpaceInBytes) : "") },
  { key: "encrypted", label: "Encrypted", get: (r) => (typeof r.isEncrypted === "boolean" ? (r.isEncrypted ? "Yes" : "No") : "") },
  { key: "tpm", label: "TPM version", get: (r) => hwText(hwHardware(r).tpmSpecificationVersion) },
  { key: "tpmMaker", label: "TPM maker", get: (r) => hwText(hwHardware(r).tpmManufacturer) },
  { key: "bios", label: "BIOS version", get: (r) => hwText(hwHardware(r).systemManagementBIOSVersion) },
  { key: "battery", label: "Battery health (%)", num: true, get: (r) => hwNum(hwHardware(r).batteryHealthPercentage) },
  { key: "cycles", label: "Battery cycles", num: true, get: (r) => hwNum(hwHardware(r).batteryChargeCycles) },
  { key: "ip", label: "IP address", get: (r) => hwText(hwHardware(r).ipAddressV4 || (hwHardware(r).wiredIPv4Addresses || [])[0]) },
  { key: "wifiMac", label: "Wi-Fi MAC", get: (r) => hwText(r.wiFiMacAddress) },
  { key: "ethMac", label: "Ethernet MAC", get: (r) => hwText(r.ethernetMacAddress) },
  { key: "join", label: "Join type", get: (r) => hwWords(r.joinType) },
  { key: "enrolment", label: "Enrolment type", get: (r) => hwWords(r.deviceEnrollmentType) },
  { key: "owner", label: "Ownership", get: (r) => hwWords(r.managedDeviceOwnerType) },
  { key: "enrolled", label: "Enrolled", get: (r) => day(r.enrolledDateTime) },
  { key: "lastSync", label: "Last check-in", get: (r) => day(r.lastSyncDateTime) },
];

/** One managedDevice record as a flat row of the report's values (empty string where Graph gave none). */
export function hardwareRow(record) {
  const row = { id: record.id };
  for (const f of HARDWARE_FIELDS) row[f.key] = f.get(record);
  return row;
}

/** The columns at least one device has a value for, in report order. */
export function hardwareColumns(rows) {
  return HARDWARE_FIELDS.filter((f) => f.key === "name" || rows.some((r) => r[f.key] !== "" && r[f.key] !== undefined));
}

/**
 * Read the full record of each device, batched. A device Graph can't answer for (deleted since the list
 * was built, no permission) is counted, not guessed at.
 * @returns { rows, failed }
 */
export async function readHardware(graph, ids) {
  const answers = await graph.batch(ids.map((id) => ({ id, url: `/deviceManagement/managedDevices/${id}` })));
  const rows = [];
  let failed = 0;
  for (const id of ids) {
    const a = answers.get(String(id));
    if (a?.status === 200 && a.body) rows.push(hardwareRow(a.body));
    else failed++;
  }
  return { rows, failed };
}
