// Group tools for the workspace: group search, Group assignments (everything that references a group,
// with a retirement checklist) and Group roster (members joined with the device index).
// All reads; nothing here changes the tenant.

import { policiesForGroup, BROAD_TARGETS } from "./setting-search.js";
import { userDeviceSummary } from "./resolve.js";
import { isTransient, odataQuote, resolveIdsByName } from "./graph.js";

const EVENTUAL = { ConsistencyLevel: "eventual" };
const encodeQuery = encodeURIComponent;

/** { [lower-case group id]: displayName } for the ids that are existing groups. */
export async function groupNames(graph, ids) {
  const names = {};
  const unique = [...new Set(ids.map((id) => String(id).toLowerCase()))];
  for (const g of await graph.getByIds(unique, ["group"])) names[String(g.id).toLowerCase()] = g.displayName;
  return names;
}

/**
 * Graph's $search (contains-style) first, a $filter (startswith) when Graph refuses the $search query itself
 * (HTTP 400). Any other failure (no session, a denied role, throttling) is the answer, not a reason to ask again
 * another way. Both are queries on `path`.
 */
export async function searchOrFilter(graph, path, select, search, filter) {
  try {
    const res = await graph.get(`${path}?$search=${encodeQuery(search)}&${select}&$orderby=displayName`, EVENTUAL);
    return res?.value || [];
  } catch (e) {
    if (e?.code !== "HTTP" || e.status !== 400) throw e;
    const res = await graph.get(`${path}?$filter=${encodeQuery(filter)}&${select}`);
    return res?.value || [];
  }
}

/** Find groups by name: $search (contains-style) first, startswith as a fallback. */
export function searchGroups(graph, query) {
  const q = String(query || "").trim();
  if (!q) return [];
  return searchOrFilter(graph, "/v1.0/groups",
    "$select=id,displayName,description,groupTypes,membershipRule,securityEnabled,mailEnabled&$top=25",
    `"displayName:${q.replace(/"/g, "")}"`, `startswith(displayName,'${odataQuote(q)}')`);
}

const groupKind = (g) => {
  const dynamic = (g.groupTypes || []).includes("DynamicMembership");
  const m365 = (g.groupTypes || []).includes("Unified");
  return `${m365 ? "Microsoft 365" : g.securityEnabled ? "Security" : "Distribution"} group, ${dynamic ? "dynamic" : "assigned"} membership`;
};

/** Run a read and turn a permission failure into an "unknown" answer instead of an error. */
async function attempt(fn) {
  try {
    return { ok: true, value: await fn() };
  } catch (e) {
    return { ok: false, error: e?.message || String(e), denied: e?.code === "FORBIDDEN" };
  }
}

async function count(graph, path) {
  const res = await graph.get(path, EVENTUAL);
  return typeof res === "number" ? res : Number(res) || 0;
}

/**
 * Everything that references a group, plus a retirement checklist.
 * @param policyIndex the built policy index (see policy-index.js)
 */
export function broadImpact(policyIndex, targetId) {
  const intune = policiesForGroup(policyIndex, targetId);
  return {
    target: { id: targetId, name: BROAD_TARGETS[targetId].name },
    intune,
    policyErrors: Object.keys(policyIndex?.errors || {}).filter((k) => !k.includes(":") || k.endsWith(":assignments")),
    policyIndexBuiltAt: policyIndex?.builtAt || 0,
  };
}

export async function groupImpact(graph, policyIndex, groupId) {
  const id = encodeQuery(groupId);
  const fields = "id,displayName,description,groupTypes,membershipRule,securityEnabled,mailEnabled,assignedLicenses,onPremisesSyncEnabled,createdDateTime";
  const group = await graph.get(`/v1.0/groups/${id}?$select=${fields}`);

  const [devices, users, parents, children, owners, appRoles, ca, roles, skus] = await Promise.all([
    attempt(() => count(graph, `/v1.0/groups/${id}/transitiveMembers/microsoft.graph.device/$count`)),
    attempt(() => count(graph, `/v1.0/groups/${id}/transitiveMembers/microsoft.graph.user/$count`)),
    attempt(() => graph.all(`/v1.0/groups/${id}/memberOf/microsoft.graph.group?$select=id,displayName`)),
    attempt(() => graph.all(`/v1.0/groups/${id}/members/microsoft.graph.group?$select=id,displayName`)),
    attempt(() => graph.all(`/v1.0/groups/${id}/owners?$select=id,displayName,userPrincipalName`)),
    attempt(() => graph.all(`/v1.0/groups/${id}/appRoleAssignments?$select=id,resourceDisplayName,resourceId`)),
    attempt(() => graph.all("/v1.0/identity/conditionalAccess/policies?$select=id,displayName,state,conditions")),
    attempt(() => graph.all("/beta/deviceManagement/roleAssignments?$select=id,displayName,members,resourceScopes,scopeMembers")),
    group.assignedLicenses?.length ? attempt(() => graph.all("/v1.0/subscribedSkus?$select=skuId,skuPartNumber")) : Promise.resolve({ ok: true, value: [] }),
  ]);

  const gid = String(groupId).toLowerCase();
  const has = (arr) => (arr || []).some((x) => String(x).toLowerCase() === gid);

  const intune = policiesForGroup(policyIndex, groupId);
  const caHits = ca.ok ? ca.value.filter((p) => has(p.conditions?.users?.includeGroups) || has(p.conditions?.users?.excludeGroups))
    .map((p) => ({ id: p.id, name: p.displayName, state: p.state, mode: has(p.conditions?.users?.excludeGroups) ? "exclude" : "include" })) : [];
  const roleHits = roles.ok ? roles.value.filter((r) => has(r.members) || has(r.resourceScopes) || has(r.scopeMembers))
    .map((r) => ({ id: r.id, name: r.displayName, as: has(r.members) ? "members" : "scope" })) : [];
  const skuName = new Map((skus.ok ? skus.value : []).map((s) => [String(s.skuId).toLowerCase(), s.skuPartNumber]));
  const licenses = (group.assignedLicenses || []).map((l) => skuName.get(String(l.skuId).toLowerCase()) || l.skuId);

  const check = (label, n, r, detail = "") => ({
    label,
    count: r && !r.ok ? null : n,
    status: r && !r.ok ? "unknown" : n > 0 ? "in-use" : "clear",
    detail: r && !r.ok ? `Couldn't check${r.denied ? " (your role or session doesn't have access)" : ""}: ${r.error}` : detail,
  });

  // Types it couldn't read, and types whose assignments it couldn't read: either may hide a use of the group.
  const policyErrors = Object.keys(policyIndex?.errors || {}).filter((k) => !k.includes(":") || k.endsWith(":assignments"));
  const includes = intune.filter((i) => i.kind !== "exclude").length;
  const checklist = [
    { ...check("Intune assignments", intune.length, null, `${includes} include, ${intune.length - includes} exclude`),
      // A type that couldn't be read leaves the answer unknown, unless something already uses the group.
      ...(policyErrors.length
        ? { status: intune.length ? "in-use" : "unknown", detail: `Some policy types couldn't be read: ${policyErrors.join(", ")}` }
        : {}) },
    check("Conditional Access policies", caHits.length, ca),
    check("Enterprise app assignments", appRoles.ok ? appRoles.value.length : 0, appRoles),
    check("Group-based licences", licenses.length, null, licenses.join(", ")),
    check("Intune role assignments", roleHits.length, roles),
    check("Member of other groups", parents.ok ? parents.value.length : 0, parents, "Removing this group changes the membership of these parent groups"),
    check("Contains other groups", children.ok ? children.value.length : 0, children),
  ];
  const verdict = checklist.some((c) => c.status === "in-use") ? "in-use"
    : checklist.some((c) => c.status === "unknown") ? "unknown" : "clear";

  return {
    group: {
      id: group.id, name: group.displayName, description: group.description || "", kind: groupKind(group),
      rule: group.membershipRule || "", synced: Boolean(group.onPremisesSyncEnabled), created: group.createdDateTime || "",
    },
    members: { devices: devices.ok ? devices.value : null, users: users.ok ? users.value : null },
    owners: owners.ok ? owners.value.map((o) => o.displayName || o.userPrincipalName) : null,
    intune,
    conditionalAccess: caHits,
    appAssignments: appRoles.ok ? appRoles.value.map((a) => a.resourceDisplayName) : [],
    licenses,
    roleAssignments: roleHits,
    parents: parents.ok ? parents.value : [],
    children: children.ok ? children.value : [],
    checklist,
    verdict,
    policyIndexBuiltAt: policyIndex?.builtAt || 0,
  };
}

/**
 * Member counts (including nested) for groups named in portal lists, for the group size hints.
 * items: [{ key, id?, name? }]. Groups known only by name are resolved by exact display name.
 * Returns { [key]: { id, devices, users, groups } | { notFound: true } | { ambiguous: n } | { retry: true } }
 * (retry: Graph was busy, so don't remember it).
 */
export async function groupSizes(graph, items) {
  const out = await resolveIdsByName(graph, items, (name) =>
    `/groups?$filter=${encodeQuery(`displayName eq '${odataQuote(name)}'`)}&$select=id,displayName&$top=5`);
  const withId = items.filter((i) => i.id && !out[i.key]);
  if (withId.length) {
    const kinds = ["device", "user", "group"];
    const res = await graph.batch(withId.flatMap((i, n) => kinds.map((k) => ({
      id: `${n}:${k}`,
      url: `/groups/${encodeQuery(i.id)}/transitiveMembers/microsoft.graph.${k}/$count`,
      headers: EVENTUAL,
    }))));
    withId.forEach((i, n) => {
      if (kinds.some((k) => isTransient(res.get(`${n}:${k}`)))) { out[i.key] = { retry: true }; return; }
      const count = (k) => {
        const r = res.get(`${n}:${k}`);
        return r?.status === 200 ? Number(r.body) || 0 : null;
      };
      out[i.key] = { id: i.id, devices: count("device"), users: count("user"), groups: count("group") };
    });
  }
  return out;
}

/** Assignment filters with their rules, for the filter rule hints. */
export async function listFilters(graph) {
  const items = await graph.all("/beta/deviceManagement/assignmentFilters?$select=id,displayName,rule,platform");
  return items.map((f) => ({ id: f.id, name: f.displayName || "", rule: f.rule || "", platform: f.platform || "" }));
}

/**
 * Group roster: every member (transitive), with devices joined to the device index for primary
 * user, compliance, OS and last check-in, and users joined to the devices they're the primary
 * user of (worst compliance, latest device's OS, most recent check-in).
 * @param lookup (refs) => Promise<results>, from the device index
 * @param devicesByUpn (upns) => Promise<{ [upn]: devices[] }>, from the device index
 */
export async function groupRoster(graph, lookup, groupId, devicesByUpn) {
  const id = encodeQuery(groupId);
  const group = await graph.get(`/v1.0/groups/${id}?$select=id,displayName`);
  const fields = "id,displayName,deviceId,userPrincipalName,mail,accountEnabled,operatingSystem,operatingSystemVersion,jobTitle,department";
  const members = await graph.all(`/v1.0/groups/${id}/transitiveMembers?$select=${fields}&$top=999`);
  const devices = members.filter((m) => String(m["@odata.type"]).endsWith("device"));
  const results = devices.length ? await lookup(devices.map((d) => ({ deviceId: d.deviceId, name: d.displayName }))) : [];
  const byObject = new Map(devices.map((d, i) => [d.id, results[i]]));
  const users = members.filter((m) => String(m["@odata.type"]).endsWith("user") && m.userPrincipalName);
  const userDevices = users.length ? await devicesByUpn(users.map((u) => u.userPrincipalName)) : {};

  const rows = members.map((m) => {
    const type = String(m["@odata.type"] || "").replace("#microsoft.graph.", "");
    if (type === "device") {
      const r = byObject.get(m.id);
      const d = r?.devices?.[0];
      return {
        type: "Device", name: m.displayName || "", objectId: m.id,
        primaryUser: d ? (d.displayName || d.upn || "") : "", upn: d?.upn || "",
        compliance: d?.compliance || "",
        os: (d ? [d.os, d.osVersion] : [m.operatingSystem, m.operatingSystemVersion]).filter(Boolean).join(" "),
        osVersion: d?.osVersion || m.operatingSystemVersion || "",
        lastCheckIn: d?.lastSync || "", managedId: d?.managedId || "",
        intune: r ? r.status !== "notFound" : false,
        duplicates: r?.devices?.length > 1 ? r.devices.length : 0,
      };
    }
    if (type === "user") {
      return {
        type: "User", name: m.displayName || "", objectId: m.id, upn: m.userPrincipalName || "",
        enabled: m.accountEnabled !== false, department: m.department || "", jobTitle: m.jobTitle || "",
        ...userDeviceSummary(userDevices[m.userPrincipalName] || []) };
    }
    return { type: type === "group" ? "Group" : type, name: m.displayName || "", objectId: m.id };
  });

  return { group: { id: group.id, name: group.displayName }, rows };
}

/** The Intune devices in a group, nested groups included, for the workspace's scope: { group, managedIds, members }.
 *  lookup(refs) resolves Entra device ids to Intune devices (the device index). */
export async function groupDeviceIds(graph, lookup, groupId) {
  const id = encodeQuery(groupId);
  const group = await graph.get(`/v1.0/groups/${id}?$select=id,displayName`);
  const members = await graph.all(`/v1.0/groups/${id}/transitiveMembers?$select=id,deviceId,displayName&$top=999`);
  const devices = members.filter((m) => String(m["@odata.type"]).endsWith("device") && m.deviceId);
  const results = devices.length ? await lookup(devices.map((d) => ({ deviceId: d.deviceId, name: d.displayName }))) : [];
  const managedIds = [...new Set(results.flatMap((r) => (r?.devices || []).map((d) => d.managedId)).filter(Boolean))];
  return { group: { id: group.id, name: group.displayName || "" }, managedIds, members: devices.length };
}

/** Find users by name or sign-in name: $search first, startswith as a fallback. */
export function searchUsers(graph, query) {
  const q = String(query || "").trim().replace(/"/g, "");
  if (!q) return [];
  const quoted = odataQuote(q);
  return searchOrFilter(graph, "/v1.0/users", "$select=id,displayName,userPrincipalName&$top=25",
    `"displayName:${q}" OR "userPrincipalName:${q}"`, `startswith(displayName,'${quoted}') or startswith(userPrincipalName,'${quoted}')`);
}

/**
 * Two members' group maps (Map of lower-case id -> { id, name, direct, via }, as memberGroups returns)
 * split into the groups both are in, and the ones only one is in. A null map means it couldn't be read.
 */
export function compareGroups(a, b) {
  if (!a || !b) return { both: [], onlyA: [], onlyB: [], unreadable: true };
  const byName = (x, y) => x.name.localeCompare(y.name);
  const both = [];
  const onlyA = [];
  for (const [id, g] of a) {
    if (b.has(id)) both.push({ ...g, other: b.get(id) });
    else onlyA.push(g);
  }
  const onlyB = [...b].filter(([id]) => !a.has(id)).map(([, g]) => g);
  return { both: both.sort(byName), onlyA: onlyA.sort(byName), onlyB: onlyB.sort(byName), unreadable: false };
}
