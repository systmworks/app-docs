// The All Reports tab's list logic: the quick-filter chips and the search. Pure, so the offline tests run it.
// The search box is the one place that filters on every keypress (owner's decision), but only from MIN_SEARCH_LENGTH letters.

export const REPORT_CONFIG = {
  minSearchLength: 3, // letters before the search filters; fewer shows the whole list
  starredChip: "Starred", // the chip after "All" that shows only the reports starred in the list
  chips: ["Apps", "Compliance", "Configuration", "Security", "Updates"], // the quick filters after "Starred", A to Z; areas from data/reports.js
};

/** A report row as an object. */
export const catalogReport = ([name, area, type, platform, description, path]) => ({ name, area, type, platform, description, path });

/** The list order: by category (area) A to Z, then by report name A to Z within each. Returns a new array. */
export function sortReports(rows) {
  const az = (x, y) => x.localeCompare(y, undefined, { sensitivity: "base", numeric: true });
  return [...rows].sort((a, b) => az(a.area, b.area) || az(a.name, b.name));
}

/**
 * The reports to show. chip is "" or "All" for no area filter, "Starred" for the names in `starred` (a Set), else an
 * area; query shorter than minSearchLength is ignored. Every word of the query must appear in the name, description,
 * area or platform (case-insensitive).
 */
export function filterReports(rows, chip = "", query = "", { minLength = REPORT_CONFIG.minSearchLength, starred = new Set() } = {}) {
  const text = String(query).trim().toLowerCase();
  const words = text.length >= minLength ? text.split(/\s+/) : [];
  return rows.filter((r) => {
    if (chip === REPORT_CONFIG.starredChip) { if (!starred.has(r.name)) return false; }
    else if (chip && chip !== "All" && r.area !== chip) return false;
    if (!words.length) return true;
    const hay = `${r.name} ${r.description} ${r.area} ${r.platform}`.toLowerCase();
    return words.every((w) => hay.includes(w));
  });
}
