// Friendly names for custom (OMA-URI) settings: a raw CSP path to the name Intune shows, a short description and the Windows
// version that introduced it. The data (data/csp-names.js, built by tools/build-csp-names.py) is large, so only the
// workspace page loads it, on first use. Pure; the data is passed in.

/** The key both sides use: lower case, no leading ./, no device or user scope, no vendor/msft. */
export function cspNameKey(path) {
  return String(path ?? "").trim().toLowerCase().replace(/^\.\//, "").replace(/^(device|user)\//, "").replace(/^vendor\/msft\//, "");
}

// Windows build numbers to the release a person knows them by.
const CSPN_RELEASES = [
  [10240, "Windows 10 1507"], [10586, "Windows 10 1511"], [14393, "Windows 10 1607"], [15063, "Windows 10 1703"], [16299, "Windows 10 1709"],
  [17134, "Windows 10 1803"], [17763, "Windows 10 1809"], [18362, "Windows 10 1903"], [18363, "Windows 10 1909"], [19041, "Windows 10 2004"],
  [19042, "Windows 10 20H2"], [19043, "Windows 10 21H1"], [19044, "Windows 10 21H2"], [22000, "Windows 11 21H2"], [22621, "Windows 11 22H2"],
  [22631, "Windows 11 23H2"], [26100, "Windows 11 24H2"],
];

/** "Windows 10 1607 or later" from a first build number, or "" when unknown. Pure. */
export function firstWindows(build) {
  const n = Number(build) || 0;
  if (!n) return "";
  const hit = [...CSPN_RELEASES].reverse().find(([b]) => n >= b);
  return hit ? `${hit[1]} or later` : "";
}

/** Rows ([key, name, description, build]) as a look-up. */
export function buildCspNameIndex(rows) {
  const byKey = new Map();
  for (const [key, name, desc, build] of rows) byKey.set(key, { name, desc, build });
  return { byKey, rows };
}

/** What is known about one path: { name, desc, since } or null. Pure. */
export function describeCsp(path, index) {
  const hit = index?.byKey.get(cspNameKey(path));
  return hit ? { name: hit.name, desc: hit.desc, since: firstWindows(hit.build) } : null;
}

/**
 * Paths whose name or description holds every word of a query, as keys for the Setting check search: a custom profile that
 * sets "AllowRealtimeMonitoring" is found by "real-time protection". At most `limit` keys.
 */
export function searchCspNames(words, index, limit = 300) {
  const ws = (words || []).map((w) => String(w).toLowerCase()).filter(Boolean);
  if (!ws.length || !index) return [];
  const out = [];
  for (const [key, name, desc] of index.rows) {
    const text = `${name} ${desc} ${key}`.toLowerCase();
    if (ws.every((w) => text.includes(w))) { out.push(key); if (out.length >= limit) break; }
  }
  return out;
}
