// Table text for spreadsheets: Save CSV and Copy table. Pure, so tests/test.html checks it.

/**
 * One cell, safe to open in a spreadsheet: a value starting with =, +, -, @, a tab or a carriage return gets a
 * leading ' so Excel and others show it as text instead of running it as a formula (a device or policy name is
 * whatever the tenant's admins typed).
 */
export function sheetCell(value) {
  const s = String(value ?? "");
  return /^[=+\-@\t\r]/.test(s) ? `'${s}` : s;
}

/** Rows as CSV: every cell quoted, quotes doubled, line breaks inside a cell kept (quoted CSV allows them). */
export const csvText = (rows) => rows.map((row) => row.map((c) => `"${sheetCell(c).replace(/"/g, '""')}"`).join(",")).join("\r\n");

/** Rows as tab-separated text for the clipboard: tabs and line breaks inside a cell become spaces. */
export const tsvText = (rows) => rows.map((row) => row.map((c) => sheetCell(String(c ?? "").replace(/[\t\r\n]+/g, " "))).join("\t")).join("\n");
