// Per-tenant index of Intune managed devices and their primary users, kept in the worker's
// IndexedDB (store.js) so lists label instantly. Built with one paged Graph query (about 1,000
// devices per page), so labelling a list never costs a Graph call per row.
//
// managedDevice.userPrincipalName / userDisplayName are the device's primary user as Intune
// shows it in its own "Primary user" column; empty means a shared or userless device.

import { ROW, buildMaps, resolveRef, norm, devicesForUpn, toDevice, latestLogon } from "./resolve.js";
import { getItem, setItem, removePrefix } from "./store.js";
import { stoppedError } from "./graph.js";
import { cleanGuid } from "../shared/guid.js";

const STALE_MS = 4 * 60 * 60 * 1000; // rebuild quietly in the background after this
const KEY_PREFIX = "ie.index.";
const OBJECT_MAP_PREFIX = "ie.objmap.";
// In chrome.storage.local: when the list was last rebuilt, so content scripts refresh their labels
// (they're sent this small value, never the list itself).
const INDEX_STAMP = "ie.indexStamp"; // the content scripts watch this key to learn the list was rebuilt
const SELECT = "id,deviceName,azureADDeviceId,userPrincipalName,userDisplayName,operatingSystem,lastSyncDateTime,osVersion,complianceState,enrolledDateTime,managedDeviceOwnerType,model,freeStorageSpaceInBytes,totalStorageSpaceInBytes,userId,serialNumber";
// Bump when ROW gains fields, so an index stored by an older version is rebuilt.
const SCHEMA = 6; // 3: last logged-on user, 4: storage, 5: primary user id, 6: serial number

export function createDeviceIndex(graph, { onProgress = () => {}, store = { getItem, setItem, removePrefix } } = {}) {
  let tid = null;
  let index = null; // { builtAt, rows }
  let maps = null;
  let objectToDevice = new Map();
  let loading = null;
  let building = null;
  let cancelled = false; // set by cancel(), checked as each page arrives
  let lastError = "";

  async function load(forTid) {
    if (tid === forTid && index) return;
    tid = forTid;
    index = null;
    maps = null;
    const [saved, objectMap] = await Promise.all([store.getItem(KEY_PREFIX + tid), store.getItem(OBJECT_MAP_PREFIX + tid)]);
    if (saved?.rows && saved.schema === SCHEMA) {
      index = saved;
      maps = buildMaps(index.rows);
    }
    objectToDevice = new Map(objectMap || []);
  }

  async function build() {
    if (building) return building;
    const forTid = tid;
    cancelled = false;
    building = (async () => {
      const rows = [];
      const logons = []; // per row: latest { userId, at } from usersLoggedOn
      onProgress({ building: true, count: 0 });
      const onPage = (items) => {
        if (cancelled) throw stoppedError();
        for (const d of items) {
          logons.push(latestLogon(d.usersLoggedOn));
          const row = [];
          row[ROW.id] = d.id;
          row[ROW.name] = d.deviceName || "";
          row[ROW.aadId] = cleanGuid(d.azureADDeviceId);
          row[ROW.upn] = d.userPrincipalName || "";
          row[ROW.displayName] = d.userDisplayName || "";
          row[ROW.os] = d.operatingSystem || "";
          row[ROW.lastSync] = d.lastSyncDateTime || "";
          row[ROW.osVersion] = d.osVersion || "";
          row[ROW.compliance] = d.complianceState || "";
          row[ROW.enrolled] = d.enrolledDateTime || "";
          row[ROW.owner] = d.managedDeviceOwnerType || "";
          row[ROW.model] = d.model || "";
          row[ROW.freeBytes] = Number(d.freeStorageSpaceInBytes) || 0;
          row[ROW.totalBytes] = Number(d.totalStorageSpaceInBytes) || 0;
          row[ROW.serial] = d.serialNumber || "";
          row[ROW.userId] = cleanGuid(d.userId);
          rows.push(row);
        }
        onProgress({ building: true, count: rows.length });
      };
      // usersLoggedOn is beta-only; if beta refuses the query, read the rest from v1.0 without it.
      try {
        await graph.pages(`/beta/deviceManagement/managedDevices?$select=${SELECT},usersLoggedOn&$top=999`, onPage);
      } catch (e) {
        if (e?.code !== "HTTP" || e.status !== 400) throw e;
        rows.length = 0;
        logons.length = 0;
        await graph.pages(`/v1.0/deviceManagement/managedDevices?$select=${SELECT}&$top=999`, onPage);
      }
      await addLastUsers(rows, logons);
      if (forTid !== tid) return; // tenant switched mid-build; discard
      index = { schema: SCHEMA, builtAt: Date.now(), rows };
      maps = buildMaps(rows);
      lastError = "";
      await store.setItem(KEY_PREFIX + tid, index);
      await chrome.storage.local.set({ [INDEX_STAMP]: index.builtAt });
    })().catch((e) => {
      if (e?.code !== "CANCELLED") lastError = e?.message || String(e);
      throw e;
    }).finally(() => {
      building = null;
      onProgress({ building: false, count: index?.rows.length || 0 });
    });
    return building;
  }

  /** Name each device's last logged-on user (usersLoggedOn only carries user ids), in bulk. */
  async function addLastUsers(rows, logons) {
    const ids = [...new Set(logons.filter(Boolean).map((l) => norm(l.userId)))];
    const users = new Map();
    try {
      for (const u of await graph.getByIds(ids, ["user"])) users.set(norm(u.id), u);
    } catch { /* no user names: the last logged-on user is left out */ }
    rows.forEach((row, i) => {
      const u = logons[i] && users.get(norm(logons[i].userId));
      if (!u) return;
      row[ROW.lastUser] = u.userPrincipalName || "";
      row[ROW.lastUserName] = u.displayName || "";
      row[ROW.lastLogOn] = logons[i].at;
    });
  }

  /** Map Entra object ids (from Entra-style lists) to Entra device ids, in bulk. */
  async function resolveObjectIds(objectIds) {
    const missing = [...new Set(objectIds.map(norm))].filter((id) => id && !objectToDevice.has(id));
    if (!missing.length) return;
    for (const obj of await graph.getByIds(missing, ["device"])) {
      if (obj.id && obj.deviceId) objectToDevice.set(norm(obj.id), norm(obj.deviceId));
    }
    // Anything not returned isn't a device (a user or group row); remember that too.
    for (const id of missing) if (!objectToDevice.has(id)) objectToDevice.set(id, "");
    await store.setItem(OBJECT_MAP_PREFIX + tid, [...objectToDevice.entries()]);
  }

  /** Load this tenant's index, building it if there isn't one; refresh quietly when stale. */
  async function ensure(forTid) {
    if (!loading || tid !== forTid) {
      // A failed read (IndexedDB refused) is not kept, so the next request tries again.
      const attempt = load(forTid).catch((e) => { if (loading === attempt) loading = null; throw e; });
      loading = attempt;
    }
    await loading;
    if (!index) {
      await build();
      // A build already running was for the tenant we just left and drops its result; build for this one.
      if (!index) await build();
    } else if (Date.now() - index.builtAt > STALE_MS) build().catch(() => {});
  }

  return {
    load,
    build,

    /** Stop a build in progress; it throws and saves nothing. */
    cancel() { if (building) cancelled = true; },

    /** Every managed device, for the workspace device reports. */
    async all(forTid) {
      await ensure(forTid);
      return { devices: index.rows.map(toDevice), builtAt: index.builtAt };
    },

    /** One device by its Intune id, or null. Reads one row, not the whole list. */
    async byManagedId(forTid, id) {
      await ensure(forTid);
      const row = maps.byId.get(norm(id));
      return row ? toDevice(row) : null;
    },

    /** The first `limit` devices (by name) whose name, primary user or user name contains `query` (any case). */
    async search(forTid, query, limit) {
      await ensure(forTid);
      const q = norm(query);
      if (!q) return [];
      const hits = index.rows.filter((row) => [ROW.name, ROW.upn, ROW.displayName].some((i) => norm(row[i]).includes(q)));
      hits.sort((a, b) => String(a[ROW.name]).localeCompare(String(b[ROW.name])));
      return hits.slice(0, limit).map(toDevice);
    },

    /** Devices each user (by UPN) is the primary user of: { [upn]: devices[] }. */
    async byUpns(forTid, upns) {
      await ensure(forTid);
      return Object.fromEntries(upns.map((u) => [u, devicesForUpn(maps, u)]));
    },

    async lookup(forTid, refs) {
      await ensure(forTid);
      const objectIds = refs.filter((r) => r.objectId && !r.deviceId && !r.managedId).map((r) => r.objectId);
      if (objectIds.length) {
        try { await resolveObjectIds(objectIds); } catch { /* fall back to name matching */ }
      }
      return refs.map((ref) => resolveRef(ref, maps, objectToDevice));
    },

    status() {
      return {
        tid,
        count: index?.rows.length || 0,
        builtAt: index?.builtAt || 0,
        building: Boolean(building),
        error: lastError,
      };
    },

    async clearAll() {
      await Promise.all([store.removePrefix(KEY_PREFIX), store.removePrefix(OBJECT_MAP_PREFIX)]);
      index = null;
      maps = null;
      objectToDevice = new Map();
      tid = null;
      loading = null;
    },
  };
}
